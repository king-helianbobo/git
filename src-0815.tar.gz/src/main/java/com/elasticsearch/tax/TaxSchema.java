package com.elasticsearch.tax;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.map.ObjectMapper;

import com.elasticsearch.query.SoulQueryUtil;
import com.splitword.lionsoul.jcseg.util.ChineseHelper;

public class TaxSchema {
	private static final Log log = LogFactory.getLog(TaxSchema.class);

	private static ObjectMapper mapper = new ObjectMapper();
	public final static String tableName = "tableName";
	public final static String fieldName = "fieldName";
	public final static String chineseFieldName = "chineseFieldName";
	public final static String chineseTableName = "chineseTableName";

	private static Map<String, Object> tableMap2(List<String> otherTokens,
			List<String> otherFields) {
		List<Map<String, Object>> array = new ArrayList<Map<String, Object>>();
		for (String token : otherTokens) {
			for (String field : otherFields) {
				Map<String, Object> tmpMap = TaxQueryFields.eachToken(field,
						token);
				if (tmpMap != null)
					array.add(tmpMap);
			}
		}
		Map<String, Object> map = SoulQueryUtil.createBooleanQueryMap(array, 1);
		return map;
	}

	private static List<Map<String, Object>> tableMapList(List<String> entitys,
			List<String> realFields, List<String> otherTokens,
			List<String> otherFields) {
		List<Map<String, Object>> array = new ArrayList<Map<String, Object>>();
		for (String entity : entitys) {
			List<Map<String, Object>> array1 = new ArrayList<Map<String, Object>>();
			for (String realField : realFields) {
				Map<String, Object> tmpMap = TaxQueryFields.eachToken(
						realField, entity);
				if (tmpMap != null)
					array1.add(tmpMap);
			}
			Map<String, Object> map1 = SoulQueryUtil.createBooleanQueryMap(
					array1, 1);
			Map<String, Object> map2 = tableMap2(otherTokens, otherFields);
			List<Map<String, Object>> array3 = new ArrayList<Map<String, Object>>();
			if (map1 != null)
				array3.add(map1);
			if (map2 != null)
				array3.add(map2);
			Map<String, Object> map3 = SoulQueryUtil.createBooleanQueryMap(
					array3, 2);
			if (map3 != null)
				array.add(map3);
		}
		return array;
	}

	public static Map<String, Object> entityMap1(List<String> otherFields,
			List<String> entitys, List<String> otherTokens) {
		Set<String> tables = new HashSet<String>();
		for (String field : otherFields) {
			String[] strs = field.split("[.]");
			String tableName = strs[0];
			tables.add(tableName);
		}
		Map<String, List<String>> fieldsMap = TaxFinalVal.fieldsMap();
		List<Map<String, Object>> array = new ArrayList<Map<String, Object>>();

		for (String tableName : tables) {
			List<String> realFields = TaxQueryFields.realFieldList(tableName,
					fieldsMap);
			log.info(entitys + "," + tableName + "," + otherTokens);
			List<Map<String, Object>> array1 = tableMapList(entitys,
					realFields, otherTokens, otherFields);
			array.addAll(array1);
		}
		return SoulQueryUtil.createBooleanQueryMap(array, 1);
	}

	public static Map<String, Object> entityMap(Set<String> tables,
			List<String> companys) {
		List<Map<String, Object>> arrayMap = new ArrayList<Map<String, Object>>();
		Map<String, List<String>> fieldsMap = TaxFinalVal.fieldsMap();
		for (String tableName : tables) { // for each table
			List<String> realFields = TaxQueryFields.realFieldList(tableName,
					fieldsMap);
			for (String company : companys) {
				for (String realField : realFields) {
					Map<String, Object> tmpMap = TaxQueryFields.eachToken(
							realField, company);
					if (tmpMap != null)
						arrayMap.add(tmpMap);
				}
			}
		}
		if (arrayMap.size() == 0)
			return null;
		else if (arrayMap.size() == 1)
			return arrayMap.get(0);
		else {
			Map<String, Object> lastMap = SoulQueryUtil.createBooleanQueryMap(
					arrayMap, 1, "all");
			return lastMap;
		}
	}

	public static Map<String, List<String>> greenFields(
			Map<String, List<String>> schemaMap, List<String> tokenList) {
		Map<String, List<String>> resultMap = new HashMap<String, List<String>>();
		// List<String> greenList = new LinkedList<String>();
		List<String> tableList = new LinkedList<String>();
		List<String> fieldList = new LinkedList<String>();
		List<String> realTokens = new LinkedList<String>();
		for (String str : tokenList) {
			if (schemaMap.containsKey(str)) {
				List<String> list = schemaMap.get(str);
				for (String field : list) {
					String[] strs = field.split("[.]");
					String tableName = strs[0];
					if (field.endsWith(".all")) {
						if (!tableList.contains(tableName))
							tableList.add(tableName);
					} else {
						fieldList.add(field);
						// greenList.add(field);
					}
				}
			} else
				realTokens.add(str);
		}
		List<String> list2 = new LinkedList<String>();
		for (String str : fieldList) {
			String[] strs = str.split("[.]");
			String tableName = strs[0];
			if (!tableList.contains(tableName))
				list2.add(str);
		}
		if (list2.size() > 0)
			resultMap.put("otherFields", list2);
		if (tableList.size() > 0)
			resultMap.put("tableList", tableList);
		if (realTokens.size() > 0)
			resultMap.put("realTokens", realTokens);
		return resultMap;
	}

	public static Map<String, Object> schemaQueryMap(String originalToken) {
		List<String> list = new LinkedList<String>();
		list.add(originalToken);
		List<Map<String, Object>> array1 = new ArrayList<Map<String, Object>>();
		for (String token : list) {
			Map<String, Object> map2 = SoulQueryUtil.termQueryMap(fieldName,
					token);
			array1.add(map2);
			if (ChineseHelper.allChineseChar(token)) {
				Map<String, Object> map1 = SoulQueryUtil.termQueryMap(
						chineseTableName, token);
				Map<String, Object> map3 = SoulQueryUtil.termQueryMap(
						chineseFieldName, token);
				array1.add(map1);
				array1.add(map3);
			}
		}
		Map<String, Object> queryMap = SoulQueryUtil.createBooleanQueryMap(
				array1, 1, "all");
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("query", queryMap);
		result.put("from", 0);
		result.put("size", 100);
		result.put("highlight", SoulQueryUtil.createHighLigthQuery(
				chineseFieldName, chineseTableName, fieldName));
		return result;
	}

	@SuppressWarnings("unchecked")
	public static List<String> analyzeHitsMap(Map<String, Object> map) {
		List<String> list = new LinkedList<String>();
		try {
			List<Map<String, Object>> hits = (List<Map<String, Object>>) map
					.get("hits");
			if (hits != null && hits.size() > 0) {
				for (int i = 0; i < hits.size(); i++) {
					Map<String, Object> map1 = hits.get(i);
					String tempResult = mapper.writeValueAsString(map1);
					// log.info(tempResult);
					Map<String, Object> lightMap = (Map<String, Object>) map1
							.get("highlight");
					Map<String, Object> sourceMap = (Map<String, Object>) map1
							.get("_source");
					String type = (String) map1.get("_id");
					if (type.startsWith("B"))
						continue;
					final String fieldNameText = (String) sourceMap
							.get(fieldName);
					final String[] fields = fieldNameText.split("\t");
					if (lightMap != null) {
						for (String highField : lightMap.keySet()) {
							List<String> highTextList = (List<String>) lightMap
									.get(highField);
							String highText = highTextList.get(0);
							String[] highs = highText.split("\t");
							for (int j = 0; j < highs.length; j++) {
								String high = highs[j];
								int idx1 = high.indexOf(SoulQueryUtil.preTag);
								int idx2 = high.indexOf(SoulQueryUtil.postTag);
								if (idx1 >= 0 && idx2 >= 0) {
									if (highField
											.equalsIgnoreCase(chineseFieldName))
										list.add(type + "." + fields[j]);
									else if (highField
											.equalsIgnoreCase(chineseTableName))
										list.add(type + ".all");
									else if (highField
											.equalsIgnoreCase(fieldName)) {
										list.add(type + "." + fields[j]);
									}
								}
							}
						}
					}
				}
				if (!list.isEmpty())
					return list;
				else
					return null;
			} else
				return null;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}
}
