package com.elasticsearch.tax;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.JsonParseException;
import org.junit.Assert;

import com.splitword.lionsoul.jcseg.util.ChineseHelper;
import com.splitword.soul.utility.StringUtil;

public class TaxFinalVal {
	private static final Log log = LogFactory.getLog(TaxFinalVal.class);
	public static final String indexOne = "tax_a";
	public static final String indexTwo = "tax_b";
	public static final String schemaIndex = "tax_schema";
	public static final String cacheIndex = "tax_cache";
	public static final String addedField = "NSR_MC_added";
	public static final String addedFieldChinese = "机构纳税人名称";

	public static final String shouldPaid = "A10.YINGNSE_JE";
	public static final String realPaid = "A10.YIJSE_JE";
	public static final String shouldDate = "A04.JK_QX";
	public static final String realDate = "A04.YZFS_RQ";

	private static Map<String, List<String>> fieldsMap = null;
	private static Map<String, List<String>> indexTypeMap = null;
	private static Map<String, Map<String, Object>> defMap = null;
	private static Map<String, String> tableMap = null;
	private static Map<String, List<String>> companyMap = null;
	private static Map<String, String> respectMap = null;
	private static Map<String, List<String>> personMap = null;
	private static boolean companyLoaded = false;
	private static boolean tableLoaded = false;
	private static boolean fieldLoaded = false;
	private static final Lock lockLock = new ReentrantLock();

	public static Map<String, List<String>> companyMap() {
		loadCompany();
		return companyMap;
	}

	public static Map<String, String> respectMap() {
		loadCompany();
		return respectMap;
	}

	public static Map<String, List<String>> personMap() {
		loadCompany();
		return personMap;
	}

	public static Map<String, Map<String, Object>> defMap() {
		loadTable();
		return defMap;
	}

	public static Map<String, String> tableMap() {
		loadTable();
		return tableMap;
	}

	public static Map<String, List<String>> indexTypeMap() {
		createFieldsMap();
		return indexTypeMap;
	}

	public static Map<String, List<String>> fieldsMap() {
		createFieldsMap();
		return fieldsMap;
	}

	private static void loadCompany() {
		if (companyLoaded)
			return;
		lockLock.lock();
		if (companyLoaded) {
			lockLock.unlock();
			return;
		}
		try {
			companyMap = loadCompanyMap("liuboOutput/company.txt");
			personMap = loadPersonMap("liuboOutput/person.txt");
			respectMap = loadRespectMap("liuboOutput/respect.txt");
			companyLoaded = true;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			lockLock.unlock();
		}
	}

	private static void loadTable() {
		if (tableLoaded)
			return;
		lockLock.lock();
		if (tableLoaded) {
			lockLock.unlock();
			return;
		}
		try {
			loadTableMap1();
			tableLoaded = true;
		} catch (JsonParseException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			lockLock.unlock();
		}
		return;
	}

	private static void createFieldsMap() {
		if (fieldLoaded)
			return;
		lockLock.lock();
		if (fieldLoaded) {
			lockLock.unlock();
			return;
		}
		try {
			String[] tables1 = { "A01", "A02", "A03", "A04", "A05", "A06",
					"A07", "A08", "A09", "A10" };
			String[] tables2 = { "B01", "B02", "B03", "B04" };
			List<String> li1 = new ArrayList<String>();
			li1 = Arrays.asList(tables1);
			List<String> li2 = new ArrayList<String>();
			li2 = Arrays.asList(tables2);
			Map<String, List<String>> map1 = TaxQueryUtil
					.createFieldsMap(tables1);
			Map<String, List<String>> map2 = TaxQueryUtil
					.createFieldsMap(tables2);
			indexTypeMap = new HashMap<String, List<String>>();
			indexTypeMap.put(indexOne, li1);
			indexTypeMap.put(indexTwo, li2);
			fieldsMap = new HashMap<String, List<String>>();
			for (String key : map1.keySet())
				fieldsMap.put(key, map1.get(key));
			for (String key : map2.keySet())
				fieldsMap.put(key, map2.get(key));
			fieldLoaded = true;
		} finally {
			lockLock.unlock();
		}
		return;
	}

	private static void loadTableMap1() throws JsonParseException, IOException {
		tableMap = TaxDataReader.readDefData2("liuboOutput/table.txt");
		defMap = TaxDataReader.readDefData("liuboOutput/def.txt");
	}

	private static Map<String, List<String>> loadCompanyMap(String path)
			throws IOException, FileNotFoundException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				new FileInputStream(path), "UTF-8"));
		String temp = null;
		Map<String, List<String>> map = new HashMap<String, List<String>>();
		while ((temp = reader.readLine()) != null) {
			temp = temp.trim();
			if (StringUtil.isBlank(temp))
				continue;
			String[] strs = temp.split(",");
			Assert.assertEquals(true, strs.length == 2 || strs.length == 3);
			List<String> resultList = new LinkedList<String>();
			for (String str : strs) {
				resultList.add(str); // original str must keep first position
				if (!ChineseHelper.allChineseChar(str)
						&& ChineseHelper.containChineseChar(str)) {
					StringBuilder builder = new StringBuilder();
					for (int i = 0; i < str.length(); i++) {
						char c = str.charAt(i);
						if (ChineseHelper.isChineseChar(c))
							builder.append(c);
					}
					resultList.add(builder.toString()); // add converted string
				}
			}
			for (String str : resultList) {
				List<String> newList = new LinkedList<String>();
				newList.addAll(resultList);
				newList.remove(str);
				map.put(str, newList);
			}
		}
		reader.close();
		return map;
	}

	private static Map<String, List<String>> loadPersonMap(String path)
			throws IOException, FileNotFoundException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				new FileInputStream(path), "UTF-8"));
		String temp = null;
		Map<String, List<String>> map = new HashMap<String, List<String>>();
		while ((temp = reader.readLine()) != null) {
			temp = temp.trim();
			if (StringUtil.isBlank(temp))
				continue;
			String[] strs = temp.split(",");
			Assert.assertEquals(true, strs.length >= 2);
			List<String> newList = new LinkedList<String>();
			final String zjh = strs[0];
			for (int i = 0; i < strs.length; i++) {
				if (i != 0) {
					String name = strs[i];
					newList.add(name);
					List<String> oldList = map.get(name);
					if (oldList == null) {
						oldList = new LinkedList<String>();
						oldList.add(zjh);
					} else {
						if (!oldList.contains(zjh))
							oldList.add(zjh);
					}
					map.put(name, oldList);
				}
			}
			map.put(zjh, newList);

		}
		reader.close();
		return map;
	}

	private static Map<String, String> loadRespectMap(String path)
			throws IOException, FileNotFoundException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				new FileInputStream(path), "UTF-8"));
		String temp = null;
		Map<String, String> map = new HashMap<String, String>();
		while ((temp = reader.readLine()) != null) {
			temp = temp.trim();
			if (StringUtil.isBlank(temp))
				continue;
			String[] strs = temp.split(",");
			Assert.assertEquals(true, strs.length == 3);
			int val1 = Integer.valueOf(strs[1]);
			int val2 = Integer.valueOf(strs[2]);
			map.put(strs[0], val1 + "/" + (val1 + val2));
		}
		reader.close();
		return map;
	}
}
