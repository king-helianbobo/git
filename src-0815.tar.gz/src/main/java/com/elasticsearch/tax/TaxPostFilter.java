package com.elasticsearch.tax;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.elasticsearch.common.joda.FormatDateTimeFormatter;
import org.elasticsearch.common.joda.Joda;
import org.elasticsearch.common.joda.time.DateTime;
import org.elasticsearch.common.joda.time.format.DateTimeFormat;
import org.elasticsearch.common.joda.time.format.DateTimeFormatter;
import org.junit.Assert;

public class TaxPostFilter {
	private static final Log log = LogFactory.getLog(TaxPostFilter.class);

	public static boolean checkDate(String dt1, String dt2) {
		FormatDateTimeFormatter formatter = Joda
				.forPattern("yyyy-MM-dd HH:mm:SS || yyyy-MM-dd");
		DateTime date1 = formatter.parser().parseDateTime(dt1);
		DateTime date2 = formatter.parser().parseDateTime(dt2);
		boolean bValue = false;
		int day1 = date1.getDayOfYear();
		int day2 = date2.getDayOfYear();
		if (day1 == day2) {
			log.info(dt1 + " and " + dt2 + "  sameDay");
			bValue = true;
		} else if (date1.isBefore(date2)) {
			log.info(dt1 + " beforeDay " + dt2);
			bValue = true;
		} else if (date1.isAfter(date2)) {
			log.info(dt1 + " afterDay " + dt2);
			bValue = false;
		} else {
			Assert.assertEquals(1, 0);
		}
		return bValue;
	}

	public static DateTime convertDate(String date) {
		FormatDateTimeFormatter formatter = Joda.forPattern("yyyy-MM-dd");
		try {
			DateTime dt = formatter.parser().parseDateTime(date);
			return dt;
		} catch (IllegalArgumentException e) {
			return null;
		}
	}

	public static boolean checkPaid(String str1, String str2) {
		Float realPaid = Float.valueOf(str1);
		Float shouldPaid = Float.valueOf(str2);
		if (Math.abs(realPaid - shouldPaid) <= 0.0000001f) {
			return true;
		} else if (realPaid < shouldPaid)
			return false;
		else
			return true;
	}

	public static void outputDate(DateTime date1, DateTime date2) {
		DateTimeFormatter outputFormat = DateTimeFormat
				.forPattern("yyyy-MM-dd");
		int year1 = date1.getYear();
		int year2 = date2.getYear();
		int month1 = date1.getMonthOfYear();
		int month2 = date2.getMonthOfYear();
		int day1 = date1.getDayOfMonth();
		int day2 = date2.getDayOfMonth();
		if (year1 != year2)
			log.info(date1.toString(outputFormat) + ","
					+ date2.toString(outputFormat));
		else if (month1 != month2)
			log.info(date1.toString(outputFormat) + ","
					+ date2.toString(outputFormat));

		if (day1 != day2) {
			log.info(day1 + "," + day2);
		}
	}
}
