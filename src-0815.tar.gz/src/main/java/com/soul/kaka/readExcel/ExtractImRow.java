package com.soul.kaka.readExcel;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ExtractImRow {
	private static FileOutputStream imOut;
	private static BufferedWriter imBw;

	static {
		try {
			imOut = new FileOutputStream("zhouqiOutput/excel/importantRow.txt");
			imBw = new BufferedWriter(new OutputStreamWriter(imOut, "utf-8"));
		} catch (FileNotFoundException | UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) throws FileNotFoundException,
			IOException {
		String testDataPath = "taxTestData1";
		listDirectory(testDataPath);

		close();
	}

	private static void listDirectory(String path)
			throws FileNotFoundException, IOException {
		File dir = new File(path);
		File file[] = dir.listFiles();
		for (int j = 0; j < file.length; j++) {
			if (file[j].isDirectory()) {
				listDirectory(file[j].getAbsolutePath());
			} else if (file[j].getName().endsWith("xls")
					&& file[j].getName().startsWith("B0")) {
				String[][] dataResult = ExtractExcelDataKaka
						.getData(file[j], 0);
				String[][] dataIm= findImColMap(dataResult);
				linkAndOutput(dataIm);
				
			} else {
				System.out.println("do nothing");
			}
		}
	}
	
	private static void linkAndOutput(String[][] dataIm) throws IOException{
		int rowImSize=dataIm.length;
		int colImSize=dataIm[0].length;
		for(int i=3;i<rowImSize;i++){
			Set<String> set=new LinkedHashSet<String>();
			for(int j=0;j<colImSize;j++){
				set.add(dataIm[i][j]);
			}
			String tempLine="";
			Iterator<String> it=set.iterator();
			while(it.hasNext()){
				tempLine=tempLine+it.next()+",";
			}
			tempLine=tempLine.substring(0, tempLine.length()-1);
			imBw.append(tempLine+"\n");
		}
		imBw.flush();
	}

	private static String[][] findImColMap(String[][] dataResult) {
		int rowCount = dataResult.length;
		int colCount = dataResult[0].length;
		Map<String, ArrayList<String>> colMap = new LinkedHashMap<String, ArrayList<String>>();
		int imColCount=0;
		
		for (int j = 1; j < colCount; j++) {
			 ArrayList<String> colList = new ArrayList<String>();
             if(isImCol(dataResult, j)){
            	 for(int i=0;i<rowCount;i++){
            		 colList.add(dataResult[i][j]);
            	 }
            	 colMap.put(dataResult[0][j], colList);
            	 imColCount++;
             }
		}
		
		String[][] returnArray = new String[rowCount][imColCount];
		int j=0;
		for(String str : colMap.keySet()){
			List<String> list=colMap.get(str);
			for(int i=0;i<rowCount;i++){
				returnArray[i][j]=list.get(i);
			}
			j++;
		}
		
		return returnArray;
	}
	
    private static boolean isImCol(String[][] dataResult,int j){
    	Map<String,Integer> colMap=new HashMap<String,Integer>();
    	for(int i=3;i<dataResult.length;i++){
    		String key=dataResult[i][j];
    		Integer count=colMap.get(key);
    		if(count==null){
    			colMap.put(key, 1);
    		}else{
    			colMap.put(key, count+1);
    		}
    	}
    	
    	for(String keyStr:colMap.keySet()){
    		Integer value=colMap.get(keyStr);
    		if(value.intValue()>1){
    			return false;
    		}
    	}
    	
    	return true;
    }

	private static void close() throws IOException {
		if (imOut != null) {
			imOut.close();
		}
		if (imBw != null) {
			imBw.close();
		}
	}

}
