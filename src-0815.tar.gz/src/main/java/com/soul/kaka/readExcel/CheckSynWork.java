package com.soul.kaka.readExcel;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.HashSet;
import java.util.Set;

import com.splitword.soul.utility.StringUtil;

public class CheckSynWork {

	private static FileOutputStream difOut;
	private static BufferedWriter difBw;
	static {
		try {
			difOut = new FileOutputStream(
					"zhouqiOutput/checkSynWork/d-5.txt");
			difBw = new BufferedWriter(new OutputStreamWriter(difOut, "utf-8"));
		} catch (FileNotFoundException | UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		//String srcPath = "/home/kaka/桌面/兼职相关/轩欢欢/前100行/b-100.txt";
		//String desPath = "/home/kaka/桌面/兼职相关/轩欢欢/前100行/c-100.txt";
		String srcPath="zhouqiOutput/checkSynWork/b-5.txt";
		String desPath="zhouqiOutput/checkSynWork/c-5.txt";
		checkSynWork(srcPath, desPath);

		close();
	}

	private static void close() throws IOException {
		if (difOut != null) {
			difOut.close();
		}
		if (difBw != null) {
			difBw.close();
		}
	}

	private static void checkSynWork(String srcPath, String desPath)
			throws IOException {
		BufferedReader srcReader = new BufferedReader(new InputStreamReader(
				new FileInputStream(srcPath), "UTF-8"));
		BufferedReader desReader = new BufferedReader(new InputStreamReader(
				new FileInputStream(desPath), "UTF-8"));
		String srcTemp = null;
		String desTemp = null;
		int row = 0;
		while (((srcTemp = srcReader.readLine()) != null)
				&& ((desTemp = desReader.readLine()) != null)) {
			srcTemp = srcTemp.trim();
			desTemp = desTemp.trim();
			row++;

			if (srcTemp.equals(desTemp)) {
				continue;
			} else if (StringUtil.isBlank(desTemp)) {
				difBw.append("第" + row + "行被删除,内容为: " + srcTemp + "\n\n");
			} else {
				Set<String> srcRowSet = new HashSet<String>();
				Set<String> desRowSet = new HashSet<String>();
				String[] srcSplit = srcTemp.split(",");
				String[] desSplit = desTemp.split(",");

				for (int i = 0; i < desSplit.length; i++) {
					desRowSet.add(desSplit[i].trim());
				}
				for (int i = 0; i < srcSplit.length; i++) {
					srcRowSet.add(srcSplit[i].trim());
				}

				difBw.append("第" + row + "行添加的词汇有: ");
				for (int i = 0; i < desSplit.length; i++) {
					if (srcRowSet.contains(desSplit[i])) {
						continue;
					} else {
						difBw.append(desSplit[i] + " ");
					}
				}
				difBw.append("\n");

				difBw.append("第" + row + "行删除的词汇有: ");
				for (int i = 0; i < srcSplit.length; i++) {
					if (desRowSet.contains(srcSplit[i])) {
						continue;
					} else {
						difBw.append(srcSplit[i] + " ");
					}
				}
				difBw.append("\n\n");
			}
			
		}

		difBw.flush();
		srcReader.close();
		desReader.close();
	}

}
