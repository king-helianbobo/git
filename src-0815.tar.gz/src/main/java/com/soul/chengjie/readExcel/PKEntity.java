package com.soul.chengjie.readExcel;

import java.io.Serializable;
import java.util.ArrayList;

public class PKEntity implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4197878438240502494L;

	private int status;

	private String tableSignature;

	public String getTableSignature() {
		return tableSignature;
	}

	public void setTableSignature(String tableSignature) {
		this.tableSignature = tableSignature;
	}

	private ArrayList<String> PKList;

	private ArrayList<String> compositePKList_2;

	private ArrayList<String> compositePKList_3;

	private ArrayList<String> compositePKList_4;

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public ArrayList<String> getPKList() {
		return PKList;
	}

	public void setPKList(ArrayList<String> pKList) {
		PKList = pKList;
	}

	public ArrayList<String> getCompositePKList_2() {
		return compositePKList_2;
	}

	public void setCompositePKList_2(ArrayList<String> compositePKList_2) {
		this.compositePKList_2 = compositePKList_2;
	}

	public ArrayList<String> getCompositePKList_3() {
		return compositePKList_3;
	}

	public void setCompositePKList_3(ArrayList<String> compositePKList_3) {
		this.compositePKList_3 = compositePKList_3;
	}

	public ArrayList<String> getCompositePKList_4() {
		return compositePKList_4;
	}

	public void setCompositePKList_4(ArrayList<String> compositePKList_4) {
		this.compositePKList_4 = compositePKList_4;
	}

}