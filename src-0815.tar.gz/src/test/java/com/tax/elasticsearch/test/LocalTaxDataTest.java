package com.tax.elasticsearch.test;

import static org.elasticsearch.common.xcontent.XContentFactory.jsonBuilder;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.io.MapWritable;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.map.ObjectMapper;
import org.elasticsearch.action.admin.indices.create.CreateIndexResponse;
import org.elasticsearch.action.admin.indices.exists.indices.IndicesExistsResponse;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.ImmutableSettings;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.elasticsearch.common.xcontent.XContentBuilder;
import org.elasticsearch.hadoop.cfg.ConfigurationOptions;
import org.elasticsearch.hadoop.cfg.SettingsManager;
import org.elasticsearch.hadoop.mr.MapReduceWriter;
import org.elasticsearch.hadoop.rest.InitializationUtils;
import org.elasticsearch.hadoop.rest.RestClient;
import org.elasticsearch.hadoop.serailize.IndexCommand;
import org.elasticsearch.hadoop.serailize.MapWritableIdExtractor;
import org.elasticsearch.hadoop.serailize.SerializationUtils;
import org.elasticsearch.hadoop.util.BytesArray;
import org.elasticsearch.hadoop.util.WritableUtils;
import org.junit.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.elasticsearch.tax.ESMapUtility;
import com.elasticsearch.tax.TaxFinalVal;
import com.elasticsearch.tax.TaxQueryUtil;
import com.elasticsearch.tax.TaxSchema;
import com.splitword.lionsoul.jcseg.util.ChineseHelper;
import com.splitword.soul.utility.StringUtil;

public class LocalTaxDataTest {
	private static Log log = LogFactory.getLog(LocalTaxDataTest.class);
	private TransportClient tcpClient;
	private ObjectMapper mapper = new ObjectMapper();

	@BeforeClass
	public void startNode() throws Exception {
		// Settings settings = ImmutableSettings.settingsBuilder()
		// .put("cluster.name", "LiuboCluster").build();
		Settings settings = ImmutableSettings.settingsBuilder()
				.put("cluster.name", "elasticsearch").build();
		tcpClient = new TransportClient(settings)
				.addTransportAddress(new InetSocketTransportAddress(
						TaxCacheTest.hostName, 9300));
	}

	private org.elasticsearch.hadoop.cfg.Settings createSettings(
			String indexName, String typeName) {
		org.elasticsearch.hadoop.cfg.Settings settings = null;
		Properties properties = new Properties();
		properties.put(ConfigurationOptions.ES_WRITE_OPERATION, "index");
		properties.put(ConfigurationOptions.ES_MAPPING_ID, "id");
		String resource = indexName + "/" + typeName;
		properties.put(ConfigurationOptions.ES_RESOURCE, resource);
		properties.put(ConfigurationOptions.ES_HOST, TaxCacheTest.hostName);
		settings = SettingsManager.loadFrom(properties);
		SerializationUtils.setValueWriterIfNotSet(settings,
				MapReduceWriter.class, log);
		InitializationUtils.setIdExtractorIfNotSet(settings,
				MapWritableIdExtractor.class, log);
		return settings;
	}

	@AfterClass
	public void closeResources() {
		tcpClient.close();
		// client.close();
	}

	@Test(enabled = true)
	public void testMethod2() throws Exception {
		createSchemaMapping(TaxFinalVal.schemaIndex);
		indexSchemaData(TaxFinalVal.schemaIndex);
	}

	@Test(enabled = true)
	public void testMethod1() throws Exception {

		String[] tableList1 = { "A01", "A02", "A03", "A04", "A05", "A06",
				"A07", "A08", "A09", "A10" };
		String[] tableList2 = { "B01", "B02", "B03", "B04" };

		taxIndexMapping(TaxFinalVal.indexOne, tableList1);
		taxIndexMapping(TaxFinalVal.indexTwo, tableList2);

		for (String typeName : tableList1)
			indexJsonData(TaxFinalVal.indexOne, typeName);
		for (String typeName : tableList2)
			indexJsonData(TaxFinalVal.indexTwo, typeName);

	}

	private void indexSchemaData(String indexName) throws Exception {
		org.elasticsearch.hadoop.cfg.Settings settings = createSettings(
				indexName, "table");
		RestClient client = new RestClient(settings);
		IndexCommand command = new IndexCommand(settings);
		BytesArray data = new BytesArray(20 * 1024 * 1024);

		for (String tableName : TaxFinalVal.tableMap().keySet()) {
			String chineseTableName = TaxFinalVal.tableMap().get(tableName);
			List<String> fieldNames = new LinkedList<String>();
			List<String> chineseFieldNames = new LinkedList<String>();
			Map<String, Object> tableDefs = TaxFinalVal.defMap().get(tableName);
			for (String field : tableDefs.keySet()) {
				fieldNames.add(field);
				@SuppressWarnings("unchecked")
				Map<String, String> tmpValue = (Map<String, String>) tableDefs
						.get(field);
				String chineseName = tmpValue.get(TaxSchema.chineseFieldName);
				chineseFieldNames.add(chineseName);
			}

			StringBuilder builder1 = new StringBuilder();
			for (int i = 0; i < fieldNames.size(); i++) {
				if (i != 0)
					builder1.append("\t" + fieldNames.get(i));
				else
					builder1.append(fieldNames.get(i));
			}
			StringBuilder builder2 = new StringBuilder();
			for (int i = 0; i < chineseFieldNames.size(); i++) {
				Assert.assertEquals(true, ChineseHelper
						.containChineseChar(chineseFieldNames.get(i)));
				if (i != 0)
					builder2.append("\t" + chineseFieldNames.get(i));
				else
					builder2.append(chineseFieldNames.get(i));
			}

			Map<String, String> entry = new LinkedHashMap<String, String>();
			entry.put("id", tableName);
			entry.put(TaxSchema.tableName, tableName);
			entry.put(TaxSchema.chineseTableName, chineseTableName);
			entry.put(TaxSchema.fieldName, builder1.toString());
			entry.put(TaxSchema.chineseFieldName, builder2.toString());

			MapWritable writable = (MapWritable) WritableUtils
					.toWritable(entry);
			int entrySize = command.prepare(writable);
			if (entrySize + data.size() > data.capacity()) {
				client.bulk(settings.getIndexType(), data.bytes(), data.size());
				data.reset();
			}
			command.write(writable, data);
		}
		client.bulk(settings.getIndexType(), data.bytes(), data.size());
		data.reset();
		client.close();
	}

	private void indexJsonData(String indexName, String typeName)
			throws Exception {

		org.elasticsearch.hadoop.cfg.Settings settings = createSettings(
				indexName, typeName);
		RestClient client = new RestClient(settings);
		IndexCommand command = new IndexCommand(settings);
		BytesArray data = new BytesArray(20 * 1024 * 1024);
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				new FileInputStream("liuboOutput/result.txt"), "UTF-8"));
		String temp = null;
		while ((temp = reader.readLine()) != null) {
			temp = temp.trim();
			if (StringUtil.isBlank(temp))
				continue;
			JsonParser jsonParser = mapper.getJsonFactory().createJsonParser(
					temp);
			@SuppressWarnings("unchecked")
			Map<String, String> entry = mapper.readValue(jsonParser, Map.class);
			Map<String, String> addedMap = new LinkedHashMap<String, String>();
			String tableName = entry.get("tableName");
			String lineNumber = entry.get("lineNumber");
			if (!tableName.equals(typeName))
				continue;

			addedMap.put("id", tableName + "#" + lineNumber);
			for (String key : entry.keySet()) {
				String value = entry.get(key);
				if (StringUtil.isBlank(value))
					continue;
				if (key.equals("lineNumber") || key.equals("tableName"))
					continue;
				addedMap.put(tableName + "." + key, value);
			}

			MapWritable writable = (MapWritable) WritableUtils
					.toWritable(addedMap);
			int entrySize = command.prepare(writable);
			if (entrySize + data.size() > data.capacity()) {
				client.bulk(settings.getIndexType(), data.bytes(), data.size());
				data.reset();
			}
			command.write(writable, data);
		}
		reader.close();
		client.bulk(settings.getIndexType(), data.bytes(), data.size());
		data.reset();
		client.close();
	}

	private void taxIndexMapping(String indexName, String... tableList) {
		try {
			IndicesExistsResponse existsResponse = tcpClient.admin().indices()
					.prepareExists(indexName).execute().actionGet();
			if (existsResponse.isExists()) {
				// if index exist, delete it
				tcpClient.admin().indices().prepareDelete(indexName).execute()
						.actionGet();
			}

			XContentBuilder builder = (XContentBuilder) jsonBuilder()
					.humanReadable(true).startObject()
					.field("settings", ESMapUtility.settingMap())
					.field("mappings", TaxQueryUtil.mappingMap(tableList))
					.endObject();

			String settings = builder.string();
			log.info(settings);
			CreateIndexResponse createIndexResponse = tcpClient.admin()
					.indices().prepareCreate(indexName).setSource(settings)
					.execute().actionGet();
			assertThat(createIndexResponse.isAcknowledged(), is(true));
			tcpClient.admin().cluster().prepareHealth(indexName)
					.setWaitForGreenStatus().execute().actionGet();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void createSchemaMapping(String indexName) {
		try {
			IndicesExistsResponse existsResponse = tcpClient.admin().indices()
					.prepareExists(indexName).execute().actionGet();
			if (existsResponse.isExists()) {
				// if index exist, delete it
				tcpClient.admin().indices().prepareDelete(indexName).execute()
						.actionGet();
			}
			XContentBuilder builder = (XContentBuilder) jsonBuilder()
					.humanReadable(true).startObject()
					.field("settings", ESMapUtility.settingMap2())
					.field("mappings", schemaMapping()).endObject();

			String settings = builder.string();
			log.info(settings);
			CreateIndexResponse createIndexResponse = tcpClient.admin()
					.indices().prepareCreate(indexName).setSource(settings)
					.execute().actionGet();
			assertThat(createIndexResponse.isAcknowledged(), is(true));
			tcpClient.admin().cluster().prepareHealth(indexName)
					.setWaitForGreenStatus().execute().actionGet();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static Map<String, Object> schemaMapping() {
		Map<String, Object> map1 = new LinkedHashMap<String, Object>();
		Map<String, Object> map2 = new LinkedHashMap<String, Object>();
		map1.put("type", "string");
		map1.put("index", "not_analyzed");
		map2.put("type", "string");
		map2.put("index_analyzer", "tax_index");
		map2.put("search_analyzer", "tax_query");
		Map<String, Object> map3 = new LinkedHashMap<String, Object>();
		map3.put("type", "string");
		map3.put("index_analyzer", "whitespace");

		Map<String, Object> tmpMap = new LinkedHashMap<String, Object>();
		tmpMap.put(TaxSchema.tableName, map1);
		tmpMap.put(TaxSchema.chineseTableName, map2);
		tmpMap.put(TaxSchema.fieldName, map3);
		tmpMap.put(TaxSchema.chineseFieldName, map2);

		Map<String, Object> typeMap = new LinkedHashMap<String, Object>();

		Map<String, Object> propertiesMap = new LinkedHashMap<String, Object>();
		propertiesMap.put("properties", tmpMap);
		typeMap.put("table", propertiesMap);

		return typeMap;
	}

}
