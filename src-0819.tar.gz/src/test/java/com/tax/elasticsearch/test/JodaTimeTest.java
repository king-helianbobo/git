package com.tax.elasticsearch.test;

import junit.framework.Assert;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.elasticsearch.common.joda.FormatDateTimeFormatter;
import org.elasticsearch.common.joda.Joda;
import org.elasticsearch.common.joda.time.DateTime;
import org.elasticsearch.common.joda.time.Days;
import org.elasticsearch.common.joda.time.LocalDate;
import org.elasticsearch.common.joda.time.Period;
import org.elasticsearch.common.joda.time.format.DateTimeFormat;
import org.elasticsearch.common.joda.time.format.DateTimeFormatter;
import org.testng.annotations.Test;

import com.elasticsearch.tax.ESMapUtility;
import com.elasticsearch.tax.CharUtility;

public class JodaTimeTest {

	private final Log log = LogFactory.getLog(JodaTimeTest.class);

	// @Test(enabled = true)
	public void jodaTimeTest1() {

		DateTimeFormatter outputFormat = DateTimeFormat
				.forPattern("yyyy-MM-dd HH:mm");
		String[] strs = { "2013-5-31 15:59:58", "2014-6-25", "2009-9-1 15:30",
				"2009-2-28 5:3", "1970-01-01", "2014-07-03" };
		FormatDateTimeFormatter formatter = Joda
				.forPattern("yyyy-MM-dd HH:mm:ss||yyyy-MM-dd||yyyy-MM-dd HH:mm");
		long millis1 = 1404369067654L;
		DateTime dt1 = new DateTime(millis1);

		log.info(dt1.toString(outputFormat));
		for (String strInputDateTime : strs) {
			long millis = formatter.parser().parseMillis(strInputDateTime);
			DateTime dt = formatter.parser().parseDateTime(strInputDateTime);
			// assertThat(input, is(formatter.printer().print(millis)));
			// fmt.parseDateTime(strInputDateTime);
			// String strOutputDateTime = fmt.print(dt);
			int numDays = Days.daysBetween(new LocalDate(dt1),
					new LocalDate(dt)).getDays();
			log.info("number of days = " + numDays + ", date="
					+ strInputDateTime);
			int iDoW = dt.getDayOfWeek();
			log.info(dt.toString(outputFormat) + "," + iDoW);
			log.info("current time is " + millis + "," + dt.getMillis());
		}
	}

	// @Test(enabled = true)
	public void jodaTimeTest3() {
		DateTimeFormatter outputFormat = DateTimeFormat
				.forPattern("yyyy-MM-dd HH:mm:ss");
		String xlsTime1 = "14-5月 -07 02.15.37.557950 下午";
		String xlsTime2 = "11-9月-98 10.17.31.960823 上午";
		String time1 = checkThisString(xlsTime1);
		String time2 = checkThisString(xlsTime2);
		FormatDateTimeFormatter formatter = Joda
				.forPattern("yy-MM-dd HH:mm:ss||yyyy-MM-dd||yyyy-MM-dd HH:mm||yyyyMMdd");
		DateTime dt1 = formatter.parser().parseDateTime(time1);
		DateTime dt2 = formatter.parser().parseDateTime(time2);
		DateTime dt3 = formatter.parser().parseDateTime("20140224");
		log.info(dt1.toString(outputFormat));
		log.info(dt2.toString(outputFormat));
		log.info(dt3.toString(outputFormat));

		int days = 41671;
		DateTime dt = new DateTime(1899, 12, 30, 0, 0, 0, 0);
		DateTime plusPeriod = dt.plus(Period.days(days));
		log.info(plusPeriod.toString(outputFormat));

		String value = "02";
		log.info(Integer.valueOf(value));
	}

	public static String checkThisString(String value) {
		StringBuilder builder = new StringBuilder();
		String result = value;
		String time = null;
		String date = null;
		if (value.contains("月") && value.contains("上午")) {
			result = value.replace("上午", "");
			result = result.trim();
			int index = result.lastIndexOf(" ");
			time = result.substring(index + 1);
			time = checkTime(time, "上午");
			date = result.substring(0, index);
		} else if (value.contains("月") && value.contains("下午")) {
			result = value.replace("下午", "");
			result = result.trim();
			int index = result.lastIndexOf(" ");
			time = result.substring(index + 1);
			time = checkTime(time, "下午");
			date = result.substring(0, index);
		} else {
			Assert.assertEquals(1, 0);// this should not happen!
		}
		date = date.replace(" ", "");
		date = checkDate(date);
		builder.append(date + " " + time);
		return builder.toString();
	}

	private static String checkTime(String time, String tag) {
		StringBuilder builder = new StringBuilder();
		String[] timeStrs = time.split("[.]");
		Assert.assertEquals(2, timeStrs[0].length());
		Assert.assertEquals(2, timeStrs[1].length());
		Assert.assertEquals(2, timeStrs[2].length());
		Assert.assertEquals(6, timeStrs[3].length());
		if (tag.equals("下午")) {
			int hour = Integer.valueOf(timeStrs[0]);
			hour = (hour + 12) % 24;
			builder.append(hour);
		} else if (tag.equals("上午"))
			builder.append(timeStrs[0]);
		builder.append(":" + timeStrs[1] + ":" + timeStrs[2]);
		return builder.toString();
	}

	private static String checkDate(String date) {
		StringBuilder builder = new StringBuilder();
		String[] dateStrs = date.split("-");
		String month = dateStrs[1].replace("月", "");
		Assert.assertEquals(2, dateStrs[0].length());
		// Assert.assertEquals(2, month.length());
		Assert.assertEquals(2, dateStrs[2].length());
		builder.append(dateStrs[2] + "-" + month + "-" + dateStrs[0]);
		return builder.toString();
	}

	// @Test(enabled = true)
	public void jodaTimeTest2() {
		String[] strs = { "2008/9/09", "2008-9-09", "2008.09.9", "2008909",
				"000320200009400445.0001", "0.000000", "1.000000", "10.000000",
				"10.010100000", "10", "0" };
		int max = Integer.MAX_VALUE;
		log.info(max);
		for (String token : strs) {
			if (ESMapUtility.convertDate1(token) != null) {
				String date = ESMapUtility.convertDate1(token);
				log.info(token + "," + date);
			}
		}
	}

	@Test(enabled = true)
	public void jodaTimeTest4() {
		String[] strs = { "10  ~ 100", "100.1～ 10.0", "  2014-  01  -   07",
				" 2014 / 01  /07", "。，、”       ｓｄｆｓｄｆ多啦哆啦abvＡａ梦１123" };
		for (String token : strs) {
			String str1 = CharUtility.alterString(token);
			String str2 = CharUtility.removeConsecutiveWhiteSpaces(str1);
			log.info(str1);
			log.info(str2);
			log.info(token);
		}
	}
}
