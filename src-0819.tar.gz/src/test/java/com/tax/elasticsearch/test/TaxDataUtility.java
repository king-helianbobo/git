package com.tax.elasticsearch.test;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Assert;
import com.elasticsearch.tax.TaxFinalVal;
import com.splitword.soul.utility.StringUtil;

public class TaxDataUtility {
	private static Map<String, String> keyMap = new HashMap<String, String>();
	private static Map<String, List<String>> sortMap = new HashMap<String, List<String>>();
	private static Log log = LogFactory.getLog(TaxDataUtility.class);
	static {
		loadSortMap();
		loadKeyMap("liuboOutput/synonym-key.txt");
	}

	private static void loadSortMap() {
		List<String> list = new LinkedList<String>();
		list.add("A04.ZSXM_DM");
		list.add("A04.SFSSQ_QSRQ");
		list.add("A05.KP_RQ");
		list.add("A06.SSQ");
		list.add("A07.SSQ");
		list.add("A08.HD_QSRQ");
		list.add("A09.SSQ");
		list.add("A10.SFSSQ_QSRQ");
		for (String realField : list) {
			String[] strs = realField.split("[.]");
			String tableName = strs[0];
			String field = strs[1];
			List<String> tempList = sortMap.get(tableName);
			if (tempList == null)
				tempList = new LinkedList<String>();
			tempList.add(realField);
			sortMap.put(tableName, tempList);
		}
	}

	private static void loadKeyMap(String path) {
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new InputStreamReader(
					new FileInputStream(path), "UTF-8"));
			String temp = null;
			while ((temp = reader.readLine()) != null) {
				temp = temp.trim();
				if (StringUtil.isBlank(temp))
					continue;
				String[] strs = temp.split("\t");
				Assert.assertEquals(true, strs.length == 3 || strs.length == 2);
				StringBuilder builder = new StringBuilder();
				String firstKey = strs[0].split("#")[1];
				builder.append(firstKey);
				for (int i = 1; i < strs.length; i++) {
					builder.append("\t" + strs[i]);
				}
				keyMap.put(strs[0], builder.toString());
			}
			if (reader != null)
				reader.close();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static Map<String, String> addSortField(
			Map<String, String> addedMap, String tableName) {
		if (!sortMap.containsKey(tableName)) {
			addedMap.put(TaxFinalVal.sortDate, "1970-01-01");
		} else {
			List<String> fields = sortMap.get(tableName);
			StringBuilder builder = new StringBuilder();
			for (int i = 0; i < fields.size(); i++) {
				String field = fields.get(i);
				// String realField = tableName + "." + field;
				String value = addedMap.get(field);
				if (TaxFinalVal.relationMap().containsKey(field)) {
					// 如果是指向附属表的外键
					log.info(value);
					String[] strs = value.split("\\s+");
					value = strs[0];
				}
				if (StringUtil.isBlank(value))
					value = " ";
				if (i != 0)
					builder.append("#" + value);
				else
					builder.append(value);
			}
			log.info(builder.toString());
			addedMap.put(TaxFinalVal.sortDate, builder.toString());
		}
		return addedMap;
	}

	public static String convertValue(String otherField, String value) {
		String[] strs = otherField.split("[.]");
		String tableName = strs[0];
		// String field = strs[1];
		String key = tableName + "#" + value;
		return keyMap.get(key);
	}
}
