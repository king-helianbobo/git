(function(a) {
	a.ui = a.ui || {};
	a.fn.tab = function(b) {
		return this.each(function() {
			var c = a.extend({},
			b);
			if (c !== false) {
				new a.ui.tab(this, c)
			}
		})
	};
	a.ui.tab = function(c, b) {
		this.settings = a.extend({},
		a.ui.tab.settings, b);
		this.element = a(c);
		this.refresh();
		this.attachEvents()
	};
	a.ui.tab.prototype = {
		refresh: function() {
			this.index = this.settings.index || 0;
			if (this.index < 0 || this.index > this.element.find(this.settings.tabs).length - 1) {
				this.index = 0
			}
			if (this.settings.cookies) {
				this.index = a.cookie(this.settings.cookies)
			}
			this.tabs = this.element.find(this.settings.tabs);
			this.box = this.element.find(this.settings.box);
			this.tabs.removeClass(this.settings.cur).eq(this.index).addClass(this.settings.cur);
			this.box.hide().eq(this.index).show();
			if (this.settings.onSet) {
				this.settings.onSet(this)
			}
		},
		attachEvents: function() {
			var b = this;
			this.tabs.each(function(c) {
				var d = a(this);
				d.bind(b.settings.evtype,
				function(f) {
					if (!d.hasClass(b.settings.cur)) {
						b.index = c;
						if (b.settings.cookies) {
							a.cookie(b.settings.cookies, b.index)
						}
						setTimeout(function() {
							b.tabs.removeClass(b.settings.cur).eq(c).addClass(b.settings.cur);
							b.box.hide().eq(c).show()
						},
						b.settings.delay);
						if (b.settings.onSelect) {
							b.settings.onSelect(b)
						}
						f.stopPropagation();
						return false
					}
				})
			})
		}
	};
	a.extend(a.ui.tab, {
		settings: {
			delay: 0,
			tabs: ">ol li",
			index: 0,
			cur: "cur",
			evtype: "click",
			box: ">.main",
			cookies: false,
			onSet: undefined,
			onSelect: undefined
		}
	})
})(jQuery);