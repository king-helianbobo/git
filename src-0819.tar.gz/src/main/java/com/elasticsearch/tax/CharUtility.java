package com.elasticsearch.tax;

import java.util.LinkedList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.splitword.lionsoul.jcseg.util.ChineseHelper;
import com.splitword.soul.utility.StringUtil;

public class CharUtility {
	private static Log log = LogFactory.getLog(CharUtility.class);
	public static final int MinQuanJiaoAlpha = 65345;// ａ
	public static final int MaxQuanJiaoAlpha = 65370;// ｚ
	public static final int MinAsciiAlpha = 65;// A
	public static final int MaxAsciiAlpha = 90;// Z
	public static final int MinQuanJiaoAlpha_UPPER = 65313;// Ａ
	public static final int MaxQuanJiaoAlpha_UPPER = 65338;// Ｚ
	public static final int MinQuanJiaoNumber = 65296;// ０
	public static final int MaxQuanJiaoNumber = 65305;// ９

	static final int LOWER_GAP = 65248;
	static final int UPPER_GAP = 65216;
	static final int UPPER_GAP_E = -32;
	static final int UPPER_GAP_N = 65248;
	private static final char[] allChars = new char[65536];

	static {
		for (int i = 0; i < allChars.length; i++) {
			if (i >= MinQuanJiaoAlpha && i <= MaxQuanJiaoAlpha) {
				allChars[i] = (char) (i - LOWER_GAP);
			} else if (i >= MinQuanJiaoAlpha_UPPER
					&& i <= MaxQuanJiaoAlpha_UPPER) {
				allChars[i] = (char) (i - UPPER_GAP - 32);
			} else if (i >= MinAsciiAlpha && i <= MaxAsciiAlpha) {
				allChars[i] = (char) (i - UPPER_GAP_E - 32);
			} else if (i >= MinAsciiAlpha + 32 && i <= MaxAsciiAlpha + 32) {
				allChars[i] = (char) (i);
			} else if (i >= MinQuanJiaoNumber && i <= MaxQuanJiaoNumber) {
				allChars[i] = (char) (i - UPPER_GAP_N);
			} else {
				allChars[i] = 0;
			}
		}
		allChars['（'] = '(';
		allChars['('] = '(';
		allChars['）'] = ')';
		allChars[')'] = ')';
		allChars['━'] = '-';
		allChars['─'] = '-';
		allChars['┄'] = '-';
		allChars['—'] = '-';
		allChars['-'] = '-';
		allChars['～'] = '~';
		allChars['~'] = '~';
		allChars['︰'] = ':';
		allChars['﹕'] = ':';
		allChars['：'] = ':';
		allChars[':'] = ':';
		allChars['＇'] = '\'';
		allChars['，'] = ',';
		allChars['﹐'] = ',';
		allChars[','] = ',';
		allChars['﹑'] = ',';
		allChars['〞'] = '"';
		allChars['”'] = '"';
		allChars['“'] = '"';
		allChars['"'] = '"';
		allChars['•'] = '.';
		allChars['.'] = '.';
		allChars['/'] = '/';
	}

	public static int chineseCharNumbers(String s) {
		int count = 0;
		Matcher matcher = Pattern.compile("[\\u4e00-\\u9fa5]").matcher(s);
		while (matcher.find()) {
			count++;
		}
		return count;
	}

	public static String alterString(String str) {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < str.length(); i++) {
			char currentChar = str.charAt(i);
			char c = allChars[currentChar];
			if (c > 0) {
				sb.append(c);
			} else if (ChineseHelper.isTraditionalChinese(currentChar)) {
				c = ChineseHelper.toSimplifiedChinese(currentChar);
				sb.append(c);
			} else if (ChineseHelper.isChineseChar(currentChar)) {
				sb.append(currentChar);
			} else if (Character.isDigit(currentChar)) {
				sb.append(currentChar);
			} else
				sb.append(" ");
		}
		return sb.toString();
	}

	public static String removeConsecutiveWhiteSpaces(String sentence) {
		int numWhiteSpace = 0;
		StringBuilder builder = new StringBuilder();
		char prevChar = ' ';
		List<String> list = new LinkedList<String>();
		list.add("~");
		list.add("/");
		list.add("-");
		for (int i = 0; i < sentence.length(); i++) {
			char c = sentence.charAt(i);
			String str = String.valueOf(c);
			if (StringUtil.isBlank(str))
				numWhiteSpace += 1;
			else if (numWhiteSpace == 0) {
				// current char must not whitespace
				prevChar = c;
				builder.append(c);
				numWhiteSpace = 0;
			} else {
				if (list.contains(String.valueOf(prevChar))
						&& Character.isDigit(c)) {
					builder.append(c);
					prevChar = c;
				} else if (Character.isDigit(prevChar)
						&& list.contains(String.valueOf(c))) {
					builder.append(c);
					prevChar = c;
				} else if (prevChar == ' ') {
					builder.append(c);
					prevChar = c;
				} else {
					builder.append(" ");
					builder.append(c);
					prevChar = c;
				}
				numWhiteSpace = 0;
			}
		}
		return builder.toString();
	}
}
