package com.elasticsearch.tax;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import com.elasticsearch.query.SoulQueryUtil;

public class TaxQueryUtil {
	private static final Log log = LogFactory.getLog(TaxQueryUtil.class);
	private static ObjectMapper mapper = new ObjectMapper();

	public static Map<String, List<String>> createFieldsMap(String... tableList) {
		Map<String, List<String>> tableMaps = new LinkedHashMap<String, List<String>>();
		for (String tableName : tableList) {
			List<String> displayFields = new LinkedList<String>();
			List<String> chineseFields = new LinkedList<String>();
			List<String> integerFields = TaxQueryFields.expectedList(tableName,
					"integer");
			List<String> floatFields = TaxQueryFields.expectedList(tableName,
					"float");
			List<String> dateFields = TaxQueryFields.expectedList(tableName,
					"date");
			List<String> dateTimeFields = TaxQueryFields.expectedList(
					tableName, "datetime");

			if (tableName.equals("A01")) {
				chineseFields.add("NSR_MC");
				chineseFields.add("ZCDZ");
				chineseFields.add("SJJYDZ");

				displayFields.add("SWGLM");
				displayFields.add("NSR_MC");
				displayFields.add("ZCDZ");
				displayFields.add("SJJYDZ");
				displayFields.add("SCJYDLXDH");
				displayFields.add("NSRZT_DM");
			} else if (tableName.equals("A02")) {
				chineseFields.add("JYFWZY");
				chineseFields.add(TaxFinalVal.addedField);// 这个域是额外添加的

				displayFields.add("SWGLM");
				displayFields.add(TaxFinalVal.addedField); // 这个域是额外添加的
				displayFields.add("ZZJGTYDM");
				displayFields.add("KYSLRQ");
				displayFields.add("SBFS_DM");
				displayFields.add("ZSFS_DM");
				displayFields.add("JKFS_DM");
			} else if (tableName.equals("A03")) {
				chineseFields.add(TaxFinalVal.addedField);// 这个域是额外添加的

				displayFields.add("SWGLM");
				displayFields.add(TaxFinalVal.addedField); // 这个域是额外添加的
				displayFields.add("XM");
				displayFields.add("ZJH");
				displayFields.add("YD_DH");
				displayFields.add("GJDQ_DM");

			} else if (tableName.equals("A04")) {
				chineseFields.add("LSNSR_MC");

				displayFields.add("SWGLM");
				displayFields.add("LSNSR_MC");
				displayFields.add("ZSXM_DM");
				// displayFields.add("PZ_XH");
				displayFields.add("SFSSQ_QSRQ");
				displayFields.add("SFSSQ_ZZRQ");
				displayFields.add("JK_QX");
				displayFields.add("SB_RQ");
			} else if (tableName.equals("A05")) {
				chineseFields.add("KP_XM");
				chineseFields.add("SKF_MC");
				chineseFields.add("FKF_MC");

				displayFields.add("FP_DM");
				displayFields.add("FP_HM");
				displayFields.add("KP_XM");
				displayFields.add("JE");
				displayFields.add("KP_RQ");
				displayFields.add("SKF_GLM");
				displayFields.add("SKF_MC");
				displayFields.add("FKF_GLM");
				displayFields.add("FKF_MC");
			} else if (tableName.equals("A06")) {
				chineseFields.add("NSR_MC");

				displayFields.add("SWGLM");
				displayFields.add("NSR_MC");
				displayFields.add("SSQ");
				displayFields.add("PZXM_DM");
				displayFields.add("BQS");
				displayFields.add("BNLJS");
				displayFields.add("PZ_XH");
			} else if (tableName.equals("A07")) {
				chineseFields.add("NSR_MC");

				displayFields.add("SWGLM");
				displayFields.add("NSR_MC");

				displayFields.add("SSQ");
				displayFields.add("ZCXM_DM");
				displayFields.add("ZCQCS");
				displayFields.add("ZCQMS");
				displayFields.add("FZXM_DM");
				displayFields.add("FZQCS");
				displayFields.add("FZQMS");
				displayFields.add("PZ_XH");
			} else if (tableName.equals("A08")) {
				chineseFields.add(TaxFinalVal.addedField);// 这个域是额外添加的

				displayFields.add("SWGLM");
				displayFields.add(TaxFinalVal.addedField); // 这个域是额外添加的
				displayFields.add("XH");
				displayFields.add("ZSXM_DM");
				displayFields.add("SBQXR_DM");
				displayFields.add("JKQXR_DM");
				displayFields.add("ZSFS_DM");
				displayFields.add("JS_JE");
				displayFields.add("ZSL");
				displayFields.add("HD_QSRQ");
				displayFields.add("HD_ZZRQ");
			} else if (tableName.equals("A09")) {
				chineseFields.add("NSR_MC");
				displayFields.add("SWGLM");
				displayFields.add("NSR_MC");
				displayFields.add("PZ_XH");
				displayFields.add("SSQ");
				displayFields.add("ZT");
			} else if (tableName.equals("A10")) {
				chineseFields.add(TaxFinalVal.addedField);// 这个域是额外添加的

				displayFields.add("SWGLM");
				displayFields.add(TaxFinalVal.addedField); // 这个域是额外添加的
				displayFields.add("PZ_XH");
				displayFields.add("NSR_MC");
				displayFields.add("SFZHM");
				displayFields.add("HJSRE_JE");
				displayFields.add("SIJMSSRE_JE");
				displayFields.add("YINGNSSDE_JE");
			} else if (tableName.equals("B01")) {
				chineseFields.add("MC");
				chineseFields.add("MC_J");
			} else if (tableName.equals("B02")) {
				chineseFields.add("MC");
				chineseFields.add("MC_J");
			} else if (tableName.equals("B03")) {
				chineseFields.add("MC");
				chineseFields.add("MC_J");
			} else if (tableName.equals("B04")) {
				chineseFields.add("MC");
				chineseFields.add("MC_J");
			}

			if (chineseFields.size() > 0)
				tableMaps.put(tableName + "#chinese", chineseFields);
			if (integerFields != null)
				tableMaps.put(tableName + "#integer", integerFields);
			if (floatFields != null)
				tableMaps.put(tableName + "#float", floatFields);
			if (dateFields != null)
				tableMaps.put(tableName + "#date", dateFields);
			if (dateTimeFields != null)
				tableMaps.put(tableName + "#datetime", dateTimeFields);
			if (displayFields.size() > 0)
				tableMaps.put(tableName + "#display", displayFields);

			List<String> tmpWordFields = TaxQueryFields.expectedList(tableName,
					"string");
			List<String> wordFields = new LinkedList<String>();
			for (String str : tmpWordFields) {
				if (!chineseFields.contains(str))
					wordFields.add(str);
			}
			if (wordFields.size() > 0)
				tableMaps.put(tableName + "#word", wordFields);
		}
		return tableMaps;
	}

	public static String queryJson(Map<String, Object> queryMap, int from,
			int size) {
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("query", queryMap);
		result.put("from", from);
		result.put("size", size);
		// List<Map<String, Object>> sortFields = new ArrayList<Map<String,
		// Object>>();
		List<Object> sortFields = new ArrayList<Object>();
		Map<String, Object> tmp1 = new HashMap<String, Object>();
		tmp1.put("_type", "asc");
		sortFields.add(tmp1);
		Map<String, Object> tmp2 = new HashMap<String, Object>();
		tmp2.put("_sortdate", "asc");
		sortFields.add(tmp2);
		// sortFields.add("_score");
		result.put("sort", sortFields);
		// result.put("track_scores", true);
		result.put("highlight", createHighLigthQuery());
		try {
			String json = mapper.writeValueAsString(result);
			return json;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}

	public static Map<String, Object> createHighLigthQuery() {
		Map<String, List<String>> fieldsMap = TaxFinalVal.fieldsMap();
		Set<String> set = new TreeSet<String>();
		for (String specialField : fieldsMap.keySet()) {
			String[] strs = specialField.split("#");
			String tableName = strs[0];
			if (!tableName.startsWith("A"))
				continue;
			String type = strs[1];
			if (type.equals("chinese")) {
				List<String> chineseFields = fieldsMap.get(specialField);
				for (String str : chineseFields)
					set.add(tableName + "." + str);
			} else if (type.equals("word")) {
				List<String> stringFields = fieldsMap.get(specialField);
				for (String field : stringFields) {
					String realField = tableName + "." + field;
					// log.info("haha " + realField);
					if (TaxFinalVal.relationMap().containsKey(realField))
						set.add(realField);
				}
			}
		}
		String[] strs = new String[set.size()];
		Iterator<String> iter = set.iterator();
		int i = 0;
		while (iter.hasNext()) {
			String str = iter.next();
			strs[i] = str;
			i++;
		}
		return SoulQueryUtil.createHighLigthQuery(strs);
	}

	public static Map<String, Object> mappingMap(String... tableList) {
		Map<String, Object> map1 = new LinkedHashMap<String, Object>();
		Map<String, Object> map2 = new LinkedHashMap<String, Object>();
		map1.put("type", "string");
		map1.put("index", "not_analyzed");
		map2.put("type", "string");
		map2.put("index_analyzer", "tax_index");
		map2.put("search_analyzer", "tax_query");
		Map<String, Object> map3 = new LinkedHashMap<String, Object>();
		Map<String, Object> map4 = new LinkedHashMap<String, Object>();
		map3.put("type", "integer");
		map4.put("type", "float");
		Map<String, Object> map5 = new LinkedHashMap<String, Object>();
		map5.put("type", "string");
		map5.put("index_analyzer", "tax_date");
		map5.put("search_analyzer", "tax_date");
		Map<String, Map<String, Object>> defMaps = TaxFinalVal.defMap();

		Map<String, List<String>> tableMaps = createFieldsMap(tableList);
		Set<String> tables = new TreeSet<String>();
		for (String str : tableMaps.keySet()) {
			String[] strs = str.split("#");
			tables.add(strs[0]);
		}
		Map<String, Object> typeMap = new LinkedHashMap<String, Object>();

		for (String tableName : tables) {
			Map<String, Object> defMap = (Map<String, Object>) defMaps
					.get(tableName);
			List<String> fields1 = tableMaps.get(tableName + "#chinese");
			List<String> fields2 = tableMaps.get(tableName + "#integer");
			List<String> fields3 = tableMaps.get(tableName + "#float");
			List<String> dateFields = tableMaps.get(tableName + "#date");
			List<String> dateTimeFields = tableMaps
					.get(tableName + "#datetime");
			Map<String, Object> tmpMap = new LinkedHashMap<String, Object>();

			Map<String, String> relationMap = TaxFinalVal.relationMap();
			// add inner field to sort based on date
			tmpMap.put(TaxFinalVal.sortDate, map1);
			for (String field : defMap.keySet()) {
				String realField = tableName + "." + field;
				if (relationMap.containsKey(realField)) {
					tmpMap.put(realField, map2);
					continue;
				}
				if (fields1 != null && fields1.contains(field)) {
					tmpMap.put(tableName + "." + field, map2);
				} else if (fields2 != null && fields2.contains(field)) {
					tmpMap.put(tableName + "." + field, map3);
				} else if (fields3 != null && fields3.contains(field)) {
					tmpMap.put(tableName + "." + field, map4);
				} else if (dateFields != null && dateFields.contains(field)) {
					tmpMap.put(tableName + "." + field, map5);
				} else if (dateTimeFields != null
						&& dateTimeFields.contains(field)) {
					tmpMap.put(tableName + "." + field, map5);
				} else
					tmpMap.put(tableName + "." + field, map1);
			}
			Map<String, Object> propertiesMap = new LinkedHashMap<String, Object>();
			propertiesMap.put("properties", tmpMap);
			typeMap.put(tableName, propertiesMap);
		}
		return typeMap;
	}

	public static Map<String, Object> queryMapWithFilter(
			Map<String, Object> queryMap, String tableName) {
		Map<String, Object> filter = new HashMap<String, Object>();
		Map<String, Object> tmp1 = new HashMap<String, Object>();
		tmp1.put("value", tableName);
		filter.put("type", tmp1);
		Map<String, Object> query = new HashMap<String, Object>();
		query.put("query", queryMap);
		Map<String, Object> filteredQuery = new HashMap<String, Object>();
		filteredQuery.put("query", queryMap);
		filteredQuery.put("filter", filter);
		Map<String, Object> tmp2 = new HashMap<String, Object>();
		tmp2.put("filtered", filteredQuery);
		return tmp2;
	}

}
