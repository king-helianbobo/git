package com.elasticsearch.tax;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.map.ObjectMapper;

public class NewTaxUtil {
	private static ObjectMapper mapper = new ObjectMapper();
	private static final Log log = LogFactory.getLog(NewTaxUtil.class);

}
