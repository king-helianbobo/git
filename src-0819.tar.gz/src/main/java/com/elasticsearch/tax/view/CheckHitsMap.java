package com.elasticsearch.tax.view;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.elasticsearch.query.SoulQueryUtil;
import com.elasticsearch.tax.ESMapUtility;
import com.elasticsearch.tax.TaxFinalVal;
import com.elasticsearch.tax.TaxPojo;
import com.elasticsearch.tax.TaxPostFilter;
import com.splitword.soul.utility.StringUtil;

public class CheckHitsMap {
	private static final Log log = LogFactory.getLog(CheckHitsMap.class);

	@SuppressWarnings("unchecked")
	private static Map<String, Object> convertSourceMap(
			Map<String, Object> sourceMap) {
		Map<String, Object> map = new LinkedHashMap<String, Object>();
		for (String key : sourceMap.keySet()) {

			String value = (String) sourceMap.get(key);
			if (StringUtil.isBlank(value))
				continue;
			if (key.equals(TaxFinalVal.sortDate))
				continue;
			else if (TaxFinalVal.relationMap().containsKey(key)) {
				String[] strs = value.split("\t");
				value = strs[1];
				map.put(key, strs[1]);
				// log.info(value + "," + strs[1]);
			} else
				map.put(key, value);
		}
		return map;
	}

	@SuppressWarnings("unchecked")
	private static Map<String, Object> convertHighlightMap(
			Map<String, Object> lightMap, Map<String, Object> sourceMap) {
		Map<String, Object> map = new LinkedHashMap<String, Object>();
		for (String key : lightMap.keySet()) {
			if (TaxFinalVal.relationMap().containsKey(key)) {
				List<String> tmpList = (List<String>) lightMap.get(key);
				String value = tmpList.get(0);
				String sourceStr = (String) sourceMap.get(key);
				String[] sourceStrings = sourceStr.split("\t");
				String[] lightStrings = value.split("\t");
				// log.info(sourceStr);
				// log.info(value);
				// Assert.assertTrue(sourceStrings.length == 2
				// || sourceStrings.length == 3);
				// Assert.assertTrue(lightStrings.length == 2
				// || lightStrings.length == 3);
				if (lightStrings[0].indexOf(SoulQueryUtil.preTag) >= 0
						&& lightStrings[0].indexOf(SoulQueryUtil.postTag) >= 0)
					map.put(key, SoulQueryUtil.preTag + sourceStrings[1]
							+ SoulQueryUtil.postTag);
				else if (lightStrings.length == 3
						&& (lightStrings[2].indexOf(SoulQueryUtil.preTag) >= 0 && lightStrings[2]
								.indexOf(SoulQueryUtil.postTag) >= 0))
					map.put(key, lightStrings[2]);
				else
					map.put(key, lightStrings[1]);
			} else {
				List<String> tmpList = (List<String>) lightMap.get(key);
				String value = tmpList.get(0);
				map.put(key, value);
			}
		}
		return map;
	}

	// we use LinkedHashMap because it could keep insert order
	@SuppressWarnings("unchecked")
	public static Map<String, Object> checkMap(Map<String, Object> map1,
			List<TaxPojo> pojoList, List<String> greenFields, String mode) {
		Map<String, Object> resultMap = new LinkedHashMap<String, Object>();
		String tableName = (String) map1.get("_type");
		resultMap.put("tableName", TaxFinalVal.tableMap().get(tableName));

		Map<String, Object> sourceMap1 = (Map<String, Object>) map1
				.get("_source");
		Map<String, Object> lightMap1 = (Map<String, Object>) map1
				.get("highlight");
		Map<String, Object> lightMap = null;
		Map<String, Object> sourceMap = convertSourceMap(sourceMap1);
		if (lightMap1 != null) {
			lightMap = convertHighlightMap(lightMap1, sourceMap1);
		}
		List<String> list1 = TaxDisplayFields.displayFields(sourceMap,
				greenFields, tableName, mode);
		int listSize = Integer.valueOf(list1.remove(0));
		Map<String, Object> defMap = TaxFinalVal.defMap().get(tableName);
		for (int i = 0; i < list1.size(); i++) {
			String field = list1.get(i);
			if (mode.equals("person") && field.equals("纳税尊重(个人)")) {
				if (sourceMap.containsKey(TaxFinalVal.realPaid)
						&& sourceMap.containsKey(TaxFinalVal.shouldPaid)) {
					String str1 = (String) sourceMap.get(TaxFinalVal.realPaid);
					String str2 = (String) sourceMap
							.get(TaxFinalVal.shouldPaid);
					boolean bPass = TaxPostFilter.checkPaid(str1, str2);
					if (bPass)
						resultMap.put(field, SoulQueryUtil.preTag + "正常缴纳"
								+ SoulQueryUtil.postTag);
					else
						resultMap.put(field, SoulQueryUtil.preTag + "未缴纳"
								+ SoulQueryUtil.postTag);
					String swglm = (String) sourceMap.get("A10.SWGLM");
					String value1 = TaxFinalVal.respectMap().get(swglm);
					resultMap.put(list1.get(i + 1), SoulQueryUtil.preTag
							+ value1 + SoulQueryUtil.postTag);
				}
				i++;
				continue;
			} else if (mode.equals("company") && field.equals("纳税尊重(企业)")) {
				if (sourceMap.containsKey(TaxFinalVal.realDate)
						&& sourceMap.containsKey(TaxFinalVal.shouldDate)) {
					String str1 = (String) sourceMap.get(TaxFinalVal.realDate);
					String str2 = (String) sourceMap
							.get(TaxFinalVal.shouldDate);
					boolean value = TaxPostFilter.checkDate(str1, str2);
					if (value)
						resultMap.put(field, SoulQueryUtil.preTag + "正常缴纳"
								+ SoulQueryUtil.postTag);
					else
						resultMap.put(field, SoulQueryUtil.preTag + "未缴纳"
								+ SoulQueryUtil.postTag);
				}
				continue;
			}
			Map<String, String> typeInfo = (Map<String, String>) defMap
					.get(field);
			String chineseFieldName = typeInfo.get("chineseFieldName");
			String resultField = tableName + "." + field;
			if (!sourceMap.containsKey(resultField))
				continue;
			String resultStr = (String) sourceMap.get(resultField);
			String anotherStr = null;
			if (lightMap != null && lightMap.containsKey(resultField))
				anotherStr = (String) lightMap.get(resultField);
			else
				anotherStr = ESMapUtility.colorSourceString(resultStr,
						pojoList, "red");
			if (i < listSize)
				resultMap.put(chineseFieldName, anotherStr);
			else {
				// log.info(anotherStr);
				if (!resultStr.equals(anotherStr)) {
					resultMap.put(chineseFieldName, anotherStr);
				}
			}
		}
		return resultMap;
	}
}
