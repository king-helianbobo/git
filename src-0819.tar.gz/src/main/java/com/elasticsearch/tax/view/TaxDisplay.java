package com.elasticsearch.tax.view;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.elasticsearch.tax.TaxFinalVal;
import com.elasticsearch.tax.TaxPojo;

public class TaxDisplay {
	private static final Log log = LogFactory.getLog(TaxDisplay.class);

	@SuppressWarnings("unchecked")
	public static Map<String, Object> pageListMap(
			Map<String, Object> tmpResultMap, List<TaxPojo> pojoList,
			List<String> greenFields, int from, String mode) {
		Map<String, Object> resultMap = (Map<String, Object>) tmpResultMap
				.get("hits");
		if (resultMap == null)
			return null;
		List<Map<String, Object>> hits = (List<Map<String, Object>>) resultMap
				.get("hits");
		Map<String, List<Map<String, Object>>> lastMap = new LinkedHashMap<String, List<Map<String, Object>>>();
		for (int i = 0; i < hits.size(); i++) {
			Map<String, Object> map1 = hits.get(i);
			Map<String, Object> checkedMap = CheckHitsMap.checkMap(map1,
					pojoList, greenFields, mode);
			String tableName = (String) checkedMap.get("tableName");
			List<Map<String, Object>> array = lastMap.get(tableName);
			if (array == null)
				array = new LinkedList<Map<String, Object>>();
			checkedMap.remove("tableName");
			array.add(checkedMap);
			lastMap.put(tableName, array);
		}
		Map<String, List<String>> fieldsMap = getAllFields(lastMap);
		Map<String, List<Map<String, Object>>> pageMap = convertMap(lastMap,
				fieldsMap);

		final String table01 = TaxFinalVal.tableMap().get("A01");
		final String table02 = TaxFinalVal.tableMap().get("A02");

		if (mode.equals("singleCompany") && pageMap.containsKey(table01)
				&& pageMap.containsKey(table02)) {
			Map<String, List<Map<String, Object>>> result = processSingleCompany(
					pageMap, table01, table02);
			pageMap = result;
		}
		return toJsonMap(resultMap, pageMap, from, hits.size());
	}

	private static Map<String, List<Map<String, Object>>> processSingleCompany(
			Map<String, List<Map<String, Object>>> pageMap, String table1,
			String table2) {
		Map<String, List<Map<String, Object>>> resMap = new LinkedHashMap<String, List<Map<String, Object>>>();
		List<Map<String, Object>> mapList1 = pageMap.get(table1);
		List<Map<String, Object>> mapList2 = pageMap.get(table2);
		// Assert.assertEquals(1, mapList1.size());
		// Assert.assertEquals(1, mapList2.size());
		Map<String, Object> map3 = new LinkedHashMap<String, Object>();
		Map<String, Object> map1 = mapList1.get(0);
		Map<String, Object> map2 = mapList2.get(0);
		for (String key : map1.keySet()) {
			// log.info(key + "," + map1.get(key));
			map3.put(key, map1.get(key));
		}
		for (String key : map2.keySet()) {
			// log.info(key + "," + map2.get(key));
			map3.put(key, map2.get(key));
		}
		List<Map<String, Object>> mapList3 = new LinkedList<Map<String, Object>>();
		mapList3.add(map3);
		resMap = new LinkedHashMap<String, List<Map<String, Object>>>();
		resMap.put("登记信息", mapList3);
		for (String table : pageMap.keySet()) {
			if (table.equals(table1) || table.equals(table2))
				continue;
			else
				resMap.put(table, pageMap.get(table));
		}
		return resMap;

	}

	private static Map<String, Object> toJsonMap(Map<String, Object> resultMap,
			Map<String, List<Map<String, Object>>> pageMap, int from, int size) {
		Map<String, Object> result = new LinkedHashMap<String, Object>();
		int totalSize = (Integer) resultMap.get("total");
		result.put("from", from);
		result.put("size", size);
		result.put("count", totalSize);
		result.put("tableSize", pageMap.size());
		List<String> tables = new LinkedList<String>();
		for (String tableName : pageMap.keySet()) {
			tables.add(tableName);
		}
		result.put("tables", tables);
		int i = 1;
		for (String tableName : pageMap.keySet()) {
			String key = "pageList" + String.valueOf(i++);
			result.put(key, pageMap.get(tableName));
		}
		return result;
	}

	private static Map<String, List<String>> getAllFields(
			Map<String, List<Map<String, Object>>> lastMap) {
		Map<String, List<String>> fieldsMap = new LinkedHashMap<String, List<String>>();
		for (String tableName : lastMap.keySet()) {
			List<Map<String, Object>> mapList = lastMap.get(tableName);
			for (int i = 0; i < mapList.size(); i++) {
				List<String> oldList = fieldsMap.get(tableName);
				List<String> newList = fieldList(mapList.get(i));
				if (oldList == null) {
					fieldsMap.put(tableName, newList);
				} else { // merge two list,but keep frequent field ahead
					List<String> common = new LinkedList<String>();
					List<String> mergeList = new LinkedList<String>();

					for (String str : oldList) {
						if (newList.contains(str))
							common.add(str);
					}
					mergeList.addAll(common);
					oldList.addAll(newList);
					for (String str : oldList) {
						if (!mergeList.contains(str))
							mergeList.add(str);
					}
					fieldsMap.put(tableName, mergeList);
				}
			}
		}
		return fieldsMap;
	}

	private static Map<String, List<Map<String, Object>>> convertMap(
			Map<String, List<Map<String, Object>>> map1,
			Map<String, List<String>> fieldsMap) {
		Map<String, List<Map<String, Object>>> pageMap = new LinkedHashMap<String, List<Map<String, Object>>>();
		for (String tableName : map1.keySet()) {
			List<Map<String, Object>> mapList = map1.get(tableName);
			List<String> fieldList = fieldsMap.get(tableName);
			// log.info(fieldList);
			for (int i = 0; i < mapList.size(); i++) {
				Map<String, Object> currentMap = mapList.get(i);
				Map<String, Object> anotherMap = new LinkedHashMap<String, Object>();
				for (String field : fieldList) {
					String value = (String) currentMap.get(field);
					if (value == null)
						anotherMap.put(field, " ");
					else
						anotherMap.put(field, value);
				}
				List<Map<String, Object>> mapList1 = pageMap.get(tableName);
				if (mapList1 == null)
					mapList1 = new LinkedList<Map<String, Object>>();
				mapList1.add(anotherMap);
				pageMap.put(tableName, mapList1);
			}
		}
		return pageMap;
	}

	private static List<String> fieldList(Map<String, Object> map1) {
		List<String> list = new LinkedList<String>();
		for (String key : map1.keySet())
			list.add(key);
		return list;
	}
}
