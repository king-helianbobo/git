package com.soul.kaka.readExcel;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.splitword.lionsoul.jcseg.util.ChineseHelper;

public class FindColFeature {
	private static String fileName = "";

	/**
	 * @param args
	 * @throws IOException
	 * @throws FileNotFoundException
	 */
	public static void main(String[] args) throws FileNotFoundException,
			IOException {
		// TODO Auto-generated method stub
		// System.out.println(allLetter(""));
		String testDataPath = "加工测试数据4";
		listDirectory(testDataPath);
	}

	private static void listDirectory(String path)
			throws FileNotFoundException, IOException {
		File dir = new File(path);
		File file[] = dir.listFiles();
		for (int j = 0; j < file.length; j++) {
			if (file[j].isDirectory()) {
				listDirectory(file[j].getAbsolutePath());
			} else if (file[j].getName().endsWith("xls")) {
				String xlsFileName = file[j].getName();
				fileName = xlsFileName.substring(0, xlsFileName.length() - 4);
				FileOutputStream xlsColFeaOut = new FileOutputStream(
						"zhouqiOutput/taxColFeature/" + fileName + ".txt");
				BufferedWriter xlsColFeaBw = new BufferedWriter(
						new OutputStreamWriter(xlsColFeaOut, "UTF-8"));
				String[][] excelRowCol = ExtractExcelDataKaka.getData(file[j],
						0);
				findColFeature(excelRowCol, xlsColFeaBw);

				xlsColFeaBw.flush();

				try {
					if (xlsColFeaOut != null) {
						xlsColFeaOut.close();
					}
					if (xlsColFeaBw != null) {
						xlsColFeaBw.close();
					}
				} catch (IOException e) {
					e.printStackTrace();
				}

			} else {
				// do nothing;
				System.out.println("do nothing");
			}
		}
	}

	private static void findColFeature(String[][] excelRowCol,
			BufferedWriter xlsColFeaBw) throws IOException {

		for (int j = 0; j < excelRowCol[0].length; j++) {
			if (excelRowCol[2][j].equals("string")) {
				stringColFeature(excelRowCol, xlsColFeaBw, j);
			} else if (excelRowCol[2][j].equals("integer")) {
				intColFeature(excelRowCol, xlsColFeaBw, j);
			} else if (excelRowCol[2][j].equals("float")) {
				floatColFeatrue(excelRowCol, xlsColFeaBw, j);
			} else {
				continue;
			}

		}
	}

	private static void floatColFeatrue(String[][] excelRowCol,
			BufferedWriter xlsColFeaBw, int j) throws IOException {
		float min = 0.0f;
		float max = 0.0f;
		for (int i = 3; i < excelRowCol.length; i++) {
			String tempStr = excelRowCol[i][j];
			if (tempStr == null || tempStr == "") {
				continue;
			}
			float tempFlo = Float.valueOf(tempStr).floatValue();
			if (tempFlo > max) {
				max = tempFlo;
			}
			if (tempFlo < min) {
				min = tempFlo;
			}
		}

		String colName = excelRowCol[0][j] + "(" + excelRowCol[1][j] + "--"
				+ excelRowCol[2][j] + ")";
		String colFeature = colName + "的特征是: " + "最大值为" + max + "\t" + "最小值为"
				+ min + "\n";
		xlsColFeaBw.append(colFeature);
	}

	private static void intColFeature(String[][] excelRowCol,
			BufferedWriter xlsColFeaBw, int j) throws IOException {
		List<String> columnList = new ArrayList<String>();
		Map<String, Integer> columnMap = new HashMap<String, Integer>();
		for (int i = 3; i < excelRowCol.length; i++) {
			String tempStr = excelRowCol[i][j];
			columnList.add(tempStr);
			Integer count = columnMap.get(tempStr);
			if (count == null) {
				columnMap.put(tempStr, 1);
			} else {
				columnMap.put(tempStr, count + 1);
			}
		}
		int colListSize = columnList.size();
		int colMapSize = columnMap.size();

		if (colMapSize<=5 || colMapSize * 1.0 / colListSize <= 0.2) {
			String colName = excelRowCol[0][j] + "(" + excelRowCol[1][j] + "--"
					+ excelRowCol[2][j] + ")";
			String colFeature = colName + "的特征是: " + "枚举类型(";
			for (Map.Entry<String, Integer> entry : columnMap.entrySet()) {
				String key = entry.getKey();
				Integer value = entry.getValue();
				if (key == null || key == "") {
					key = "null";
					colFeature = colFeature + key + ":" + value + "\t";
				} else {
					colFeature = colFeature + key + ":" + value + "\t";
				}
			}
			colFeature = colFeature + ")\n";
			xlsColFeaBw.append(colFeature);
		} else {
			int min = 0;
			int max = 0;
			for (int i = 3; i < excelRowCol.length; i++) {
				String tempStr = excelRowCol[i][j];
				if (tempStr == null || tempStr == "") {
					continue;
				}
				int tempFlo = Integer.valueOf(tempStr).intValue();
				if (tempFlo > max) {
					max = tempFlo;
				}
				if (tempFlo < min) {
					min = tempFlo;
				}
			}
			String colName = excelRowCol[0][j] + "(" + excelRowCol[1][j] + "--"
					+ excelRowCol[2][j] + ")";
			String colFeature = colName + "的特征是: " + "最大值为" + max + "\t"
					+ "最小值为" + min + "\n";
			xlsColFeaBw.append(colFeature);
		}
	}

	private static void stringColFeature(String[][] excelRowCol,
			BufferedWriter xlsColFeaBw, int j) throws IOException {
		List<String> columnList = new ArrayList<String>();
		Map<String, Integer> columnMap = new HashMap<String, Integer>();
		for (int i = 3; i < excelRowCol.length; i++) {
			String tempStr = excelRowCol[i][j];
			columnList.add(tempStr);
			Integer count = columnMap.get(tempStr);
			if (count == null) {
				columnMap.put(tempStr, 1);
			} else {
				columnMap.put(tempStr, count + 1);
			}
		}

		int flag = 0;
		int numAll = 0;
		int letterAll = 0;
		int colListSize = columnList.size();
		int colMapSize = columnMap.size();

		for (int i = 3; i < excelRowCol.length; i++) {
			String tempStr = excelRowCol[i][j];
			if (ChineseHelper.containChineseChar(tempStr)) {
				flag = 1;
				break;
			} else {
				if (ChineseHelper.allNumerical(tempStr)) {
					numAll++;
				} else if (allLetter(tempStr)) {
					letterAll++;
				}
			}
		}

		if (flag == 0) {
			if (numAll == colListSize) {
				flag = 2;
			} else if (letterAll == colListSize) {
				flag = 3;
			} else {
				flag = 4;
			}
		}

		switch (flag) {
		case 1: {
			String colName = excelRowCol[0][j] + "(" + excelRowCol[1][j] + "--"
					+ excelRowCol[2][j] + ")";
			String colFeature = colName + "的特征是: 列中某一行中存在汉字字符\n";
			xlsColFeaBw.append(colFeature);
			break;
		}
		case 2: {
			if (colMapSize<=5 || colMapSize * 1.0 / colListSize <= 0.2) {
				String colName = excelRowCol[0][j] + "(" + excelRowCol[1][j]
						+ "--" + excelRowCol[2][j] + ")";
				String colFeature = colName + "的特征是:全是数字,且是枚举类型(";
				for (Map.Entry<String, Integer> entry : columnMap.entrySet()) {
					String key = entry.getKey();
					Integer value = entry.getValue();
					if (key == null || key == "") {
						key = "null";
						colFeature = colFeature + key + ":" + value + "\t";
					} else {
						colFeature = colFeature + key + ":" + value + "\t";
					}
				}
				colFeature = colFeature + ")\n";
				xlsColFeaBw.append(colFeature);
			} else {
				long min = 0;
				long max = 0;
				for (int i = 3; i < excelRowCol.length; i++) {
					String tempStr = excelRowCol[i][j];
					if (tempStr == null || tempStr == "") {
						continue;
					}
					long tempFlo = Long.valueOf(tempStr).longValue();
					if (tempFlo > max) {
						max = tempFlo;
					}
					if (tempFlo < min) {
						min = tempFlo;
					}
				}
				String colName = excelRowCol[0][j] + "(" + excelRowCol[1][j]
						+ "--" + excelRowCol[2][j] + ")";
				String colFeature = colName + "的特征是:全是数字,但不是枚举类型, " + "最大值为"
						+ max + "\t" + "最小值为" + min + "\n";
				xlsColFeaBw.append(colFeature);
			}
			break;
		}

		case 3: {
			if (colMapSize<=5 || colMapSize * 1.0 / colListSize <= 0.2) {
				String colName = excelRowCol[0][j] + "(" + excelRowCol[1][j]
						+ "--" + excelRowCol[2][j] + ")";
				String colFeature = colName + "的特征是:全是字母,且是枚举类型(";
				for (Map.Entry<String, Integer> entry : columnMap.entrySet()) {
					String key = entry.getKey();
					Integer value = entry.getValue();
					if (key == null || key == "") {
						key = "null";
						colFeature = colFeature + key + ":" + value + "\t";
					} else {
						colFeature = colFeature + key + ":" + value + "\t";
					}
				}
				colFeature = colFeature + ")\n";
				xlsColFeaBw.append(colFeature);
			} else {
				String colName = excelRowCol[0][j] + "(" + excelRowCol[1][j]
						+ "--" + excelRowCol[2][j] + ")";
				String colFeature = colName + "的特征是:全是字母,但不是枚举类型\n";
				xlsColFeaBw.append(colFeature);
			}
			break;
		}

		case 4: {
			if (colMapSize<=5 || colMapSize * 1.0 / colListSize <= 0.2) {
				String colName = excelRowCol[0][j] + "(" + excelRowCol[1][j]
						+ "--" + excelRowCol[2][j] + ")";
				String colFeature = colName + "的特征是:数字与字母交替存在,且是枚举类型(";
				for (Map.Entry<String, Integer> entry : columnMap.entrySet()) {
					String key = entry.getKey();
					Integer value = entry.getValue();
					if (key == null || key == "") {
						key = "null";
						colFeature = colFeature + key + ":" + value + "\t";
					} else {
						colFeature = colFeature + key + ":" + value + "\t";
					}
				}
				colFeature = colFeature + ")\n";
				xlsColFeaBw.append(colFeature);
			} else {
				String colName = excelRowCol[0][j] + "(" + excelRowCol[1][j]
						+ "--" + excelRowCol[2][j] + ")";
				String colFeature = colName + "的特征是:数字与字母交替存在,且不是枚举类型\n";
				xlsColFeaBw.append(colFeature);
			}
			break;
		}

		default:
			String colName = excelRowCol[0][j] + "(" + excelRowCol[1][j] + "--"
					+ excelRowCol[2][j] + ")";
			String colFeature = colName + "的特征是: 列中某一行中存在其他情况\n";
			xlsColFeaBw.append(colFeature);
		}
	}

	// 判断字符串是否全是字母
	public static boolean allLetter(String str) {
		for (int i = str.length(); --i >= 0;) {
			if (!Character.isLetter(str.charAt(i))) {
				return false;
			}
		}
		return true;
	}
}
