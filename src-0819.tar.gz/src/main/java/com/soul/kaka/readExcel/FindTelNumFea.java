package com.soul.kaka.readExcel;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

public class FindTelNumFea {
	private static String fileName = "";
	
	public static void main(String[] args) throws FileNotFoundException, IOException {
		String testDataPath = "加工测试数据4";
		listDirectory(testDataPath);
	}
	
	private static void listDirectory(String path)
			throws FileNotFoundException, IOException {
		File dir = new File(path);
		File file[] = dir.listFiles();
		for (int j = 0; j < file.length; j++) {
			if (file[j].isDirectory()) {
				listDirectory(file[j].getAbsolutePath());
			} else if (file[j].getName().endsWith("xls")) {
				String xlsFileName = file[j].getName();
				fileName = xlsFileName.substring(0, xlsFileName.length() - 4);
				FileOutputStream xlsColFeaOut = new FileOutputStream(
						"zhouqiOutput/taxColFeaImpro/" + fileName + ".txt");
				BufferedWriter xlsColFeaBw = new BufferedWriter(
						new OutputStreamWriter(xlsColFeaOut, "UTF-8"));
				String[][] excelRowCol = ExtractExcelDataKaka.getData(file[j],
						0);
				findTelNumFea(excelRowCol, xlsColFeaBw);

				xlsColFeaBw.flush();

				try {
					if (xlsColFeaOut != null) {
						xlsColFeaOut.close();
					}
					if (xlsColFeaBw != null) {
						xlsColFeaBw.close();
					}
				} catch (IOException e) {
					e.printStackTrace();
				}

			} else {
				System.out.println("do nothing");
			}
		}
	}
	
	private static void findTelNumFea(String[][] excelRowCol,
			BufferedWriter xlsColFeaBw) throws IOException {

		for (int j = 0; j < excelRowCol[0].length; j++) {
			if (excelRowCol[2][j].equals("string")) {
				
			}
			System.out.println(excelRowCol[1][j]);
		}
	}

}
