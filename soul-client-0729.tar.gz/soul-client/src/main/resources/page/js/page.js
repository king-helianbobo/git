function pageT(v, n, f) {
	//alert(n);
	$
			.ajax({
				type : 'POST',
				url : '../?method=mypage&nature=true',
				data : 'input=' + v + '&&from=' + parseInt(n - 1) * 8
						+ '&&size=8&&tagType=tag' + parseInt(f + 1) + '',
				success : function(data) {
					var obj = '';
					var time;
					var t = 1;
					var flag = '';
					document.getElementById('tabInfoDiv').innerHTML = '';
					var jsonobj = eval('(' + data + ')');
					var currentPage = jsonobj.from;
					
					for (var i = 0; i < jsonobj.pageList.length; i++) {
						var temp = '';
						temp+=EnumaKey(jsonobj.pageList[i],temp);
						obj+=temp;
					}
					
					obj += '<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp</span>';
					if (n > 1) {
						obj += '<span style=cursor:pointer; onclick=pages_prev('
								+ '"'
								+ v
								+ '"'
								+ ','
								+ n
								+ ','
								+ f
								+ ')><<上一页&nbsp;</span>';
					}
					if (n > 5) {
						for (var i = (n - 4); i < n; i++) {
							pg = '<Font color=red>' + i + '</font>';
							obj += '<a style=cursor:pointer onclick=javascript:pageT('
								+ '"'
								+ v
								+ '"'
								+ ','
								+ i
								+ ','
								+ f
								+ ');>['
								+ pg + ']</a>&nbsp;';
						}
						pg = '<Font color=black>' + n + '</font>';
						obj += '<a style=cursor:pointer onclick=javascript:pageT('
							+ '"'
							+ v
							+ '"'
							+ ','
							+ n
							+ ','
							+ f
							+ ');>['
							+ pg + ']</a>&nbsp;';
						
						var tempFlag = Math.ceil(jsonobj.count / size) - n;
						var maxSize;
						
						if(tempFlag >= 3)
							maxSize = n + 3;
						else
							maxSize = Math.ceil(jsonobj.count / size);
						
						for (var i = n + 1; i <= maxSize; i++) {
							pg = '<Font color=red>' + i + '</font>';
							obj += '<a style=cursor:pointer onclick=javascript:pageT('
								+ '"'
								+ v
								+ '"'
								+ ','
								+ i
								+ ','
								+ f
								+ ');>['
								+ pg + ']</a>&nbsp;';
						}
					} else {
						var tempSize = Math.ceil(jsonobj.count / size);
						var tempSize_1;
						
						if(tempSize >=8)
							tempSize_1 = size;
						else
							tempSize_1 = tempSize;
						
							for (var i = 1; i <= tempSize_1; i++) {
								if (i == n)
									pg = '<Font color=black>' + i + '</font>';
								else
									pg = '<Font color=red>' + i + '</font>';

								obj += '<a style=cursor:pointer onclick=javascript:pageT('
									+ '"'
									+ v
									+ '"'
									+ ','
									+ i
									+ ','
									+ f
									+ ');>['
									+ pg + ']</a>&nbsp;'
							}
					}
					
					if (n != Math.ceil(jsonobj.count / size))
						obj += '<span style=cursor:pointer onclick=pages_next('
								+ '"' + v + '"' + ',' + n + ',' + f
								+ ')>下一页>></span>';
					document.getElementById('tabInfoDiv').innerHTML = obj
				}
			});
}
function pages_next(v, n, f) {
	//alert(n);
	$
			.ajax({
				type : 'POST',
				url : '../?method=mypage&nature=true',
				data : 'input=' + v + '&&from=' + parseInt((n-1) * 8 + 8)
						+ '&&size=8&&tagType=tag' + parseInt(f + 1) + '',
				success : function(data) {
					var obj = '';
					var time;
					var t = 1;
					var flag = '';
					document.getElementById('tabInfoDiv').innerHTML = '';
					var jsonobj = eval('(' + data + ')');
					var currentPage = jsonobj.from;
					obj+="<div style=text-align:left;>搜索结果(共<Font color=red>" + Math.ceil(jsonobj.count) + 
					"</font>条记录)"+
							"<p>";
					
					for (var i = 0; i < jsonobj.pageList.length; i++) {
						var temp = '';
						temp+=EnumaKey(jsonobj.pageList[i],temp);
						obj+=temp;
					}
					
					if (flag < Math.ceil(jsonobj.count / size))
						flag = n + 1;
					obj += '<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp</span>';
					if (flag > 1)
						obj += '<span style=cursor:pointer; onclick=pages_prev('
								+ '"'
								+ v
								+ '"'
								+ ','
								+ flag
								+ ','
								+ f
								+ ')><<上一页&nbsp;</span>';

					var pg;
					if (flag > 5) {
						for (var i = (flag - 4); i < flag; i++) {
							pg = '<Font color=red>' + i + '</font>';
							obj += '<a style=cursor:pointer onclick=javascript:pageT('
									+ '"'
									+ v
									+ '"'
									+ ','
									+ i
									+ ','
									+ f
									+ ');>[' + pg + ']</a>&nbsp;'

						}
						pg = '<Font color=black>' + flag + '</font>';
						obj += '<a style=cursor:pointer onclick=javascript:pageT('
								+ '"'
								+ v
								+ '"'
								+ ','
								+ i
								+ ','
								+ f
								+ ');>['
								+ pg + ']</a>&nbsp;'

						var tempFlag = Math.ceil(jsonobj.count / size) - flag;
						var maxSize;
						
						if(tempFlag >= 3)
							maxSize = flag + 3;
						else
							maxSize = Math.ceil(jsonobj.count / size);
						for (var i = flag + 1; i <= maxSize; i++) {
							pg = '<Font color=red>' + i + '</font>';
							obj += '<a style=cursor:pointer onclick=javascript:pageT('
									+ '"'
									+ v
									+ '"'
									+ ','
									+ i
									+ ','
									+ f
									+ ');>[' + pg + ']</a>&nbsp;'
						}
					} else {
						var tempSize = Math.ceil(jsonobj.count / size);
						var tempSize_1;
						
						if(tempSize >=8)
							tempSize_1 = size;
						else
							tempSize_1 = tempSize;
						
						for (var i = 1; i <= tempSize_1; i++) {
							if (i == flag)
								pg = '<Font color=black>' + i + '</font>';
							else
								pg = '<Font color=red>' + i + '</font>';

							obj += '<a style=cursor:pointer onclick=javascript:pageT('
									+ '"'
									+ v
									+ '"'
									+ ','
									+ i
									+ ','
									+ f
									+ ');>[' + pg + ']</a>&nbsp;'
						}
					}

					if (flag < Math.ceil(jsonobj.count / size))
						obj += '<span style=cursor:pointer onclick=pages_next('
								+ '"' + v + '"' + ',' + flag + ',' + f
								+ ')>下一页>></span>';

					document.getElementById('tabInfoDiv').innerHTML = obj
				}
			});
}
function pages_prev(v, n, f) {
	//alert(n);
	$
			.ajax({
				type : 'POST',
				url : '../?method=mypage&nature=true',
				data : 'input=' + v + '&&from=' + parseInt((n-1)*8 - 8)
						+ '&&size=8&&tagType=tag' + parseInt(f + 1) + '',
				success : function(data) {
					var obj = '';
					var time;
					var t = 1;
					var flag = '';
					document.getElementById('tabInfoDiv').innerHTML = '';
					var jsonobj = eval('(' + data + ')');
					var currentPage = jsonobj.from;
					obj+="<div style=text-align:left;>搜索结果(共<Font color=red>" + Math.ceil(jsonobj.count) + 
					"</font>条记录)"+
							"<p>";
					
					for (var i = 0; i < jsonobj.pageList.length; i++) {
						var temp = '';
						temp+=EnumaKey(jsonobj.pageList[i],temp);
						obj+=temp;
					}
					
					obj += '<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp</span>';
					//if (flag < Math.ceil(jsonobj.count / size))
						flag = n - 1;
					if (flag > 1) {
						obj += '<span style=cursor:pointer; onclick=pages_prev('
								+ '"'
								+ v
								+ '"'
								+ ','
								+ flag
								+ ','
								+ f
								+ ')><<上一页&nbsp;</span>';
					}

					//flag = n - 1;
					var pg;
					if (flag < 6) {
						var tempSize = Math.ceil(jsonobj.count / size);
						var tempSize_1;
						
						if(tempSize >=8)
							tempSize_1 = size;
						else
							tempSize_1 = tempSize;
						
						for (var i = 1; i <= tempSize_1; i++) {
							if (i == flag)
								pg = '<Font color=black>' + i + '</font>';
							else
								pg = '<Font color=red>' + i + '</font>';

							obj += '<a style=cursor:pointer onclick=javascript:pageT('
									+ '"'
									+ v
									+ '"'
									+ ','
									+ i
									+ ','
									+ f
									+ ');>[' + pg + ']</a>&nbsp;'
						}
					} else {
						for (var i = (flag - 4); i < flag; i++) {
							pg = '<Font color=red>' + i + '</font>';
							obj += '<a style=cursor:pointer onclick=javascript:pageT('
									+ '"'
									+ v
									+ '"'
									+ ','
									+ i
									+ ','
									+ f
									+ ');>[' + pg + ']</a>&nbsp;'
						}
						pg = '<Font color=black>' + flag + '</font>';
						obj += '<a style=cursor:pointer onclick=javascript:pageT('
								+ '"'
								+ v
								+ '"'
								+ ','
								+ i
								+ ','
								+ f
								+ ');>['
								+ pg + ']</a>&nbsp;'
								
								var tempFlag = Math.ceil(jsonobj.count / size) - flag;
								var maxSize;
								
								if(tempFlag >= 3)
									maxSize = flag + 3;
								else
									maxSize = Math.ceil(jsonobj.count / size);
								
						for (var i = flag + 1; i <= maxSize; i++) {
							pg = '<Font color=red>' + i + '</font>';
							obj += '<a style=cursor:pointer onclick=javascript:pageT('
									+ '"'
									+ v
									+ '"'
									+ ','
									+ i
									+ ','
									+ f
									+ ');>[' + pg + ']</a>&nbsp;'
						}
					}
					if (flag != Math.ceil(jsonobj.count / size))
						obj += '<span style=cursor:pointer onclick=pages_next('
								+ '"' + v + '"' + ',' + flag + ',' + f
								+ ')>下一页>></span>';

					document.getElementById('tabInfoDiv').innerHTML = obj
				}
			});
}
