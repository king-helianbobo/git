package com.elasticsearch.application.client;

import java.io.Closeable;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.httpclient.HostConfiguration;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.URI;
import org.apache.commons.httpclient.params.HttpClientParams;
import org.apache.commons.httpclient.params.HttpConnectionManagerParams;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.ObjectMapper;

import com.elasticsearch.application.TaxDataReader;
import com.elasticsearch.application.query.PostQuery;
import com.elasticsearch.application.query.SoulQueryUtil;

public class TaxHttpClient implements Closeable {

	protected String url = null;
	protected String index = null;
	private static ObjectMapper mapper = new ObjectMapper();
	protected PostQuery postQuery = null;
	private static final Log log = LogFactory.getLog(TaxHttpClient.class);

	public static Map<String, Map<String, Object>> tableDefMap = null;
	public static Map<String, Map<String, List<String>>> tableFieldsMap = null;
	public static Map<String, String> tableNamesMap = null;
	static {
		try {
			tableDefMap = TaxDataReader.readDefData("liuboOutput/def.txt");
			tableNamesMap = TaxDataReader.readDefData2("liuboOutput/table.txt");
			tableFieldsMap = TaxQueryUtil.generateList();
			log.info("resultMap.size() = " + tableDefMap.size());
		} catch (JsonParseException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public TaxHttpClient(String url, String index) {
		HttpClientParams params = new HttpClientParams();
		params.setConnectionManagerTimeout(20 * 1000);
		HttpClient client = new HttpClient(params);
		HostConfiguration hostConfig = new HostConfiguration();
		this.url = url;
		this.index = index;
		// this.type = type;
		try {
			hostConfig.setHost(new URI(this.url, false));
		} catch (IOException ex) {
			throw new IllegalArgumentException("Invalid target URI " + url, ex);
		}
		client.setHostConfiguration(hostConfig);
		HttpConnectionManagerParams connectionParams = client
				.getHttpConnectionManager().getParams();
		// make sure to disable Nagle's protocol
		connectionParams.setTcpNoDelay(true);
		this.postQuery = new PostQuery(client);
	}

	protected List<Map<String, Object>> primeTokenList(String queryStr) {
		String query = index + "/_analyze?analyzer=soul_query_nature&pretty";
		Map<String, Object> map = postQuery.post(query, queryStr);
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> tokenMaps = (List<Map<String, Object>>) map
				.get("tokens");
		return tokenMaps;
	}

	protected Map<Integer, List<Map<String, Object>>> secondTokenList(
			List<Map<String, Object>> tokenMaps) {
		Map<Integer, List<Map<String, Object>>> posMaps = new HashMap<Integer, List<Map<String, Object>>>();
		for (int i = 0; i < tokenMaps.size(); i++) {
			Map<String, Object> tmp = tokenMaps.get(i);
			String type = (String) tmp.get("type");
			int position = (Integer) tmp.get("position");
			if (type.equals("null") || type.equals("w"))
				continue;
			List<Map<String, Object>> mapList = posMaps.get(position);
			if (mapList == null)
				mapList = new LinkedList<Map<String, Object>>();
			mapList.add(tmp);
			posMaps.put(position, mapList);
		}
		if (posMaps.isEmpty())
			return null;
		else {
			Map<Integer, List<Map<String, Object>>> result = new HashMap<Integer, List<Map<String, Object>>>();
			Set<String> set = new HashSet<String>();
			for (Integer pos : posMaps.keySet()) {
				List<Map<String, Object>> list = posMaps.get(pos);
				String key = (String) list.get(0).get("token");
				if (!set.contains(key)) {
					set.add(key);
					result.put(pos, list);
				}
			}
			return result;
		}
	}

	@Override
	public void close() {
		postQuery.close();
	}

	private Map<String, Object> termQueryMap(String token, String tableName) {
		Map<String, Object> defMap = tableDefMap.get(tableName);
		Map<String, List<String>> fieldsMap = tableFieldsMap.get(tableName);

		List<Map<String, Object>> array = new ArrayList<Map<String, Object>>();
		// List<String> chineseFields = null;
		List<String> integerFields = null;
		List<String> floatFields = null;
		// List<String> commonFields = null;

		if (fieldsMap != null) {
			// chineseFields = fieldsMap.get("chinese");
			integerFields = fieldsMap.get("integer");
			floatFields = fieldsMap.get("float");
		}
		for (String field : defMap.keySet()) {
			// if (field.equals("SL"))
			// continue;
			Map<String, Object> map1 = null;
			if (floatFields != null && floatFields.contains(field)) {
				if (ESearchMapUtil.isFloat(token)) {
					log.info("token " + token + " is float");
					map1 = SoulQueryUtil.termQueryMap(tableName + "." + field,
							token);
				} else
					map1 = null;
			} else if (integerFields != null && integerFields.contains(field)) {
				if (ESearchMapUtil.isInteger(token)) {
					map1 = SoulQueryUtil.termQueryMap(tableName + "." + field,
							token);
				} else
					map1 = null;
			} else
				map1 = SoulQueryUtil.termQueryMap(tableName + "." + field,
						token);
			if (map1 != null)
				array.add(map1);
		}
		return SoulQueryUtil.createBooleanQueryMap(array, 1, "all");
	}

	public String taxSearchMultiType(String queryStr, int from, int size) {
		String url = index + "/_search?pretty=true";
		List<Map<String, Object>> primeTokens = primeTokenList(queryStr);
		Map<Integer, List<Map<String, Object>>> tokens = secondTokenList(primeTokens);
		if (tokens == null || tokens.isEmpty())
			return null;
		List<Map<String, Object>> array1 = new ArrayList<Map<String, Object>>();
		for (String tableName : tableDefMap.keySet()) {
			if (!tableFieldsMap.containsKey(tableName))
				continue;
			log.info(tableName);
			List<Map<String, Object>> array = new ArrayList<Map<String, Object>>();
			for (Integer position : tokens.keySet()) {
				List<Map<String, Object>> tmpList = tokens.get(position);
				String token = (String) tmpList.get(0).get("token");
				log.info(token);
				array.add(termQueryMap(token, tableName));
			}
			Map<String, Object> queryMap1 = SoulQueryUtil
					.createBooleanQueryMap(array, array.size(), "all");
			Map<String, Object> queryMap = TaxQueryUtil.queryMapWithFilter(
					queryMap1, tableName);
			array1.add(queryMap);
		}
		Map<String, Object> lastMap = SoulQueryUtil.createBooleanQueryMap(
				array1, 1, "all");
		String json = TaxQueryUtil.queryJson(lastMap, from, size);
		log.info(json);
		// log.info(url);
		Map<String, Object> map = postQuery.post(url, json);
		return constructJsonResult(map, from);
	}

	@SuppressWarnings("unchecked")
	public static String constructJsonResult(Map<String, Object> resultMap,
			int from) {
		try {
			resultMap = (Map<String, Object>) resultMap.get("hits");
			if (resultMap == null)
				return null;
			List<Map<String, Object>> hits = (List<Map<String, Object>>) resultMap
					.get("hits");

			List<Map<String, Object>> array = new ArrayList<Map<String, Object>>();
			for (int i = 0; i < hits.size(); i++) {
				Map<String, Object> map1 = hits.get(i);
				// String map1Json = mapper.writeValueAsString(map1);
				String tableName = (String) map1.get("_type");
				Map<String, List<String>> fieldsMap = tableFieldsMap
						.get(tableName);
				List<String> displayFields = fieldsMap.get("display");
				Map<String, Object> defMap = tableDefMap.get(tableName);
				if (displayFields == null) {
					List<String> tmpList = new LinkedList<String>();
					for (String field : defMap.keySet()) {
						tmpList.add(field);
					}
					displayFields = tmpList;
				}
				Map<String, Object> lightMap = (Map<String, Object>) map1
						.get("highlight");
				Map<String, Object> sourceMap = (Map<String, Object>) map1
						.get("_source");
				Map<String, Object> result2 = new LinkedHashMap<String, Object>();
				// 注意result2是保持顺序的
				result2.put("表名", tableNamesMap.get(tableName));
				for (String field : displayFields) {
					String resultField = tableName + "." + field;
					if (!sourceMap.containsKey(resultField))
						continue;
					String str = (String) sourceMap.get(resultField);
					if (lightMap != null && lightMap.containsKey(resultField)) {
						List<String> tmpList = (List<String>) lightMap
								.get(resultField);
						str = tmpList.get(0);
					}
					Map<String, String> typeInfo = (Map<String, String>) defMap
							.get(field);
					String chineseFieldName = typeInfo.get("chineseFieldName");
					result2.put(chineseFieldName, str);
				}
				if (lightMap != null) {
					for (String resultField : lightMap.keySet()) {
						String[] strs = resultField.split("[.]");
						String field = strs[1];
						if (displayFields.contains(field))
							continue;
						else {
							List<String> tmpList = (List<String>) lightMap
									.get(resultField);
							String str = tmpList.get(0);
							Map<String, String> typeInfo = (Map<String, String>) defMap
									.get(field);
							String chineseFieldName = typeInfo
									.get("chineseFieldName");
							result2.put(chineseFieldName, str);
						}
					}
				}
				array.add(result2);
			}
			Map<String, Object> result = new HashMap<String, Object>();
			int totalSize = (Integer) resultMap.get("total");
			result.put("count", totalSize);
			result.put("size", hits.size());
			result.put("from", from);
			result.put("pageList", array);
			String resultJson = mapper.writeValueAsString(result);
			log.info(resultJson);
			return resultJson;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}
}
