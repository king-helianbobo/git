package com.elasticsearch.application.client;

import java.util.LinkedHashMap;
import java.util.Map;

import com.splitword.soul.utility.StringUtil;

public class ESearchMapUtil {
	public static Map<String, Object> settingMap() {
		Map<String, Object> tmp1 = new LinkedHashMap<String, Object>();
		tmp1.put("refresh_interval", 10);
		tmp1.put("number_of_replicas", 1);
		Map<String, Object> tmp2 = new LinkedHashMap<String, Object>();
		tmp2.put("index", tmp1);
		return tmp2;
	}

	public static Map<String, Object> untouchedMap(String fieldName,
			String analyzer) {
		Map<String, Object> tmp1 = new LinkedHashMap<String, Object>();
		tmp1.put("type", "string");
		tmp1.put("index_analyzer", analyzer);

		Map<String, Object> tmp2 = new LinkedHashMap<String, Object>();
		tmp2.put("type", "string");
		tmp2.put("index", "not_analyzed");

		Map<String, Object> second = new LinkedHashMap<String, Object>();
		second.put(fieldName, tmp1);
		second.put("untouched", tmp2);

		Map<String, Object> first = new LinkedHashMap<String, Object>();
		first.put("type", "multi_field");
		first.put("fields", second);
		return first;
	}

	public static boolean isFloat(String value) {
		if (StringUtil.isBlank(value)) {
			return false;
		}
		Float number = null;
		try {
			number = Float.parseFloat(value);
		} catch (NumberFormatException e) {
			return false;
		}
		if (!value.contains(".")) {
			return false;
		} else if (value.startsWith("0.")) {
			return true;
		} else if (value.startsWith("0"))
			return false;
		else
			return true;

	}

	public static boolean isInteger(String value) {
		if (StringUtil.isBlank(value)) {
			return false;
		}
		Integer number = null;
		try {
			number = Integer.parseInt(value);
		} catch (NumberFormatException e) {
			return false;
		}
		if (String.valueOf(number).equals(value))
			return true;
		else
			return false;
	}

	public static boolean isLong(String value) {
		if (StringUtil.isBlank(value)) {
			return false;
		}
		Long number = null;
		try {
			number = Long.parseLong(value);
		} catch (NumberFormatException e) {
			return false;
		}
		if (String.valueOf(number).equals(value))
			return true;
		else
			return false;
	}
}
