package com.elasticsearch.application.client;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.map.ObjectMapper;

import com.elasticsearch.application.query.SoulQueryUtil;
import com.splitword.soul.utility.StringUtil;

public class TaxQueryUtil {

	private static ObjectMapper mapper = new ObjectMapper();
	private static final Log log = LogFactory.getLog(TaxQueryUtil.class);

	public static Map<String, Map<String, List<String>>> generateList() {
		List<String> tableList = new LinkedList<String>();
		tableList.add("A01");
		tableList.add("A02");
		tableList.add("A03");
		tableList.add("A04");
		tableList.add("A05");
		tableList.add("A06");
		tableList.add("A07");
		tableList.add("A08");
		tableList.add("A09");
		tableList.add("A10");
		tableList.add("B03");

		Set<String> field1 = new HashSet<String>();
		Set<String> field2 = new HashSet<String>();
		Set<String> field3 = new HashSet<String>();
		Set<String> field4 = new HashSet<String>();

		Map<String, Map<String, List<String>>> tableMaps = new LinkedHashMap<String, Map<String, List<String>>>();
		for (String tableName : tableList) {
			List<String> chineseFields = new LinkedList<String>();
			List<String> integerFields = new LinkedList<String>();
			List<String> floatFields = new LinkedList<String>();
			List<String> displayFields = new LinkedList<String>();
			List<String> amendFields = new LinkedList<String>();
			if (tableName.equals("A01")) {
				chineseFields.add("NSR_MC");
				chineseFields.add("ZCDZ");
				chineseFields.add("SJJYDZ");
				displayFields.add("SWGLM");
				displayFields.add("NSR_MC");
				displayFields.add("ZCDZ");
				displayFields.add("SJJYDZ");
				displayFields.add("SCJYDLXDH");
				displayFields.add("NSRZT_DM");
			} else if (tableName.equals("A02")) {
				chineseFields.add("JYFWZY");
				integerFields.add("CYRS");
				integerFields.add("WJRYRS");
				integerFields.add("GTHHRS");
				integerFields.add("GTGGRS");

				floatFields.add("GYTZ_BL");
				floatFields.add("WZTZ_BL");
				floatFields.add("ZZRTZ_BL");

				displayFields.add("SWGLM");

				displayFields.add("ZZJGTYDM");
				displayFields.add("KYSLRQ");
				displayFields.add("SBFS_DM");
				displayFields.add("ZSFS_DM");
				displayFields.add("JKFS_DM");
				amendFields.add("纳税人名称");
			} else if (tableName.equals("B03")) {
				chineseFields.add("MC");
				chineseFields.add("MC_J");
			} else if (tableName.equals("A03")) {
				if (TaxQueryFields.integerList(tableName) != null)
					integerFields = TaxQueryFields.integerList(tableName);
				if (TaxQueryFields.floatList(tableName) != null)
					floatFields = TaxQueryFields.floatList(tableName);
				chineseFields.add("LSNSR_MC");
				displayFields.add("SWGLM");
				displayFields.add("LSNSR_MC");
				displayFields.add("PZ_XH");
				displayFields.add("SFSSQ_QSRQ");
				displayFields.add("SFSSQ_ZZRQ");
				displayFields.add("JK_QX");
				displayFields.add("SB_RQ");
			} else if (tableName.equals("A04")) {
				if (TaxQueryFields.integerList(tableName) != null)
					integerFields = TaxQueryFields.integerList(tableName);
				if (TaxQueryFields.floatList(tableName) != null)
					floatFields = TaxQueryFields.floatList(tableName);
				chineseFields.add("NSR_MC");

				displayFields.add("SWGLM");
				displayFields.add("NSR_MC");
				displayFields.add("PZ_XH");
				displayFields.add("SSQ");
				displayFields.add("ZT");
			} else if (tableName.equals("A05")) {
				if (TaxQueryFields.integerList(tableName) != null)
					integerFields = TaxQueryFields.integerList(tableName);
				if (TaxQueryFields.floatList(tableName) != null)
					floatFields = TaxQueryFields.floatList(tableName);
				chineseFields.add("KP_XM");
				chineseFields.add("SKF_MC");
				chineseFields.add("FKF_MC");

				displayFields.add("FP_DM");
				displayFields.add("KP_XM");
				displayFields.add("JE");
				displayFields.add("KP_RQ");
				displayFields.add("SKF_GLM");
				displayFields.add("SKF_MC");
				displayFields.add("FKF_GLM");
				displayFields.add("FKF_MC");
			} else if (tableName.equals("A06")) {
				if (TaxQueryFields.integerList(tableName) != null)
					integerFields = TaxQueryFields.integerList(tableName);
				if (TaxQueryFields.floatList(tableName) != null)
					floatFields = TaxQueryFields.floatList(tableName);
				chineseFields.add("NSR_MC");

				displayFields.add("SWGLM");
				displayFields.add("NSR_MC");
				displayFields.add("PZ_XH");
				displayFields.add("SSQ");
				displayFields.add("BQS");
				displayFields.add("BNLJS");

			} else if (tableName.equals("A07")) {
				if (TaxQueryFields.integerList(tableName) != null)
					integerFields = TaxQueryFields.integerList(tableName);
				if (TaxQueryFields.floatList(tableName) != null)
					floatFields = TaxQueryFields.floatList(tableName);
				chineseFields.add("NSR_MC");

				displayFields.add("SWGLM");
				displayFields.add("NSR_MC");
				displayFields.add("PZ_XH");
				displayFields.add("SSQ");
				displayFields.add("ZCXM_DM");
				displayFields.add("ZCQCS");
				displayFields.add("ZCQMS");
				displayFields.add("FZXM_DM");
				displayFields.add("FZQCS");
				displayFields.add("FZQMS");
			} else if (tableName.equals("A08")) {
				if (TaxQueryFields.integerList(tableName) != null)
					integerFields = TaxQueryFields.integerList(tableName);
				if (TaxQueryFields.floatList(tableName) != null)
					floatFields = TaxQueryFields.floatList(tableName);
				displayFields.add("SWGLM");
				// displayFields.add("NSR_MC");
				displayFields.add("XH");
				displayFields.add("ZSXM_DM");
				displayFields.add("SBQXR_DM");
				displayFields.add("JKQXR_DM");
				displayFields.add("ZSFS_DM");
				displayFields.add("JS_JE");
				displayFields.add("ZSL");
				displayFields.add("HD_QSRQ");
				displayFields.add("HD_ZZRQ");
			} else if (tableName.equals("A09")) {
				if (TaxQueryFields.integerList(tableName) != null)
					integerFields = TaxQueryFields.integerList(tableName);
				if (TaxQueryFields.floatList(tableName) != null)
					floatFields = TaxQueryFields.floatList(tableName);
				displayFields.add("SWGLM");
				// displayFields.add("NSR_MC");
				displayFields.add("PZ_XH");
				displayFields.add("NSR_MC");
				displayFields.add("SFZHM");
				displayFields.add("HJSRE_JE");
				displayFields.add("SIJMSSRE_JE");
				displayFields.add("YINGNSSDE_JE");
			} else if (tableName.equals("A10")) {
				if (TaxQueryFields.integerList(tableName) != null)
					integerFields = TaxQueryFields.integerList(tableName);
				if (TaxQueryFields.floatList(tableName) != null)
					floatFields = TaxQueryFields.floatList(tableName);
				displayFields.add("SWGLM");
				displayFields.add("XM");
				displayFields.add("ZJH");
				displayFields.add("YD_DH");
				displayFields.add("GJDQ_DM");
			}
			Map<String, List<String>> tmp = new LinkedHashMap<String, List<String>>();
			if (chineseFields.size() > 0) {
				tmp.put("chinese", chineseFields);
				for (String str : chineseFields)
					field1.add(str);
			}
			if (integerFields.size() > 0) {
				tmp.put("integer", integerFields);
				log.info("table:" + tableName + "," + integerFields);
				for (String str : integerFields)
					field2.add(str);
			}
			if (floatFields.size() > 0) {
				tmp.put("float", floatFields);
				log.info("table:" + tableName + "," + floatFields);
				for (String str : floatFields)
					field3.add(str);
			}
			if (displayFields.size() > 0)
				tmp.put("display", displayFields);
			if (tmp.size() > 0) {
				tableMaps.put(tableName, tmp);
			}
		}
		log.info(field1);
		log.info(field2);
		log.info(field3);
		return tableMaps;
	}

	public static String queryJson(Map<String, Object> queryMap, int from,
			int size) {
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("query", queryMap);
		result.put("from", from);
		result.put("size", size);
		// List<Map<String, Object>> sortFields = new ArrayList<Map<String,
		// Object>>();
		List<Object> sortFields = new ArrayList<Object>();
		Map<String, Object> tmp = new HashMap<String, Object>();
		tmp.put("_type", "desc");

		sortFields.add(tmp);
		sortFields.add("_score");
		result.put("sort", sortFields);
		result.put("track_scores", true);

		result.put("highlight", createHighLigthQuery());

		try {
			String json = mapper.writeValueAsString(result);
			return json;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}

	public static Map<String, Object> createHighLigthQuery() {
		// List<String> fileds = new LinkedList<String>();
		Set<String> set = new HashSet<String>();
		for (String tableName : TaxHttpClient.tableDefMap.keySet()) {
			Map<String, Object> tableDef = TaxHttpClient.tableDefMap
					.get(tableName);
			for (String field : tableDef.keySet()) {
				// fileds.add(field);
				set.add(tableName + "." + field);
			}
		}
		// log.info(fileds.size());
		log.info(set.size());
		String[] strs = new String[set.size()];
		Iterator<String> iter = set.iterator();
		int i = 0;
		while (iter.hasNext()) {
			String str = iter.next();
			strs[i] = str;
			i++;
		}

		return SoulQueryUtil.createHighLigthQuery(strs);
	}

	public static Map<String, Object> mappingMap() {

		Map<String, Object> map1 = new LinkedHashMap<String, Object>();
		Map<String, Object> map2 = new LinkedHashMap<String, Object>();
		map1.put("type", "string");
		map1.put("index", "not_analyzed");
		map2.put("type", "string");
		map2.put("index_analyzer", "soul_index");
		map2.put("search_analyzer", "soul_query");
		Map<String, Object> map3 = new LinkedHashMap<String, Object>();
		Map<String, Object> map4 = new LinkedHashMap<String, Object>();
		map3.put("type", "integer");
		map4.put("type", "float");
		Map<String, Map<String, Object>> defMaps = TaxHttpClient.tableDefMap;
		Map<String, Map<String, List<String>>> tableMaps = generateList();
		Map<String, Object> typeMap = new LinkedHashMap<String, Object>();
		for (String tableName : tableMaps.keySet()) {
			Map<String, Object> defMap = (Map<String, Object>) defMaps
					.get(tableName);
			Map<String, List<String>> fieldsMap = tableMaps.get(tableName);
			List<String> fields1 = null;
			List<String> fields2 = null;
			List<String> fields3 = null;
			if (fieldsMap != null) {
				fields1 = fieldsMap.get("chinese");
				fields2 = fieldsMap.get("integer");
				fields3 = fieldsMap.get("float");
			}
			Map<String, Object> tmpMap = new LinkedHashMap<String, Object>();
			for (String field : defMap.keySet()) {
				if (fields1 != null && fields1.contains(field)) {
					tmpMap.put(tableName + "." + field, map2);
				} else if (fields2 != null && fields2.contains(field)) {
					tmpMap.put(tableName + "." + field, map3);
				} else if (fields3 != null && fields3.contains(field)) {
					tmpMap.put(tableName + "." + field, map4);
				} else
					tmpMap.put(tableName + "." + field, map1);
			}
			Map<String, Object> propertiesMap = new LinkedHashMap<String, Object>();
			propertiesMap.put("properties", tmpMap);
			typeMap.put(tableName, propertiesMap);
		}
		return typeMap;
	}

	public static Map<String, Object> queryMapWithFilter(
			Map<String, Object> queryMap, String tableName) {
		Map<String, Object> filter = new HashMap<String, Object>();
		Map<String, Object> tmp1 = new HashMap<String, Object>();
		tmp1.put("value", tableName);
		filter.put("type", tmp1);
		Map<String, Object> query = new HashMap<String, Object>();
		query.put("query", queryMap);
		Map<String, Object> filteredQuery = new HashMap<String, Object>();
		filteredQuery.put("query", queryMap);
		filteredQuery.put("filter", filter);
		Map<String, Object> tmp2 = new HashMap<String, Object>();
		tmp2.put("filtered", filteredQuery);
		return tmp2;
	}
}
