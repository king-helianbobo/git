package com.elasticsearch.application.client;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class TaxQueryFields {

	static public List<String> integerList(String tableName) {
		List<String> integerFields = new LinkedList<String>();
		Map<String, Object> tableDefMap = TaxHttpClient.tableDefMap
				.get(tableName);
		if (tableDefMap != null) {
			for (String field : tableDefMap.keySet()) {
				@SuppressWarnings("unchecked")
				Map<String, String> tmp = (Map<String, String>) tableDefMap
						.get(field);
				String type = tmp.get("dataType");

				if (type.equals("integer"))
					integerFields.add(field);
			}
		}
		if (integerFields.size() > 0)
			return integerFields;
		else
			return null;
	}

	static public List<String> floatList(String tableName) {
		List<String> floatFields = new LinkedList<String>();

		Map<String, Object> tableDefMap = TaxHttpClient.tableDefMap
				.get(tableName);
		if (tableDefMap != null) {
			for (String field : tableDefMap.keySet()) {
				@SuppressWarnings("unchecked")
				Map<String, String> tmp = (Map<String, String>) tableDefMap
						.get(field);
				String type = tmp.get("dataType");

				if (type.equals("float"))
					floatFields.add(field);

			}

		}
		if (floatFields.size() > 0)
			return floatFields;
		else
			return null;
	}
}
