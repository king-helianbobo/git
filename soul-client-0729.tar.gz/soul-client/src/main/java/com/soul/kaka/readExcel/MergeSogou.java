package com.soul.kaka.readExcel;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;

public class MergeSogou {

	private static FileOutputStream sougoSegOut;
	private static BufferedWriter sougoSegBw;
	
	static{
		try{
			sougoSegOut = new FileOutputStream(
					"zhouqiOutput/sougou/mergeSougou.txt");
			sougoSegBw = new BufferedWriter(new OutputStreamWriter(
					sougoSegOut, "UTF-8"));
		}catch(FileNotFoundException | UnsupportedEncodingException e){
			e.printStackTrace();
		}
				
	}
	
	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
        String generalTextPath="zhouqiOutput/sougou/四十万汉语大词库.txt";
        String adminTextPath="zhouqiOutput/sougou/四级行政区划地名词库-ExtractBySoft.txt";
        outputGeneralToTxt(generalTextPath);
		outputAdminToTxt(adminTextPath);
		
		close();
	}
	
	private static void close() throws IOException{
		if(sougoSegOut!=null){
			sougoSegOut.close();
		}
		if(sougoSegBw!=null){
			sougoSegBw.close();
		}
	}
	
	private static void outputAdminToTxt(String adminTextPath)
			throws IOException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				new FileInputStream(adminTextPath), "GB2312"));
		String temp = null;
		while ((temp = reader.readLine()) != null) {
			temp = temp.trim();
			String[] str=temp.split(" ");
			String outStr=str[1].trim()+"\n";
			sougoSegBw.append(outStr);
		}
		reader.close();
		sougoSegBw.flush();
	}
	
	private static void outputGeneralToTxt(String generalTextPath)
			throws IOException {
		BufferedReader reader= new BufferedReader(new InputStreamReader(
				new FileInputStream(generalTextPath), "UTF-8"));
		String temp = null;
		while ((temp = reader.readLine()) != null) {
			temp = temp.trim();
			String outStr =temp+"\n";
			sougoSegBw.append(outStr);
		}
		reader.close();
		sougoSegBw.flush();
	}

}
