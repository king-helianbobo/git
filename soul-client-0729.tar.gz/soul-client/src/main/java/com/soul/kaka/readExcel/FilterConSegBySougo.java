package com.soul.kaka.readExcel;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import com.splitword.soul.utility.StringUtil;

public class FilterConSegBySougo {

	private static FileOutputStream segFilterBySougoOut2;
	private static BufferedWriter segFilterBySougoBw2;
	private static FileOutputStream segFilterBySougoOut3;
	private static BufferedWriter segFilterBySougoBw3;

	static {
		try {
			segFilterBySougoOut2 = new FileOutputStream(
					"zhouqiOutput/official-07-22Result/categorySegFilterBySougo2.txt");
			segFilterBySougoBw2 = new BufferedWriter(new OutputStreamWriter(
					segFilterBySougoOut2, "UTF-8"));

			segFilterBySougoOut3 = new FileOutputStream(
					"zhouqiOutput/official-07-22Result/categorySegFilterBySougo3.txt");
			segFilterBySougoBw3 = new BufferedWriter(new OutputStreamWriter(
					segFilterBySougoOut3, "UTF-8"));
		} catch (FileNotFoundException | UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}

	/**
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		String sougoMergePath = "zhouqiOutput/sougou/mergeSougou.txt";
		String filteredSegPath2 = "zhouqiOutput/official-07-22Result/categorySegFilter2.txt";
		String filteredSegPath3 = "zhouqiOutput/official-07-22Result/categorySegFilter3.txt";
		Set<String> sougoSet = createSougoSet(sougoMergePath);
		
		ArrayList<String> categorySegFilterList2=filterSegBySougo(filteredSegPath2,sougoSet);
		ArrayList<String> categorySegFilterList3=filterSegBySougo(filteredSegPath3,sougoSet);
		
		outPutFilterResultToTxt2(categorySegFilterList2);
		outPutFilterResultToTxt3(categorySegFilterList3);
		
		close();
	}
	
	private static void outPutFilterResultToTxt2(ArrayList<String> list) throws IOException{
		for(String str:list){
			segFilterBySougoBw2.append(str.trim()+"\n");
		}
		segFilterBySougoBw2.flush();
	}

	private static void outPutFilterResultToTxt3(ArrayList<String> list) throws IOException{
		for(String str:list){
			segFilterBySougoBw3.append(str.trim()+"\n");
		}
		segFilterBySougoBw3.flush();
	}
	
	private static ArrayList<String> filterSegBySougo(String filteredSegPath,
			Set<String> sougoSet) throws IOException, FileNotFoundException {
		ArrayList<String> filterList = new ArrayList<String>();

		BufferedReader reader = new BufferedReader(new InputStreamReader(
				new FileInputStream(filteredSegPath), "UTF-8"));
		String temp = null;
		while ((temp = reader.readLine()) != null) {
			temp = temp.trim();
			if (StringUtil.isBlank(temp))
				continue;
			else {
				String[] str = temp.split(":");
                if(sougoSet.contains(str[0].trim())){
                	filterList.add(str[0].trim());
                }
			}
		}
		
		if(reader!=null){
			reader.close();
		}
		return filterList;
	}

	private static void close() throws IOException {
		if (segFilterBySougoOut2 != null) {
			segFilterBySougoOut2.close();
		}
		if (segFilterBySougoBw2 != null) {
			segFilterBySougoBw2.close();
		}

		if (segFilterBySougoOut3 != null) {
			segFilterBySougoOut3.close();
		}
		if (segFilterBySougoBw3 != null) {
			segFilterBySougoBw3.close();
		}
	}

	private static Set<String> createSougoSet(String sougoTextPath)
			throws IOException {
		Set<String> sougoSet = new HashSet<String>();

		BufferedReader reader = new BufferedReader(new InputStreamReader(
				new FileInputStream(sougoTextPath), "UTF-8"));
		String temp = null;
		while ((temp = reader.readLine()) != null) {
			temp = temp.trim();
			if (StringUtil.isBlank(temp))
				continue;
			else {
				sougoSet.add(temp.trim());
			}
		}
		reader.close();
		// System.out.println(standardSet.size());
		return sougoSet;
	}

}
