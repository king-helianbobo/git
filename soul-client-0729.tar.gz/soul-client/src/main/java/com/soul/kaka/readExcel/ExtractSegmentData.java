package com.soul.kaka.readExcel;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.splitword.lionsoul.jcseg.util.ChineseHelper;

;

public class ExtractSegmentData {

	public static void main(String[] args) throws Exception {
        
		String testFilesPath="zhouqiOutput/testFiles";
		readAndWriteText(testFilesPath);
	}

	private static void readAndWriteText(String path)
			throws FileNotFoundException, IOException {
		File dir = new File(path);
		File file[] = dir.listFiles();

		for (int j = 0; j < file.length; j++) {
			if (file[j].isDirectory()) {
				readAndWriteText(file[j].getAbsolutePath());
			} else if (file[j].getName().endsWith("txt")) {
				FileOutputStream wordSegmentOut;
				BufferedWriter wordSegmentBw;
				String filename = file[j].getName();
				wordSegmentOut = new FileOutputStream("zhouqiOutput/segmentText/"
						+ filename);
				wordSegmentBw = new BufferedWriter(new OutputStreamWriter(
						wordSegmentOut, "utf-8"));
				char[] result = getTextData(file[j]);
				ArrayList<String> segmentList = makeSegment(result);

				Map<String, Integer> segmentMap = countSegmentMap(segmentList);

				outPutSegmentMapToTxt(segmentMap, wordSegmentBw);

				try {
					if (wordSegmentBw != null)
						wordSegmentBw.close();
					if (wordSegmentOut != null) {
						wordSegmentOut.close();
					}
				} catch (IOException e) {
					e.printStackTrace();
				}

			} else {
				System.out.println("do nothing");
			}
		}

	}

	private static char[] getTextData(File file) throws FileNotFoundException,
			IOException {
		char[] chTxt = new char[50000];
		InputStreamReader isr = new InputStreamReader(new FileInputStream(file));
		int length = isr.read(chTxt);
		chTxt[length] = '終';

		if (isr != null) {
			isr.close();
		}

		return chTxt;
	}

	public static char[] getTextData(String str) throws FileNotFoundException,
			IOException {
		int length = str.length();
		char[] chTxt;
		if(length<1000){
			chTxt = new char[1000];
		}else if(length>=1000 && length<10000){
			chTxt = new char[10000];
		}else if(length>=10000 && length<100000){
			chTxt = new char[100000];
		}else if(length>=100000 && length<200000){
			chTxt = new char[200000];
		}else if(length>=200000 && length<500000){
			chTxt = new char[500000];
		}else{
			chTxt = new char[1000000];
		}
		
		for (int i = 0; i < length; i++) {
			chTxt[i] = str.charAt(i);
		}
		chTxt[length] = '終';
		return chTxt;
	}

	public static ArrayList<String> makeSegment(char[] result) {
		ArrayList<String> segmentList = new ArrayList<String>();
		int i = 0;
		int start = -1;
		int end = -1;
		boolean flag = false;
		while (true) {
			if (result[i] == '終') {
				//注意最后一个片段的处理
				String str = new String(result, start + 1, end - start);
				int length = str.length();
				if (length >= 2 && length <= 6) {
					segmentList.add(str);
				}
				break;
			}
			if (ChineseHelper.isChineseChar(result[i])) {
				i++;
				end++;
				flag = true;
			} else if (flag) {
				String str = new String(result, start + 1, end - start);
				int length = str.length();
				if (length >= 2 && length <= 6) {
					segmentList.add(str);
				}

				i++;
				end++;
				start = end;
				flag = false;
			} else {
				i++;
				start++;
				end++;
			}
		}

		return segmentList;
	}

	public static Map<String, Integer> countSegmentMap(ArrayList<String> wordList) {
		Map<String, Integer> segmentMap = new HashMap<String, Integer>();
		for (int i = 0; i < wordList.size(); i++) {
			String keyStr = (String) wordList.get(i);
			Integer count = segmentMap.get(keyStr);
			if (count == null)
				segmentMap.put(keyStr, 1);
			else
				segmentMap.put(keyStr, count + 1);
		}

		return segmentMap;

	}
	
	public static void countSegmentMap(ArrayList<String> wordList,Map<String, Integer> segmentMap) {
		for (int i = 0; i < wordList.size(); i++) {
			String keyStr = (String) wordList.get(i);
			Integer count = segmentMap.get(keyStr);
			if (count == null)
				segmentMap.put(keyStr, 1);
			else
				segmentMap.put(keyStr, count + 1);
		}
	}

	public static void outPutSegmentMapToTxt(Map<String, Integer> map,
			BufferedWriter wordSegmentBw) throws IOException {

		for (Map.Entry<String, Integer> entry : map.entrySet()) {
			String key = entry.getKey();
			Integer value = entry.getValue();
			String outStr = key + ":  " + value + "\n";
			wordSegmentBw.append(outStr);
		}

		wordSegmentBw.flush();
	}
	
	
	

}
