package com.elasticsearch.action.refresh;

import java.io.IOException;
import java.util.Arrays;

import org.elasticsearch.action.support.broadcast.BroadcastOperationRequest;
import org.elasticsearch.common.io.stream.StreamInput;
import org.elasticsearch.common.io.stream.StreamOutput;

public class RefreshRequest extends BroadcastOperationRequest {

	private String field; // which field to refresh
	private String action = "refresh"; // or load
	private String type = "suggest"; // or spell

	public String field() {
		return field;
	}

	public void field(String field) {
		this.field = field;
	}

	public String action() {
		return action;
	}

	public void action(String action) {
		this.action = action;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public RefreshRequest() {
	}

	public RefreshRequest(String... indices) {
		super(indices);
	}

	@Override
	public void readFrom(StreamInput in) throws IOException {
		super.readFrom(in);
		field = in.readString();
		action = in.readString();
		type = in.readString();
	}

	@Override
	public void writeTo(StreamOutput out) throws IOException {
		super.writeTo(out);
		out.writeString(field);
		out.writeString(action);
		out.writeString(type);
	}

	@Override
	public String toString() {
		return String.format("[%s] field[%s]", Arrays.toString(indices), field);
	}

}
