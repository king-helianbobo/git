package com.elasticsearch.action.service;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.IndexWriterConfig.OpenMode;
import org.apache.lucene.search.highlight.InvalidTokenOffsetsException;
import org.apache.lucene.search.spell.HighFrequencyDictionary;
import org.apache.lucene.search.suggest.analyzing.AnalyzingSuggester;
import org.apache.lucene.search.suggest.analyzing.FuzzySuggester;
import org.apache.lucene.search.suggest.fst.FSTCompletionLookup;
import org.apache.lucene.store.RAMDirectory;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.map.ObjectMapper;
import org.elasticsearch.common.base.Joiner;
import org.elasticsearch.common.base.Objects;
import org.elasticsearch.common.cache.CacheBuilder;
import org.elasticsearch.common.cache.CacheLoader;
import org.elasticsearch.common.cache.LoadingCache;
import org.elasticsearch.common.collect.Lists;
import org.elasticsearch.common.inject.Inject;
import org.elasticsearch.common.inject.internal.ToStringBuilder;
import org.elasticsearch.common.io.stream.StreamInput;
import org.elasticsearch.common.io.stream.StreamOutput;
import org.elasticsearch.common.io.stream.Streamable;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.xcontent.ToXContent;
import org.elasticsearch.common.xcontent.XContentBuilder;
import org.elasticsearch.index.analysis.AnalysisService;
import org.elasticsearch.index.engine.Engine;
import org.elasticsearch.index.mapper.MapperService;
import org.elasticsearch.index.settings.IndexSettings;
import org.elasticsearch.index.shard.AbstractIndexShardComponent;
import org.elasticsearch.index.shard.IndexShardState;
import org.elasticsearch.index.shard.ShardId;
import org.elasticsearch.index.shard.service.IndexShard;
import org.elasticsearch.plugin.EsStaticValue;
import org.elasticsearch.plugin.LuceneTermsInEs;
import org.elasticsearch.plugin.LuceneTermsInEs.LuceneFieldIterator;
import org.elasticsearch.plugin.SoulSpellChecker;
import org.elasticsearch.plugin.SoulTitleRamCache;
import org.elasticsearch.plugin.TermListCache;
import org.splitword.soul.keyword.KeyWordComputer;
import org.splitword.soul.utility.StringUtil;

import com.elasticsearch.action.refresh.ShardRefreshRequest;
import com.elasticsearch.action.refresh.ShardRefreshResponse;
import com.elasticsearch.action.statistic.FstStats;
import com.elasticsearch.action.statistic.ShardSuggestStatisticsResponse;
import com.elasticsearch.action.suggest.ShardSuggestRequest;
import com.elasticsearch.action.suggest.ShardSuggestResponse;
import com.elasticsearch.action.termlist.ShardTermlistRequest;
import com.elasticsearch.action.termlist.ShardTermlistResponse;
import com.elasticsearch.action.termlist.TermInfoPojo;

public class ShardSuggestService extends AbstractIndexShardComponent {

	private final IndexShard indexShard;
	private final ReentrantLock lock = new ReentrantLock();
	private IndexReader indexReader;

	private final LoadingCache<String, SoulSpellChecker> spellCheckCache;
	private final LoadingCache<String, SoulTitleRamCache> titleSuggestCache;
	private final LoadingCache<String, Map<String, TermInfoPojo>> termListCache;
	private final LoadingCache<String, FSTCompletionLookup> lookupCache;
	private final LoadingCache<FieldType, AnalyzingSuggester> analyzingSuggesterCache;
	private final LoadingCache<FieldType, FuzzySuggester> fuzzySuggesterCache;
	private final LoadingCache<String, HighFrequencyDictionary> dictCache;

	private static Log log = LogFactory.getLog(ShardSuggestService.class);
	private static final String tabTag = "#";

	@Inject
	public ShardSuggestService(ShardId shardId,
			@IndexSettings Settings indexSettings, final IndexShard indexShard,
			final AnalysisService analysisService,
			final MapperService mapperService) {
		super(shardId, indexSettings);
		this.indexShard = indexShard;

		titleSuggestCache = CacheBuilder.newBuilder().build(
				new CacheLoader<String, SoulTitleRamCache>() {
					@Override
					public SoulTitleRamCache load(String cacheKey)
							throws Exception {
						SoulTitleRamCache titleCache = new SoulTitleRamCache(
								new RAMDirectory());
						IndexReader reader = createOrGetIndexReader();
						String strs[] = cacheKey.split(tabTag);
						String whichField = strs[2];
						log.info(whichField
								+ " is called, to perform suggest.[");
						LuceneTermsInEs info = new LuceneTermsInEs(reader);
						titleCache.fillLuceneDirectory(info, whichField);
						info = null;
						return titleCache;
					}
				});

		spellCheckCache = CacheBuilder.newBuilder().build(
				new CacheLoader<String, SoulSpellChecker>() {
					@Override
					public SoulSpellChecker load(String cacheKey)
							throws Exception {
						SoulSpellChecker spellChecker = new SoulSpellChecker(
								new RAMDirectory());
						IndexWriterConfig config = new IndexWriterConfig(
								EsStaticValue.LuceneVersion, null);
						config.setOpenMode(OpenMode.CREATE_OR_APPEND);
						String strs[] = cacheKey.split(tabTag);
						String whichField = strs[2];
						HighFrequencyDictionary dict = new HighFrequencyDictionary(
								createOrGetIndexReader(), whichField, 0);
						spellChecker.indexDictionary(dict, config, false);
						dict = null;
						return spellChecker;
					}
				});

		termListCache = CacheBuilder.newBuilder().build(
				new CacheLoader<String, Map<String, TermInfoPojo>>() {
					@Override
					public Map<String, TermInfoPojo> load(String cacheKey)
							throws Exception {
						Engine.Searcher searcher = indexShard
								.acquireSearcher("termlist");
						IndexReader reader = searcher.reader();
						TermListCache loader = new TermListCache(reader);
						String[] strs = cacheKey.split(tabTag);
						String[] fieldNames = new String[strs.length - 2];
						for (int i = 2; i < strs.length; i++)
							fieldNames[i - 2] = strs[i];
						Map<String, TermInfoPojo> map = loader.load(fieldNames);
						loader = null;
						searcher.close();
						return map;
					}
				});

		/*********************** ignore below cache ****************************/

		lookupCache = CacheBuilder.newBuilder().build(
				new CacheLoader<String, FSTCompletionLookup>() {
					@Override
					public FSTCompletionLookup load(String field)
							throws Exception {
						FSTCompletionLookup lookup = new FSTCompletionLookup();
						lookup.build(dictCache.getUnchecked(field));
						return lookup;
					}
				});

		dictCache = CacheBuilder.newBuilder().build(
				new CacheLoader<String, HighFrequencyDictionary>() {
					@Override
					public HighFrequencyDictionary load(String field)
							throws Exception {
						return new HighFrequencyDictionary(
								createOrGetIndexReader(), field, 0);
						// at least once
					}
				});

		analyzingSuggesterCache = CacheBuilder.newBuilder().build(
				new AbstractCacheLoaderSuggester.CacheLoaderAnalyzingSuggester(
						mapperService, analysisService, dictCache));

		fuzzySuggesterCache = CacheBuilder.newBuilder().build(
				new AbstractCacheLoaderSuggester.CacheLoaderFuzzySuggester(
						mapperService, analysisService, dictCache));

		/*********************** ignore below cache ****************************/

	}

	public ShardRefreshResponse refresh(ShardRefreshRequest shardRefreshRequest) {
		String field = shardRefreshRequest.field();
		String type = shardRefreshRequest.getType();
		String action = shardRefreshRequest.action();
		String cacheKey = shardRefreshRequest.index() + tabTag + type + tabTag
				+ field;
		if (action.equalsIgnoreCase("refresh") && StringUtil.isBlank(type)) {
			refreshAll();
		} else if (action.equalsIgnoreCase("load")) {
			if (type.equalsIgnoreCase("spell"))
				spellCheckCache.getUnchecked(cacheKey);
			else if (type.equalsIgnoreCase("suggest"))
				titleSuggestCache.getUnchecked(cacheKey);
		} else if (action.equalsIgnoreCase("refresh")) {
			resetIndexReader();
			if (spellCheckCache.asMap().keySet().contains(cacheKey)) {
				SoulSpellChecker spellChecker = spellCheckCache
						.getIfPresent(cacheKey);
				// Returns the value associated with key in this cache, or
				// null if there is no cached value for key
				if (spellChecker != null) {
					spellCheckCache.refresh(cacheKey);
					try {
						spellChecker.close();
					} catch (IOException e) {
						logger.error("Could not close spellchecker for [{}]",
								e, cacheKey);
					}
				}
			}
			if (titleSuggestCache.asMap().keySet().contains(cacheKey)) {
				SoulTitleRamCache suggestCache = titleSuggestCache
						.getIfPresent(cacheKey);
				if (suggestCache != null) {
					titleSuggestCache.refresh(cacheKey);
					try {
						suggestCache.close();
					} catch (IOException e) {
						logger.error("Could not close soulTitleCache for [{}]",
								e, cacheKey);
					}
				}
			}
			HighFrequencyDictionary dict = dictCache.getIfPresent(cacheKey);
			if (dict != null)
				dictCache.refresh(cacheKey);

			FSTCompletionLookup lookup = lookupCache.getIfPresent(cacheKey);
			if (lookup != null)
				lookupCache.refresh(cacheKey);

			for (FieldType fieldType : analyzingSuggesterCache.asMap().keySet()) {
				if (fieldType.field().equals(shardRefreshRequest.field())) {
					analyzingSuggesterCache.refresh(fieldType);
				}
			}

			for (FieldType fieldType : fuzzySuggesterCache.asMap().keySet()) {
				if (fieldType.field().equals(shardRefreshRequest.field())) {
					fuzzySuggesterCache.refresh(fieldType);
				}
			}
		}
		Map<String, Integer> map = new HashMap<String, Integer>();
		map.put(cacheKey, 1);
		return new ShardRefreshResponse(shardId.index().name(), shardId.id(),
				map);
	}

	public void shutDown() {
		resetIndexReader();
		for (Map.Entry<String, SoulSpellChecker> entry : spellCheckCache
				.asMap().entrySet()) {
			try {
				entry.getValue().close();
			} catch (IOException e) {
				logger.error("Could not close spellchecker for [{}]", e,
						entry.getKey());
			}
		}
		for (Entry<String, SoulTitleRamCache> entry : titleSuggestCache.asMap()
				.entrySet()) {
			try {
				entry.getValue().close();
			} catch (IOException e) {
				logger.error("Could not close SoulTitleCache for [{}]", e,
						entry.getKey());
			}
		}
		// discard all entries in this cache
		spellCheckCache.invalidateAll();
		titleSuggestCache.invalidateAll();
		termListCache.invalidateAll();
		dictCache.invalidateAll();
		lookupCache.invalidateAll();
		analyzingSuggesterCache.invalidateAll();
		fuzzySuggesterCache.invalidateAll();
	}

	private void refreshAll() {
		resetIndexReader();
		try {
			for (String field : spellCheckCache.asMap().keySet()) {
				SoulSpellChecker oldValue = spellCheckCache.getUnchecked(field);
				spellCheckCache.refresh(field);
				oldValue.close();
			}
			for (String field : titleSuggestCache.asMap().keySet()) {
				SoulTitleRamCache oldValue = titleSuggestCache
						.getUnchecked(field);
				titleSuggestCache.refresh(field);
				oldValue.close();
			}

			for (String field : dictCache.asMap().keySet()) {
				dictCache.refresh(field);
			}
			for (String field : lookupCache.asMap().keySet()) {
				lookupCache.refresh(field);
			}

			for (FieldType fieldType : analyzingSuggesterCache.asMap().keySet()) {
				analyzingSuggesterCache.refresh(fieldType);
			}

			for (FieldType fieldType : fuzzySuggesterCache.asMap().keySet()) {
				fuzzySuggesterCache.refresh(fieldType);
			}

		} catch (IOException e) {
			logger.error("Error refreshing spell checker cache [{}]", e,
					shardId);
		}
	}

	public ShardSuggestResponse suggest(ShardSuggestRequest shardSuggestRequest) {
		if ("spell".equals(shardSuggestRequest.suggestType())) {
			List<String> suggestions = new ArrayList<String>();
			float similarity = shardSuggestRequest.similarity();
			if (similarity <= 1.0f) {
				suggestions.addAll(spellCheckSuggest(shardSuggestRequest));
			}
			return new ShardSuggestResponse(shardId.index().name(),
					shardId.id(), suggestions);
		} else if ("suggest".equals(shardSuggestRequest.suggestType())) {
			List<String> suggestions = new ArrayList<String>();
			suggestions.addAll(titleCacheSuggest(shardSuggestRequest));
			return new ShardSuggestResponse(shardId.index().name(),
					shardId.id(), suggestions);
		} else {
			return null;
		}
	}

	public ShardTermlistResponse termList(ShardTermlistRequest request) {
		String[] fields = request.fields();
		// fields must be ordered ,so we use json array
		StringBuilder builder = new StringBuilder();
		builder.append(request.index());
		builder.append(tabTag);
		builder.append("termlist");
		builder.append(tabTag);
		for (int i = 0; i < fields.length; i++) {
			builder.append(fields[i]);
			if (i != (fields.length - 1))
				builder.append(tabTag);
		}
		String action = request.action();
		if (action.equals("termlist")) {
			String cacheKey = builder.toString();
			Map<String, TermInfoPojo> map = termListCache
					.getUnchecked(cacheKey);
			String term = request.term();
			TermInfoPojo info = map.get(term);
			if (info != null) {
				Map<String, TermInfoPojo> result = new HashMap<String, TermInfoPojo>();
				TermInfoPojo tmpInfo = new TermInfoPojo();
				// must return new object,else original object will be altered
				tmpInfo.docFreq(info.getDocFreq());
				tmpInfo.totalFreq(info.getTotalFreq());
				result.put(term, tmpInfo);
				return new ShardTermlistResponse(request.index(),
						request.shardId(), result);
			}
		} else if (action.equals("keywords")) {
			Engine.Searcher searcher = indexShard.acquireSearcher("termlist");
			IndexReader reader = searcher.reader();
			LuceneTermsInEs fieldInfo = new LuceneTermsInEs(reader);
			ObjectMapper mapper = new ObjectMapper();
			TermInfoPojo tmpInfo = new TermInfoPojo();
			// SoulHttpClient termListClient = new SoulHttpClient(
			// "http://localhost:9200", request.index(), "table");
			KeyWordComputer kwc = new KeyWordComputer(20);
			UpdateIndex updateOp = new UpdateIndex("localhost",
					request.index(), "table");
			try {
				LuceneFieldIterator iter = fieldInfo.iterator();
				String json = null;
				while ((json = iter.nextJson(null, fields[0], fields[1])) != null) {
					if ((json.equals("null")) || (StringUtil.isBlank(json)))
						continue;
					JsonParser jsonParser = mapper.getJsonFactory()
							.createJsonParser(json);
					@SuppressWarnings("unchecked")
					Map<String, Object> map = mapper.readValue(jsonParser,
							Map.class);
					String title = (String) map.get("title");
					String content = (String) map.get("content");
					String typeAndId = (String) map.get("field1");
					String[] strs = typeAndId.split("#");
					Map<String, String> entry = new HashMap<String, String>();
					entry.put("id", strs[1]);
					entry.put("keywords", kwc.computeKeywords(title, content));
					log.info(entry.get("id") + "[ ]" + title + "[ ]"
							+ entry.get("keywords"));
					// updateOp.writeMapData2(entry);
					updateOp.writeMapData(entry);
				}
				updateOp.writeLastData();
				tmpInfo.docFreq(1);
				tmpInfo.totalFreq(1);
				log.info("keywords update operation finished!");
			} catch (IOException e) {
				tmpInfo.docFreq(0);
				tmpInfo.totalFreq(0);
				e.printStackTrace();
			}
			searcher.close();
			Map<String, TermInfoPojo> result = new HashMap<String, TermInfoPojo>();
			result.put("keywords", tmpInfo);
			return new ShardTermlistResponse(request.index(),
					request.shardId(), null);
		}
		return new ShardTermlistResponse(request.index(), request.shardId(),
				null);
	}

	private Collection<String> spellCheckSuggest(
			ShardSuggestRequest shardRequest) {
		String term = shardRequest.term();
		Integer limit = shardRequest.size();
		Float similarity = shardRequest.similarity();
		String field = shardRequest.field();
		String type = shardRequest.suggestType();
		// add type string to distinguish spell or suggest
		String cacheKey = shardRequest.index() + tabTag + type + tabTag + field;
		try {
			SoulSpellChecker checker = spellCheckCache.getUnchecked(cacheKey);
			String[] suggestSimilar = checker.suggestSimilar(term, limit,
					similarity);
			// log.info(cacheKey + ", " + term + ", " + limit + ", " +
			// similarity);
			return Arrays.asList(suggestSimilar);
		} catch (IOException e) {
			logger.error(
					"Error getting spellchecker suggestions for shard [{}] field [{}] term [{}] limit [{}] similarity [{}]",
					e, shardId, field, term, limit, similarity);
		}
		return Collections.emptyList();
	}

	private Collection<String> titleCacheSuggest(
			ShardSuggestRequest shardRequest) {
		String field = shardRequest.field();
		String term = shardRequest.term();
		String type = shardRequest.suggestType();
		Integer limit = shardRequest.size();
		String cacheKey = shardRequest.index() + tabTag + type + tabTag + field;
		try {
			SoulTitleRamCache titleCache = titleSuggestCache
					.getUnchecked(cacheKey);
			String[] titles = titleCache.suggestTitles(term, limit);
			if (titles == null)
				return Collections.emptyList();
			for (String title : titles)
				log.info("in return result:[" + title + "]");
			// log.info(cacheKey + " , " + term + " , " + limit);
			return Arrays.asList(titles);
		} catch (IOException e) {
			logger.error(
					"Error getting title suggestions for shard [{}] field [{}] term [{}] limit [{}] similarity [{}]",
					e, shardId, field, term, limit);
		} catch (InvalidTokenOffsetsException e) {
			e.printStackTrace();
		}
		return Collections.emptyList();
	}

	private void resetIndexReader() {
		// get current index reader for this shard
		IndexReader currentIndexReader = null;
		if (indexShard.state() == IndexShardState.STARTED) {
			Engine.Searcher currentIndexSearcher = indexShard
					.acquireSearcher("suggest");
			currentIndexReader = currentIndexSearcher.reader();
		}
		// if this index reader is not used in the current index searcher, we
		// need to decrease the old reference count
		if (indexReader != null && indexReader.getRefCount() > 0
				&& !indexReader.equals(currentIndexReader)) {
			try {
				indexReader.decRef();
			} catch (IOException e) {
				logger.error(
						"Error decreasing indexreader ref count [{}] of shard [{}]",
						e, indexReader.getRefCount(), shardId);
			}
		}
		indexReader = null;
	}

	public ShardSuggestStatisticsResponse getStatistics() {
		ShardSuggestStatisticsResponse shardSuggestStatisticsResponse = new ShardSuggestStatisticsResponse(
				shardId());

		for (FieldType fieldType : analyzingSuggesterCache.asMap().keySet()) {
			long sizeInBytes = analyzingSuggesterCache.getIfPresent(fieldType)
					.sizeInBytes();
			FstStats.FstIndexShardStats fstIndexShardStats = new FstStats.FstIndexShardStats(
					shardId, "analyzingsuggester", fieldType, sizeInBytes);
			shardSuggestStatisticsResponse.getFstIndexShardStats().add(
					fstIndexShardStats);
		}

		for (FieldType fieldType : fuzzySuggesterCache.asMap().keySet()) {
			long sizeInBytes = fuzzySuggesterCache.getIfPresent(fieldType)
					.sizeInBytes();
			FstStats.FstIndexShardStats fstIndexShardStats = new FstStats.FstIndexShardStats(
					shardId, "fuzzysuggester", fieldType, sizeInBytes);
			shardSuggestStatisticsResponse.getFstIndexShardStats().add(
					fstIndexShardStats);
		}

		return shardSuggestStatisticsResponse;
	}

	// this does not look thread safe and nice...
	private IndexReader createOrGetIndexReader() {
		try {
			if (indexReader == null) {
				lock.lock();
				if (indexReader == null) {
					Engine.Searcher indexSearcher = indexShard
							.acquireSearcher("suggest");
					indexReader = indexSearcher.reader();
					// If this reader closes, we have to refresh all our
					// data structures!
					indexReader
							.addReaderClosedListener(new IndexReader.ReaderClosedListener() {
								// This listener will be invoked when this
								// reader is closed
								@Override
								public void onClose(IndexReader reader) {
									refreshAll();
								}
							});
				}
			}
		} finally {
			if (lock.isLocked()) {
				lock.unlock();
			}
		}
		logger.info("1 shard {} : ref count {}", shardId,
				indexReader.getRefCount());
		return indexReader;
	}

	public static class FieldType implements Streamable, Serializable,
			ToXContent {

		private String field;
		private List<String> types = Lists.newArrayList();
		private String queryAnalyzer;
		private String indexAnalyzer;
		private boolean preservePositionIncrements = true;

		public FieldType() {
		}

		public FieldType(ShardSuggestRequest shardSuggestRequest) {
			this.field = shardSuggestRequest.field();
		}

		public String field() {
			return field;
		}

		public String[] types() {
			return types.toArray(new String[] {});
		}

		public String queryAnalyzer() {
			return queryAnalyzer;
		}

		public String indexAnalyzer() {
			return indexAnalyzer;
		}

		public boolean preservePositionIncrements() {
			return preservePositionIncrements;
		}

		@Override
		public boolean equals(Object obj) {
			if (obj == null) {
				return false;
			}
			if (getClass() != obj.getClass()) {
				return false;
			}
			final FieldType other = (FieldType) obj;

			return Objects.equal(this.field(), other.field())
					&& Objects.equal(this.queryAnalyzer(),
							other.queryAnalyzer())
					&& Objects.equal(this.indexAnalyzer(),
							other.indexAnalyzer())
					&& Objects.equal(this.types, other.types)
					&& Objects.equal(this.preservePositionIncrements(),
							other.preservePositionIncrements());
		}

		@Override
		public int hashCode() {
			int hashCode = this.field().hashCode();
			hashCode += this.types.hashCode();
			if (this.queryAnalyzer != null)
				hashCode += this.queryAnalyzer.hashCode();
			if (this.indexAnalyzer != null)
				hashCode += this.indexAnalyzer.hashCode();
			hashCode += Boolean.valueOf(preservePositionIncrements).hashCode();

			return hashCode;
		}

		@Override
		public String toString() {
			ToStringBuilder toStringBuilder = new ToStringBuilder(
					this.getClass()).add("field", this.field());

			toStringBuilder.add("preservePositionIncrements",
					this.preservePositionIncrements);
			if (queryAnalyzer != null && queryAnalyzer.equals(indexAnalyzer)) {
				toStringBuilder.add("analyzer", this.queryAnalyzer);
			} else {
				if (queryAnalyzer != null) {
					toStringBuilder.add("queryAnalyzer", queryAnalyzer);
				}
				if (indexAnalyzer != null) {
					toStringBuilder.add("indexAnalyzer", indexAnalyzer);
				}
			}

			if (types.size() > 0) {
				toStringBuilder.add("types", Joiner.on("-").join(types));
			}

			return toStringBuilder.toString();
		}

		@SuppressWarnings("unchecked")
		@Override
		public void readFrom(StreamInput in) throws IOException {
			field = in.readString();
			queryAnalyzer = in.readOptionalString();
			indexAnalyzer = in.readOptionalString();
			types = (List<String>) in.readGenericValue();
			preservePositionIncrements = in.readBoolean();
		}

		@Override
		public void writeTo(StreamOutput out) throws IOException {
			out.writeString(field);
			out.writeOptionalString(queryAnalyzer);
			out.writeOptionalString(indexAnalyzer);
			out.writeGenericValue(types);
			out.writeBoolean(preservePositionIncrements);
		}

		@Override
		public XContentBuilder toXContent(XContentBuilder builder, Params params)
				throws IOException {
			// builder.startObject(field);
			builder.field("field", field);
			if (queryAnalyzer != null && queryAnalyzer.equals(indexAnalyzer)) {
				builder.field("analyzer", this.queryAnalyzer);
			} else {
				if (queryAnalyzer != null)
					builder.field("queryAnalyzer", queryAnalyzer);
				if (indexAnalyzer != null)
					builder.field("indexAnalyzer", indexAnalyzer);
			}
			if (!preservePositionIncrements)
				builder.field("preservePositionIncrements",
						preservePositionIncrements);
			if (types.size() > 0)
				builder.field("types", types());
			// builder.endObject();
			return builder;
		}
	}
}
