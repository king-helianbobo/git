package com.elasticsearch.action.service;

import java.io.IOException;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.io.MapWritable;
import org.elasticsearch.hadoop.cfg.ConfigurationOptions;
import org.elasticsearch.hadoop.cfg.Settings;
import org.elasticsearch.hadoop.cfg.SettingsManager;
import org.elasticsearch.hadoop.mr.MapReduceWriter;
import org.elasticsearch.hadoop.rest.InitializationUtils;
import org.elasticsearch.hadoop.rest.RestClient;
import org.elasticsearch.hadoop.serailize.MapWritableIdExtractor;
import org.elasticsearch.hadoop.serailize.SerializationUtils;
import org.elasticsearch.hadoop.serailize.UpdateCommand;
import org.elasticsearch.hadoop.util.BytesArray;
import org.elasticsearch.hadoop.util.WritableUtils;

public class UpdateIndex {
	private String hostName = "localhost";
	private String indexName = "soul_test";
	private String typeName = "table";
	BytesArray data = new BytesArray(128 * 1024);
	private Settings settings;
	private RestClient client;
	private UpdateCommand command;
	private static Log log = LogFactory.getLog(UpdateIndex.class);

	UpdateIndex(String hostName, String indexName, String typeName) {
		this.hostName = hostName;
		this.indexName = indexName;
		this.typeName = typeName;
		Properties properties = new Properties();
		properties.put(ConfigurationOptions.ES_WRITE_OPERATION, "update");
		properties.put(ConfigurationOptions.ES_MAPPING_ID, "id");
		String resource = indexName + "/" + typeName;
		properties.put(ConfigurationOptions.ES_RESOURCE, resource);
		properties.put(ConfigurationOptions.ES_HOST, hostName);
		properties.put(ConfigurationOptions.ES_UPSERT_DOC, false);
		settings = SettingsManager.loadFrom(properties);
		SerializationUtils.setValueWriterIfNotSet(settings,
				MapReduceWriter.class, log);
		InitializationUtils.setIdExtractorIfNotSet(settings,
				MapWritableIdExtractor.class, log);
		client = new RestClient(settings);
		command = new UpdateCommand(settings);
	}

	public void writeMapData(Map<String, String> entry) {
		try {
			MapWritable writable = (MapWritable) WritableUtils
					.toWritable(entry);
			int entrySize = command.prepare(writable);
			// log.info(entrySize + "," + data.size() + "," + data.capacity()
			// + "," + entry.get("id"));
			if (entrySize + data.size() > data.capacity()) {
				client.bulk(settings.getIndexType(), data.bytes(), data.size());
				data.reset();
			}
			command.write(writable, data);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void writeMapData2(Map<String, String> entry) {
		try {
			MapWritable writable = (MapWritable) WritableUtils
					.toWritable(entry);
			int entrySize = command.prepare(writable);
			command.write(writable, data);
			client.bulk(settings.getIndexType(), data.bytes(), data.size());
			data.reset();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void writeLastData() {
		try {
			client.bulk(settings.getIndexType(), data.bytes(), data.size());
			data.reset();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
