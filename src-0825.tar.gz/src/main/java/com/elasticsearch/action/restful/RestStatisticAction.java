package com.elasticsearch.action.restful;

import static org.elasticsearch.rest.RestRequest.Method.GET;
import static org.elasticsearch.rest.action.support.RestActions.buildBroadcastShardsHeader;

import org.elasticsearch.client.Client;
import org.elasticsearch.common.inject.Inject;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.xcontent.XContentBuilder;
import org.elasticsearch.rest.BaseRestHandler;
import org.elasticsearch.rest.BytesRestResponse;
import org.elasticsearch.rest.RestChannel;
import org.elasticsearch.rest.RestController;
import org.elasticsearch.rest.RestRequest;
import org.elasticsearch.rest.RestResponse;
import org.elasticsearch.rest.RestStatus;
import org.elasticsearch.rest.action.support.RestBuilderListener;

import com.elasticsearch.action.statistic.SuggestStatisticsAction;
import com.elasticsearch.action.statistic.SuggestStatisticsRequest;
import com.elasticsearch.action.statistic.SuggestStatisticsResponse;

public class RestStatisticAction extends BaseRestHandler {

	@Inject
	public RestStatisticAction(Settings settings, Client client,
			RestController controller) {
		super(settings, client);
		controller.registerHandler(GET, "/__suggestStatistics", this);
	}

	@Override
	public void handleRequest(final RestRequest request,
			final RestChannel channel) {
		SuggestStatisticsRequest suggestStatisticsRequest = new SuggestStatisticsRequest();

		client.execute(SuggestStatisticsAction.INSTANCE,
				suggestStatisticsRequest,
				new RestBuilderListener<SuggestStatisticsResponse>(channel) {
					@Override
					public RestResponse buildResponse(
							SuggestStatisticsResponse response,
							XContentBuilder builder) throws Exception {
						builder.startObject();
						buildBroadcastShardsHeader(builder, response);
						response.fstStats().toXContent(builder, null);
						builder.endObject();
						return new BytesRestResponse(RestStatus.OK, builder);
					}
				});
	}
}
