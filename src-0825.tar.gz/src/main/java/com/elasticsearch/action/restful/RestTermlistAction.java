package com.elasticsearch.action.restful;

import static org.elasticsearch.rest.RestRequest.Method.GET;
import static org.elasticsearch.rest.RestRequest.Method.POST;
import static org.elasticsearch.rest.RestStatus.OK;
import static org.elasticsearch.rest.action.support.RestActions.buildBroadcastShardsHeader;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.elasticsearch.ElasticsearchException;
import org.elasticsearch.client.Client;
import org.elasticsearch.common.Strings;
import org.elasticsearch.common.inject.Inject;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.xcontent.XContentBuilder;
import org.elasticsearch.common.xcontent.XContentFactory;
import org.elasticsearch.common.xcontent.XContentParser;
import org.elasticsearch.common.xcontent.support.XContentMapValues;
import org.elasticsearch.rest.BaseRestHandler;
import org.elasticsearch.rest.BytesRestResponse;
import org.elasticsearch.rest.RestChannel;
import org.elasticsearch.rest.RestController;
import org.elasticsearch.rest.RestRequest;
import org.elasticsearch.rest.RestResponse;
import org.elasticsearch.rest.RestStatus;
import org.elasticsearch.rest.action.support.RestBuilderListener;

import com.elasticsearch.action.termlist.TermInfoPojo;
import com.elasticsearch.action.termlist.TermlistAction;
import com.elasticsearch.action.termlist.TermlistRequest;
import com.elasticsearch.action.termlist.TermlistResponse;

public class RestTermlistAction extends BaseRestHandler {

	private static Log log = LogFactory.getLog(RestTermlistAction.class);

	@Inject
	public RestTermlistAction(Settings settings, Client client,
			RestController controller) {
		super(settings, client);
		controller.registerHandler(GET, "/{index}/_termlist", this);
		controller.registerHandler(GET, "/{index}/{type}/_termlist", this);
		controller.registerHandler(POST, "/{index}/_termlist", this);
		controller.registerHandler(POST, "/{index}/{type}/_termlist", this);
	}

	@SuppressWarnings("unchecked")
	public void handleRequest(final RestRequest request,
			final RestChannel channel) throws IOException {
		final String[] indices = Strings.splitStringByCommaToArray(request
				.param("index"));
		final String action = "action";
		final String fields = "fields";
		final String term = "term";
		final String size = "size";
		Map<String, Object> parserMap = null;
		TermlistRequest termlistRequest = new TermlistRequest(indices);
		if (request.hasContent()) {
			XContentParser parser = XContentFactory.xContent(request.content())
					.createParser(request.content());
			parserMap = parser.mapAndClose();
		} else if (request.hasParam("source")) {
			String source = request.param("source");
			XContentParser parser = XContentFactory.xContent(source)
					.createParser(source);
			parserMap = parser.mapAndClose();
		} else {
			handleException(channel, request, new ElasticsearchException(
					"Please provide body data or source parameter"));
		}
		termlistRequest.action(XContentMapValues.nodeStringValue(
				parserMap.get(action), null)); // get action
		termlistRequest.term(XContentMapValues.nodeStringValue(
				parserMap.get(term), null)); // get field
		termlistRequest.setSize(XContentMapValues.nodeIntegerValue(
				parserMap.get(size), 0));
		if (parserMap.get(fields) != null)
			termlistRequest.fields((List<String>) parserMap.get(fields));

		String expectedAction = termlistRequest.action();

		if (expectedAction == null)
			return;
		else if (!expectedAction.equalsIgnoreCase("termlist")
				&& !expectedAction.equalsIgnoreCase("keywords"))
			return;

		client.execute(TermlistAction.INSTANCE, termlistRequest,
				new RestBuilderListener<TermlistResponse>(channel) {
					@Override
					public RestResponse buildResponse(
							TermlistResponse response, XContentBuilder builder)
							throws Exception {
						builder.startObject();
						buildBroadcastShardsHeader(builder, response);
						builder.startArray("termList");
						for (Map.Entry<String, TermInfoPojo> t : response
								.getTermMap().entrySet()) {
							builder.startObject().field("term", t.getKey());
							if (t.getValue().getDocFreq() != null) {
								builder.field("docFreq", t.getValue()
										.getDocFreq());
							}
							if (t.getValue().getTotalFreq() != null) {
								builder.field("totalFreq", t.getValue()
										.getTotalFreq());
							}
							builder.endObject();
						}
						builder.endArray().endObject();
						return new BytesRestResponse(OK, builder);
					}
				});
	}

	final void handleException(final RestChannel channel,
			final RestRequest request, final ElasticsearchException e) {
		channel.sendResponse(new BytesRestResponse(RestStatus.BAD_REQUEST, e
				.getDetailedMessage()));
	}
}