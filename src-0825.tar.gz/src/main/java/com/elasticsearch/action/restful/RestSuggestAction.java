package com.elasticsearch.action.restful;

import static org.elasticsearch.rest.RestRequest.Method.GET;
import static org.elasticsearch.rest.RestRequest.Method.POST;
import static org.elasticsearch.rest.action.support.RestActions.buildBroadcastShardsHeader;

import java.io.IOException;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.elasticsearch.ElasticsearchException;
import org.elasticsearch.client.Client;
import org.elasticsearch.common.Strings;
import org.elasticsearch.common.inject.Inject;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.xcontent.XContentBuilder;
import org.elasticsearch.common.xcontent.XContentFactory;
import org.elasticsearch.common.xcontent.XContentParser;
import org.elasticsearch.common.xcontent.support.XContentMapValues;
import org.elasticsearch.rest.BaseRestHandler;
import org.elasticsearch.rest.BytesRestResponse;
import org.elasticsearch.rest.RestChannel;
import org.elasticsearch.rest.RestController;
import org.elasticsearch.rest.RestRequest;
import org.elasticsearch.rest.RestResponse;
import org.elasticsearch.rest.RestStatus;
import org.elasticsearch.rest.action.support.RestBuilderListener;
import org.splitword.soul.utility.StringUtil;

import com.elasticsearch.action.suggest.SuggestAction;
import com.elasticsearch.action.suggest.SuggestRequest;
import com.elasticsearch.action.suggest.SuggestResponse;

public class RestSuggestAction extends BaseRestHandler {

	private static Log log = LogFactory.getLog(RestSuggestAction.class);

	@Inject
	public RestSuggestAction(Settings settings, Client client,
			RestController controller) {
		// we accept GET and post method
		super(settings, client);
		controller.registerHandler(GET, "/{index}/__suggest", this);
		controller.registerHandler(GET, "/{index}/{type}/__suggest", this);
		controller.registerHandler(POST, "/{index}/__suggest", this);
		controller.registerHandler(POST, "/{index}/{type}/__suggest", this);
	}

	@Override
	public void handleRequest(final RestRequest request,
			final RestChannel channel) throws IOException {
		final String[] indices = Strings.splitStringByCommaToArray(request
				.param("index"));
		Map<String, Object> parserMap = null;
		if (request.hasContent()) {
			XContentParser parser = XContentFactory.xContent(request.content())
					.createParser(request.content());
			parserMap = parser.mapAndClose();
		} else if (request.hasParam("source")) {
			String source = request.param("source");
			XContentParser parser = XContentFactory.xContent(source)
					.createParser(source);
			parserMap = parser.mapAndClose();
		} else {
			handleException(channel, request, new ElasticsearchException(
					"Please provide body data or source parameter"));
		}

		SuggestRequest suggestRequest = new SuggestRequest(indices);
		suggestRequest.field(XContentMapValues.nodeStringValue(
				parserMap.get("field"), " ")); // get field

		suggestRequest.suggestType(XContentMapValues.nodeStringValue(
				parserMap.get("type"), " "));// get type

		suggestRequest.term(XContentMapValues.nodeStringValue(
				parserMap.get("term"), " "));
		suggestRequest.similarity(XContentMapValues.nodeFloatValue(
				parserMap.get("similarity"), 0.9f));
		suggestRequest.size(XContentMapValues.nodeIntegerValue(
				parserMap.get("size"), 10));

		if (StringUtil.isBlank(suggestRequest.field())
				|| StringUtil.isBlank(suggestRequest.suggestType())) {
			handleException(channel, request, new ElasticsearchException(
					"Please provide field and suggestType!"));
		}

		log.info(suggestRequest.toString());

		client.execute(SuggestAction.INSTANCE, suggestRequest,
				new RestBuilderListener<SuggestResponse>(channel) {
					@Override
					public RestResponse buildResponse(SuggestResponse response,
							XContentBuilder builder) throws Exception {
						builder.startObject();
						buildBroadcastShardsHeader(builder, response);
						builder.field("suggestions", response.suggestions());
						builder.endObject();
						return new BytesRestResponse(RestStatus.OK, builder);
					}
				});
	}

	final void handleException(final RestChannel channel,
			final RestRequest request, final ElasticsearchException e) {
		channel.sendResponse(new BytesRestResponse(RestStatus.BAD_REQUEST, e
				.getDetailedMessage()));
	}
}
