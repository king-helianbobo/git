package com.elasticsearch.action.restful;

import org.elasticsearch.action.ActionListener;
import org.elasticsearch.action.ActionRequestBuilder;
import org.elasticsearch.client.Client;
import org.elasticsearch.client.internal.InternalClient;

import com.elasticsearch.action.refresh.RefreshRequest;
import com.elasticsearch.action.refresh.RefreshResponse;
import com.elasticsearch.action.refresh.SuggestRefreshAction;

public class RefreshRequestBuilder
		extends
		ActionRequestBuilder<RefreshRequest, RefreshResponse, RefreshRequestBuilder> {

	public RefreshRequestBuilder(Client client) {
		super((InternalClient) client, new RefreshRequest());
	}

	@Override
	protected void doExecute(ActionListener<RefreshResponse> listener) {
		((Client) client).execute(SuggestRefreshAction.INSTANCE, request,
				listener);
	}

	public RefreshRequestBuilder setIndices(String... indices) {
		request.indices(indices);
		return this;
	}

	public RefreshRequestBuilder setField(String field) {
		request.field(field);
		return this;
	}

	public RefreshRequestBuilder setType(String type) {
		request.setType(type);
		return this;
	}

	public RefreshRequestBuilder setAction(String action) {
		request.action(action);
		return this;
	}
}
