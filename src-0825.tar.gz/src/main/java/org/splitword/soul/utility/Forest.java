package org.splitword.soul.utility;

public class Forest implements TrieInterface {
	private TrieInterface[] branchs = new TrieInterface[65536];

	public TrieInterface add(TrieInterface branch) {
		TrieInterface temp = this.branchs[branch.getC()];
		if (temp == null)
			this.branchs[branch.getC()] = branch;
		else {
			switch (branch.getStatus()) {
			case 1:
				if (temp.getStatus() == 3) {
					temp.setStatus(2);
				}
				break;
			case 3:
				if (temp.getStatus() == 1) {
					temp.setStatus(2);
				}
				temp.setParam(branch.getParams());
			}
		}
		return this.branchs[branch.getC()];
	}

	public boolean contains(char c) {
		return this.branchs[c] != null;
	}

	public TrieInterface get(char c) {
		if (c > 66535) {
			return null;
		}
		return this.branchs[c];
	}

	public int compareTo(char c) {
		return 0;
	}

	public boolean equals(char c) {
		return false;
	}

	public char getC() {
		return '\000';
	}

	public int getNature() {
		return 0;
	}

	public byte getStatus() {
		return 0;
	}

	public void setNature(int nature) {
	}

	public void setStatus(int status) {
	}

	public int getSize() {
		return this.branchs.length;
	}

	public String[] getParams() {
		return null;
	}

	public void setParam(String[] param) {
	}

	public TrieInterface getParams(String keyWord) {
		TrieInterface branch = this;
		for (int j = 0; j < keyWord.length(); j++) {
			branch = branch.get(keyWord.charAt(j));
			if (branch == null) {
				return null;
			}
		}
		return branch;
	}

	public GetTrieWords getWord(String content) {
		return new GetTrieWords(this, content);
	}

	public void clear() {
		// clear memory
		branchs = new TrieInterface[65535];
	}
}