package org.splitword.soul.utility;

import java.io.BufferedReader;
import java.io.IOException;

import org.splitword.soul.domain.Term;

public class LibraryToForest {

	public static Forest fillForest(Forest forest, BufferedReader br)
			throws Exception {
		if (br == null)
			return forest;
		try {
			String temp = null;
			while ((temp = br.readLine()) != null) {
				if (StringUtil.isBlank(temp))
					continue;
				insertWord(forest, temp);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			br.close();
		}
		return forest;
	}

	public static void insertWord(Forest forest, String lineStr) {
		String[] param = lineStr.split("\\s+");
		for (int i = 0; i < param.length; i++) {
			if (StringUtil.isBlank(param[i]))
				try {
					throw new IOException("library error ,locate in " + lineStr);
				} catch (IOException e) {
					e.printStackTrace();
				}
			else
				param[i] = WordAlter.alterAlphaAndNumber(param[i]);
		}
		String[] resultParams = new String[param.length - 1];
		for (int j = 1; j < param.length; j++) {
			resultParams[j - 1] = param[j];
		}
		insertKeyValue(forest, param[0], resultParams);
	}

	public static void insertWord(Forest forest, TrieValue value) {
		insertKeyValue(forest, value.getKeyword(), value.getParamers());
	}

	private static void insertKeyValue(Forest forest, String key, String[] param) {
		TrieInterface branch = forest;
		char[] chars = key.toCharArray();
		for (int i = 0; i < chars.length; i++) {
			if (i == chars.length - 1) {
				branch.add(new Branch(chars[i], 3, param));
			} else {
				branch.add(new Branch(chars[i], 1, null));
			}
			branch = branch.get(chars[i]);
		}
	}

	public static void removeWord(Forest forest, String word) {
		TrieInterface branch = forest;
		char[] chars = WordAlter.alterAlphaAndNumber(word).toCharArray();
		for (int i = 0; i < chars.length; i++) {
			if (branch == null)
				return;
			if (chars.length == i + 1) {
				branch.add(new Branch(chars[i], -1, null));
			}
			branch = branch.get(chars[i]);
		}
	}

	public static TrieInterface termStatus(TrieInterface branch, String name) {
		for (int j = 0; j < name.length(); j++) {
			branch = branch.get(name.charAt(j));
			if (branch == null) {
				return null;
			}
		}
		return branch;
	}

	public static TrieInterface termStatus(TrieInterface branch, Term term) {
		String name = term.getName();
		return termStatus(branch, name);
	}
}