package org.splitword.soul.recognition;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.splitword.soul.domain.NewWord;
import org.splitword.soul.domain.Term;
import org.splitword.soul.domain.TermNature;
import org.splitword.soul.domain.ViterbiGraph;
import org.splitword.soul.jcseg.util.ChineseHelper;
import org.splitword.soul.utility.TermUtil;

public class RuleRecogntion {
	private static Map<String, List<RulePojo>> ruleMap = new HashMap<String, List<RulePojo>>();
	// private static Log log = LogFactory.getLog(RuleRecogntion.class);
	static StringBuilder strBuilder = null;
	static List<Integer> lenList = null;
	static List<String> endList = null;
	static List<Boolean> stayList = null;
	static final String[] strs = { "《", "“", "\"", "、", "——", "-", "【", "(",
			",", "：", "或", " " };
	static {
		final int baseLen = 4;
		for (String str : strs) {
			List<RulePojo> list = new LinkedList<RulePojo>();
			if (str.equals("《")) {
				list.add(new RulePojo("》", 5));
			} else if (str.equals("“")) {
				list.add(new RulePojo("”", 5));
			} else if (str.equals("\"")) {
				list.add(new RulePojo("\"", 5));
			} else if (str.equals("、")) {
				list.add(new RulePojo("、", 5, true));
				list.add(new RulePojo(")", 5, false));
				list.add(new RulePojo("的", 2, false));
				list.add(new RulePojo("等", 2, false));
				list.add(new RulePojo("和", 2, false));
				list.add(new RulePojo("及", 2, false));
			} else if (str.equals("——")) {
				list.add(new RulePojo("——", baseLen, true));
			} else if (str.equals("-")) {
				list.add(new RulePojo("-", baseLen));
			} else if (str.equals("【")) {
				list.add(new RulePojo("】", 6));
			} else if (str.equals("(")) {
				list.add(new RulePojo(")", 4));
				list.add(new RulePojo("、", 4));
			} else if (str.equals(",")) {
				list.add(new RulePojo(",", 3));
			} else if (str.equals("：")) {
				list.add(new RulePojo(" ", 4));
			} else if (str.equals(" ")) {
				list.add(new RulePojo(" ", 4));
			} else if (str.equals("或")) {
				list.add(new RulePojo("的", 3));
				list.add(new RulePojo("在", 3));
				list.add(new RulePojo("；", 3));
				list.add(new RulePojo(" ", 3));
				list.add(new RulePojo("。", 3));
				list.add(new RulePojo("，", 3));
				list.add(new RulePojo(";", 3));
			}
			if (!list.isEmpty())
				ruleMap.put(str, list);
		}
	}

	private static void reset() {
		endList = null;
		strBuilder = null;
		stayList = null;
		lenList = null;
	}

	public static void recognition(Term[] terms) {
		String name = null;
		Term from = null;
		Term to = null;
		int length = terms.length - 1;
		for (int i = 0; i < length; i++) {
			if (terms[i] == null)
				continue;
			name = terms[i].getName();
			if (endList == null) {
				if (ruleMap.get(name) != null) {
					List<RulePojo> list = ruleMap.get(name);
					endList = new LinkedList<String>();
					stayList = new LinkedList<Boolean>();
					lenList = new LinkedList<Integer>();
					for (int j = 0; j < list.size(); j++) {
						RulePojo pojo = list.get(j);
						endList.add(pojo.string());
						stayList.add(pojo.stay());
						lenList.add(pojo.maxLength());
					}
					strBuilder = new StringBuilder();
					from = terms[i];
				}
			} else if (endList.contains(name)) {
				String word = strBuilder.toString();
				to = terms[i];
				int index = -1;
				for (int j = 0; j < endList.size(); j++) {
					if (endList.get(j).equals(name)) {
						index = j;
						break;
					}
				}
				Term term2 = to.getFrom();
				Term term1 = from.getTo();
				if (term1.equals(term2)) {
					// 已经是一个词，不需做任何事
				} else if (ChineseHelper.allChineseChar(word)
						&& (word.length() >= 2)
						&& (word.length() <= lenList.get(index))) {
					int offe = term1.getOffe();
					for (int k = offe; k < to.getOffe(); k++)
						terms[k] = null;
					Term term = new Term(word, offe, new TermNature("rule", 1));
					terms[offe] = term;
					TermUtil.termLink(from, term);
					TermUtil.termLink(term, to);
				}
				boolean flag = stayList.get(index);
				if (flag)
					i -= 1;
				reset();
			} else if (checkMaximumLen(strBuilder.length())) {
				reset();
			} else {
				strBuilder.append(name);
			}
		}
		reset();// must call this function
	}

	private static boolean checkMaximumLen(int len) {
		Set<Integer> set = new TreeSet<Integer>();
		for (int i = 0; i < lenList.size(); i++) {
			if (len >= (lenList.get(i) + 1)) {
				set.add(i);
			}
		}
		if (set.isEmpty())
			return false;
		else if (set.size() == lenList.size())
			return true;
		else {
			List<String> list1 = new LinkedList<String>();
			List<Boolean> list2 = new LinkedList<Boolean>();
			List<Integer> list3 = new LinkedList<Integer>();
			for (int j = 0; j < lenList.size(); j++) {
				if (!set.contains(j)) {
					list1.add(endList.get(j));
					list2.add(stayList.get(j));
					list3.add(lenList.get(j));
				}
			}
			endList = list1;
			stayList = list2;
			lenList = list3;
			return false;
		}
	}

	public static List<NewWord> recognition(ViterbiGraph graph) {
		return recognition(graph.convertedStr);
	}

	private static List<NewWord> recognition(String sentence) {
		return null;
	}
}
