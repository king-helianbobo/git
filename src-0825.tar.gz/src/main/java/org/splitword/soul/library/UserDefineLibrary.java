package org.splitword.soul.library;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.elasticsearch.plugin.EsStaticValue;
import org.splitword.soul.utility.Forest;
import org.splitword.soul.utility.IOUtil;
import org.splitword.soul.utility.LibraryToForest;
import org.splitword.soul.utility.MyStaticValue;
import org.splitword.soul.utility.StringUtil;
import org.splitword.soul.utility.TrieInterface;
import org.splitword.soul.utility.TrieValue;
import org.splitword.soul.utility.WordAlter;

public class UserDefineLibrary {
	private static Log log = LogFactory.getLog(UserDefineLibrary.class);
	public static List<Forest> forests = null;
	public static Forest ambiguityForest = null;
	static {
		initUserLibrary();
		initAmbiguityLibrary();
	}

	public static void insertWordToUserDefineLibrary(String key, String nature,
			int freq) {
		String[] paramers = new String[2];
		paramers[0] = WordAlter.alterAlphaAndNumber(nature);
		paramers[1] = String.valueOf(freq);
		TrieValue value = new TrieValue(WordAlter.alterAlphaAndNumber(key),
				paramers);
		Forest forest = forests.get(0);
		LibraryToForest.insertWord(forest, value);
	}

	private static boolean isOverlap(String str1, String str2) {
		int len1 = str1.length();
		int len2 = str2.length();
		int len = Math.min(len1, len2);
		for (int i = 1; i <= len; i++) {
			if (str1.substring(0, i).equals(str2.substring(len2 - i)))
				return true;
			if (str2.substring(0, i).equals(str1.substring(len1 - i)))
				return true;
		}
		return false;
	}

	private static void checkAmbiguity(BufferedReader br) throws Exception {
		Map<Integer, String> tree = new TreeMap<Integer, String>();
		int i = 0;
		String temp = null;
		while ((temp = br.readLine()) != null) {
			if (StringUtil.isBlank(temp))
				continue;
			String[] param = temp.split("\\s+");
			tree.put(i, param[0]);
			for (int j = 0; j < param.length; j++) {
				if (StringUtil.isBlank(param[j]))
					throw new IOException("ambiguity library error,locate in "
							+ (i + 1) + " line!");
			}
			++i;
		}
		int size = i;
		for (i = 0; i < size; i++) {
			String stri = tree.get(i);
			for (int j = i + 1; j < size; j++) {
				String strj = tree.get(j);
				if (isOverlap(stri, strj)) {
					log.error("word " + stri + " conflict with " + strj);
				}
			}
		}
	}

	/**
	 * load ambiguity sentence library
	 */
	private static void initAmbiguityLibrary() {
		try {
			BufferedReader reader = MyStaticValue.ambiguityLibraryReader();
			checkAmbiguity(reader);
			ambiguityForest = LibraryToForest.fillForest(new Forest(), reader);
			reader.close();
		} catch (Exception e) {
			log.error("init ambiguity library error.");
			e.printStackTrace();
		}

	}

	private static void initUserLibrary() {
		try {
			forests = new LinkedList<Forest>();
			Forest userDefineForest1 = new Forest();
			Forest userDefineForest2 = new Forest();
			Forest userDefineForest3 = new Forest();
			forests.add(userDefineForest1);
			forests.add(userDefineForest2);
			forests.add(userDefineForest3);
			loadLibrary(forests, MyStaticValue.userDefineLibrary1Reader());
			loadLibrary(forests, MyStaticValue.userDefineLibrary2Reader());
			loadLibrary(forests, MyStaticValue.userDefineLibrary3Reader());
			loadSynonymLibrary(forests, "library/synonym-tax.txt");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void loadSynonymLibrary(List<Forest> forestList, String path) {
		String convertedPath = EsStaticValue.getPath(path);
		log.info(convertedPath);
		BufferedReader br = null;
		try {
			br = new BufferedReader(new InputStreamReader(new FileInputStream(
					convertedPath), "UTF-8"));

			String temp = null;

			while ((temp = br.readLine()) != null) {
				if (StringUtil.isBlank(temp)) {
					continue;
				} else {
					String[] strs = temp.split(",");
					for (String key1 : strs) {
						if (StringUtil.isBlank(key1))
							continue;
						String key = WordAlter.alterAlphaAndNumber(key1);
						boolean bExist = false;
						for (int i = 0; i < forestList.size(); i++) {
							Forest forest = forestList.get(i);
							TrieInterface branch = LibraryToForest.termStatus(
									forest, key);
							if (branch != null
									&& (branch.getStatus() == 2 || branch
											.getStatus() == 3)) {
								log.info("This string " + key
										+ " has contained!");
								bExist = true;
							}
						}
						if (!bExist) {
							log.info("This string " + key + " is inserted");
							TrieValue value = new TrieValue(key, "userDefine",
									"1000");
							if (key.length() <= 3 && key.length() >= 2)
								LibraryToForest.insertWord(forestList.get(0),
										value);
							else if (key.length() <= 5 && key.length() >= 4)
								LibraryToForest.insertWord(forestList.get(1),
										value);
							else
								LibraryToForest.insertWord(forestList.get(2),
										value);
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			IOUtil.close(br);
			br = null;
		}
	}

	private static void loadLibrary(List<Forest> forestList, BufferedReader br) {
		String temp = null;
		TrieValue value = null;
		try {
			if (forestList.size() != 3)
				throw new IOException("There shoud be three list!");
			while ((temp = br.readLine()) != null) {
				if (StringUtil.isBlank(temp)) {
					continue;
				} else {

					String[] strs = WordAlter.alterAlphaAndNumber(temp).split(
							"\\s+");
					if (strs.length != 3)
						throw new IOException("library error ,locate in "
								+ temp);
					for (int i = 0; i < strs.length; i++) {
						if (StringUtil.isBlank(strs[i]))
							throw new IOException("library error ,locate in "
									+ temp);
					}
					String keyword = strs[0];
					if (keyword.length() <= 1)
						continue;
					boolean bExist = false;
					for (int i = 0; i < forestList.size(); i++) {
						Forest forest = forestList.get(i);
						TrieInterface branch = LibraryToForest.termStatus(
								forest, keyword);
						if (branch != null
								&& (branch.getStatus() == 2 || branch
										.getStatus() == 3)) {
							log.info(temp);
							log.info("This string " + keyword + "," + strs[1]
									+ "," + strs[2] + " has contained!");
							bExist = true;
							break;
						}
					}
					if (bExist)
						continue;

					value = new TrieValue(keyword, strs[1], strs[2]);
					if (keyword.length() <= 3 && keyword.length() >= 2)
						LibraryToForest.insertWord(forestList.get(0), value);
					else if (keyword.length() <= 5 && keyword.length() >= 4)
						LibraryToForest.insertWord(forestList.get(1), value);
					else
						LibraryToForest.insertWord(forestList.get(2), value);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			IOUtil.close(br);
			br = null;
		}
	}

	public static void removeWordInForest(Forest forest, String word) {
		if (forest == null)
			forest = forests.get(0);
		LibraryToForest.removeWord(forest, word);
	}

}
