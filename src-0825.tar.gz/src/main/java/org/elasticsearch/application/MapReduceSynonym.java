package org.elasticsearch.application;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Partitioner;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.LineReader;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.elasticsearch.hadoop.mr.JoinFileInputSplit;
import org.elasticsearch.hadoop.mr.JoinNLineInputFormat;
import org.splitword.soul.utility.CompactHashMap;
import org.splitword.soul.word2Vec.WordEntry;

public class MapReduceSynonym extends Configured implements Tool {

	private static final Log log = LogFactory.getLog(MapReduceSynonym.class);
	private static int topNumber = 20;
	private static String seperator = "\t";
	private static final int size = 200;

	private static void insertTopN(String name, float score,
			List<WordEntry> wordsEntrys) {
		if (wordsEntrys.size() < topNumber) {
			wordsEntrys.add(new WordEntry(name, score));
			return;
		}
		float min = Float.MAX_VALUE;
		int minOffe = 0;
		for (int i = 0; i < topNumber; i++) {
			WordEntry wordEntry = wordsEntrys.get(i);
			if (min > wordEntry.score) {
				min = wordEntry.score;
				minOffe = i;
			}
		}
		if (score > min) {
			wordsEntrys.set(minOffe, new WordEntry(name, score));
		}
	}

	public static class ThisMapper extends
			Mapper<LongWritable, Text, Text, Text> {
		Map<String, float[]> anotherMap = new CompactHashMap<String, float[]>();
		String[] anotherStrs = null;
		String[] currentStrs = null;
		Map<String, float[]> currentMap = new CompactHashMap<String, float[]>();
		Map<String, List<WordEntry>> resultMap = new CompactHashMap<String, List<WordEntry>>();

		private static int anotherSeq = 0;
		private static int currentSeq = 0;

		private void initLog4jSettings(String logPath) {
			FileAppender fa = new FileAppender();
			fa.setName("FileLogger");
			fa.setFile(logPath);
			fa.setLayout(new PatternLayout("%d %-5p [%c{1}] %m%n"));
			fa.setThreshold(Level.INFO);
			fa.setAppend(true);
			fa.activateOptions();
			Logger.getRootLogger().getLoggerRepository().resetConfiguration();
			Logger.getRootLogger().addAppender(fa);
		}

		protected void setup(Context context) throws IOException,
				InterruptedException {
			Configuration conf = context.getConfiguration();
			initLog4jSettings("/tmp/4.log");
			JoinFileInputSplit split = (JoinFileInputSplit) context
					.getInputSplit();
			log.info(split.getPath().toString());
			currentSeq = split.getCurrentSeq();
			anotherSeq = split.getAnotherSeq();

			fillWordMap(split, conf, currentMap, split.getStart(),
					split.getStart() + split.getLength());
			currentStrs = new String[currentMap.size()];
			int i = 0;
			for (String word : currentMap.keySet())
				currentStrs[i++] = word;

			if (currentSeq != anotherSeq) {
				fillWordMap(split, conf, anotherMap, split.getAnotherStart(),
						split.getAnotherStart() + split.getAnotherLen());
				anotherStrs = new String[anotherMap.size()];
				i = 0;
				for (String word : anotherMap.keySet())
					anotherStrs[i++] = word;
			}
		}

		/**
		 * Called once at the end of the task.
		 */
		protected void cleanup(Context context) throws IOException,
				InterruptedException {
			anotherMap.clear();
			currentMap.clear();
			resultMap.clear();
			anotherMap = null;
			currentMap = null;
			resultMap = null;// release memory
		}

		@Override
		protected void map(LongWritable key, Text value, Context context)
				throws IOException, InterruptedException {
			Set<WordEntry> set = null;
			String word = null;
			int seqNumber = (int) key.get();
			if (seqNumber < currentMap.size()) {
				word = currentStrs[seqNumber];
				float[] wordVector = currentMap.get(word);
				if (currentSeq == anotherSeq) {
					set = distance(word, wordVector);
				} else {
					set = anotherDistance(word, wordVector);
				}
			} else {
				int number = seqNumber - currentMap.size();
				word = anotherStrs[number];
				List<WordEntry> anotherEntrys = resultMap.get(word);
				set = new TreeSet<WordEntry>(anotherEntrys);
			}
			Iterator<WordEntry> iter = set.iterator();
			StringBuilder builder = new StringBuilder();
			String head1 = "[" + anotherSeq + "," + currentSeq + "]";
			while (iter.hasNext()) {
				builder.append(seperator);
				WordEntry entry = iter.next();
				builder.append(entry.toString());
			}
			String str1 = head1 + builder.toString();
			Text result1 = new Text(str1);
			context.write(new Text(word), result1);
		}

		private void fillWordMap(JoinFileInputSplit split, Configuration conf,
				Map<String, float[]> map, long start, long end)
				throws IOException {
			long pos = start;
			final Path file = split.getPath();
			FileSystem fs = file.getFileSystem(conf);
			FSDataInputStream fileIn = fs.open(split.getPath());
			fileIn.seek(start);
			LineReader reader = new LineReader(fileIn, conf);
			if (start != 0) {
				start += reader.readLine(new Text(), 0, (int) (end - pos));
				pos = start;
			}
			while (pos <= end) {
				Text value = new Text();
				int newSize = reader.readLine(value, Integer.MAX_VALUE,
						(int) (end - pos));
				if (newSize == 0) {
					break;
				} else {
					String temp = value.toString();
					if (temp == null)
						break;
					String[] strs = temp.split("\t");
					String key = strs[0];
					float[] vector = new float[size];
					for (int j = 0; j < size; j++) {
						vector[j] = Float.valueOf(strs[j + 1]);
					}
					map.put(key, vector);
				}
				pos += newSize;
			}
			reader.close();
			fileIn.close();
		}

		@SuppressWarnings("unused")
		private Set<WordEntry> distance(String word, float[] vector)
				throws IOException {
			List<WordEntry> wordEntrys = new ArrayList<WordEntry>(topNumber);
			Set<Entry<String, float[]>> entrySet = anotherMap.entrySet();
			for (Entry<String, float[]> entry : entrySet) {
				String name = entry.getKey();
				if (name.equals(word)) {
					continue;
				}
				float score = 0;
				float[] tmpVector = entry.getValue();
				for (int i = 0; i < vector.length; i++) {
					score += vector[i] * tmpVector[i];
				}
				insertTopN(name, score, wordEntrys);
			}
			return new TreeSet<WordEntry>(wordEntrys);
		}

		@SuppressWarnings("unused")
		private Set<WordEntry> anotherDistance(String word, float[] vector)
				throws IOException {
			List<WordEntry> wordEntrys = new ArrayList<WordEntry>(topNumber);
			for (String name : anotherMap.keySet()) {
				List<WordEntry> anotherEntrys = resultMap.get(name);
				if (anotherEntrys == null)
					anotherEntrys = new ArrayList<WordEntry>(topNumber);
				float score = 0;
				float[] tmpVector = anotherMap.get(name);
				for (int i = 0; i < vector.length; i++) {
					score += vector[i] * tmpVector[i];
				}
				insertTopN(name, score, wordEntrys);
				insertTopN(word, score, anotherEntrys);
				resultMap.put(name, anotherEntrys);
			}
			return new TreeSet<WordEntry>(wordEntrys);
		}
	}

	public static class ThisReducer extends Reducer<Text, Text, Text, Text> {
		public void reduce(Text key, Iterable<Text> values, Context context)
				throws IOException, InterruptedException {
			List<WordEntry> wordEntrys = new ArrayList<WordEntry>(topNumber);
			for (Text val : values) {
				String[] texts = val.toString().split(seperator);
				String tag = texts[0];
				int num = (texts.length - 1) / 2;
				for (int i = 0; i < num; i++) {
					String name = texts[2 * i + 1];
					float score = Float.valueOf(texts[2 * i + 2]);
					insertTopN(name, score, wordEntrys);
				}
			}
			StringBuilder builder = new StringBuilder();
			Set<WordEntry> set = new TreeSet<WordEntry>(wordEntrys);
			Iterator<WordEntry> iter = set.iterator();
			int size = set.size();
			int number = 0;
			while (iter.hasNext()) {
				WordEntry entry = iter.next();
				number++;
				builder.append(entry.toString());
				if (number != size)
					builder.append(seperator);
			}
			Text result = new Text(builder.toString());
			context.write(key, result);
			log.info("totalNumber = " + number);
		}
	}

	public static class ThisPartitioner extends Partitioner<Text, Text> {
		@Override
		public int getPartition(Text key, Text value, int numPartitions) {
			return (key.hashCode() & Integer.MAX_VALUE) % numPartitions;
		}
	}

	public int run(String[] args) throws Exception {
		Configuration conf = getConf();
		int numLines = Integer.valueOf(args[0]);
		conf.setInt("mapreduce.input.lineinputformat.linespermap", numLines);
		Job job = new Job(conf);
		job.setInputFormatClass(JoinNLineInputFormat.class);
		JoinNLineInputFormat.addInputPath(job, new Path(args[1]));
		job.setJarByClass(MapReduceSynonym.class);
		job.setJobName("Word2Vec-For-MapReduce");
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(Text.class);
		job.setNumReduceTasks(4);
		job.setPartitionerClass(ThisPartitioner.class);
		job.setMapperClass(ThisMapper.class);
		job.setReducerClass(ThisReducer.class);
		job.setOutputFormatClass(TextOutputFormat.class);
		FileOutputFormat.setOutputPath(job, new Path(args[2]));

		boolean success = job.waitForCompletion(true);
		return success ? 0 : 1;
	}

	public static void main(String[] args) throws Exception {
		int ret = ToolRunner.run(new MapReduceSynonym(), args);
		System.exit(ret);
	}
}