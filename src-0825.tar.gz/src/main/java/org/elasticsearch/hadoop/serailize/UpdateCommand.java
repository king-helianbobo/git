package org.elasticsearch.hadoop.serailize;

import org.elasticsearch.hadoop.cfg.ConfigurationOptions;
import org.elasticsearch.hadoop.cfg.Settings;
import org.elasticsearch.hadoop.util.BytesArray;
import org.elasticsearch.hadoop.util.StringUtils;

public class UpdateCommand extends AbstractCommand {

	private final boolean UPSERT_DOC;

	private final byte[] HEADER_PREFIX = ("{\""
			+ ConfigurationOptions.ES_OPERATION_UPDATE + "\":{\"_id\":\"")
			.getBytes(StringUtils.UTF_8);
	private final byte[] HEADER_SUFFIX_DOC_UPSERT = ("\"}}\n{\"doc_as_upsert\":true,\"doc\":")
			.getBytes(StringUtils.UTF_8);
	private final byte[] HEADER_SUFFIX_NO_DOC_UPSERT = ("\"}}\n{\"doc\":")
			.getBytes(StringUtils.UTF_8);
	private final byte[] BODY_DOC_UPSERT_SUFFIX = ("}")
			.getBytes(StringUtils.UTF_8);

	public UpdateCommand(Settings settings) {
		super(settings);
		UPSERT_DOC = settings.getUpsertDoc();
	}

	@Override
	protected boolean isIdRequired() {
		return true;
	}

	@Override
	protected byte[] headerPrefix() {
		return HEADER_PREFIX;
	}

	@Override
	protected byte[] headerSuffix() {
		return (UPSERT_DOC ? HEADER_SUFFIX_DOC_UPSERT
				: HEADER_SUFFIX_NO_DOC_UPSERT);
	}

	@Override
	protected byte[] header() {
		throw new UnsupportedOperationException(
				"Id is required but none was given");
	}

	@Override
	public int prepare(Object object) {
		return super.prepare(object) + BODY_DOC_UPSERT_SUFFIX.length;
	}

	@Override
	protected void writeSource(Object object, BytesArray buffer) {
		// write document
		super.writeSource(object, buffer);
		// append body
		copyIntoBuffer(BODY_DOC_UPSERT_SUFFIX, buffer);
	}
}