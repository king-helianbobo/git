package org.elasticsearch.plugin.analyzer;

import java.io.Reader;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.Tokenizer;
import org.apache.lucene.analysis.standard.StandardFilter;
import org.elasticsearch.plugin.EsStaticValue;
import org.elasticsearch.plugin.tokenizer.TaxQueryTokenizer;
import org.splitword.soul.analysis.BasicAnalysis;

public class TaxQueryAnalyzer extends Analyzer {

	public TaxQueryAnalyzer() {
		super();
	}

	@Override
	protected TokenStreamComponents createComponents(String fieldName,
			final Reader reader) {

		Tokenizer tokenizer = new TaxQueryTokenizer(new BasicAnalysis(reader,
				true), reader);

		TokenStream result = new StandardFilter(EsStaticValue.LuceneVersion,
				tokenizer);
		// result = new PinyinTokenFilter(result, false, false);
		return new TokenStreamComponents(tokenizer, result);
	}
}
