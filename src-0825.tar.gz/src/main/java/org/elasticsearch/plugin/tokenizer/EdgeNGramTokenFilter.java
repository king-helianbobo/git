package org.elasticsearch.plugin.tokenizer;

import java.io.IOException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.lucene.analysis.TokenFilter;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
import org.elasticsearch.plugin.EsStaticValue;

public class EdgeNGramTokenFilter extends TokenFilter {
	public static final Side DEFAULT_SIDE = Side.FRONT;
	private static Log log = LogFactory.getLog(EdgeNGramTokenFilter.class);
	public static int offset = 0;
	public static boolean isFront = true;
	private String originalText = null;
	private String convertedText = null;

	/** Specifies which side of the input the n-gram should be generated from */
	public static enum Side {

		/** Get the n-gram from the front of the input */
		FRONT {
			@Override
			public String getLabel() {
				return "front";
			}
		},

		/** Get the n-gram from the end of the input */
		BACK {
			@Override
			public String getLabel() {
				return "back";
			}
		},
		/** Get the n-gram from the end of the input */
		TWOSIDE {

			@Override
			public String getLabel() {
				return "twoside";
			}
		};

		public abstract String getLabel();

		// Get the appropriate Side from a string
		public static Side getSide(String sideName) {
			if (FRONT.getLabel().equals(sideName)) {
				return FRONT;
			}
			if (BACK.getLabel().equals(sideName)) {
				return BACK;
			}
			if (TWOSIDE.getLabel().equals(sideName)) {
				return BACK;
			}
			return null;
		}
	}

	private final int minGram;
	private final int maxGram;
	private Side side;
	private String type;
	private int position;
	private int curGramSize;
	private int tokStart;
	private int tokenEnd;
	private int tokenLength;
	private boolean firstTimeSawThisToken = true;

	private final CharTermAttribute termAtt = addAttribute(CharTermAttribute.class);
	private final OffsetAttribute offsetAtt = addAttribute(OffsetAttribute.class);
	private final TypeAttribute typeAtt = addAttribute(TypeAttribute.class);
	private final PositionIncrementAttribute posAtt = addAttribute(PositionIncrementAttribute.class);

	public EdgeNGramTokenFilter(TokenStream input, Side side, int minGram,
			int maxGram) {
		super(input);
		if (side == null) {
			throw new IllegalArgumentException(
					"side must be either front or back");
		}
		if (minGram < 1) {
			throw new IllegalArgumentException("minGram must be greater than 0");
		}
		if (minGram > maxGram) {
			throw new IllegalArgumentException(
					"minGram must not be greater than maxGram");
		}
		this.minGram = minGram;
		this.maxGram = maxGram;
		this.side = side;
	}

	public EdgeNGramTokenFilter(TokenStream input, Side side, int minGram) {
		super(input);
		if (side == null) {
			throw new IllegalArgumentException(
					"side must be either front or back");
		}
		if (minGram < 1) {
			throw new IllegalArgumentException("minGram must be greater than 0");
		}
		this.minGram = minGram;
		this.maxGram = Integer.MAX_VALUE; // no limit
		this.side = side;
	}

	public EdgeNGramTokenFilter(TokenStream input, String sideLabel,
			int minGram, int maxGram) {
		this(input, Side.getSide(sideLabel), minGram, maxGram);
	}

	@Override
	public final boolean incrementToken() throws IOException {
		while (true) {
			if (originalText == null) {
				if (!input.incrementToken()) {
					return false;
				} else {
					int curTermLength = termAtt.length();
					char[] curTermBuffer = new char[curTermLength];
					System.arraycopy(termAtt.buffer(), 0, curTermBuffer, 0,
							curTermLength);
					tokenLength = curTermLength;
					originalText = new String(curTermBuffer);
					tokStart = offsetAtt.startOffset();
					tokenEnd = offsetAtt.endOffset();
					type = typeAtt.type();
					position = posAtt.getPositionIncrement();
					if (type.equals(EsStaticValue.TYPE_HANZI)) {
						firstTimeSawThisToken = true;
						curGramSize = 1;
						// set minimum size to 1 for Chinese characters
					} else if (type.equals(EsStaticValue.TYPE_SYNONYM)) {
						curGramSize = curTermLength;
						// synonym word not convert to EdgeNGram format
					} else if (type.equals(EsStaticValue.TYPE_PINYIN)) {
						curGramSize = minGram;
						convertedText = originalText.replaceAll(" ", "");
						tokenLength = convertedText.length();
					} else { // English words need keep minGram
						firstTimeSawThisToken = true;
						curGramSize = minGram;
					}
				}
			}
			if (curGramSize <= maxGram) { // current gram length
				if (curGramSize >= tokenLength) {
					// if remaining input is too short, still generate
					if (type.equals(EsStaticValue.TYPE_PINYIN))
						pinyinOperation(0, tokenLength, 0);
					else if (type.equals(EsStaticValue.TYPE_SYNONYM))
						commonOperation(0, tokenLength, 0);
					else {
						int positionInc = firstTimeSawThisToken ? position : 0;
						commonOperation(0, tokenLength, positionInc);
					}
					originalText = null;
					return true;
				} else {
					if (side == Side.FRONT || side == Side.BACK) {
						int start;
						if (side == Side.FRONT)
							start = 0;
						else
							start = tokenLength - curGramSize;
						if (type.equals(EsStaticValue.TYPE_PINYIN))
							pinyinOperation(start, curGramSize, 0);
						else if (type.equals(EsStaticValue.TYPE_SYNONYM))
							commonOperation(start, curGramSize, 0);
						else {
							int inc = firstTimeSawThisToken ? position : 0;
							commonOperation(start, curGramSize, inc);
							if (firstTimeSawThisToken)
								firstTimeSawThisToken = false;
						}
						curGramSize++;
						return true;
					} else {
						int backStart = tokenLength - curGramSize;
						clearAttributes();
						if (isFront) {
							if (type.equals(EsStaticValue.TYPE_PINYIN))
								pinyinOperation(0, curGramSize, 0);
							else if (type.equals(EsStaticValue.TYPE_SYNONYM))
								commonOperation(0, curGramSize, 0);
							else {
								int inc = firstTimeSawThisToken ? position : 0;
								commonOperation(0, curGramSize, inc);
								if (firstTimeSawThisToken)
									firstTimeSawThisToken = false;
							}
							isFront = false;
						} else {
							if (type.equals(EsStaticValue.TYPE_PINYIN))
								pinyinOperation(backStart, curGramSize, 0);
							else if (type.equals(EsStaticValue.TYPE_SYNONYM))
								commonOperation(backStart, curGramSize, 0);
							else {
								int inc = firstTimeSawThisToken ? position : 0;
								commonOperation(backStart, curGramSize, inc);
								if (firstTimeSawThisToken)
									firstTimeSawThisToken = false;
							}
							isFront = true;
							curGramSize++;
						}
						return true;
					}
				}
			}
			originalText = null;
		}
	}

	private void commonOperation(int startOffset, int length, int positionInc) {
		clearAttributes();
		termAtt.append(originalText
				.substring(startOffset, startOffset + length));
		if (type.equalsIgnoreCase(EsStaticValue.TYPE_SYNONYM))
			offsetAtt.setOffset(tokStart, tokenEnd);
		else
			offsetAtt.setOffset(tokStart, tokStart + length);
		typeAtt.setType(type);
		posAtt.setPositionIncrement(positionInc);
	}

	private void pinyinOperation(int start, int len, int positionInc) {
		clearAttributes();
		String subPinyin = convertedText.substring(start, start + len);
		int j = 0;
		int numSpace = 0;
		for (int i = 0; i < originalText.length(); i++) {
			if (j >= subPinyin.length())
				break;
			if (originalText.charAt(i) == subPinyin.charAt(j)) {
				j++;
				continue;
			} else if (originalText.charAt(i) == ' ') {
				numSpace++;
			} else {
				try {
					throw new Exception("Pinyin " + originalText
							+ " is unlegal!");
				} catch (Exception e) {
					log.error("Pinyin: " + originalText + " is unlegal!");
					e.printStackTrace();
				}
			}

		}
		if ((tokStart + numSpace + 1) > tokenEnd)
			log.error("tokenStart and tokenEnd error!");
		offsetAtt.setOffset(tokStart, tokStart + numSpace + 1);
		termAtt.append(subPinyin);
		typeAtt.setType(type);
		posAtt.setPositionIncrement(positionInc);
	}

	@Override
	public void reset() throws IOException {
		super.reset();
		originalText = null;
	}
}