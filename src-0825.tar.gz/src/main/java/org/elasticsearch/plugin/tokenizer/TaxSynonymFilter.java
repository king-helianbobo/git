package org.elasticsearch.plugin.tokenizer;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.lucene.analysis.TokenFilter;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
import org.elasticsearch.plugin.EsStaticValue;

public class TaxSynonymFilter extends TokenFilter {
	private static Log log = LogFactory.getLog(TaxSynonymFilter.class);

	private final CharTermAttribute termAtt = addAttribute(CharTermAttribute.class);
	private final OffsetAttribute offsetAtt = addAttribute(OffsetAttribute.class);
	private final TypeAttribute typeAtt = addAttribute(TypeAttribute.class);
	private final PositionIncrementAttribute posAtt = addAttribute(PositionIncrementAttribute.class);

	private List<String> synonymList = null;
	private String primeToken = null;
	private String tokenType = null;
	private int totalNumber = 1;
	private int tokenStart;
	private int tokenEnd;
	private int tokenPosition;
	private int curNumber = 0;
	private Map<String, List<String>> taxSynonymTree = null;

	public TaxSynonymFilter(TokenStream input) {
		// accept one token stream and synonym tree
		super(input);
		EsStaticValue.loadData();
		taxSynonymTree = EsStaticValue.taxTree;
	}

	@Override
	public final boolean incrementToken() throws IOException {
		while (true) {
			if (primeToken == null) {
				if (!input.incrementToken()) {
					return false;
				} else {
					int curTermLength = termAtt.length();
					char[] curTermBuffer = new char[curTermLength];
					System.arraycopy(termAtt.buffer(), 0, curTermBuffer, 0,
							curTermLength);
					primeToken = new String(curTermBuffer);
					tokenType = typeAtt.type();
					tokenPosition = posAtt.getPositionIncrement();
					totalNumber = 1;
					if (taxSynonymTree != null) {
						List<String> list = taxSynonymTree.get(primeToken);
						if (list != null && list.size() > 0) {
							synonymList = new LinkedList<String>();
							synonymList.addAll(list);
							totalNumber += synonymList.size();
						} else
							synonymList = null;
					} else {
						synonymList = null;
					}
					tokenStart = offsetAtt.startOffset();
					tokenEnd = offsetAtt.endOffset();
					curNumber = 0; // first time we get equivalent Term
				}
			}
			if (curNumber < totalNumber) {
				if (curNumber == 0) {
					clearAttributes();
					offsetAtt.setOffset(tokenStart, tokenEnd);
					termAtt.append(primeToken);
					posAtt.setPositionIncrement(tokenPosition);
					typeAtt.setType(tokenType);
				} else if (synonymList != null) {
					clearAttributes();
					offsetAtt.setOffset(tokenStart, tokenEnd);
					String text = synonymList.remove(0); // get and remove
					termAtt.append(text);
					typeAtt.setType(EsStaticValue.TYPE_SYNONYM);
					posAtt.setPositionIncrement(0);
					if (synonymList.size() == 0)
						synonymList = null;
				}
				curNumber++;
				return true;
			} else
				primeToken = null;
		}
	}

	@Override
	public void reset() throws IOException {
		super.reset();
		primeToken = null;
	}
}
