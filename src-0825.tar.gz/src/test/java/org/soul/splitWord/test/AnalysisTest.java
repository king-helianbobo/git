package org.soul.splitWord.test;

import java.io.IOException;
import java.io.StringReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.elasticsearch.plugin.EsStaticValue;
import org.splitword.soul.analysis.BasicAnalysis;
import org.splitword.soul.domain.Term;
import org.splitword.soul.keyword.WordExtract;
import org.splitword.soul.library.UserDefineLibrary;
import org.splitword.soul.utility.FilterModifyWord;
import org.splitword.soul.utility.StringUtil;
import org.testng.annotations.Test;

public class AnalysisTest {
	private final Log log = LogFactory.getLog(AnalysisTest.class);

	@Test
	public void basicSplitTest() {
		BasicAnalysis analysis = new BasicAnalysis(true);
		String[] texts = { "几年来王玉兰与博爱车队义务接送高考生一百多名,一直协助斯诺登的维基解密",
				"例如我们叫布什总统，为何不叫乔治总统。我们说爱因斯坦，而不是叫他阿尔伯特。", "哆啦Ａ梦是个玩具，什么是哆啦a梦？",
				"税费所属期起始日期", "税费所属期终止日期", "POS机标记", "税费所属期", "税费所属期时间" };
		for (String str : texts) {
			List<Term> parses = analysis.parse(str);
			log.info(parses);
			for (Term parse : parses) {
				if (parse.getSubTermList() != null) {
					List<Term> terms = parse.getSubTermList();
					for (Term subTerm : terms)
						log.info(subTerm.getName());
				}
			}
		}
	}

	// @Test
	public void keywordExtractTest() {
		BasicAnalysis analysis = new BasicAnalysis(true);
		String text = "查询编号： WX20131021036 信件标题： 有可能偷排污水 信件内容： 在我们这边宏源技校，现在是保利地产，原学校宿舍后面我看见工人排了一根下水管，做得很隐密。我不知道他们排的水是不是雨水还是污水，排水管往河里排有没有通过你们，因为我们那里的河今己年水质才好一点，如偷排希望你们查看一下对我们老百姓有一个交待。 信件分类： 咨询 内容分类： 环境市容 接收时间： 2013-10-21 11:20:44 接收部门： 市环保局 答复时间： 2013-10-21 13:05:04 答复部门： 市环保局 处理结果： 经环境监察人员现场查看，投诉人反映的校舍旁有新安装一根排水管，经向项目管理人员了解，该排水管是建筑方提前铺设，原本计划用于新建房地产项目中挖地基进行排水作业，目前还未使用，现场已要求企业不得将建设过程中可能产生的污水通过该排水管排往河道内。大队将做好对该建设项目的监察工作，如发现违法排污现象，将依法进行处理，建议投诉人留下联系方式，以便于大队及时将调查情况回复投诉人，如有情况反映，可第一时间联系新区环保热线电话（15251524891）。 满意度评价： 满意";
		List<Term> parse = analysis.parse(text);
		log.info(parse);
		StringBuilder builder = new StringBuilder();
		for (int i = 0; i < parse.size(); i++) {
			Term term = parse.get(i);
			String name = term.getName();
			String nature = term.getNatrue().natureStr;
			if (StringUtil.isBlank(nature) || StringUtil.isBlank(name))
				continue;
			if (nature.equals("null"))
				continue;
			if (nature.startsWith("vn") || nature.startsWith("n")) {
				log.info(term);
				builder.append(name);
				builder.append("\t");
			}

		}
		log.info(builder.toString());
		WordExtract extractor = new WordExtract();// use text rank algorithm
		extractor.setPrecisionHigh();
		Map<String, Integer> map = extractor.extract(builder.toString(), 10);
		for (String str : map.keySet())
			log.info(str + "," + map.get(str));
	}

	// @Test
	public void stopWordTest() {
		String parseStr = "哆啦Ａ梦是个玩具";
		Set<String> hs = EsStaticValue.stopWordsSet;
		try {
			BasicAnalysis analysis = new BasicAnalysis(new StringReader(
					parseStr));
			Term next = null;
			while ((next = analysis.next()) != null) {
				if (!hs.contains(next.getName())) {
					log.info("[" + next.getName() + "] not skipped");
				} else {
					log.info("[" + next.getName() + "] will skip");
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// @Test
	public void userDefineLibraryTest() {
		BasicAnalysis analysis = new BasicAnalysis(true);
		String str = "soul中文分词是一个不错的系统";
		UserDefineLibrary.insertWordToUserDefineLibrary("soul中文分词",
				"userDefine", 1000);
		List<Term> terms = analysis.parse(str);
		log.info(terms);
		UserDefineLibrary.removeWordInForest(null, "soul中文分词");
		terms = analysis.parse(str);
		log.info(terms);
		str = "上海电力a与2012年财务报表";
		UserDefineLibrary.insertWordToUserDefineLibrary("上海电力Ａ", "词性", 1000);
		terms = analysis.parse(str);
		log.info(terms);
	}

	// @Test
	public void FilterAndUpdateNatureTest() {
		BasicAnalysis analysis = new BasicAnalysis(true);
		HashMap<String, String> updateDic = new HashMap<String, String>();
		updateDic.put("停用词", "userDefine"); // userDefine TermNature
		updateDic.put("并且", "_stop");// use termNature _stop
		updateDic.put("12345", "number");// 数字
		updateDic.put("但是", FilterModifyWord._stop);
		updateDic.put("，", FilterModifyWord._stop);
		FilterModifyWord.setUpdateDic(updateDic);
		List<Term> parse = analysis
				.parse("过滤停用词，并且修正词12345为用户自定义词性，但是必须设置停用词词典");
		parse = FilterModifyWord.modifResult(parse);
		log.info(parse);
	}

}
