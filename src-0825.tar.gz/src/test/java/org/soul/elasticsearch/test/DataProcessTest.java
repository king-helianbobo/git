package org.soul.elasticsearch.test;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.elasticsearch.application.util.OfficialDataUtils;
import org.elasticsearch.application.util.SoulFileWriter;
import org.elasticsearch.application.util.TestDataReader;
import org.splitword.soul.utility.SoulArrays;
import org.testng.annotations.Test;

public class DataProcessTest {
	private static final Log log = LogFactory.getLog(DataProcessTest.class);
	private static ObjectMapper mapper = new ObjectMapper();

	// private String sourcePath = "/mnt/e/official-data-06-28.txt";
	private String sourcePath = "/mnt/e/data_out_7.24";
	// private String sourcePath = "/mnt/e/official-data-07-22.txt";
	// private String writeDir = "/mnt/e/official-06-28/";
	private String writeDir = "/mnt/e/official-07-23/";
	final String prefixTag = "tag";

	// final String prefixTag = "hot";

	// @Test
	public void officialDataTest1() throws Exception {
		List<Map<String, String>> result = null;
		final int totalNum = 8000; // each text file contains 8000 lines
		int documentNumber = 0;
		int actualNumber = 0;
		int duplicateNum = 0;
		Map<String, String> urlTitleMap = new HashMap<String, String>();
		Map<String, Integer> urlCountMap = new HashMap<String, Integer>();
		Map<String, Integer> titleCountMap = new HashMap<String, Integer>();
		SoulFileWriter writer = null;
		TestDataReader reader = new TestDataReader(sourcePath, "utf-8");
		while ((result = reader.nextData(20, TestDataReader.OfficialFormat)) != null) {
			for (int i = 0; i < result.size(); i++) {
				if (actualNumber % totalNum == 0) {
					if (writer != null)
						writer.close();
					int seq = actualNumber / totalNum + 1;
					String writePath = null;
					if (seq < 10)
						writePath = writeDir + prefixTag + "0"
								+ String.valueOf(seq) + ".txt";
					else
						writePath = writeDir + prefixTag + String.valueOf(seq)
								+ ".txt";
					writer = new SoulFileWriter(writePath);
				}
				documentNumber++;
				Map<String, String> tmpEntry = result.get(i);
				Map<String, String> entry = OfficialDataUtils
						.checkThisEntry(tmpEntry);
				if (entry == null)
					continue;
				else {
					String url = entry.get(OfficialDataUtils.idField);
					String title = entry.get(OfficialDataUtils.titleField);
					String tag = entry.get("tag");
					if (tag.equals("热点问题")) {
						String content = entry
								.get(OfficialDataUtils.contentField);
						if (content.indexOf(title) >= 0
								&& content.indexOf("问题") >= 0
								&& content.indexOf("答案") >= 0) {
							int index1 = content.indexOf(title);
							int index2 = content.indexOf("问题");
							int index3 = content.indexOf("答案");
							if ((index2 > index1) && (index3 > index2))
								content = content.substring(index3 + 3);
						}
						entry.put(OfficialDataUtils.contentField, content);
					}
					String tmp = urlTitleMap.get(url);
					if (tmp == null) {
						urlTitleMap.put(url, title);
						urlCountMap.put(url, 1);
						String json = mapper.writeValueAsString(entry);
						writer.writeWithNewLine(json);
						actualNumber += 1;
					} else if (tmp.equals(title)) {
						// log.error(documentNumber + "," + title + "," + url);
						int number = urlCountMap.get(url);
						urlCountMap.put(url, (number + 1));
						duplicateNum++;
					} else {
						// log.error("papa: " + url + "," + title + "," + tmp);
					}
					if (titleCountMap.get(title) == null)
						titleCountMap.put(title, 1);
					else {
						int titleNum = titleCountMap.get(title);
						titleCountMap.put(title, titleNum + 1);
					}
				}
			}
		}
		if (writer != null)
			writer.close();
		log.error(duplicateNum + "," + urlTitleMap.size() + ", actualNumber = "
				+ actualNumber + ",documentNumber = " + documentNumber);
		// for (String str : urlCountMap.keySet()) {
		// Integer number = urlCountMap.get(str);
		// if (number != 2) {
		// log.info("number = " + number + ",url = " + str);
		// }
		// }
		writer = new SoulFileWriter(writeDir + "question1");
		for (String str : titleCountMap.keySet()) {
			Integer number = titleCountMap.get(str);
			Map<String, Integer> tmpMap = new HashMap<String, Integer>();
			tmpMap.put(str, number);
			String json = mapper.writeValueAsString(tmpMap);
			writer.writeWithNewLine(json);
		}
		writer.close();
	}

	// @Test
	public void officialDataTest2() throws JsonParseException,
			JsonMappingException, NumberFormatException, IOException {
		Map<String, Integer> tableMap = new HashMap<String, Integer>();
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				new FileInputStream(writeDir + "question"), "UTF-8"));
		String temp = null;
		while ((temp = reader.readLine()) != null) {
			temp = temp.trim();
			JsonParser jsonParser = mapper.getJsonFactory().createJsonParser(
					temp);
			@SuppressWarnings("unchecked")
			Map<String, Integer> entry = mapper
					.readValue(jsonParser, Map.class);
			for (String key : entry.keySet()) {
				int value = entry.get(key);
				tableMap.put(key, value);
			}
		}
		reader.close();

		List<Map.Entry<String, Integer>> list = SoulArrays.sortMapByValue(
				tableMap, 1);
		for (int i = 0; i < 200; i++) {
			Map.Entry<String, Integer> entry = list.get(i);
			String key = entry.getKey();
			log.info(entry.getKey() + ", " + String.valueOf(entry.getValue()));
		}
	}

	// @Test(enabled = true)
	public void officialDataTest3() throws Exception {
		SoulFileWriter writer = new SoulFileWriter("/tmp/b.txt");
		TestDataReader reader = new TestDataReader("/mnt/e/official-07-22/",
				"utf-8");
		List<Map<String, String>> result = null;
		SoulFileWriter urlWriter = new SoulFileWriter("/tmp/1.txt");

		Map<Float, String> map1 = new HashMap<Float, String>();
		Map<Float, String> map2 = new HashMap<Float, String>();
		Map<Float, String> map3 = new HashMap<Float, String>();
		while ((result = reader.nextData(10, TestDataReader.JsonFormat)) != null) {
			for (int i = 0; i < result.size(); i++) {
				Map<String, String> entry = result.get(i);
				String title = entry.get(OfficialDataUtils.titleField);
				String content = entry.get(OfficialDataUtils.contentField);
				String url = entry.get(OfficialDataUtils.urlField);
				urlWriter.writeWithNewLine(entry.get("id"));
				int count = OfficialDataUtils.notChineseCharCount(content);
				float ratio = ((float) count) / (float) content.length();
				if (ratio > 0.0) {
					map1.put((float) ratio, url);
					map2.put((float) ratio, content);
					map3.put((float) ratio, title);
				}
			}
		}
		List<Entry<Float, String>> list = SoulArrays.sortMapByKey(map1, 1);
		for (int i = 0; i < 200; i++) {
			Entry<Float, String> entry = list.get(i);
			float ratio = entry.getKey();
			String content = map2.get(ratio);
			String url = map1.get(ratio);
			String title = map3.get(ratio);
			writer.writeWithNewLine("**************Beg**************");
			writer.writeWithNewLine(url);
			writer.writeWithNewLine(title);
			writer.writeWithNewLine(content);
			log.info(ratio);
			writer.writeWithNewLine("**************End**************");
		}
		writer.close();
		urlWriter.close();
	}

	private void filterJson(TestDataReader reader, Set<String> filters,
			String writeDir, String prefixTag) throws Exception {
		List<Map<String, String>> result = null;
		final int totalNum = 8000; // each text file contains 8000 lines
		SoulFileWriter writer = null;
		int actualNumber = 0;
		while ((result = reader.nextData(20, TestDataReader.JsonFormat)) != null) {
			for (int i = 0; i < result.size(); i++) {
				if (actualNumber % totalNum == 0) {
					if (writer != null)
						writer.close();
					int seq = actualNumber / totalNum + 1;
					String writePath = null;
					if (seq < 10)
						writePath = writeDir + prefixTag + "0"
								+ String.valueOf(seq) + ".txt";
					else
						writePath = writeDir + prefixTag + String.valueOf(seq)
								+ ".txt";
					writer = new SoulFileWriter(writePath);
				}
				Map<String, String> tmpEntry = result.get(i);
				String id = tmpEntry.get("id");
				if (!filters.contains(id)) {
					String json = mapper.writeValueAsString(tmpEntry);
					writer.writeWithNewLine(json);
					actualNumber += 1;
				}
			}
		}
		if (writer != null)
			writer.close();
	}

	@Test(enabled = true)
	public void officialDataTest4() throws Exception {
		BufferedReader reader1 = new BufferedReader(new InputStreamReader(
				new FileInputStream("/tmp/1.txt"), "UTF-8"));
		String temp = null;
		Set<String> urlSet = new HashSet<String>();
		while ((temp = reader1.readLine()) != null) {
			temp = temp.trim();
			String id = temp;
			urlSet.add(id);
		}
		reader1.close();
		TestDataReader reader2 = new TestDataReader("/mnt/e/official-07-23",
				"utf-8");
		filterJson(reader2, urlSet, "/tmp/b/", "filter");
	}

	// @Test
	public void convertDataToHdfsFormat() throws IOException {
		TestDataReader reader = new TestDataReader("/tmp/staticpage_update",
				"utf-8");
		reader.convertToJson("/tmp/official2.txt",
				TestDataReader.OfficialFormat);
		ObjectMapper mapper = new ObjectMapper();
		BufferedReader reader1 = new BufferedReader(new InputStreamReader(
				new FileInputStream("/tmp/official2.txt"), "utf-8"));
		String json = null;
		while ((json = reader1.readLine()) != null) {
			JsonParser jsonParser = mapper.getJsonFactory().createJsonParser(
					json);
			@SuppressWarnings("unchecked")
			Map<String, Object> map = mapper.readValue(jsonParser, Map.class);
			log.info(map.get("id") + "," + map.get("contenttitle"));
		}
		reader1.close();
	}

}
