package org.soul.lucene.test;

import java.io.StringReader;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
import org.elasticsearch.plugin.analyzer.TaxDateAnalyzer;
import org.elasticsearch.plugin.analyzer.TaxQueryAnalyzer;
import org.elasticsearch.plugin.analyzer.TaxSchemaAnalyzer;
import org.testng.annotations.Test;

public class TaxAnalyzerTest {

	private Log log = LogFactory.getLog(TaxAnalyzerTest.class);
	String[] texts = { "江阴市盈嘉置业有限公司在2013年3月份 3月2013年服务费 30万4千" };
	String[] dates = { "2013-02-23", "2013-02", "2013-10" };
	String[] hahas = {
			"机构纳税人主表",
			"30万4千",
			"凭证序号	应征明细序号	税务管理码	历史纳税人名称	征收项目	征收品目	税费所属期起始日期	税费所属期终止日期	缴款期限	申报日期	应征发生日期	预算科目	预算分配比率	税款属性一	税款属性二	征收方式	代征属性	调账类型	注册类型	隶属关系	行业	计税依据	扣除税额	税率	应税税费金额	记账应征金额	作废标记	已开票标记	征收机关	核算机关	管理机关	稽查机关	录入人员	录入时间	修改时间	收款国库	税费标记	财政属地	票证种类	凭证种类	控股类型	税款所属机关	双定序号	录入机关	POS机标记" };

	@Test
	public void TestAnalyzer1() {
		// Analyzer analyzer = new TaxQueryAnalyzer();
		Analyzer analyzer = new TaxSchemaAnalyzer();
		for (String text : hahas)
			analyze(analyzer, text);
	}

	// @Test
	public void TestAnalyzer2() {
		Analyzer analyzer = new TaxDateAnalyzer();
		for (int i = 0; i < dates.length; i++) {
			String date = dates[i];
			analyze(analyzer, date);
		}
	}

	void analyze(Analyzer analyzer, String text) {
		try {
			TokenStream tokenStream = analyzer.tokenStream("content",
					new StringReader(text));
			tokenStream.reset();
			while (tokenStream.incrementToken()) {
				CharTermAttribute charAttribute = tokenStream
						.getAttribute(CharTermAttribute.class);
				OffsetAttribute offsetAttribute = tokenStream
						.getAttribute(OffsetAttribute.class);
				PositionIncrementAttribute posAttr = tokenStream
						.getAttribute(PositionIncrementAttribute.class);
				TypeAttribute typeAtt = tokenStream
						.getAttribute(TypeAttribute.class);
				log.info("[" + offsetAttribute.startOffset() + ","
						+ offsetAttribute.endOffset() + ","
						+ charAttribute.toString() + ","
						+ posAttr.getPositionIncrement() + "," + typeAtt.type()
						+ "]");
			}
			tokenStream.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
