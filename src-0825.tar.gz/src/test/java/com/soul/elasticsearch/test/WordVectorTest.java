package com.soul.elasticsearch.test;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import junit.framework.Assert;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.elasticsearch.application.util.SoulFileWriter;
import org.elasticsearch.application.util.TermPojo;
import org.elasticsearch.application.util.TestDataReader;
import org.splitword.soul.analysis.BasicAnalysis;
import org.splitword.soul.domain.Term;
import org.splitword.soul.keyword.KeyWordComputer;
import org.splitword.soul.utility.OfficialChars;
import org.splitword.soul.utility.StringUtil;
import org.splitword.soul.utility.WordAlter;
import org.splitword.soul.word2Vec.Word2Vec;
import org.splitword.soul.word2Vec.WordEntry;
import org.testng.annotations.Test;

public class WordVectorTest {
	Word2Vec word2Vec = new Word2Vec();
	private static Log log = LogFactory.getLog(WordVectorTest.class);
	String[] texts = { "补办", "牡丹花", "梅花", "牡丹", "挂失", "顺产", "妇科", "美丽", "玫瑰",
			"总经理", "商业", "玫瑰花", "电子商务" };

	// @Test(enabled = true)
	public void combineFileTest() throws IOException {
		String[] paths = { "/mnt/f/vectors3/part-r-00000",
				"/mnt/f/vectors3/part-r-00001", "/mnt/f/vectors3/part-r-00002",
				"/mnt/f/vectors3/part-r-00003" };
		SoulFileWriter writer = new SoulFileWriter(
				"/mnt/f/vectors3/vectors3.txt");
		for (String path : paths) {
			FileInputStream in = new FileInputStream(path);
			BufferedReader br = new BufferedReader(new InputStreamReader(in,
					"utf8"));
			String temp = null;
			while ((temp = br.readLine()) != null) {
				writer.writeWithNewLine(temp);
			}
			br.close();
		}
		writer.close();
	}

	// @Test
	public void freqDataExtractTest() throws FileNotFoundException, IOException {
		SoulFileWriter writer = new SoulFileWriter("/tmp/freq.txt");
		int maxDocFreq = -1;
		BufferedReader br = new BufferedReader(
				new InputStreamReader(new FileInputStream(
						"/mnt/f/important-0523/freq1.txt"), "utf-8"));
		String temp = null;
		Map<String, TermPojo> resultMap = new TreeMap<String, TermPojo>();
		while ((temp = br.readLine()) != null) {
			String result = temp.trim();
			String[] texts = result.split("\t");
			Assert.assertEquals(texts.length, 6);
			String name = texts[0];
			String nature = texts[1];
			int docFreq = Integer.valueOf(texts[2]);
			int totalFreq = Integer.valueOf(texts[3]);
			int titleFreq = Integer.valueOf(texts[4]);
			int contentFreq = Integer.valueOf(texts[5]);
			TermPojo pojo = new TermPojo(name, nature, docFreq, totalFreq,
					titleFreq, contentFreq);
			Assert.assertTrue(resultMap.get(name) == null);
			resultMap.put(name, pojo);
			if (docFreq > maxDocFreq)
				maxDocFreq = docFreq;
		}
		br.close();
		int totalLine = 0;
		for (String key : resultMap.keySet()) {
			TermPojo pojo = resultMap.get(key);
			String nature = pojo.getNature();
			if (nature.equals("null") || nature.equals("w")
					|| nature.equals("m") || nature.equals("en")
					|| nature.equals("nr"))
				continue;
			int totalFreq = pojo.getTotalFreq();
			if (totalFreq >= 20) {
				writer.writeWithNewLine(pojo.toString());
				totalLine++;
			}
		}
		writer.close();
		log.info("max document freq is " + maxDocFreq + ", totalLine is "
				+ totalLine);
	}

	@Test(enabled = true)
	public void loadGoogleModelTest() throws IOException {
		String path = "/mnt/f/tmp/vectors-0530.bin";
		// word2Vec.loadGoogleModel(path);
		word2Vec.loadGoogleModel(path, KeyWordComputer.getFreqMap());
		word2Vec.writeWordMap("/tmp/vectors4.txt");
		for (String text : texts) {
			Set<WordEntry> set = word2Vec.distance(text);
			if (set == null)
				continue;
			else {
				Iterator<WordEntry> iter = set.iterator();
				List<String> list1 = new LinkedList<String>();
				List<Float> list2 = new LinkedList<Float>();
				while (iter.hasNext()) {
					WordEntry entry = iter.next();
					String name = entry.name;
					float score = entry.score;
					if (WordAlter.bIntersection(text, name)) {
						list1.add(name);
						list2.add(score);
					}
				}
				log.info(text + "," + list1 + "," + list2);
			}
		}
	}

	// @Test(enabled = true)
	public void prepareDataForWordVector2() throws Exception {
		List<Set<String>> setList = SynonymDataUtil
				.getData("/tmp/new.txt", ",");
		Map<String, String> map = new HashMap<String, String>();
		for (int i = 0; i < setList.size(); i++) {
			Set<String> set = setList.get(i);
			List<String> list = new LinkedList<String>();
			for (String str : set) {
				if (str.length() >= 2)
					list.add(str);
			}
			if (list.size() >= 2) {
				String str1 = list.get(0);
				for (int k = 1; k < list.size(); k++) {
					String anotherStr = list.get(k);
					map.put(anotherStr, str1);
				}
			}
		}
		FileInputStream in = new FileInputStream(
				"/mnt/f/important-0523/train.txt");
		BufferedReader reader1 = new BufferedReader(new InputStreamReader(in,
				"utf-8"));
		SoulFileWriter writer = new SoulFileWriter("/mnt/f/tmp/b.txt");
		String temp = null;
		int num = 0;
		while ((temp = reader1.readLine()) != null) {
			StringBuilder builder = new StringBuilder();
			String[] strs = temp.split("\\s+");
			for (int i = 0; i < strs.length; i++) {
				String converted = map.get(strs[i]);
				if (converted != null)
					builder.append(converted + " ");
				else
					builder.append(strs[i] + " ");
			}
			writer.writeWithNewLine(builder.toString());
			num++;
			if (num % 10000 == 0)
				log.info("num is " + num);
		}

		reader1.close();
		writer.close();
	}

	// @Test(enabled = true)
	public void prepareDataForWordVector() throws Exception {
		SoulFileWriter writer = new SoulFileWriter("/mnt/f/tmp/b.txt");
		TestDataReader reader = null;
		List<Map<String, String>> result = null;
		BasicAnalysis analysis = new BasicAnalysis();
		int docNumber = 0;
		reader = new TestDataReader(OfficialDataTest.sourcePath, "utf-8");
		while ((result = reader.nextData(20, TestDataReader.OfficialFormat)) != null) {
			writeResultToFile(analysis, writer, result, true);
			docNumber += 20;
		}
		reader = new TestDataReader("/mnt/f/Sogou/", "gbk");
		while ((result = reader.nextData(20, TestDataReader.SogouFormat)) != null) {
			writeResultToFile(analysis, writer, result, false);
			docNumber += 20;
			log.info(docNumber);
		}
		writer.close();
	}

	void writeResultToFile(BasicAnalysis analysis, SoulFileWriter writer,
			List<Map<String, String>> result, boolean bRemove) {
		for (int i = 0; i < result.size(); i++) {
			Map<String, String> entry = result.get(i);
			String title = entry.get("contenttitle");
			String content = entry.get("content");
			if (title == null || content == null)
				continue;
			else if (StringUtil.isBlank(title) || StringUtil.isBlank(content))
				continue;
			if (bRemove) {
				String content2 = OfficialChars.convertInvalidChars(content);
				String title2 = OfficialChars.convertInvalidChars(title);
				title = title2;
				content = content2;
			}
			String toParse = title + "\t" + content;
			List<Term> terms = analysis.parse(toParse);
			StringBuilder builder = new StringBuilder();
			for (int j = 0; j < terms.size(); j++) {
				String item = terms.get(j).getName();
				if (item.length() > 0) {
					builder.append(item + " ");
				}
			}
			builder.append("\n");
			writer.writeStr(builder.toString());
		}
	}
}
