package com.soul.elasticsearch.test;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.elasticsearch.application.util.ExtractUtil;
import org.elasticsearch.application.util.SoulFileWriter;
import org.splitword.soul.jcseg.util.ChineseHelper;
import org.splitword.soul.utility.StringUtil;
import org.testng.Assert;

public class SynonymDataUtil {
	private static final Log log = LogFactory.getLog(SynonymDataUtil.class);
	private static final String splitTag = ",";

	private static List<Set<String>> checkThisList(List<Set<String>> setList,
			Set<String> thisSet) {
		List<Set<String>> last = new LinkedList<Set<String>>();
		Set<Integer> result = new TreeSet<Integer>();
		for (int i = 0; i < setList.size(); i++) {
			Set<String> set = setList.get(i);
			if (set.containsAll(thisSet)) {
				Assert.assertEquals(false, true);
			} else if (thisSet.containsAll(set)) {
				log.info("aContained: " + thisSet);
				log.info("aContained: " + set);
				result.add(i);
			} else
				last.add(set);
		}
		last.add(thisSet);
		return last;
	}

	public static List<Set<String>> checkThisFile(String path, String split)
			throws IOException {
		List<Set<String>> setList = new ArrayList<Set<String>>();
		@SuppressWarnings("resource")
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				new FileInputStream(path), "UTF-8"));
		String temp = null;
		int line = 0;
		terms: while ((temp = reader.readLine()) != null) {
			line++;
			String[] strs = temp.split(split);
			for (String str : strs) {
				if (StringUtil.isBlank(str)
						|| !ChineseHelper.allChineseChar(str))
					log.error(line + " is wrong " + temp);
			}
			Set<String> thisSet = new TreeSet<String>();
			for (String str : strs)
				thisSet.add(str.trim());

			for (int i = 0; i < setList.size(); i++) {
				Set<String> set = setList.get(i);
				if (set.containsAll(thisSet)) {
					log.info("bContained: " + thisSet);
					log.info("bContained: " + set);
					continue terms;
				}
			}
			List<Set<String>> last = checkThisList(setList, thisSet);
			setList.clear();
			setList = last;
		}
		log.info("Total Word Line Numer is " + setList.size());
		return setList;
	}

	public static boolean mergeTwoFiles(String path1, String path2,
			String filePath) throws IOException {
		List<Set<String>> list1 = getData(path1, splitTag);
		List<Set<String>> list2 = getData(path2, splitTag);
		SoulFileWriter writer = new SoulFileWriter(filePath);
		SoulFileWriter anotherWriter = new SoulFileWriter("/tmp/2.txt");
		Set<Integer> coverSet1 = new TreeSet<Integer>();
		Set<Integer> coverSet2 = new TreeSet<Integer>();
		Set<Integer> coverSet3 = new TreeSet<Integer>();
		Set<Integer> coverSet4 = new TreeSet<Integer>();
		int number = 0;
		for (int i = 0; i < list1.size(); i++) {
			Set<String> set1 = list1.get(i);
			int a = 0;
			List<Map<Integer, Set<String>>> result = new LinkedList<Map<Integer, Set<String>>>();
			for (int j = 0; j < list2.size(); j++) {
				Set<String> set2 = list2.get(j);
				boolean bContained = false;
				boolean bCovered = false;
				for (String str : set2) {
					if (set1.contains(str))
						bContained = true;
				}
				if (set2.size() <= set1.size())
					bCovered = set1.containsAll(set2);
				else
					bCovered = set2.containsAll(set1);
				if (bCovered) {
					if (set2.size() < set1.size())
						coverSet1.add(i);
					else if (set2.size() > set1.size())
						coverSet2.add(j);
					else {
						coverSet3.add(i);
						coverSet4.add(j);
					}
				} else if (bContained) {
					Map<Integer, Set<String>> map = new HashMap<Integer, Set<String>>();
					map.put(j, set2);
					result.add(map);
				} else
					a++;
			}
			if (a == list2.size()) {
				Assert.assertEquals(true, result.isEmpty());
				number++;
				anotherWriter.writeStr(ExtractUtil.setToString(set1));
			}
			if (!result.isEmpty())
				test1(writer, result, set1);
		}
		log.info(coverSet1.size() + "," + coverSet2.size() + ","
				+ coverSet3.size() + "," + coverSet4.size());
		log.info(coverSet3);
		log.info(coverSet4);
		log.info("differenet lines:" + number);
		writer.close();

		Iterator<Integer> it = coverSet1.iterator();
		while (it.hasNext()) {
			int seq = it.next();
			Set<String> hahaSet = list1.get(seq);
			anotherWriter.writeStr(ExtractUtil.setToString(hahaSet));
		}
		it = coverSet2.iterator();
		while (it.hasNext()) {
			int seq = it.next();
			Set<String> hahaSet = list2.get(seq);
			anotherWriter.writeStr(ExtractUtil.setToString(hahaSet));
		}
		it = coverSet3.iterator();
		while (it.hasNext()) {
			int seq = it.next();
			Set<String> hahaSet = list1.get(seq);
			anotherWriter.writeStr(ExtractUtil.setToString(hahaSet));
		}
		anotherWriter.close();

		return true;
	}

	private static void test1(SoulFileWriter writer,
			List<Map<Integer, Set<String>>> result, Set<String> set1) {
		List<Set<String>> list = new LinkedList<Set<String>>();
		writer.writeWithNewLine(ZzdxDataTest.preTag);
		writer.writeStr(ExtractUtil.setToString(set1));
		terms: for (int j = 0; j < result.size(); j++) {
			Map<Integer, Set<String>> map = result.get(j);
			Assert.assertEquals(true, map.size() == 1);
			int key = -1;
			for (Integer key1 : map.keySet()) {
				key = key1;
				break;
			}
			Set<String> setII = map.get(key);
			for (int k = 0; k < list.size(); k++) {
				Set<String> setJJ = list.get(k);
				if (setJJ.containsAll(setII)) {
					log.info("bContained: " + set1);
					continue terms;
				} else if (setII.containsAll(setJJ)) {
					log.info("aContained: " + setII);
					log.info("aContained: " + setJJ);
					list.set(k, setII);
					log.info(list.get(k));
					continue terms;
				}
			}
			list.add(setII);
		}
		Set<String> total = new TreeSet<String>();
		for (int k = 0; k < list.size(); k++) {
			Set<String> set2 = list.get(k);
			Set<String> set12 = new TreeSet<String>();
			for (String str : set2) {
				if (!set1.contains(str) && !total.contains(str)) {
					set12.add(str);
					total.add(str);
				}
			}
			if (!set12.isEmpty())
				writer.writeStr(ExtractUtil.setToString(set12));
		}
		writer.writeWithNewLine(ZzdxDataTest.postTag);
	}

	public static List<Set<String>> getData(String path, String regex)
			throws IOException {
		List<Set<String>> list = new ArrayList<Set<String>>();
		String temp = null;
		int line = 0;
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				new FileInputStream(path), "UTF-8"));
		while ((temp = reader.readLine()) != null) {
			line++;
			if (StringUtil.isBlank(temp)) {
				log.error("line number: " + line + " is blank!");
				continue;
			} else if (temp.equals(ZzdxDataTest.preTag))
				continue;
			else if (temp.equals(ZzdxDataTest.postTag))
				continue;
			String[] strs = temp.split(regex);
			Set<String> set = new TreeSet<String>();
			for (String str : strs) {
				String text = str.trim();
				if (!ChineseHelper.allChineseChar(text)
						|| StringUtil.isBlank(text))
					log.error("line number: " + line + ", " + temp);
				else
					set.add(text);
			}
			list.add(set);
		}
		log.info("total number is " + line);
		reader.close();
		return list;
	}
}
