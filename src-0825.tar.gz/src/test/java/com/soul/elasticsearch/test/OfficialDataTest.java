package com.soul.elasticsearch.test;

import static org.elasticsearch.common.xcontent.XContentFactory.jsonBuilder;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.io.MapWritable;
import org.elasticsearch.action.admin.indices.create.CreateIndexResponse;
import org.elasticsearch.action.admin.indices.exists.indices.IndicesExistsResponse;
import org.elasticsearch.application.util.OfficialDataUtils;
import org.elasticsearch.application.util.TestDataReader;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.joda.FormatDateTimeFormatter;
import org.elasticsearch.common.joda.Joda;
import org.elasticsearch.common.joda.time.DateTime;
import org.elasticsearch.common.joda.time.format.DateTimeFormat;
import org.elasticsearch.common.joda.time.format.DateTimeFormatter;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.elasticsearch.common.xcontent.XContentBuilder;
import org.elasticsearch.hadoop.cfg.ConfigurationOptions;
import org.elasticsearch.hadoop.cfg.Settings;
import org.elasticsearch.hadoop.cfg.SettingsManager;
import org.elasticsearch.hadoop.mr.MapReduceWriter;
import org.elasticsearch.hadoop.rest.InitializationUtils;
import org.elasticsearch.hadoop.rest.RestClient;
import org.elasticsearch.hadoop.serailize.IndexCommand;
import org.elasticsearch.hadoop.serailize.MapWritableIdExtractor;
import org.elasticsearch.hadoop.serailize.SerializationUtils;
import org.elasticsearch.hadoop.util.BytesArray;
import org.elasticsearch.hadoop.util.WritableUtils;
import org.splitword.soul.keyword.KeyWordComputer;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class OfficialDataTest {
	private static Log log = LogFactory.getLog(OfficialDataTest.class);
	private RestClient client;
	private Settings settings;
	private TransportClient tcpClient;
	static KeyWordComputer kwe = new KeyWordComputer(20);
	public static String hostName = "192.168.2.249";
	public static String indexName = "official_mini";
	public static String typeName = "table";
	public static String sourcePath = "/mnt/f/tmp/official-05-29/";
	public static FormatDateTimeFormatter formatter = Joda
			.forPattern("yyyy-MM-dd HH:mm:ss||yyyy-MM-dd||yyyy-MM-dd HH:mm||yyyy/MM/dd HH:mm:ss");

	public static DateTimeFormatter outputFormat = DateTimeFormat
			.forPattern("yyyy-MM-dd");

	@BeforeClass
	public void startNode() throws Exception {
		Properties properties = new Properties();
		properties.put(ConfigurationOptions.ES_WRITE_OPERATION, "index");
		properties.put(ConfigurationOptions.ES_MAPPING_ID, "id");
		String resource = indexName + "/" + typeName;
		properties.put(ConfigurationOptions.ES_RESOURCE, resource);
		properties.put(ConfigurationOptions.ES_HOST, hostName);
		settings = SettingsManager.loadFrom(properties);
		SerializationUtils.setValueWriterIfNotSet(settings,
				MapReduceWriter.class, log);
		InitializationUtils.setIdExtractorIfNotSet(settings,
				MapWritableIdExtractor.class, log);
		client = new RestClient(settings);
		tcpClient = new TransportClient()
				.addTransportAddress(new InetSocketTransportAddress(hostName,
						9300));
	}

	@AfterClass
	public void closeResources() {
		tcpClient.close();
		client.close();
	}

	@Test(enabled = true)
	public void testMethod1() throws Exception {
		createIndexMapping();
		indexJsonData(sourcePath, 1000);
	}

	private void indexJsonData(String path, int number) throws Exception {
		IndexCommand command = new IndexCommand(settings);
		TestDataReader reader = new TestDataReader(path, "utf-8");
		List<Map<String, String>> result = null;
		BytesArray data = new BytesArray(20 * 1024 * 1024);
		int currentNum = 0;
		while ((result = reader.nextData(20, TestDataReader.JsonFormat)) != null) {
			for (int i = 0; i < result.size(); i++) {
				Map<String, String> tmpEntry = result.get(i);
				Map<String, String> entry = OfficialDataUtils
						.checkThisEntry(tmpEntry);
				if (entry == null)
					continue;
				else {
					String title = (String) entry.get("contenttitle");
					String content = (String) entry.get("content");
					entry.put("keywords", kwe.computeKeywords(title, content));
					log.info(entry.get("keywords"));
					String time = (String) entry.get("postTime");
					log.info(time);
					if (!time.equals("null")) {
						DateTime dt = formatter.parser().parseDateTime(time);
						// int iDoW = dt.getDayOfWeek();
						// log.info(dt.toString() + "," + iDoW);
						String date = dt.toString(outputFormat);
						entry.put("postTime", date);
						log.info(date);
					} else
						entry.remove("postTime");
					// entry.put(, "1970-01-01");
					MapWritable writable = (MapWritable) WritableUtils
							.toWritable(entry);
					int entrySize = command.prepare(writable);
					if (entrySize + data.size() > data.capacity()) {
						client.bulk(settings.getIndexType(), data.bytes(),
								data.size());
						data.reset();
					}
					command.write(writable, data);
				}
			}
			currentNum++;
			if (currentNum >= number && number > 0)
				break;
		}
		client.bulk(settings.getIndexType(), data.bytes(), data.size());
		data.reset();
	}

	private void createIndexMapping() {
		try {
			IndicesExistsResponse existsResponse = tcpClient.admin().indices()
					.prepareExists(indexName).execute().actionGet();
			if (existsResponse.isExists()) {
				// if index exist, delete it
				tcpClient.admin().indices().prepareDelete(indexName).execute()
						.actionGet();
			}
			XContentBuilder builder = (XContentBuilder) jsonBuilder()
					.startObject().startObject("settings").startObject("index")
					.field("refresh_interval", -1)
					.field("number_of_replicas", 1).endObject().endObject()
					.startObject("mappings").startObject(typeName)
					.startObject("properties").startObject("url")
					.field("type", "string").field("index", "not_analyzed")
					.endObject().startObject("tag").field("type", "string")
					.field("index", "not_analyzed").endObject()
					.startObject("postTime").field("type", "date")
					.field("ignore_malformed", false).field("format", "date")
					.endObject().startObject("source").field("type", "string")
					.field("index", "not_analyzed").endObject()
					.startObject("keywords").field("type", "multi_field")
					.startObject("fields").startObject("keywords")
					.field("type", "string")
					.field("index_analyzer", "whitespace").endObject()
					.startObject("untouched").field("type", "string")
					.field("index", "not_analyzed").endObject().endObject()
					.endObject().startObject("contenttitle")
					.field("type", "multi_field").startObject("fields")
					.startObject("contenttitle").field("type", "string")
					.field("index_analyzer", "soul_title")
					.field("search_analyzer", "soul_query").endObject()
					.startObject("untouched").field("type", "string")
					.field("index", "not_analyzed").endObject().endObject()
					.endObject().startObject("content").field("type", "string")
					.field("index_analyzer", "soul_index")
					.field("search_analyzer", "soul_query").endObject()
					.endObject().endObject().endObject().endObject();
			String settings = builder.string();
			log.info(settings);
			CreateIndexResponse createIndexResponse = tcpClient.admin()
					.indices().prepareCreate(indexName).setSource(settings)
					.execute().actionGet();
			assertThat(createIndexResponse.isAcknowledged(), is(true));
			tcpClient.admin().cluster().prepareHealth(indexName)
					.setWaitForGreenStatus().execute().actionGet();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
