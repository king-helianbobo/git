package com.soul.elasticsearch.test;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.elasticsearch.application.util.ExtractUtil;
import org.elasticsearch.application.util.SoulFileWriter;
import org.junit.Assert;
import org.splitword.soul.jcseg.util.ChineseHelper;
import org.splitword.soul.utility.StringUtil;
import org.splitword.soul.utility.WordAlter;
import org.testng.annotations.Test;

public class ZzdxDataTest {
	private static final String splitTag = ",";
	private static final Log log = LogFactory.getLog(ZzdxDataTest.class);
	public static final String preTag = "**************************Beg**************************";
	public static final String postTag = "**************************End**************************";

	// @Test
	public void test1() throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(
				new FileInputStream("part2/a1.txt"), "utf-8"));
		String temp = null;
		int line = 0;
		int number1 = 0;
		int number2 = 0;
		List<Set<String>> result = new LinkedList<Set<String>>();
		while ((temp = br.readLine()) != null) {
			line++;
			if (StringUtil.isBlank(temp)) {
				log.error(line);
				continue;
			}
			String[] texts = temp.split(",");
			Set<String> set = new TreeSet<String>();
			for (String text : texts) {
				if (!ChineseHelper.allChineseChar(text)
						|| StringUtil.isBlank(text))
					log.error(temp + "," + line);
				else
					set.add(text);
			}
			// String key = ExtractUtil.setToString(set, false);
			if (set.size() >= 3) {
				result.add(set);
				number1++;
			} else if (set.size() == 2) {
				number2++;
			} else {
				log.info(line + "," + temp);
			}
		}
		br.close();
		log.info(number1 + ", " + number2);
		SoulFileWriter writer = new SoulFileWriter("/tmp/a111.txt");
		SoulFileWriter.writeSet(writer, result);
	}

	// @Test
	public void testMethod4() throws IOException {
		List<Set<String>> setList1 = SynonymDataUtil.getData(
				"library/synonym-new.txt", splitTag);
		SoulFileWriter writer1 = new SoulFileWriter("/tmp/haha-1.txt");
		SoulFileWriter writer2 = new SoulFileWriter("/tmp/haha-2.txt");
		SoulFileWriter writer3 = new SoulFileWriter("/tmp/haha-3.txt");
		List<Set<String>> setList3 = SynonymDataUtil.getData("library/im1.txt",
				splitTag);
		int num1 = 0, num2 = 0, num3 = 0;
		for (int i = 0; i < setList1.size(); i++) {
			Set<String> set1 = setList1.get(i);
			List<Set<String>> result = new LinkedList<Set<String>>();
			for (int j = 0; j < setList3.size(); j++) {
				Set<String> set3 = setList3.get(j);
				Set<String> commonSet = new TreeSet<String>();
				for (String str : set3) {
					if (set1.contains(str))
						commonSet.add(str);
				}
				if (commonSet.size() > 0) {
					result.add(set3);
				}
			}
			if (result.size() > 0) {
				num1++;
				writer1.writeWithNewLine("*****************Beg****************");
				writer1.writeStr(ExtractUtil.setToString(set1));
				for (Set<String> set3 : result)
					writer1.writeStr(ExtractUtil.setToString(set3));
				// writer1.writeWithNewLine("*****************End****************");
			} else {
				num2++;
				writer2.writeStr(ExtractUtil.setToString(set1));
			}
		}

		terms: for (int i = 0; i < setList3.size(); i++) {
			Set<String> set3 = setList3.get(i);
			for (int j = 0; j < setList1.size(); j++) {
				Set<String> set1 = setList1.get(j);
				Set<String> commonSet = new TreeSet<String>();
				for (String str : set3) {
					if (set1.contains(str))
						commonSet.add(str);
				}
				if (commonSet.size() > 0) {
					continue terms;
				}
			}
			num3++;
			writer3.writeStr(ExtractUtil.setToString(set3));

		}
		log.info(num1 + "," + num2 + "," + num3);
		writer1.close();
		writer2.close();
		writer3.close();
	}

	// @Test
	public void testMethod3() throws IOException {
		List<Set<String>> setList1 = SynonymDataUtil.getData(
				"library/important-0603.txt", splitTag);
		List<Set<String>> setList2 = SynonymDataUtil.getData(
				"library/synonym-new.txt", splitTag);
		setList1.addAll(setList2);
		SoulFileWriter writer = new SoulFileWriter("/tmp/haha6.txt");
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				new FileInputStream("library/haha1.txt"), "UTF-8"));
		String temp = null;
		int num = 0;
		int line = 0;
		int total = 0;
		Set<String> totalString = new TreeSet<String>();
		for (int i = 0; i < setList1.size(); i++) {
			Set<String> set = setList1.get(i);
			totalString.addAll(set);
			total += set.size();
		}

		terms: while ((temp = reader.readLine()) != null) {
			line++;
			String[] strs = temp.split(splitTag);
			Set<String> tmp = new TreeSet<String>();
			for (String str : strs)
				tmp.add(str);
			for (int i = 0; i < setList1.size(); i++) {
				Set<String> set = setList1.get(i);
				if (set.containsAll(tmp)) {
					log.info(temp);
					continue terms;
				}
			}
			writer.writeWithNewLine(temp);
			num++;
		}
		log.info("setList1's isze is " + setList1.size());
		log.info("setList1's total string is " + total + ","
				+ totalString.size());
		log.info("Last synonym group is " + num);
		writer.close();
		reader.close();
	}

	private void check(String writePath, List<Set<String>> setList2)
			throws IOException {
		List<Set<String>> setList1 = SynonymDataUtil.getData(
				"library/important-0613.txt-3", splitTag);
		List<Set<String>> setList3 = SynonymDataUtil.getData(
				"library/synonym-new.txt", splitTag);
		Set<String> strs1 = new TreeSet<String>();
		Set<String> strs2 = new TreeSet<String>();
		Set<String> strs3 = new TreeSet<String>();
		for (Set<String> set : setList1) {
			for (String str : set)
				strs1.add(str);
		}
		for (Set<String> set : setList2) {
			for (String str : set)
				strs2.add(str);
		}
		for (Set<String> set : setList3) {
			for (String str : set)
				strs3.add(str);
		}
		int line = 0;
		SoulFileWriter writer1 = new SoulFileWriter(writePath + "-1");
		for (String str : strs2) {
			if (!strs1.contains(str) && !strs3.contains(str)
					&& str.length() > 1) {
				line++;
				writer1.writeWithNewLine(preTag);
				log.info(str + " is not contained!");
				for (Set<String> set : setList2) {
					if (set.contains(str)) {
						writer1.writeStr(ExtractUtil.setToString(set));
					}
				}
				writer1.writeWithNewLine(postTag);
			}
		}
		writer1.close();
		log.info("total number is " + line);
		log.info(strs1.size() + "," + strs2.size() + "," + strs3.size());
		SoulFileWriter writer2 = new SoulFileWriter(writePath);
		SoulFileWriter.writeSet(writer2, setList1);
	}

	@Test
	public void zzdxDataTest() throws FileNotFoundException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(
				new FileInputStream("/tmp/1"), "utf-8"));
		String writePath = "/tmp/a.txt";
		String temp = null;
		int line = 0;
		List<Set<String>> setList = new LinkedList<Set<String>>();
		while ((temp = br.readLine()) != null) {
			line++;
			if (StringUtil.isBlank(temp)) {
				log.error(line);
				continue;
			}
			String[] texts = temp.split(",");
			if (texts.length == 1) {
				if (!texts[0].equals(preTag) && !texts[0].equals(postTag)) {
					log.error(temp + "," + line);
				}
				continue;
			}
			for (String text : texts) {
				if (!ChineseHelper.allChineseChar(text)
						|| StringUtil.isBlank(text))
					log.error(temp + "," + line);
			}
			Set<String> set = new TreeSet<String>();
			for (int i = 0; i < texts.length; i++) {
				String text = WordAlter.alterAlphaAndNumber(texts[i].trim());
				set.add(text);
			}
			setList.add(set);
		}
		br.close();
		SoulFileWriter writer1 = new SoulFileWriter(writePath + "-tmp");
		SoulFileWriter.writeSet(writer1, setList);
		List<Set<String>> setList1 = SynonymDataUtil.checkThisFile(writePath
				+ "-tmp", splitTag);
		SoulFileWriter writer2 = new SoulFileWriter(writePath);
		SoulFileWriter.writeSet(writer2, setList1);
		// check(writePath, setList1);
	}

	private boolean isTotalContained(String checkStr, Set<String> set) {
		for (String text : set) {
			if (checkStr.indexOf(text) < 0)
				return false;
			if (checkStr.equalsIgnoreCase(text))
				return false;
		}
		String content = checkStr;
		for (String text : set) {
			StringBuilder builder = new StringBuilder();
			builder.append(content.replaceFirst(text, ""));
			content = builder.toString();
		}
		if (content.isEmpty())
			return true;
		else {
			// log.info(checkStr + "," + ExtractUtil.setToString(set, false));
			return true;
		}
	}

	private boolean isContained(String key, Set<String> set) {
		String content = key;
		for (String text : set) {
			StringBuilder builder = new StringBuilder();
			builder.append(content.replaceFirst(text, ""));
			content = builder.toString();
		}
		if (content.isEmpty()) {
			log.info(key + "," + ExtractUtil.setToString(set, false));
			return true;
		} else {

			return false;
		}
	}

	// @Test
	public void test3() throws FileNotFoundException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(
				new FileInputStream("/tmp/result5.txt"), "utf-8"));
		String writePath = "/tmp/a.txt";
		String temp = null;
		int line = 0;
		int number = 0;
		List<Set<String>> setList = new LinkedList<Set<String>>();
		SoulFileWriter writer1 = new SoulFileWriter(writePath + "-1");
		SoulFileWriter writer2 = new SoulFileWriter(writePath + "-2");
		SoulFileWriter writer3 = new SoulFileWriter(writePath + "-3");
		while ((temp = br.readLine()) != null) {
			line++;
			String[] texts = temp.split("\t");
			Assert.assertEquals(1, (texts.length % 2));
			String key = texts[0];
			Set<String> set = new TreeSet<String>();
			for (int i = 1; i < texts.length; i += 2) {
				String text = texts[i];
				int freq = Integer.valueOf(texts[i + 1]);
				Assert.assertEquals(true, (freq > 0));
				if (text.length() > 1)
					set.add(text);
			}
			if (set.size() > 1) {
				if (isTotalContained(key, set))
					writer2.writeWithNewLine(temp);
				else {
					if (!isContained(key, set))
						set.add(key);
					setList.add(set);
				}
			} else if (set.size() == 1) {
				String tmpStr = ExtractUtil.setToString(set, false);
				if (key.indexOf(tmpStr) < 0 && tmpStr.indexOf(key) < 0) {
					set.add(key);
					setList.add(set);
				} else
					writer3.writeWithNewLine(temp);
			} else
				continue;
		}
		br.close();
		SoulFileWriter.writeSet(writer1, setList);
		writer2.close();
		writer3.close();
		log.info("line = " + line + ", invalid number = " + number);
	}

	// @Test
	public void test2() throws FileNotFoundException, IOException {
		List<Set<String>> setList = SynonymDataUtil.getData("/tmp/1", splitTag);
		List<Set<String>> setList1 = SynonymDataUtil.getData(
				"library/synonym-new.txt", splitTag);
		List<Set<String>> setList2 = SynonymDataUtil.getData(
				"library/synonym-soul.txt", splitTag);
		SoulFileWriter writer = new SoulFileWriter("/tmp/a.txt");
		terms: for (int i = 0; i < setList.size(); i++) {
			Set<String> set1 = setList.get(i);
			String tmpStr = ExtractUtil.setToString(set1, false);
			for (int j = 0; j < setList1.size(); j++) {
				Set<String> setj = setList1.get(j);
				if (setj.containsAll(set1)) {
					log.info(tmpStr);
					continue terms;
				}
			}
			for (int j = 0; j < setList2.size(); j++) {
				Set<String> setj = setList2.get(j);
				if (setj.containsAll(set1)) {
					log.info(tmpStr);
					continue terms;
				}
			}
			writer.writeWithNewLine(tmpStr);
		}
		writer.close();
	}
}
