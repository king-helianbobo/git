package com.soul.check.data.test;

import static org.splitword.soul.library.InitDictionary.base;
import static org.splitword.soul.library.InitDictionary.check;
import static org.splitword.soul.library.InitDictionary.status;
import static org.splitword.soul.library.InitDictionary.termNatures;
import static org.splitword.soul.library.InitDictionary.words;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.elasticsearch.utility.ChineseHelper;
import org.splitword.soul.domain.NatureInLib;
import org.splitword.soul.domain.PersonNatureAttr;
import org.splitword.soul.domain.TermNature;
import org.splitword.soul.domain.TermNatures;
import org.splitword.soul.library.InitDictionary;
import org.splitword.soul.library.MyStaticValue;
import org.splitword.soul.library.NatureLibrary;
import org.splitword.soul.library.PersonAttrLib;
import org.splitword.soul.utility.StringUtil;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class BaseArrayTest {
	private static final Log log = LogFactory.getLog(BaseArrayTest.class);

	@BeforeClass
	public void startNode() throws Exception {
		InitDictionary.init();
	}

	@AfterClass
	public void endNode() throws Exception {
		PersonAttrLib.clear();
	}

	private static int baseValue(String str) {
		int baseValue = str.charAt(0);
		for (int i = 1; i < str.length(); i++) {
			baseValue = base[baseValue] + str.charAt(i);
			if (baseValue > base.length - 1)
				log.error("error string " + str);
		}
		return baseValue;
	}

	private static int checkValue(String str) {
		if (str.length() == 1)
			return -1;
		String anotherStr = str.substring(0, str.length() - 1);
		return baseValue(anotherStr);
	}

	private void checkNatureStr(String word, String natureStr) {
		if (StringUtil.isBlank(natureStr))
			log.error(word + "," + natureStr);
		else if (natureStr.equalsIgnoreCase("null")) {
			// log.error(word + "," + natureStr);
		} else {
			TermNature[] natures = TermNature.setNatureStrToArray(natureStr);
			for (TermNature nature : natures) {
				String str = nature.natureInLib.natureStr;
				NatureInLib tmp = NatureLibrary.haveThisNature(str);
				if (tmp == null)
					log.error(word + "," + natureStr);
			}
		}
	}

	@Test
	public void checkBaseArrayTest1() throws NumberFormatException, IOException {
		BufferedReader reader = MyStaticValue.getBaseArrayReader();
		String temp = null;
		int line = 0;
		while ((temp = reader.readLine()) != null) {
			line++;
			String[] strs = temp.split("\\s+");
			String word = strs[1];
			if (StringUtil.isBlank(word))
				log.error(line);
			int status1 = Integer.parseInt(strs[4]);
			if (status1 < 1 || status1 > 5)
				log.error(temp);
			if (status1 < 4) {
				if (!ChineseHelper.allChineseChar(word))
					log.error(line + "," + temp);
				if (!ChineseHelper.isChinese(word))
					log.error(line + "," + temp);
			} else {
				if (ChineseHelper.containChineseChar(word))
					log.error(line + "," + temp);
			}

			int number = Integer.parseInt(strs[0]);
			int baseValue = baseValue(word);
			int checkValue1 = Integer.parseInt(strs[3]);
			int checkValue2 = checkValue(word);
			int checkValue3 = check[number];

			if ((checkValue1 != checkValue2) || (checkValue2 != checkValue3)) {
				log.error(checkValue1 + "," + checkValue2 + "," + checkValue3);
				log.error(strs[0] + "," + baseValue + "," + word);
			}
			if (number != baseValue)
				log.error(strs[0] + "," + baseValue + "," + word);

			String natureStr = strs[5];
			checkNatureStr(word, natureStr);
		}
		reader.close();

	}

	@Test
	public void checkBaseArrayTest3() throws NumberFormatException, IOException {
		Map<String, PersonNatureAttr> personMap = PersonAttrLib.personMap();
		TermNatures tn = null;
		for (String key : personMap.keySet()) {
			int number = baseValue(key);
			String word = words[number];
			// if (StringUtil.isNotBlank(word) && word.equals(key))
			if (word != null && !word.equals(key)) {
				// log.info(key + "," + word);
			} else if (word == null)
				log.info(key + "," + word);
			else {
				// log.info(key + "," + word);
			}
			char c = key.charAt(0);
			// if (key.length() == 1)
			// log.info(key);
			if (status[c] >= 1) {
				continue;
			}
			if (status[c] == 0) {
				log.info(key);
				base[c] = c;
				// check[c] = -1;
				status[c] = 3;
				words[c] = key;
			}
			if ((tn = termNatures[c]) == null) {
				tn = new TermNatures(TermNature.NR);
			}
			tn.personNature = personMap.get(key);
			termNatures[c] = tn;
		}
	}
}
