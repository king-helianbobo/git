package com.soul.elasticsearch.test;

import static org.elasticsearch.common.xcontent.XContentFactory.jsonBuilder;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.io.IOException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.elasticsearch.action.admin.indices.create.CreateIndexResponse;
import org.elasticsearch.action.admin.indices.exists.indices.IndicesExistsResponse;
import org.elasticsearch.common.xcontent.XContentBuilder;
import org.testng.annotations.Test;

public class TempTest extends AbstractDataTest {
	private static final Log log = LogFactory.getLog(TempTest.class);

	@Test
	public void testMethod2() throws IOException {
		createIndexMapping();
	}

	private void createIndexMapping() {
		try {
			IndicesExistsResponse existsResponse = tcpClient().admin()
					.indices().prepareExists(indexName).execute().actionGet();
			if (existsResponse.isExists()) {
				// if index exist, delete it
				tcpClient().admin().indices().prepareDelete(indexName)
						.execute().actionGet();
			}
			// XContentBuilder builder = (XContentBuilder) jsonBuilder()
			// .startObject().startObject("settings").startObject("index")
			// .field("refresh_interval", -1)
			// .field("number_of_replicas", 1).endObject().endObject()
			// .startObject("mappings").startObject(typeName)
			// .startObject("properties").startObject("title")
			// .field("type", "preanalyzed").endObject().endObject()
			// .endObject().endObject();
			XContentBuilder builder = (XContentBuilder) jsonBuilder()
					.startObject().startObject("mappings")
					.startObject(typeName).startObject("properties")
					.startObject("hello").field("type", "preanalyzed")
					.endObject().endObject().endObject().endObject();
			String settings = builder.string();
			log.info(settings);
			CreateIndexResponse createIndexResponse = tcpClient().admin()
					.indices().prepareCreate(indexName).setSource(settings)
					.execute().actionGet();
			assertThat(createIndexResponse.isAcknowledged(), is(true));
			tcpClient().admin().cluster().prepareHealth(indexName)
					.setWaitForGreenStatus().execute().actionGet();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
