package com.soul.elasticsearch.test;

import static org.elasticsearch.common.xcontent.XContentFactory.jsonBuilder;

import java.io.IOException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.elasticsearch.action.admin.indices.create.CreateIndexResponse;
import org.elasticsearch.action.admin.indices.exists.indices.IndicesExistsResponse;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.common.xcontent.XContentBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.QueryStringQueryBuilder;
import org.junit.Assert;
import org.testng.annotations.Test;

public class EdgeNGramTest extends AbstractDataTest {

	private final Log log = LogFactory.getLog(EdgeNGramTest.class);
	private String indexName = "test";
	private String typeName = "test1";

	// @Test
	public void createIndexTestWithMapping() {
		try {
			IndicesExistsResponse existsResponse = tcpClient().admin()
					.indices().prepareExists(indexName).execute().actionGet();
			if (existsResponse.isExists()) { // if index exist, delete it
				tcpClient().admin().indices().prepareDelete(indexName)
						.execute().actionGet();
			}
			XContentBuilder builder = (XContentBuilder) jsonBuilder()
					.startObject().startObject("mappings")
					.startObject(typeName).startObject("properties")
					.startObject("content").field("type", "string")
					.field("index_analyzer", "soul_pinyin")
					.field("search_analyzer", "whitespace").endObject()
					.endObject().endObject().endObject().endObject();
			String settings = builder.string();
			log.info(settings);
			CreateIndexResponse createIndexResponse = tcpClient().admin()
					.indices().prepareCreate(indexName).setSource(settings)
					.execute().actionGet();
			Assert.assertTrue(createIndexResponse.isAcknowledged());
			tcpClient().admin().cluster().prepareHealth(indexName)
					.setWaitForGreenStatus().execute().actionGet();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testMethod1() throws Exception {
		String[] strs = { "沈阳", "沈阳市长", "沈阳大学", "沈从文" };
		for (int i = 0; i < strs.length; i++) {
			tcpClient()
					.prepareIndex(indexName, typeName, String.valueOf((i + 1)))
					.setSource("content", strs[i]).get();
		}
	}

	@Test
	public void testMethod2() {
		String queryStr[] = { "shencong", "shenc", "沈阳", "sheny" };
		for (String str : queryStr) {
			SearchResponse searchResponse = tcpClient()
					.prepareSearch(indexName)
					.setQuery(
							QueryBuilders
									.queryString(str)
									.defaultField("content")
									.defaultOperator(
											QueryStringQueryBuilder.Operator.AND))
					.get();
			log.info("QueryStringTest[" + str + "] ***********"
					+ searchResponse.toString());
		}
	}
}
