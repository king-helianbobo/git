package org.mapper.attachment.test;

import static org.elasticsearch.common.xcontent.XContentFactory.jsonBuilder;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;

import junit.framework.Assert;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.analysis.tokenattributes.FlagsAttribute;
import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
import org.apache.lucene.analysis.tokenattributes.PayloadAttribute;
import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.IndexWriterConfig.OpenMode;
import org.apache.lucene.index.IndexableField;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.RAMDirectory;
import org.elasticsearch.common.Base64;
import org.elasticsearch.common.xcontent.XContentBuilder;
import org.elasticsearch.common.xcontent.XContentFactory;
import org.elasticsearch.index.mapper.DocumentMapper;
import org.elasticsearch.index.mapper.FieldMapper;
import org.elasticsearch.index.mapper.ParseContext.Document;
import org.elasticsearch.index.mapper.preanalyzed.PreAnalyzedFieldMapper;
import org.elasticsearch.index.mapper.preanalyzed.PreAnalyzedFieldMapper.PreAnalyzedTokenStream;
import org.elasticsearch.plugin.EsStaticValue;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class PreAnalyzedMapperTest {
	private static final Log log = LogFactory
			.getLog(PreAnalyzedMapperTest.class);
	Directory directory = null;
	IndexReader indexReader = null;
	IndexSearcher indexSearcher = null;

	@BeforeClass
	public void beforeClass() {
		IndexWriter indexWriter = null;
		directory = new RAMDirectory(); // this index will RAM resident
		IndexWriterConfig iwConfig = new IndexWriterConfig(
				EsStaticValue.LuceneVersion, null);
		iwConfig.setOpenMode(OpenMode.CREATE_OR_APPEND);
		try {
			indexWriter = new IndexWriter(directory, iwConfig);
			String mapping = XContentFactory.jsonBuilder().startObject()
					.startObject("type").startObject("properties")
					.startObject("field").field("type", "preanalyzed")
					.endObject().startObject("time").field("type", "string")
					.endObject().endObject().endObject().endObject().string();

			log.info(mapping);

			DocumentMapper mapper = MapperTestUtils.newParser().parse(mapping);

			FieldMapper fieldMapper = mapper.mappers().smartNameFieldMapper(
					"field");

			Assert.assertEquals(fieldMapper.fieldType().stored(), false);
			XContentBuilder builder1 = jsonBuilder().startObject()
					.field("v", "1")
					.field("str", "This string should be stored.")
					.startArray("tokens");
			builder1.startObject().field("t", "testterm1").field("s", 1)
					.field("e", 8).endObject();
			builder1.startObject().field("t", "testterm2").field("s", 1)
					.field("e", 8).field("i", 0).endObject();
			builder1.startObject().field("t", "testterm3").field("s", 9)
					.field("e", 15).endObject();
			builder1.startObject().field("t", "hello").field("s", 16)
					.field("e", 18).endObject();
			builder1.startObject().field("t", "testterm4")
					.field("p", Base64.encodeBytes("my payload".getBytes()))
					.field("y", "testtype").field("f", "0x4").endObject();
			String json = builder1.string();

			XContentBuilder builder = jsonBuilder().startObject()
					.field("_id", 1).field("field", json)
					.field("time", "hello world").endObject();

			log.info(builder.string());
			// Document doc1 =
			// mapper.parse(builder.string().getBytes()).rootDoc();
			Document doc = mapper.parse(builder.bytes()).rootDoc();
			indexWriter.addDocument(doc);
			indexWriter.close();
			indexReader = DirectoryReader.open(directory);
			indexSearcher = new IndexSearcher(indexReader);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@AfterClass
	public void afterClass() {
		if (indexReader != null) {
			try {
				indexReader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		if (directory != null) {
			try {
				directory.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	@Test
	public void testMethod2() throws IOException {
		Query query = new TermQuery(new Term("field", "testterm1"));
		TopDocs topDocs = indexSearcher.search(query, 1);
		log.info("Hit: " + topDocs.totalHits);
		ScoreDoc[] scoreDocs = topDocs.scoreDocs;
		for (int i = 0; i < Math.min(topDocs.totalHits, 1); i++) {
			org.apache.lucene.document.Document targetDoc = indexSearcher
					.doc(scoreDocs[i].doc);
			log.info("Document content: " + targetDoc.toString());
		}
	}

	// @Test
	public void testMethod1() throws IOException {

		String mapping = XContentFactory.jsonBuilder().startObject()
				.startObject("type").startObject("properties")
				.startObject("field").field("type", "preanalyzed").endObject()
				.endObject().endObject().endObject().string();

		DocumentMapper mapper = MapperTestUtils.newParser().parse(mapping);

		FieldMapper fieldMapper = mapper.mappers()
				.smartNameFieldMapper("field");

		Assert.assertEquals(fieldMapper.fieldType().stored(), false);
		XContentBuilder builder1 = jsonBuilder().startObject().field("v", "1")
				.field("str", "This string should be stored.")
				.startArray("tokens");
		builder1.startObject().field("t", "testterm1").field("s", 1)
				.field("e", 8).endObject();
		builder1.startObject().field("t", "testterm2").field("s", 1)
				.field("e", 8).field("i", 0).endObject();
		builder1.startObject().field("t", "testterm3").field("s", 9)
				.field("e", 15).endObject();
		builder1.startObject().field("t", "testterm4")
				.field("p", Base64.encodeBytes("my payload".getBytes()))
				.field("y", "testtype").field("f", "0x4").endObject();
		String json = builder1.string();

		XContentBuilder builder = jsonBuilder().startObject().field("_id", 1)
				.field("field", json).endObject();

		log.info(builder.string());
		// Document doc1 = mapper.parse(builder.string().getBytes()).rootDoc();
		Document doc = mapper.parse(builder.bytes()).rootDoc();
		log.info(doc.toString());
		log.info(doc.getFields());
		IndexableField field = doc.getField("field");
		String text = field.stringValue();
		log.info(text);
		TokenStream ts = doc.getField("field").tokenStream(
				mapper.indexAnalyzer(), null);

		CharTermAttribute termAtt = ts.addAttribute(CharTermAttribute.class);
		OffsetAttribute offsetAtt = ts.addAttribute(OffsetAttribute.class);
		PositionIncrementAttribute posIncrAtt = ts
				.addAttribute(PositionIncrementAttribute.class);
		PayloadAttribute payloadAtt = ts.addAttribute(PayloadAttribute.class);
		TypeAttribute typeAtt = ts.addAttribute(TypeAttribute.class);
		FlagsAttribute flagsAtt = ts.addAttribute(FlagsAttribute.class);

		assertTrue(ts.incrementToken());
		assertEquals("testterm1",
				new String(termAtt.buffer(), 0, termAtt.length()));
		assertEquals(1, offsetAtt.startOffset());
		assertEquals(8, offsetAtt.endOffset());
		assertEquals(1, posIncrAtt.getPositionIncrement());

		assertTrue(ts.incrementToken());
		assertEquals("testterm2", termAtt.toString());
		assertEquals(1, offsetAtt.startOffset());
		assertEquals(8, offsetAtt.endOffset());
		assertEquals(0, posIncrAtt.getPositionIncrement());

		assertTrue(ts.incrementToken());
		assertEquals("testterm3", termAtt.toString());
		assertEquals(9, offsetAtt.startOffset());
		assertEquals(15, offsetAtt.endOffset());
		assertEquals(1, posIncrAtt.getPositionIncrement());

		assertTrue(ts.incrementToken());
		assertEquals("testterm4", termAtt.toString());
		assertEquals(0, offsetAtt.startOffset());
		assertEquals(0, offsetAtt.endOffset());
		assertEquals(1, posIncrAtt.getPositionIncrement());
		// assertEquals("my payload",
		// new String(Base64.decode(payloadAtt.getPayload().bytes)));
		assertEquals(4, flagsAtt.getFlags());
		assertEquals("testtype", typeAtt.type());
	}

	// @Test
	public void testPreAnalyzedTokenStream() throws IOException {
		XContentBuilder tsBuilder = jsonBuilder().startObject().field("v", "1")
				.field("str", "This string should be stored.")
				.startArray("tokens");
		tsBuilder.startObject().field("t", "testterm1").field("s", 1)
				.field("e", 8).endObject();
		tsBuilder.startObject().field("t", "testterm2").field("s", 1)
				.field("e", 8).field("i", 0).endObject();
		tsBuilder.startObject().field("t", "testterm3").field("s", 9)
				.field("e", 15).endObject();
		tsBuilder.startObject().field("t", "testterm4")
				.field("p", Base64.encodeBytes("my payload".getBytes()))
				.field("y", "testtype").field("f", "0x4").endObject();
		tsBuilder.endArray().endObject();

		PreAnalyzedTokenStream ts = new PreAnalyzedFieldMapper.PreAnalyzedTokenStream(
				tsBuilder.bytes().toBytesRef());

		CharTermAttribute termAtt = ts.addAttribute(CharTermAttribute.class);
		OffsetAttribute offsetAtt = ts.addAttribute(OffsetAttribute.class);
		PositionIncrementAttribute posIncrAtt = ts
				.addAttribute(PositionIncrementAttribute.class);
		PayloadAttribute payloadAtt = ts.addAttribute(PayloadAttribute.class);
		TypeAttribute typeAtt = ts.addAttribute(TypeAttribute.class);
		FlagsAttribute flagsAtt = ts.addAttribute(FlagsAttribute.class);

		assertTrue(ts.incrementToken());
		assertEquals("testterm1",
				new String(termAtt.buffer(), 0, termAtt.length()));
		assertEquals(1, offsetAtt.startOffset());
		assertEquals(8, offsetAtt.endOffset());
		assertEquals(1, posIncrAtt.getPositionIncrement());

		assertTrue(ts.incrementToken());
		assertEquals("testterm2", termAtt.toString());
		assertEquals(1, offsetAtt.startOffset());
		assertEquals(8, offsetAtt.endOffset());
		assertEquals(0, posIncrAtt.getPositionIncrement());

		assertTrue(ts.incrementToken());
		assertEquals("testterm3", termAtt.toString());
		assertEquals(9, offsetAtt.startOffset());
		assertEquals(15, offsetAtt.endOffset());
		assertEquals(1, posIncrAtt.getPositionIncrement());

		assertTrue(ts.incrementToken());
		assertEquals("testterm4", termAtt.toString());
		assertEquals(0, offsetAtt.startOffset());
		assertEquals(0, offsetAtt.endOffset());
		assertEquals(1, posIncrAtt.getPositionIncrement());
		// assertEquals("my payload",
		// new String(Base64.decode(payloadAtt.getPayload().bytes)));
		assertEquals(4, flagsAtt.getFlags());
		assertEquals("testtype", typeAtt.type());
	}
}
