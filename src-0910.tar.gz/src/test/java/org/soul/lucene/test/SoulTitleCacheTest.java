package org.soul.lucene.test;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.miscellaneous.PerFieldAnalyzerWrapper;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.IndexWriterConfig.OpenMode;
import org.apache.lucene.index.MultiFields;
import org.apache.lucene.index.Term;
import org.apache.lucene.index.TermsEnum;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.highlight.Highlighter;
import org.apache.lucene.search.highlight.InvalidTokenOffsetsException;
import org.apache.lucene.search.highlight.QueryScorer;
import org.apache.lucene.search.highlight.SimpleHTMLFormatter;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.store.LockObtainFailedException;
import org.apache.lucene.store.RAMDirectory;
import org.apache.lucene.util.Bits;
import org.elasticsearch.plugin.EsStaticValue;
import org.elasticsearch.plugin.LuceneTermsInEs;
import org.elasticsearch.plugin.LuceneTermsInEs.LuceneFieldIterator;
import org.elasticsearch.plugin.SoulJcsegAnalyzer;
import org.elasticsearch.plugin.analyzer.SoulPinyinAnalyzer;
import org.splitword.soul.analysis.BasicAnalysis;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class SoulTitleCacheTest {

	private static Log log = LogFactory.getLog(SoulTitleCacheTest.class);
	private static final String pinyinField = "pinyinField";
	private static final String wordField = "wordField";
	private static final String idField = "ID";
	private static final String indexPath = "/mnt/f/tmp/Lucene-2";
	private static final Analyzer soulAnalyzer = new SoulPinyinAnalyzer();

	private void createIndex(Directory directory) {
		Map<String, Analyzer> analyzerMap = new HashMap<String, Analyzer>();
		analyzerMap.put(pinyinField, soulAnalyzer);
		analyzerMap.put(wordField, new SoulJcsegAnalyzer());
		PerFieldAnalyzerWrapper wrapper = new PerFieldAnalyzerWrapper(
				new StandardAnalyzer(EsStaticValue.LuceneVersion), analyzerMap);
		IndexWriter indexWriter = null;
		IndexWriterConfig iwConfig = new IndexWriterConfig(
				EsStaticValue.LuceneVersion, wrapper);
		iwConfig.setOpenMode(OpenMode.CREATE_OR_APPEND);
		try {
			indexWriter = new IndexWriter(directory, iwConfig);
			for (int i = 0; i < LuceneQueryTest.texts.length; i++) {
				Document doc = new Document();
				doc.add(new StringField(idField, String.valueOf(i + 1),
						Field.Store.YES));
				doc.add(new TextField(pinyinField, LuceneQueryTest.texts[i],
						Field.Store.YES));
				// doc.add(new TextField(wordField, texts[i], Field.Store.YES));
				indexWriter.addDocument(doc);
			}
			indexWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// @Test
	public void testMethod3() throws IOException {
		Directory directory = FSDirectory.open(new File(indexPath));
		createIndex(directory);
	}

	@BeforeClass
	public void beforeClass() {
		// ramDirectory = new RAMDirectory();
		// createIndex(ramDirectory);
		// try {
		// indexReader = DirectoryReader.open(ramDirectory);
		// indexSearcher = new IndexSearcher(indexReader);
		// } catch (IOException e) {
		// e.printStackTrace();
		// }
	}

	// @Test
	public void testMethod2() {
		try {
			Directory directory = FSDirectory.open(new File(indexPath));
			IndexReader reader = DirectoryReader.open(directory);
			LuceneTermsInEs fieldInfo = new LuceneTermsInEs(reader, idField,
					pinyinField);
			fillThisDictionary(fieldInfo);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// @Test
	public void testMethod4() {
		try {
			Directory directory = FSDirectory.open(new File(indexPath));
			IndexReader reader = DirectoryReader.open(directory);
			Bits liveDocs = MultiFields.getLiveDocs(reader);
			for (int i = 0; i < reader.maxDoc(); i++) {
				if (liveDocs != null && !liveDocs.get(i))
					continue;
				Document doc = reader.document(i);
				log.info(doc.get(idField) + " Document content: "
						+ doc.get(pinyinField));
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	private void fillThisDictionary(LuceneTermsInEs fieldInfo) {
		try {
			final Directory dir = new RAMDirectory();
			Map<String, Analyzer> analyzerMap = new HashMap<String, Analyzer>();
			analyzerMap.put(pinyinField, soulAnalyzer);
			PerFieldAnalyzerWrapper wrapper = new PerFieldAnalyzerWrapper(
					new StandardAnalyzer(EsStaticValue.LuceneVersion),
					analyzerMap);
			IndexWriterConfig iwConfig = new IndexWriterConfig(
					EsStaticValue.LuceneVersion, wrapper);
			iwConfig.setOpenMode(OpenMode.CREATE_OR_APPEND);
			final IndexWriter writer = new IndexWriter(dir, iwConfig);
			final List<TermsEnum> termsEnums = new ArrayList<TermsEnum>();
			LuceneFieldIterator iter = fieldInfo.iterator();
			String json;
			while ((json = iter.nextJsonWithinField(termsEnums, pinyinField)) != null) {
				log.info(json);
			}
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testMethod1() {
		try {
			Directory directory = FSDirectory.open(new File(indexPath));
			IndexReader reader = DirectoryReader.open(directory);
			IndexSearcher searcher = new IndexSearcher(reader);
			String[] keywords = { "厦门大学", "满宠南阳手下", "guany" };
			// String[] keywords = {"guany"};
			SimpleHTMLFormatter simpleHTMLFormatter = new SimpleHTMLFormatter(
					"<em>", "</em>");

			for (String keyword : keywords) {
				List<String> terms = BasicAnalysis.parse(keyword,
						EsStaticValue.stopWordsSet);
				BooleanQuery query = new BooleanQuery();
				if (terms.isEmpty())
					continue;
				else {
					float score = 0.0f;
					for (int i = 0; i < terms.size(); i++) {
						String value = terms.get(i);
						Query tq = new TermQuery(new Term(pinyinField, value));
						score += 1.0f;
						tq.setBoost(score);
						log.info("value = " + value + " , " + score);
						query.add(new BooleanClause(tq,
								BooleanClause.Occur.SHOULD));
					}
				}
				Highlighter highlighter = new Highlighter(simpleHTMLFormatter,
						new QueryScorer(query));
				TopDocs topDocs = searcher.search(query, 100);
				log.info("Hit: " + topDocs.totalHits);
				ScoreDoc[] scoreDocs = topDocs.scoreDocs;
				if (topDocs == null || topDocs.totalHits <= 0)
					continue;
				for (int i = 0; i < topDocs.totalHits; i++) {
					TreeMap<String, Integer> tree = new TreeMap<String, Integer>();
					Document targetDoc = searcher.doc(scoreDocs[i].doc);
					String text = targetDoc.get(pinyinField);
					// highlighter.setTextFragmenter(new SimpleFragmenter(text
					// .length()));
					try {
						String highLightText = highlighter.getBestFragment(
								soulAnalyzer, null, text);
						String temp = terms.get(terms.size() - 1);
						String[] similars = analyze(soulAnalyzer, text, temp,
								tree);
						if ((similars != null) && (similars.length > 0)) {
							for (String str : similars)
								log.info(str);
						}
						log.info("Score: " + scoreDocs[i].score
								+ " Document content: " + text
								+ " highLight text: " + highLightText);
					} catch (InvalidTokenOffsetsException e) {
						e.printStackTrace();
					}
				}
			}
		} catch (CorruptIndexException e) {
			e.printStackTrace();
		} catch (LockObtainFailedException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	String[] analyze(Analyzer analyzer, String text, String keyword,
			TreeMap<String, Integer> tree) {
		try {
			TokenStream tokenStream = analyzer.tokenStream(null,
					new StringReader(text));
			tokenStream.reset();
			while (tokenStream.incrementToken()) {
				CharTermAttribute charAttribute = tokenStream
						.getAttribute(CharTermAttribute.class);
				OffsetAttribute offsetAttribute = tokenStream
						.getAttribute(OffsetAttribute.class);
				TypeAttribute typeAtt = tokenStream
						.getAttribute(TypeAttribute.class);
				String type = typeAtt.type();
				if (type.equalsIgnoreCase(EsStaticValue.TYPE_HANZI)
						|| type.equalsIgnoreCase(EsStaticValue.TYPE_PINYIN)) {
					String key = charAttribute.toString();
					int start = offsetAttribute.startOffset();
					int end = offsetAttribute.endOffset();
					if (tree.get(key) != null) {
						int value = tree.get(key);
						tree.put(key, value + 1);
					} else
						tree.put(key, 1);
					log.info("[" + key + "," + start + "," + end + "]");
				}

			}
			tokenStream.close();
			int number = 0;
			StringBuilder builder = new StringBuilder();
			for (String key : tree.keySet()) {
				if (number == (tree.size() - 1))
					builder.append(key);
				else
					builder.append(key + ",");
				number++;
			}
			String termList = builder.toString();
			String[] prefixs = termList.split(",");
			List<String> result = new ArrayList<String>();
			for (String prefix : prefixs) {
				if (prefix.startsWith(keyword)
						&& !prefix.equalsIgnoreCase(keyword)) {
					log.info(prefix);
					result.add(prefix);
				}
			}
			if (result.size() > 0) {
				String[] strs = new String[result.size()];
				for (int i = 0; i < result.size(); i++) {
					strs[i] = result.get(i);
				}
				return strs;
			} else
				return null;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}
