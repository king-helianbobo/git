package org.soul.elasticsearch.test;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.map.ObjectMapper;
import org.elasticsearch.application.util.ExtractUtil;
import org.elasticsearch.application.util.OfficialDataUtils;
import org.elasticsearch.application.util.SoulFileWriter;
import org.elasticsearch.application.util.TestDataReader;
import org.testng.Assert;

public class DataCheckTest {
	private static final Log log = LogFactory
			.getLog(DataCheckTest.class);

	// @Test
	public void extractSynonymTxt() throws IOException {
		String paths[] = { "library/seg/1-1.txt", "library/seg/2-1.txt",
				"library/seg/3-1.txt", "library/seg/4-1.txt",
				"library/seg/5-1.txt", "library/seg/8-1.txt" };
		List<Set<String>> setList = new ArrayList<Set<String>>();
		String temp = null;
		int num = 0;

		for (String path : paths) {
			InputStream in = new FileInputStream(path);
			@SuppressWarnings("resource")
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					in, "UTF-8"));
			while ((temp = reader.readLine()) != null) {
				String[] strs = temp.split("\\s+");// 一个或多个空格
				Assert.assertEquals(strs.length, 2);
				String str1 = strs[0].trim();
				String str2 = strs[1].trim();
				log.info(str1 + " " + str2);
				boolean contained = false;
				for (int i = 0; i < setList.size(); i++) {
					Set<String> set = setList.get(i);
					if (set.contains(str1) && set.contains(str2)) {
						log.info("this line has contained!");
						contained = true;
					} else if (set.contains(str1)) {
						set.add(str2);
						contained = true;
					} else if (set.contains(str2)) {
						set.add(str1);
						contained = true;
					} else {
						// do nothing
					}
				}
				if (!contained) {
					Set<String> set = new HashSet<String>();
					set.add(str1);
					set.add(str2);
					setList.add(set);
				}
				num++;
			}
		}
		log.info("Total Word count is " + num);
		log.info("Total Word Line Numer is " + setList.size());
		SoulFileWriter writer = new SoulFileWriter("/tmp/a.txt");
		for (int i = 0; i < setList.size(); i++) {
			Set<String> set = setList.get(i);
			String result = ExtractUtil.setToString(set);
			log.info(result);
			writer.writeStr(result);
		}
		writer.close();
	}

	// @Test
	public void dataTest3() throws IOException {
		Map<String, Integer> map = new HashMap<String, Integer>();
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				new FileInputStream("library/wuxi.dic"), "utf-8"));
		String temp = null;
		while ((temp = reader.readLine()) != null) {
			String[] strs = temp.split("\t");
			String str1 = strs[0].trim();
			String str3 = strs[2].trim();
			map.put(str1, Integer.valueOf(str3));
		}
		reader.close();
		reader = new BufferedReader(new InputStreamReader(new FileInputStream(
				"library/newword.txt"), "utf-8"));
		while ((temp = reader.readLine()) != null) {
			String[] strs = temp.split("\t");
			String str1 = strs[0].trim();
			String str3 = strs[2].trim();
			if (map.containsKey(str1))
				log.info(str1 + " has contained!");
		}
		reader.close();
		reader = new BufferedReader(new InputStreamReader(new FileInputStream(
				"/mnt/f/tmp/a.txt"), "utf-8"));
		while ((temp = reader.readLine()) != null) {
			String[] strs = temp.split("\t");
			String str1 = strs[0].trim();
			String str3 = strs[2].trim();
			if (!map.containsKey(str1))
				log.info(str1 + " has contained!");
		}
		reader.close();
	}

	// @Test
	public void fillSogouDataTest() throws Exception {
		String path = "/mnt/f/Sogou";
		String writeDir = "/mnt/f/tmp/sogou-05-29/";
		List<Map<String, String>> result = null;
		final int totalNum = 10000; // each text file contains 10000 lines
		int docNumber = 0;
		int number = 0;
		int duplicateNum = 0;
		Map<String, String> urlMap = new HashMap<String, String>();
		SoulFileWriter writer = null;
		TestDataReader reader = new TestDataReader(path, "gbk");
		ObjectMapper mapper = new ObjectMapper();
		while ((result = reader.nextData(20, TestDataReader.SogouFormat)) != null) {
			for (int i = 0; i < result.size(); i++) {
				if (number % totalNum == 0) {
					if (writer != null)
						writer.close();
					int seq = number / totalNum + 1;
					String writePath = null;
					if (seq < 10)
						writePath = writeDir + "a00" + String.valueOf(seq)
								+ ".txt";
					else if (seq < 100)
						writePath = writeDir + "a0" + String.valueOf(seq)
								+ ".txt";
					else
						writePath = writeDir + "a" + String.valueOf(seq)
								+ ".txt";
					writer = new SoulFileWriter(writePath);
				}
				docNumber++;
				Map<String, String> entry = result.get(i);
				String url = entry.get(OfficialDataUtils.urlField);
				String title = entry.get(OfficialDataUtils.titleField);
				String tmp = urlMap.get(url);
				if (tmp == null) {
					urlMap.put(url, title);
					String json = mapper.writeValueAsString(entry);
					writer.writeWithNewLine(json);
					number += 1;
				} else if (tmp.equals(title)) {
					log.error(docNumber + "," + title + "," + url);
					duplicateNum++;
				} else {
					log.error("papa " + url + "," + title + "," + tmp);
				}
			}
		}
		if (writer != null)
			writer.close();
		log.error(duplicateNum + "," + urlMap.size());
	}

	// @Test
	public void extractWuxi() {
		String paths[] = { "/mnt/f/tmp/wuxi.txt" };
		InputStream in;
		BufferedReader reader;
		SoulFileWriter writer = new SoulFileWriter("/mnt/f/tmp/b.txt");
		String temp = null;
		int num = 0;
		try {
			for (String path : paths) {
				in = new FileInputStream(path);
				reader = new BufferedReader(new InputStreamReader(in, "gbk"));
				while ((temp = reader.readLine()) != null) {
					String[] strs = temp.split(" ");
					String str1 = strs[0].trim();
					int start = str1.indexOf("{");
					int end = str1.indexOf("}");
					StringBuilder builder = new StringBuilder();
					String freq = str1.substring(start + 1, end);
					String str2 = strs[1].trim();
					num++;
					builder.append(str2 + "\t");
					builder.append("userWuxi" + "\t" + freq);
					builder.append("\n");
					writer.writeStr(builder.toString());
					log.info(builder.toString());
				}
			}
			log.info("Total Word count is " + num);
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
