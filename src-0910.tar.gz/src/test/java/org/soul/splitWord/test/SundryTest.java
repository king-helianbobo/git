package org.soul.splitWord.test;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.map.ObjectMapper;
import org.elasticsearch.common.joda.FormatDateTimeFormatter;
import org.elasticsearch.common.joda.Joda;
import org.elasticsearch.common.joda.time.DateTime;
import org.elasticsearch.common.joda.time.Days;
import org.elasticsearch.common.joda.time.LocalDate;
import org.elasticsearch.common.joda.time.format.DateTimeFormat;
import org.elasticsearch.common.joda.time.format.DateTimeFormatter;
import org.elasticsearch.utility.ChineseHelper;
import org.elasticsearch.utility.OfficialChars;
import org.elasticsearch.utility.WordAlter;
import org.testng.annotations.Test;

public class SundryTest {

	private final Log log = LogFactory.getLog(SundryTest.class);

	// @Test(enabled = true)
	public void jodaTimeTest1() {
		final float da = 0.08f;
		final float db = 0.05f;
		final float dm = (float) (3.16f * Math.pow(10.0f, -11.0f));
		DateTime date = new DateTime();
		String a = date.toString();
		String b = date.toString("dd:MM:yy");
		log.info(a + "," + b + "," + date.getMillis());
		DateTimeFormatter outputFormat = DateTimeFormat
				.forPattern("yyyy-MM-dd HH:mm");
		String[] strs = { "2013-5-31 15:59:58", "2014-6-25", "2009-9-1 15:30",
				"2009-2-28 5:3", "1970-01-01", "2014-07-03" };
		FormatDateTimeFormatter formatter = Joda
				.forPattern("yyyy-MM-dd HH:mm:ss||yyyy-MM-dd||yyyy-MM-dd HH:mm");
		long millis1 = 1404369067654L;
		DateTime dt1 = new DateTime(millis1);

		log.info(dt1.toString(outputFormat));
		for (String strInputDateTime : strs) {
			long millis = formatter.parser().parseMillis(strInputDateTime);
			DateTime dt = formatter.parser().parseDateTime(strInputDateTime);
			// assertThat(input, is(formatter.printer().print(millis)));
			// fmt.parseDateTime(strInputDateTime);
			// String strOutputDateTime = fmt.print(dt);
			int numDays = Days.daysBetween(new LocalDate(dt1),
					new LocalDate(dt)).getDays();
			log.info("number of days = " + numDays + ", date="
					+ strInputDateTime);
			int iDoW = dt.getDayOfWeek();
			log.info(dt.toString(outputFormat) + "," + iDoW);
			log.info("current time is " + millis + "," + dt.getMillis());
			// DateTime dt1 = outputFormat.parseDateTime(dt.toString());
			// log.info(dt1.toString());
			float dx = Math.abs(date.getMillis() - dt.getMillis());
			float f = 1.0f + (float) (da / (db + dm * dx));
			log.info(f);
		}
	}

	// @Test(enabled = true)
	public void jodaTimeTest2() {
		final float startA = 17.001f;
		final float endA = 1.001f;
		final float startDay = 1.0f;
		final float endDay = 2000.0f;
		DateTimeFormatter outputFormat = DateTimeFormat
				.forPattern("yyyy-MM-dd HH:mm");
		String[] strs = { "2013-5-31 15:59:58", "2014-6-25", "2009-03-20",
				"2009-2-28 5:3", "1970-01-01", "2014-07-03" };
		FormatDateTimeFormatter formatter = Joda
				.forPattern("yyyy-MM-dd HH:mm:ss||yyyy-MM-dd||yyyy-MM-dd HH:mm");
		DateTime date = new DateTime();
		for (String strInputDateTime : strs) {
			long millis = formatter.parser().parseMillis(strInputDateTime);
			DateTime dt = new DateTime(millis);
			int numDays = Days.daysBetween(new LocalDate(date),
					new LocalDate(dt)).getDays();
			int days = Math.abs(numDays) + 1;
			log.info("number of days = " + days + ", date=" + strInputDateTime);
			float dx;
			if (days <= endDay)
				dx = (days - startDay) * (endA - startA) / (endDay - startDay)
						+ startA;
			else
				dx = (float) (1.0f / (Math.log10(10 + days - endDay)));
			log.info(dx);
		}
	}

	@Test
	public void traditionalToSimplifiedChineseTest() {
		List<String> all = new ArrayList<String>();
		all.add("關注十八大：台港澳密集解讀十八大報告”");
		all.add("关注十八大：台港澳密集解读十八大报告”");
		all.add("參選國民黨主席？ 胡志強首度鬆口稱“會考慮”");
		all.add("参选国民党主席？ 胡志强首度松口称“会考虑”");
		all.add("駁謝長廷“國民黨像東廠” 藍營吁其勿惡意嘲諷");
		all.add("驳谢长廷“国民党像东厂” 蓝营吁其勿恶意嘲讽");
		all.add("台藝人陳俊生出軌逼死女友 絕情獸行遭曝光");
		all.add("台艺人陈俊生出轨逼死女友 绝情兽行遭曝光");
		all.add("林益世想回高雄探母 法官警告勿有逃亡念頭");
		all.add("林益世想回高雄探母 法官警告勿有逃亡念头");
		for (int i = 0; i < all.size(); i++) {
			if (i % 2 == 0) {
				String str1 = ChineseHelper.traditionalToSimplified(all.get(i));
				assertEquals(all.get(i + 1), str1);
			}
		}
	}

	// @Test
	public void wordAlterTest() {
		String[] strs = { "。，、”  ｓｄｆｓｄｆ多啦哆啦Ａａ梦１123", "习近平和朱镕基情切照相",
				"關注十八大：台港澳密集解讀十八大報告" };
		for (String str : strs) {
			String result = WordAlter.alterAlphaAndNumber(str);
			log.info(WordAlter.chineseCharNumbers(str) + " :[ " + result + " ]");
			for (int i = 0; i < str.length(); i++) {
				char c = str.charAt(i);
				if (ChineseHelper.isChineseChar(c))
					log.info(c);
			}
		}
	}

	// @Test
	public void invalidCharTest() throws IOException {
		String[] strs = {
				"1、本表供变更医师执业注册事项使用。 2、一律用钢笔或毛笔填写，内容要具体、真实、字迹要端正清楚。",
				"  a。  bbb    为督促各参建单位切实落实“    一节两会   ”期间安全生产及节后复工安全生产各项工作，建管处安全生产领导小组近日对在建的新沟河西直湖港南枢纽工程、纳新桥闸站改造工程、骂蠡港河道综合整治工程等进行了一次安全生产检查。检查中，发现个别施工单位项目经理、监理单位总监不到位、安全台账资料不完善等问题。个别工地施工现场存在施工人员高空作业安全防护不到位、施工现场油罐放置不规范、缺少消防设施、缺少安全警示标志、临时用电不规范等安全隐患。     针对本次检查出的各种问题，建管处安全生产领导小组已督促各参建单位立即进行整改，并就下阶段工作提出四点要求：一是高度重视，切实加强对安全生产工作的组织领导；二是突出重点，层层落实各项安全防范措施；三是提高意识、抓好安全培训教育工作；四是制定并落实汛期施工防汛预案和应急预案。  " };
		for (String str : strs) {
			String converted = OfficialChars.convertInvalidChars(str);
			// String result = WordAlter.alterAlphaAndNumber(converted);
			log.info("[" + str + "]");
			log.info("[" + converted + "]");
		}
		String source = "首页(www.wuxi.gov).cn/)\t政民互动\t行风热线(www.wuxi.gov.cn/msmy/hfrx/index.shtml)";
		strs = source.split("\t");
		Map<String, Object> result = new HashMap<String, Object>();
		List<Map<String, Object>> array = new ArrayList<Map<String, Object>>();
		for (String str : strs) {
			int begin = str.indexOf('(');
			int end = str.lastIndexOf(')');
			Map<String, Object> tmp = new HashMap<String, Object>();
			if (end >= 0 && begin >= 0) {
				String url = str.substring(begin + 1, end);
				String tag = str.substring(0, begin);
				log.info(str + "," + tag + "," + url);
				tmp.put(tag, url);
			} else {
				log.info(str);
				tmp.put(str, "null");
			}
			array.add(tmp);
		}
		result.put("source", array);
		ObjectMapper mapper = new ObjectMapper();
		String resultJson = mapper.writeValueAsString(result);
		log.info("result: " + resultJson);
	}
}
