package org.soul.splitWord.test;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Test;
import org.soul.lucene.test.LuceneQueryTest;
import org.splitword.soul.library.InitDictionary;

public class CrfSegTest {
	private final Log log = LogFactory.getLog(CrfSegTest.class);

	@Test
	public void crfModelSegTest1() {
		for (String str : LuceneQueryTest.texts) {
			log.info(InitDictionary.getCRFSplitWord().cut(str));
		}
	}
}
