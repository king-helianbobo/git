package org.splitword.soul.jcseg.util;

import static org.splitword.soul.library.InitDictionary.systemChars;

import java.io.IOException;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.zip.ZipInputStream;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class PinyinResource {
	private static Log log = LogFactory.getLog(PinyinResource.class);

	private static Properties getResource(String resourceName) {
		ZipInputStream zip = new ZipInputStream(
				PinyinResource.class.getResourceAsStream(resourceName));
		try {
			zip.getNextEntry();
			Properties p = new Properties();
			p.load(zip);
			zip.close();
			return p;
		} catch (IOException e) {
			log.error("Exception in loading PinyinResource", e);
		}
		return null;
	}

	protected static Properties getPinyinTable() {
		String resourceName = "/pinyindata/pinyin.db";
		return getResource(resourceName);
	}

	protected static Properties getMutilPintinTable() {
		String resourceName = "/pinyindata/mutil_pinyin.db";
		return getResource(resourceName);
	}

	public static void readTraditionalTable() {
		String resourceName = "/pinyindata/chinese.db";
		Properties properties = getResource(resourceName);
		Set<Entry<Object, Object>> set = properties.entrySet();
		for (Entry<Object, Object> entry : set) {
			String key = (String) entry.getKey();
			String value = (String) entry.getValue();
			if (key.length() != 1 || value.length() != 1)
				log.error(key + "," + value);
			else {
				char char1 = key.charAt(0);
				char char2 = value.charAt(0);
				if (systemChars[char1] == 0)
					systemChars[char1] = char2;
				if (systemChars[char2] == 0)
					systemChars[char2] = char2;
				// if (systemChars[char1] == 0 && systemChars[char2] == 0)
				// log.info(key + "," + value);
			}
		}
		set = null;
		properties = null;
		// return properties;
	}
}
