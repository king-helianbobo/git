package org.splitword.soul.library;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.elasticsearch.utility.ChineseHelper;
import org.splitword.soul.crfModel.Model;
import org.splitword.soul.crfModel.SplitWord;
import org.splitword.soul.domain.PersonNatureAttr;
import org.splitword.soul.domain.TermNature;
import org.splitword.soul.domain.TermNatures;
import org.splitword.soul.jcseg.util.PinyinResource;
import org.splitword.soul.utility.StringUtil;

public class InitDictionary {
	private static Log log = LogFactory.getLog(InitDictionary.class);
	private static int arrayLength = -1;
	public static final char[] systemChars = new char[65536];
	public static int[] base = null;
	public static int[] check = null;
	public static byte[] status = null;
	public static String[] words = null;
	public static TermNatures[] termNatures = null;

	private static final Lock LOCK = new ReentrantLock();
	private static SplitWord crfSplitWord = null;

	static {
		init();
		PersonAttrLib.clear();
		// release memory
	}

	public static void init() {
		long start = System.currentTimeMillis();
		try {
			initBaseArray();
			long end = System.currentTimeMillis();
			log.info("init core library use time :" + (end - start)
					+ " milliseconds");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void initBaseArray() throws Exception {
		BufferedReader reader = MyStaticValue.getBaseArrayReader();
		initArraySize(reader);
		reader.close();
		reader = MyStaticValue.getBaseArrayReader();
		initArrays(reader);
		reader.close();
	}

	private static void initArraySize(BufferedReader reader) throws IOException {
		String temp = null;
		String last = null;
		while ((temp = reader.readLine()) != null) {
			last = temp;
		}
		String[] strs = last.split("\\s+");
		arrayLength = Integer.parseInt(strs[0]) + 1;
		base = new int[arrayLength];
		check = new int[arrayLength];
		status = new byte[arrayLength];
		words = new String[arrayLength];
		termNatures = new TermNatures[arrayLength];
	}

	private static void initArrays(BufferedReader reader) throws Exception {
		String temp = null;
		Map<String, PersonNatureAttr> personMap = PersonAttrLib.personMap();
		while ((temp = reader.readLine()) != null) {
			String[] strs = temp.split("\\s+");
			int num = Integer.parseInt(strs[0]);
			words[num] = strs[1];
			base[num] = Integer.parseInt(strs[2]);
			check[num] = Integer.parseInt(strs[3]);
			status[num] = Byte.parseByte(strs[4]);
			String nature = strs[5];
			if (status[num] < 4) {
				for (int i = 0; i < strs[1].length(); i++) {
					char c = strs[1].charAt(i);
					if (ChineseHelper.isChineseChar(c)) // only consider Chinese
						systemChars[c] = c;
				}
			}
			if (!nature.equalsIgnoreCase("null")) {
				TermNatures tn = new TermNatures(
						TermNature.setNatureStrToArray(strs[5]), num);
				PersonNatureAttr personAttr = personMap.get(strs[1]);
				// default personNatureAttr is personNatureAttr.NULL
				if (personAttr != null)
					tn.personNature = personAttr;
				termNatures[num] = tn;
			}
		}
		initPerson(personMap);
		// traditional Chinese to simplified Chinese
		BufferedReader reader2 = DictionaryReader.getReader("jianFan.dic");
		while ((temp = reader2.readLine()) != null) {
			temp = temp.trim();
			if (StringUtil.isBlank(temp)) {
				continue;
			}
			if (systemChars[temp.charAt(0)] == 0) {
				systemChars[temp.charAt(0)] = temp.charAt(2);
			}
		}
		PinyinResource.readTraditionalTable();
		reader.close();
		reader2.close();
	}

	private static void initPerson(Map<String, PersonNatureAttr> personMap) {
		Set<Entry<String, PersonNatureAttr>> entrySet = personMap.entrySet();
		TermNatures tn = null;
		for (Entry<String, PersonNatureAttr> entry : entrySet) {
			if (entry.getKey().length() == 1) {
				char c = entry.getKey().charAt(0);
				if (status[c] >= 1) {
					continue;
				}
				if (status[c] == 0) {
					base[c] = c;
					check[c] = -1;
					status[c] = 3;
					words[c] = entry.getKey();
				}
				if ((tn = termNatures[c]) == null) {
					tn = new TermNatures(TermNature.NR);
				}
				tn.personNature = entry.getValue();
				termNatures[c] = tn;
			}
		}
	}

	public static boolean isInSystemDic(String str) {
		if (StringUtil.isBlank(str)) {
			return false;
		}
		int baseValue = str.charAt(0);
		int checkValue = 0;
		for (int i = 1; i < str.length(); i++) {
			checkValue = baseValue;
			baseValue = base[baseValue] + str.charAt(i);
			if (baseValue > check.length - 1)
				return false;
			if (check[baseValue] != -1 && check[baseValue] != checkValue) {
				return false;
			}
		}
		return status[baseValue] > 0;
	}

	// word's id in array.dic
	public static int wordId(String str) {
		if (StringUtil.isBlank(str)) {
			return -1;
		}
		int baseValue = str.charAt(0);
		int checkValue = 0;
		for (int i = 1; i < str.length(); i++) {
			checkValue = baseValue;
			baseValue = base[baseValue] + str.charAt(i);
			if (baseValue > check.length - 1)
				return -1;
			if (check[baseValue] != -1 && check[baseValue] != checkValue) {
				return -1;
			}
		}
		if (status[baseValue] > 0)
			return baseValue;
		else
			return -1;
	}

	public static SplitWord getCRFSplitWord() {
		if (crfSplitWord != null) {
			return crfSplitWord;
		}
		LOCK.lock();
		if (crfSplitWord != null) {
			return crfSplitWord;
		}
		try {
			long start = System.currentTimeMillis();
			// crfSplitWord = new SplitWord(Model.loadModel(DictionaryReader
			// .getInputStream("crf/crf.model")));
			crfSplitWord = new SplitWord(Model.readModel(DictionaryReader
					.getInputStream("crf/crf-model")));
			log.info("load crf model, use time: "
					+ (System.currentTimeMillis() - start) + " milliseconds!");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			LOCK.unlock();
		}
		return crfSplitWord;
	}
}
