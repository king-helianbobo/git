package org.splitword.soul.library;

import java.io.BufferedReader;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class MyStaticValue {

	public static Log libLog = LogFactory.getLog(MyStaticValue.class);
	public static boolean allowNameRecognize = true;
	public static boolean allowNumRecognize = true;
	public static boolean allowQuantifierRecognize = true;

	public static BufferedReader getPersonReader() {
		return DictionaryReader.getReader("person/person.dic");
	}

	public static BufferedReader userDefineLibrary1Reader() {
		return DictionaryReader.getReader("dictionary/default.dic");
	}

	public static BufferedReader userDefineLibrary2Reader() {
		return DictionaryReader.getReader("dictionary/wuxi.dic");
	}

	public static BufferedReader userDefineLibrary3Reader() {
		return DictionaryReader.getReader("dictionary/newword.dic");
	}

	public static BufferedReader ambiguityLibraryReader() {
		return DictionaryReader.getReader("dictionary/ambiguity.dic");
	}

	public static BufferedReader stopWordReader() {
		return DictionaryReader.getReader("dictionary/stopWord.dic");
	}

	public static BufferedReader termPojoReader() {
		return DictionaryReader.getReader("freq.dic");
	}

	public static BufferedReader getCompanyReader() {
		return DictionaryReader.getReader("company/company.data");
	}

	public static BufferedReader getBaseArrayReader() {
		return DictionaryReader.getReader("arrays.dic");
	}

	public static BufferedReader getNatureMapReader() {
		return DictionaryReader.getReader("nature/nature.map");
	}

	public static BufferedReader getNatureTableReader() {
		return DictionaryReader.getReader("nature/nature.table");
	}

}
