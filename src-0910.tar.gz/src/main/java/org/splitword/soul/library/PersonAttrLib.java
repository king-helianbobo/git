package org.splitword.soul.library;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.elasticsearch.utility.CompactHashMap;
import org.splitword.soul.domain.PersonNatureAttr;
import org.splitword.soul.utility.StringUtil;

public class PersonAttrLib {

	private static Log log = LogFactory.getLog(PersonAttrLib.class);
	private static Map<String, PersonNatureAttr> pnMap = null;
	private static boolean bCleared = false;

	public static Map<String, PersonNatureAttr> personMap()
			throws NumberFormatException, IOException {
		if (bCleared)
			return null;
		else if (pnMap != null && pnMap.size() > 0) {
			return pnMap;
		} else {
			init1();
			init2();
			return pnMap;
		}
	}

	public static void clear() {
		bCleared = true;
		pnMap = null; // release memory
	}

	private void logPersonFreqMap(Map<String, int[][]> map) {
		// just for test purpose
		Set<Entry<String, int[][]>> entrySet = map.entrySet();
		for (Entry<String, int[][]> entry : entrySet) {
			StringBuilder str = new StringBuilder();
			str.append(entry.getKey() + "[ ");
			int ints[][] = entry.getValue();
			for (int i = 0; i < ints.length; i++) {
				str.append("(");
				for (int j = 0; j < ints[i].length; j++)
					str.append(ints[i][j] + " ");
				str.append(")");
			}
			str.append("]");
			log.info(str.toString());
		}
	}

	@SuppressWarnings("unchecked")
	private static Map<String, int[][]> getPersonFreqMap() {
		InputStream inputStream = null;
		ObjectInputStream objectInputStream = null;
		Map<String, int[][]> map = new HashMap<String, int[][]>(0);
		try {
			inputStream = DictionaryReader
					.getInputStream("person/asian_name_freq.data");
			objectInputStream = new ObjectInputStream(inputStream);
			map = (Map<String, int[][]>) objectInputStream.readObject();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (objectInputStream != null)
					objectInputStream.close();
				if (inputStream != null)
					inputStream.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return map;
	}

	// "person/asian_name_freq.data"
	private static void init2() throws NumberFormatException, IOException {
		Map<String, int[][]> personFreqMap = getPersonFreqMap();
		// logPersonFreqMap(personFreqMap);
		// int line = 0;
		Set<Entry<String, int[][]>> entrySet = personFreqMap.entrySet();
		PersonNatureAttr pna = null;
		for (Entry<String, int[][]> entry : entrySet) {
			String key = entry.getKey().trim();
			// line++;
			if (StringUtil.isBlank(key)) {
				key = entry.getKey();
				// no need to remove whitespace
				// log.info("line number = " + line);
			}
			pna = pnMap.get(key);
			if (pna == null) {
				pna = new PersonNatureAttr();
				pna.setlocFreq(entry.getValue());
				pnMap.put(key, pna);
			} else {
				pna.setlocFreq(entry.getValue());
			}
		}
		personFreqMap = null; // release memory
	}

	// person.dic
	private static void init1() throws NumberFormatException, IOException {
		BufferedReader br = null;
		try {
			pnMap = new CompactHashMap<String, PersonNatureAttr>();
			br = MyStaticValue.getPersonReader(); // "person/person.dic"
			String temp = null;
			PersonNatureAttr pna = null;
			// int line = 0;
			while ((temp = br.readLine()) != null) {
				// line++;
				String[] strs = temp.split("\t");
				String str = strs[0].trim();
				if (StringUtil.isBlank(str)) {
					str = strs[0];
					// log.info("line number = " + line);
				}
				pna = pnMap.get(str);
				if (pna == null) {
					pna = new PersonNatureAttr();
				}
				pna.addFreq(Integer.parseInt(strs[1]),
						Integer.parseInt(strs[2]));
				pnMap.put(str, pna);
			}
		} finally {
			if (br != null)
				br.close();
		}
	}
}
