package org.splitword.soul.domain;

public class PersonNatureAttr {

	public static final PersonNatureAttr NULL = new PersonNatureAttr();
	private int[][] locFreq = null;
	public int split;
	// 12
	public int begin;
	// 11+12
	public int end;
	public int freqSum;

	// 是否有可能是名字的第一个字
	public boolean flag;

	/**
	 * 对person.dic中的词，词是否在人名前后，比如总理可出现在人名之前或之后
	 * 
	 * @param index
	 * @param freq
	 */
	public void addFreq(int index, int freq) {
		switch (index) {
		case 11:
			this.begin += freq;
			freqSum += freq;
			break;
		case 12:
			this.end += freq;
			freqSum += freq;
			break;
		case 44:
			this.split += freq;
			freqSum += freq;
			break;
		}
	}

	public int getFreq(int length, int loc) {
		if (locFreq == null)
			return 0;
		if (length > 3)
			length = 3;
		if (loc > 4)
			loc = 4;
		return locFreq[length][loc];
	}

	/**
	 * 词频记录表
	 * 
	 * @param ints
	 */
	public void setlocFreq(int[][] ints) {
		for (int i = 0; i < ints.length; i++) {
			if (ints[i][0] > 0) {
				flag = true;
			}
		}
		locFreq = ints;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("begin=" + begin);
		sb.append(",");
		sb.append("end=" + end);
		sb.append(",");
		sb.append("split=" + split);
		return sb.toString();
	}
}
