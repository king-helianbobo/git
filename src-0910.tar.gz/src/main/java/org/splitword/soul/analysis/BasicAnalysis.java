package org.splitword.soul.analysis;

import java.io.Reader;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.elasticsearch.hadoop.util.StringUtils;
import org.splitword.soul.domain.Term;
import org.splitword.soul.domain.ViterbiGraph;
import org.splitword.soul.library.MyStaticValue;
import org.splitword.soul.recognition.AsianNameRecognition;
import org.splitword.soul.recognition.ForeignNameRecognition;
import org.splitword.soul.recognition.NatureRecognition;
import org.splitword.soul.recognition.NumberRecognition;
import org.splitword.soul.recognition.UserDefineRecognition;
import org.splitword.soul.utility.Forest;

public class BasicAnalysis extends Analysis {

	private static Log log = LogFactory.getLog(BasicAnalysis.class);
	private UserDefineRecognition userDefineRecognition = new UserDefineRecognition();

	public BasicAnalysis() {
	};

	public BasicAnalysis(boolean bNature) {
		this.bNature = bNature;
	}

	public BasicAnalysis(Reader reader) {
		super(reader);
	}

	public BasicAnalysis(Reader reader, boolean bNature) {
		super(reader, bNature);
	}

	@Override
	protected List<Term> getResult(final ViterbiGraph graph) {
		Merger merger = new Merger() {
			@Override
			public List<Term> merge() {
				graph.walkPath();// construct optimal path
				// 先人名识别，然后数字识别，因为某些姓名中含有数字（三本五十六）
				if (graph.hasPerson && MyStaticValue.allowNameRecognize) {
					new AsianNameRecognition(graph.terms).recognition();
					graph.walkPathByScore();
					AsianNameRecognition.nameAmbiguity(graph.terms);
					new ForeignNameRecognition(graph.terms).recognition();
					graph.walkPathByScore();
				}
				if (graph.hasNum) // recognize consecutive numbers
					NumberRecognition.recognition(graph.terms);
				if (forests == null) {
					userDefineRecognize(graph, null);
				} else {
					/*
					 * 对部分自定义词(如拳皇ova)，放在ambiguityLibrary里无效
					 * 因为对[漂亮mm打拳皇ova很厉害]这句话，由于[打拳]使得[拳皇ova]分不出来
					 * 这里还应该对基础词库和用户自定义词库做个检查，如（没准生证）
					 */
					for (int i = 0; i < forests.size(); i++) {
						Forest forest = forests.get(i);
						if (forest == null)
							continue;
						userDefineRecognize(graph, forest);
					}
				}

				// RuleRecogntion.recognition(graph.terms);
				// 屏蔽基于规则的新词发现
				if (bNature) { // nature recognition
					List<Term> result = getResult();
					new NatureRecognition(result).recognition();
				}
				return getResult();
			}

			private void userDefineRecognize(final ViterbiGraph graph,
					Forest forest) {
				userDefineRecognition.resetData(graph.terms, forest);
				userDefineRecognition.recognition();
				graph.rmLittlePath();
				graph.walkPathByScore();
			}

			private List<Term> getResult() {
				List<Term> result = new ArrayList<Term>();
				int length = graph.terms.length - 1;
				for (int i = 0; i < length; i++) {
					if (graph.terms[i] != null) {
						result.add(graph.terms[i]);
					}
				}
				return result;
			}
		};
		return merger.merge();
	}

	public List<Term> parse(String str) {
		return this.parseStr(str);
	}

	public static List<String> parse(String str, Set<String> filter) {
		List<Term> terms = new BasicAnalysis().parseStr(str);
		List<String> result = new LinkedList<String>();
		for (int i = 0; i < terms.size(); i++) {
			Term term = terms.get(i);
			if (term == null)
				break;
			String name = term.getName();
			if (filter != null && filter.contains(name)) {
				continue;
			} else if (!StringUtils.hasText(name)) {
				continue;
			} else {
				result.add(name);
			}
		}
		return result;
	}

}
