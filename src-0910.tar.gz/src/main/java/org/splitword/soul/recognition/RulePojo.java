package org.splitword.soul.recognition;

public class RulePojo {
	private String endString = null;
	private int maximumLen = -1;
	boolean bStay = false;

	public String string() {
		return this.endString;
	}

	public int maxLength() {
		return this.maximumLen;
	}

	public boolean stay() {
		return this.bStay;
	}

	RulePojo(String endString, int maximumLen, boolean bStay) {
		this.endString = endString;
		this.maximumLen = maximumLen;
		this.bStay = bStay;
	}

	RulePojo(String endString, int maximumLen) {
		this.endString = endString;
		this.maximumLen = maximumLen;
		this.bStay = false;
	}
}
