package org.splitword.soul.utility;

public class Branch implements TrieInterface {

	private TrieInterface[] branches = null;
	private char c;
	private byte status = 1;
	private TrieInterface branch = null;
	private String[] param = null;

	public TrieInterface add(TrieInterface branch) {
		if (branches == null) {
			branches = new TrieInterface[0];
		}
		int bs = SoulArrays.binarySearch(branches, branch.getC());
		if (bs >= 0) {
			this.branch = this.branches[bs];
			switch (branch.getStatus()) {
			case -1:
				this.branch.setStatus(1);
				break;
			case 1:
				if (this.branch.getStatus() == 3) {
					this.branch.setStatus(2);
				}
				break;
			case 3:
				if (this.branch.getStatus() != 3) {
					this.branch.setStatus(2);
				}
				this.branch.setParam(branch.getParams());
			}
			return this.branch;
		} else {
			TrieInterface[] newBranches = new TrieInterface[branches.length + 1];
			int insert = -(bs + 1);
			System.arraycopy(branches, 0, newBranches, 0, insert);
			System.arraycopy(branches, insert, newBranches, insert + 1,
					branches.length - insert);
			newBranches[insert] = branch;
			branches = newBranches;
			return branch;
		}
	}

	public Branch(char c, int status, String[] param) {
		this.c = c;
		this.status = (byte) status;
		this.param = param;
	}

	public TrieInterface get(char c) {
		if (this.branches == null) {
			return null;
		}
		int i = SoulArrays.binarySearch(this.branches, c);
		if (i < 0) {
			return null;
		}
		return this.branches[i];
	}

	public boolean contains(char c) {
		if (this.branches == null) {
			return false;
		}
		return SoulArrays.binarySearch(this.branches, c) > -1;
	}

	public int compareTo(char c) {
		if (this.c > c)
			return 1;
		if (this.c < c) {
			return -1;
		}
		return 0;
	}

	public boolean equals(char c) {
		return this.c == c;
	}

	@Override
	public int hashCode() {
		return this.c;
	}

	public byte getStatus() {
		return this.status;
	}

	public void setStatus(int status) {
		this.status = (byte) status;
	}

	public char getC() {
		return this.c;
	}

	public String[] getParams() {
		return this.param;
	}

	public String getParam(int i) {
		if (param != null && param.length > i) {
			return param[i];
		}
		return null;
	}

	public void setParam(String[] param) {
		this.param = param;
	}
}
