package org.elasticsearch.index.mapper.preanalyzed;

import org.elasticsearch.common.inject.AbstractModule;

public class PreAnalyzedIndexModule extends AbstractModule {

	@Override
	protected void configure() {
		bind(RegisterPreAnalyzedTypeParser.class).asEagerSingleton();
	}

}
