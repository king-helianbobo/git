package org.elasticsearch.application.util;

import java.util.Map;
import java.util.Set;

import junit.framework.Assert;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.elasticsearch.utility.OfficialChars;
import org.elasticsearch.utility.WordAlter;
import org.splitword.soul.library.InitDictionary;
import org.splitword.soul.utility.StringUtil;

public class OfficialDataUtils {
	private static Log log = LogFactory.getLog(OfficialDataUtils.class);
	public final static String titleField = "contenttitle";
	public final static String contentField = "content";
	public final static String urlField = "url";
	public final static String idField = "id";

	public static Map<String, String> checkThisEntry(Map<String, String> entry) {
		Set<String> keySet = entry.keySet();
		if (!keySet.contains(urlField) || !keySet.contains(titleField))
			return null;
		String title = entry.get(titleField);
		String content = entry.get(contentField);
		String url = entry.get(urlField);
		String result = checkUrl(url);
		if (result == null)
			return null;
		String content1 = OfficialChars.removeTimeInContent(title, content);
		String content2 = OfficialChars.convertInvalidChars(content1);
		String title2 = OfficialChars.convertInvalidChars(title);
		String content3 = OfficialChars.removeConsecutiveWhiteSpaces(content2);
		String title3 = OfficialChars.removeWhiteSpaces(title2);
		boolean bTitle = checkTitle(title3);
		if (!bTitle) {
			log.info(title);
			return null;
		}

		int count = OfficialDataUtils.notChineseCharCount(content3);
		float ratio = ((float) count) / (float) content3.length();
		if (ratio >= 0.75f)
			return null;

		entry.put(contentField, content3);
		entry.put(titleField, title3);
		entry.put(urlField, result);
		entry.put(idField, result.toLowerCase());// convert id to lower case
		return entry;
	}

	public static int invalidCharCount(String content) {
		int count = 0;
		for (int j = 0; j < content.length(); j++) {
			char c = content.charAt(j);
			if (!WordAlter.isLetterOrDigit(c))
				count++;
		}
		return count;
	}

	public static int notChineseCharCount(String content) {
		int count = 0;
		for (int j = 0; j < content.length(); j++) {
			char c = content.charAt(j);
			if (InitDictionary.systemChars[c] <= 0)
				count++;
		}
		return count;
	}

	private static boolean checkTitle(String title) {
		boolean bPass = true;
		if (StringUtil.isBlank(title))
			bPass = false;
		else if (title.equalsIgnoreCase("null"))
			bPass = false;
		else if (title.equalsIgnoreCase("untitled"))
			bPass = false;
		else if (title.equalsIgnoreCase("test"))
			bPass = false;
		else if (title.contains("附件") && title.length() <= 4)
			bPass = false;
		String[] ignoreds = { "热点问题汇编", "无锡市锡山区人民政府关于对锡东新城全面开展殡葬整治工作的实施意见",
				"中国无锡·无锡市人民政府·中国无锡政府门户网站·首页", "锡政发〔2001〕253号签发：王荣",
				"锡滨安发（2006）1号", "中国无锡·无锡市人民政府·中国无锡政府门户网站·走进直播间·", "无标题文档",
				"本栏目暂无内容", "锡价费函[2005]号", "锡药监办[2003]30号签发人：谢寿坤",
				"中国无锡·无锡市政风行风热线", "中国无锡·Guu" };
		for (String str : ignoreds) {
			if (title.indexOf(str) >= 0)
				bPass = false;
		}

		if (!bPass) {
			log.error("ignored title : " + title);
		}
		return bPass;
	}

	private static String checkUrl(String url) {
		StringBuilder builder = new StringBuilder();
		final String header = "http://";
		int j = url.indexOf(header);
		if (j >= 0)
			j += header.length();
		else if (url.startsWith("www")) {
			j = 0;
		} else {
			log.error("unlegal url: " + url);
			return null;
		}
		int number = 0;
		builder.append(header);
		for (; j < url.length() - 1; j++) {
			char c1 = url.charAt(j);
			char c2 = url.charAt(j + 1);
			if ((c1 == '\\') && (Character.isLetterOrDigit(c2))) {
				log.error("unlegal url: " + url);
				return null;
			} else if ((c1 == '/') && (c2 == '/')) {
				builder.append(c1);
				j += 1; // skip c2
				number++;
			} else
				builder.append(c1);
		}
		builder.append(url.charAt(url.length() - 1)); // 获得url
		Assert.assertEquals(true, (number == 0 || number == 1));
		String result = builder.toString();
		String[] urlFilters = { "blind1111111111", "wap", "blind" };
		for (String ignoredStr : urlFilters) {
			if (result.contains(ignoredStr)) {
				// log.error("ignored url : " + result + "," + title);
				if (!result.contains("/wap/"))
					log.error("ignored url : " + result);
				if (!result.contains("/blind/"))
					log.error("ignored url : " + result);
				return null;
			}
		}
		return result;
	}

	public static String checkTag(String tagType) {
		int index = -1;
		final String[] tags = { "魅力锡城", "锡城资讯", "信息公开", "公共服务", "政务大厅", "政民互动",
				"热点问题" };
		for (int i = 0; i < tags.length; i++) {
			String str = tags[i];
			if (tagType.equalsIgnoreCase(str)) {
				index = i;
				break;
			}
		}
		if (index < 0) {
			log.info("invalid tag: " + tagType);
		}
		Assert.assertEquals(true, (index >= 0 && index < tags.length));
		return "tag" + (index + 1);
	}
}
