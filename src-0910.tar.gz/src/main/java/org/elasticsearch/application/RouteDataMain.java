package org.elasticsearch.application;

import static org.elasticsearch.common.xcontent.XContentFactory.jsonBuilder;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.io.MapWritable;
import org.elasticsearch.action.admin.indices.create.CreateIndexResponse;
import org.elasticsearch.action.admin.indices.exists.indices.IndicesExistsResponse;
import org.elasticsearch.application.util.OfficialDataUtils;
import org.elasticsearch.application.util.TestDataReader;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.joda.FormatDateTimeFormatter;
import org.elasticsearch.common.joda.Joda;
import org.elasticsearch.common.joda.time.DateTime;
import org.elasticsearch.common.joda.time.format.DateTimeFormat;
import org.elasticsearch.common.joda.time.format.DateTimeFormatter;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.elasticsearch.common.xcontent.XContentBuilder;
import org.elasticsearch.hadoop.cfg.ConfigurationOptions;
import org.elasticsearch.hadoop.cfg.Settings;
import org.elasticsearch.hadoop.cfg.SettingsManager;
import org.elasticsearch.hadoop.mr.MapReduceWriter;
import org.elasticsearch.hadoop.rest.InitializationUtils;
import org.elasticsearch.hadoop.rest.RestClient;
import org.elasticsearch.hadoop.serailize.IndexCommand;
import org.elasticsearch.hadoop.serailize.MapWritableIdExtractor;
import org.elasticsearch.hadoop.serailize.SerializationUtils;
import org.elasticsearch.hadoop.util.BytesArray;
import org.elasticsearch.hadoop.util.WritableUtils;
import org.splitword.soul.utility.StringUtil;

public class RouteDataMain {
	private static Log log = LogFactory.getLog(RouteDataMain.class);
	private static String hostName = "192.168.2.61";
	private static String indexName = "route_mini_0722";
	private static String sourcePath = "/mnt/e/official-07-22/hot01.txt";

	private static final FormatDateTimeFormatter formatter = Joda
			.forPattern("yyyy-MM-dd HH:mm:ss||yyyy-MM-dd||yyyy-MM-dd HH:mm||yyyy/MM/dd HH:mm:ss");
	private static final DateTimeFormatter outputFormat = DateTimeFormat
			.forPattern("yyyy-MM-dd");
	private static final String typeName = "table";

	private static void indexJsonData(String path, int number) throws Exception {
		Properties properties = new Properties();
		properties.put(ConfigurationOptions.ES_WRITE_OPERATION, "index");
		properties.put(ConfigurationOptions.ES_MAPPING_ID, "id");
		String resource = indexName + "/" + typeName;
		properties.put(ConfigurationOptions.ES_RESOURCE, resource);
		properties.put(ConfigurationOptions.ES_HOST, hostName);
		Settings settings = SettingsManager.loadFrom(properties);
		SerializationUtils.setValueWriterIfNotSet(settings,
				MapReduceWriter.class, log);
		InitializationUtils.setIdExtractorIfNotSet(settings,
				MapWritableIdExtractor.class, log);
		RestClient client = new RestClient(settings);
		IndexCommand command = new IndexCommand(settings);
		TestDataReader reader = new TestDataReader(path, "utf-8");
		List<Map<String, String>> result = null;
		BytesArray data = new BytesArray(20 * 1024 * 1024);
		int currentNum = 0;
		while ((result = reader.nextData(20, TestDataReader.JsonFormat)) != null) {
			for (int i = 0; i < result.size(); i++) {
				Map<String, String> entry = result.get(i);
				// Map<String, String> entry = OfficialDataUtility
				// .checkThisEntry(tmpEntry);
				// 已经检查过了，没必要再次检查。
				String time = (String) entry.get("postTime");
				if (!time.equals("null")) {
					DateTime dt = formatter.parser().parseDateTime(time);
					String date = dt.toString(outputFormat);
					entry.put("postTime", date);
					log.info(date);
				} else
					entry.remove("postTime");
				checkKeywords(entry);
				String tag = OfficialDataUtils.checkTag(entry.get("tag"));
				entry.put("tag", tag);
				MapWritable writable = (MapWritable) WritableUtils
						.toWritable(entry);
				int entrySize = command.prepare(writable);
				if (entrySize + data.size() > data.capacity()) {
					client.bulk(settings.getIndexType(), data.bytes(),
							data.size());
					data.reset();
				}
				command.write(writable, data);
			}
			currentNum++;
			if (currentNum >= number && number > 0)
				break;
		}
		client.bulk(settings.getIndexType(), data.bytes(), data.size());
		data.reset();
		client.close();
	}

	private static void checkKeywords(Map<String, String> entry) {
		String keywords = entry.get("keywords");
		String subjectOne = entry.get("subjectone");
		String subjectTwo = entry.get("subjecttwo");
		if (entry.containsKey("keywords"))
			entry.remove("keywords");
		if (entry.containsKey("subjectone"))
			entry.remove("subjectone");
		if (entry.containsKey("subjecttwo"))
			entry.remove("subjecttwo");
		if (StringUtil.isNotBlank(keywords)
				&& StringUtil.isNotBlank(subjectOne)
				&& StringUtil.isNotBlank(subjectTwo)) {
			List<String> list = new LinkedList<String>();
			List<String> resultList = new LinkedList<String>();
			list.add(subjectOne);
			list.add(subjectTwo);
			list.add(keywords);
			for (String listStr : list) {
				String[] strs = listStr.split("\t");
				for (String str : strs) {
					// if (ChineseHelper.allChineseChar(str)
					// && !resultList.contains(str))
					if (!resultList.contains(str))
						resultList.add(str);
				}
			}
			if (resultList.contains("其他"))
				resultList.remove("其他");
			if (resultList.size() > 0) {
				StringBuilder builder = new StringBuilder();
				for (String str : resultList)
					builder.append(str + "\t");
				entry.put("keywords", builder.toString());
				String tag = entry.get("tag");
				// 只有《信息公开》栏目里才有关键字和主题词
				if (!tag.equals("信息公开"))
					log.info("invalid tag: " + tag);
				log.info("keywords: " + entry.get("keywords"));
			}
		}
	}

	@SuppressWarnings("resource")
	private static void createIndexMapping() {
		try {
			TransportClient tcpClient = new TransportClient()
					.addTransportAddress(new InetSocketTransportAddress(
							hostName, 9300));
			IndicesExistsResponse existsResponse = tcpClient.admin().indices()
					.prepareExists(indexName).execute().actionGet();
			if (existsResponse.isExists()) {
				// if index exist, delete it
				tcpClient.admin().indices().prepareDelete(indexName).execute()
						.actionGet();
			}
			XContentBuilder builder = (XContentBuilder) jsonBuilder()
					.startObject().startObject("settings").startObject("index")
					.field("refresh_interval", -1)
					.field("number_of_replicas", 1).endObject().endObject()
					.startObject("mappings").startObject(typeName)
					.startObject("_routing").field("_required", true)
					.field("path", "tag").endObject().startObject("properties")
					.startObject("url").field("type", "string")
					.field("index", "not_analyzed").endObject()
					.startObject("tag").field("type", "string")
					.field("index", "not_analyzed").endObject()
					.startObject("postTime").field("type", "date")
					.field("ignore_malformed", false).field("format", "date")
					.endObject().startObject("source").field("type", "string")
					.field("index", "not_analyzed").endObject()
					.startObject("keywords").field("type", "multi_field")
					.startObject("fields").startObject("keywords")
					.field("type", "string")
					.field("index_analyzer", "whitespace").endObject()
					.startObject("untouched").field("type", "string")
					.field("index", "not_analyzed").endObject().endObject()
					.endObject().startObject("contenttitle")
					.field("type", "multi_field").startObject("fields")
					.startObject("contenttitle").field("type", "string")
					.field("index_analyzer", "soul_title")
					.field("search_analyzer", "soul_query").endObject()
					.startObject("untouched").field("type", "string")
					.field("index", "not_analyzed").endObject().endObject()
					.endObject().startObject("content").field("type", "string")
					.field("index_analyzer", "soul_index")
					.field("search_analyzer", "soul_query").endObject()
					.endObject().endObject().endObject().endObject();
			String settings = builder.string();
			log.info(settings);
			CreateIndexResponse createIndexResponse = tcpClient.admin()
					.indices().prepareCreate(indexName).setSource(settings)
					.execute().actionGet();
			tcpClient.admin().cluster().prepareHealth(indexName)
					.setWaitForGreenStatus().execute().actionGet();
			tcpClient.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) throws Exception {
		if (args == null || args.length <= 0) {
			log.info("invalid arguments!");
		} else if (args[0].equalsIgnoreCase("create")) {
			hostName = args[1];
			indexName = args[2];
			createIndexMapping();
		} else if (args[0].equalsIgnoreCase("index")) {
			hostName = args[1];
			indexName = args[2];
			sourcePath = args[3];
			int number = Integer.MAX_VALUE;
			if (args[4] != null && args[4].length() > 0)
				number = Integer.valueOf(args[4]);
			indexJsonData(sourcePath, number);
		} else {
			log.info("invalid arguments!");
		}
	}
}
