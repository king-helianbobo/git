package org.elasticsearch.plugin;

import org.elasticsearch.index.analysis.AnalysisModule;
import org.elasticsearch.plugin.analyzer.SoulIndexAnalyzerProvider;
import org.elasticsearch.plugin.analyzer.SoulNatureAnalyzerProvider;
import org.elasticsearch.plugin.analyzer.SoulPinyinAnalyzerProvider;
import org.elasticsearch.plugin.analyzer.SoulQueryAnalyzerProvider;
import org.elasticsearch.plugin.analyzer.SoulTitleAnalyzerProvider;
import org.elasticsearch.plugin.analyzer.TaxDateAnalyzerProvider;
import org.elasticsearch.plugin.analyzer.TaxIndexAnalyzerProvider;
import org.elasticsearch.plugin.analyzer.TaxQueryAnalyzerProvider;
import org.elasticsearch.plugin.analyzer.TaxSchemaAnalyzerProvider;

public class SoulAnalysisBindProcessor extends
		AnalysisModule.AnalysisBinderProcessor {

	@Override
	public void processAnalyzers(AnalyzersBindings analyzersBindings) {
		analyzersBindings.processAnalyzer("soul_index",
				SoulIndexAnalyzerProvider.class);
		analyzersBindings.processAnalyzer("soul_query",
				SoulQueryAnalyzerProvider.class);
		analyzersBindings.processAnalyzer("soul_query_nature",
				SoulNatureAnalyzerProvider.class);
		analyzersBindings.processAnalyzer("soul_pinyin",
				SoulPinyinAnalyzerProvider.class);
		analyzersBindings.processAnalyzer("soul_title",
				SoulTitleAnalyzerProvider.class);

		analyzersBindings.processAnalyzer("tax_index",
				TaxIndexAnalyzerProvider.class);
		analyzersBindings.processAnalyzer("tax_query",
				TaxQueryAnalyzerProvider.class);
		analyzersBindings.processAnalyzer("tax_date",
				TaxDateAnalyzerProvider.class);
		analyzersBindings.processAnalyzer("tax_schema",
				TaxSchemaAnalyzerProvider.class);
		super.processAnalyzers(analyzersBindings);
	}
}
