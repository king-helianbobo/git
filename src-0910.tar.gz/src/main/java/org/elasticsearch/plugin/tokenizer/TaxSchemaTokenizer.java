package org.elasticsearch.plugin.tokenizer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.lucene.analysis.Tokenizer;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
import org.elasticsearch.hadoop.util.StringUtils;
import org.elasticsearch.plugin.EsStaticValue;
import org.elasticsearch.utility.JcsegInstance;
import org.splitword.soul.analysis.Analysis;
import org.splitword.soul.domain.Term;
import org.splitword.soul.domain.TermNature;
import org.splitword.soul.jcseg.JcSegment;
import org.splitword.soul.utility.StringUtil;

public class TaxSchemaTokenizer extends Tokenizer {

	private static Log log = LogFactory.getLog(TaxSchemaTokenizer.class);
	private final CharTermAttribute termAtt = addAttribute(CharTermAttribute.class);
	private final OffsetAttribute offsetAtt = addAttribute(OffsetAttribute.class);
	private final PositionIncrementAttribute posAttr = addAttribute(PositionIncrementAttribute.class);
	private final TypeAttribute typeAtt = addAttribute(TypeAttribute.class);
	protected Analysis analysis = null; // analysis tool
	private List<Term> subTerms = null;
	private String pinyin = null;
	private int startOffset = -1;
	private int endOffset = -1;
	private static JcSegment seg = JcsegInstance.instance();

	public TaxSchemaTokenizer(Analysis analy, Reader input) {
		super(input);
		this.analysis = analy;
	}

	private void clear() {
		pinyin = null;
		startOffset = -1;
		endOffset = -1;
	}

	@Override
	public final boolean incrementToken() throws IOException {
		clearAttributes();
		int position = 0;
		Term term = null;
		String name = null;
		int length = 0;
		boolean flag = true;
		int numWhiteSpace = 0;

		if (StringUtil.isNotBlank(pinyin)) {
			String[] zimus = pinyin.split(" ");
			StringBuilder builder3 = new StringBuilder();
			for (int j = 0; j < zimus.length; j++) {
				String zimu = zimus[j];
				builder3.append(zimu.charAt(0));
			}
			// String jc = builder3.toString().toUpperCase();
			String jc = builder3.toString().toLowerCase();
			posAttr.setPositionIncrement(0);
			termAtt.setEmpty().append(jc);
			offsetAtt.setOffset(startOffset, endOffset);
			typeAtt.setType("abbreviation");
			clear();
			return true;
		}
		if (subTerms != null) {
			Term subTerm = subTerms.remove(0);
			posAttr.setPositionIncrement(0);
			String token = subTerm.getName();
			termAtt.setEmpty().append(token);
			offsetAtt.setOffset(subTerm.getOffe(),
					subTerm.getOffe() + token.length());
			typeAtt.setType("subterm");
			if (subTerms.isEmpty())
				subTerms = null;
			return true;
		}
		do {
			term = analysis.next();
			if (term == null) {
				break;
			}
			name = term.getName();
			length = name.length();
			if (term.getTermNatures().termNatures[0] == TermNature.EN) {
				term.setName(name);
			}
			if (!StringUtils.hasText(name)) {
				numWhiteSpace++;
				continue; // set continuous whiteSpace as one,keep its position
			} else {
				if (numWhiteSpace > 0) {
					position++;
					numWhiteSpace = 0;
				}
				position++;
				flag = false;
			}
		} while (flag);
		if (term != null) {
			posAttr.setPositionIncrement(position);
			termAtt.setEmpty().append(term.getName());
			offsetAtt.setOffset(term.getOffe(), term.getOffe() + length);
			if (analysis.bNature()) {
				String nature = term.getNatrue().natureStr;
				typeAtt.setType(nature);
			} else
				typeAtt.setType(EsStaticValue.TYPE_WORD);

			pinyin = seg.convertToPinyin(term.getName(), true);
			if (StringUtil.isNotBlank(pinyin)) {
				startOffset = term.getOffe();
				endOffset = term.getOffe() + length;
			} else
				clear();
			if (term.getSubTermList() != null)
				subTerms = term.getSubTermList();
			return true;
		} else {
			return false;
		}
	}

	@Override
	public void reset() throws IOException {
		super.reset();
		analysis.resetContent(new BufferedReader(input));
	}

}
