package org.elasticsearch.plugin.tokenizer;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.lucene.analysis.TokenFilter;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
import org.elasticsearch.plugin.EsStaticValue;
import org.elasticsearch.utility.ChineseHelper;
import org.elasticsearch.utility.JcsegInstance;
import org.splitword.soul.jcseg.JcSegment;

public class PinyinTokenFilter extends TokenFilter {
	// private static Log log = LogFactory.getLog(PinyinTokenFilter.class);
	private int totalNumber = 1; // number of tokens to be convert
	private int tokenStart;
	private int tokenEnd;
	private int position = 1;
	private int curNumber = 0;
	private boolean bPinyinSpace = true;// 字与字间的拼音是不是放置一个空格
	private final CharTermAttribute termAtt = addAttribute(CharTermAttribute.class);
	private final OffsetAttribute offsetAtt = addAttribute(OffsetAttribute.class);
	private final TypeAttribute typeAtt = addAttribute(TypeAttribute.class);
	private final PositionIncrementAttribute posAtt = addAttribute(PositionIncrementAttribute.class);

	private static JcSegment seg = JcsegInstance.instance();
	private Map<String, List<String>> synonymTree = null;
	private List<String> synonymList = null;
	private String pinyin = null;
	private String originalToken = null;

	public PinyinTokenFilter(TokenStream input) { // accept one token stream
		super(input);
		synonymTree = null;
		bPinyinSpace = true;
	}

	public PinyinTokenFilter(TokenStream input, boolean bSynonym,
			boolean bSeperate) {
		// accept one token stream and synonym tree
		super(input);
		if (bSynonym) { // if need to use synonym tree
			EsStaticValue.loadData();
			synonymTree = EsStaticValue.synonymTree;
		} else
			synonymTree = null;
		this.bPinyinSpace = bSeperate;
	}

	@Override
	public final boolean incrementToken() throws IOException {
		while (true) {
			if (originalToken == null) {
				if (!input.incrementToken()) {
					return false;
				} else {
					int curTermLength = termAtt.length();
					char[] curTermBuffer = new char[curTermLength];
					System.arraycopy(termAtt.buffer(), 0, curTermBuffer, 0,
							curTermLength);
					originalToken = new String(curTermBuffer);
					position = posAtt.getPositionIncrement();
					totalNumber = 1;
					if (ChineseHelper.containChineseChar(originalToken)) {
						Reader reader = new StringReader(originalToken);
						pinyin = seg.convertToPinyin(reader, bPinyinSpace);
						totalNumber += 1;
					} else {
						// if not include Chinese chars, pinyin is null
						pinyin = null;
					}
					if (synonymTree != null) {
						List<String> list = synonymTree.get(originalToken);
						if (list != null) {
							totalNumber += (list.size());
							synonymList = new LinkedList<String>();
							synonymList.addAll(list);
						} else
							synonymList = null;
					} else {
						synonymList = null;
					}
					tokenStart = offsetAtt.startOffset();
					tokenEnd = offsetAtt.endOffset();
					curNumber = 0; // first time we get original token
				}
			}
			if (curNumber < totalNumber) {
				if (curNumber == 0) {
					clearAttributes();
					offsetAtt.setOffset(tokenStart, tokenEnd);
					termAtt.append(originalToken);
					posAtt.setPositionIncrement(position);
					if (pinyin == null)
						typeAtt.setType(EsStaticValue.TYPE_WORD);
					else
						typeAtt.setType(EsStaticValue.TYPE_HANZI);
				} else if (pinyin != null) {
					clearAttributes();
					offsetAtt.setOffset(tokenStart, tokenEnd);
					termAtt.copyBuffer(pinyin.toCharArray(), 0, pinyin.length());
					typeAtt.setType(EsStaticValue.TYPE_PINYIN);
					posAtt.setPositionIncrement(0); // position increment is 0
					pinyin = null;
				} else if (synonymList != null) {
					clearAttributes();
					offsetAtt.setOffset(tokenStart, tokenEnd);
					String text = synonymList.remove(0);
					termAtt.append(text);
					typeAtt.setType(EsStaticValue.TYPE_SYNONYM);
					posAtt.setPositionIncrement(0);// position increment is 0
					if (synonymList.size() == 0)
						synonymList = null;
				}
				curNumber++;
				return true;
			} else
				originalToken = null;
		}
	}

	@Override
	public void reset() throws IOException {
		super.reset();
		originalToken = null;
	}
}
