package org.elasticsearch.plugin.tokenizer;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.lucene.analysis.TokenFilter;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
import org.apache.lucene.analysis.tokenattributes.TypeAttribute;

public class DateTokenFilter extends TokenFilter {
	private final CharTermAttribute termAtt = addAttribute(CharTermAttribute.class);
	private final OffsetAttribute offsetAtt = addAttribute(OffsetAttribute.class);
	private final TypeAttribute typeAtt = addAttribute(TypeAttribute.class);
	private final PositionIncrementAttribute posAtt = addAttribute(PositionIncrementAttribute.class);
	private static Log log = LogFactory.getLog(DateTokenFilter.class);

	private int totalNumber = 1; // number of tokens to be convert
	private int curNumber = 0;
	private String dateStr = null;
	private String timeStr = null;

	private int tokenStart;// be initialized by incrementToken
	private int tokenEnd;// be initialized by incrementToken
	private int tokenPosition;// be initialized by incrementToken
	private String originalToken = null;
	private List<String> dayList = null;

	public DateTokenFilter(TokenStream input) { // accept one token stream
		super(input);
	}

	@Override
	public final boolean incrementToken() throws IOException {
		while (true) {
			if (originalToken == null) {
				if (!input.incrementToken()) {
					return false;
				} else {
					int curTermLength = termAtt.length();
					char[] curTermBuffer = new char[curTermLength];
					System.arraycopy(termAtt.buffer(), 0, curTermBuffer, 0,
							curTermLength);
					originalToken = new String(curTermBuffer);
					tokenPosition = posAtt.getPositionIncrement();
					totalNumber = 1;
					curNumber = 0; // first time we get original token

					if (originalToken.indexOf("-") >= 0) {
						dateStr = originalToken;
						timeStr = null;
					} else if (originalToken.indexOf(":") >= 0) {
						dateStr = null;
						timeStr = originalToken;
					} else {
						dateStr = null;
						timeStr = null;
						log.error("wrong format " + originalToken);
					}

					if (dateStr != null) {
						dayList = parseDateTime(dateStr);
						totalNumber += dayList.size();
					} else
						dayList = null;

					tokenStart = offsetAtt.startOffset();
					tokenEnd = offsetAtt.endOffset();
				}
			}
			if (curNumber < totalNumber) {
				if (curNumber == 0) {
					clearAttributes();
					offsetAtt.setOffset(tokenStart, tokenEnd);
					termAtt.append(originalToken);
					posAtt.setPositionIncrement(tokenPosition);
					if (dateStr != null)
						typeAtt.setType("date");
					else if (timeStr != null)
						typeAtt.setType("time");
				} else if (dayList != null) {
					clearAttributes();
					offsetAtt.setOffset(tokenStart, tokenEnd);
					String text = dayList.remove(0);
					termAtt.append(text);
					typeAtt.setType("date");
					posAtt.setPositionIncrement(0);// position increment is 0
					if (dayList.size() == 0)
						dayList = null;
				}
				curNumber++;
				return true;
			} else
				originalToken = null;
		}
	}

	private List<String> parseDateTime(String originalToken) {
		List<String> list = new LinkedList<String>();
		String[] strs = originalToken.split("-");
		if (strs.length != 2 && strs.length != 3)
			log.error("wrong format for [" + originalToken + "]");
		if (strs.length == 2) {
			list.add(strs[0]);
		} else if (strs.length == 3) {
			list.add(strs[0]);
			list.add(strs[0] + "-" + strs[1]);
		}
		return list;
	}

	@Override
	public void reset() throws IOException {
		super.reset();
		originalToken = null;
		dateStr = null;
		timeStr = null;
	}
}
