package org.elasticsearch.plugin;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.miscellaneous.PerFieldAnalyzerWrapper;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.AtomicReaderContext;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.IndexWriterConfig.OpenMode;
import org.apache.lucene.index.Term;
import org.apache.lucene.index.Terms;
import org.apache.lucene.index.TermsEnum;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.highlight.Highlighter;
import org.apache.lucene.search.highlight.InvalidTokenOffsetsException;
import org.apache.lucene.search.highlight.QueryScorer;
import org.apache.lucene.search.highlight.SimpleHTMLFormatter;
import org.apache.lucene.store.AlreadyClosedException;
import org.apache.lucene.store.Directory;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.map.ObjectMapper;
import org.elasticsearch.plugin.LuceneTermsInEs.LuceneFieldIterator;
import org.elasticsearch.plugin.analyzer.SoulPinyinAnalyzer;
import org.splitword.soul.analysis.BasicAnalysis;
import org.splitword.soul.utility.StringUtil;

public class SoulTitleRamCache implements java.io.Closeable {
	private static Log log = LogFactory.getLog(SoulTitleRamCache.class);
	private static final String wordField = "wordField";
	private static final String idField = "idField";
	private final Object searcherLock = new Object();
	private final Object modifyCurrentIndexLock = new Object();
	private volatile boolean closed = false;
	private IndexSearcher searcher;
	private Directory titleIndex;
	private ObjectMapper mapper = new ObjectMapper();
	private static SimpleHTMLFormatter htmlFormatter = new SimpleHTMLFormatter(
			"<span style='color:red'>", "</span>");
	private static Analyzer analyzer = new SoulPinyinAnalyzer();
	private static Map<String, Integer> tree = new TreeMap<String, Integer>();

	public SoulTitleRamCache(Directory indexDir) throws IOException {
		this.titleIndex = indexDir;
		setTitleIndex(titleIndex);
	}

	private void setTitleIndex(Directory indexDir) throws IOException {
		synchronized (modifyCurrentIndexLock) {
			ensureOpen();
			if (!DirectoryReader.indexExists(indexDir)) {
				IndexWriter writer = new IndexWriter(
						indexDir,
						new IndexWriterConfig(EsStaticValue.LuceneVersion, null));
				writer.close();
			}
			swapSearcher(indexDir);
		}
	}

	public void clearIndex() throws IOException {
		synchronized (modifyCurrentIndexLock) {
			ensureOpen();
			final Directory dir = this.titleIndex;
			final IndexWriter writer = new IndexWriter(dir,
					new IndexWriterConfig(EsStaticValue.LuceneVersion, null)
							.setOpenMode(OpenMode.CREATE));
			writer.close();
			swapSearcher(dir);
		}
	}

	/**
	 * Check whether the word exists in index
	 */
	public boolean exist(String word) throws IOException {
		final IndexSearcher indexSearcher = obtainSearcher();
		try {
			return indexSearcher.getIndexReader().docFreq(
					new Term(wordField, word)) > 0;
		} finally {
			releaseSearcher(indexSearcher);
		}
	}

	/* get suggest titles at least titleNum */
	public String[] suggestTitles(String keyword, int titleNum)
			throws IOException, InvalidTokenOffsetsException {
		List<String> terms = BasicAnalysis.parse(keyword,
				EsStaticValue.stopWordsSet);
		BooleanQuery query = new BooleanQuery();
		if (terms.isEmpty())
			return null;
		else {
			float score = 0.0f;
			for (int i = 0; i < terms.size(); i++) {
				String value = terms.get(i);
				Query tq = new TermQuery(new Term(wordField, value));
				score += 1.0f;
				tq.setBoost(score);
				query.add(new BooleanClause(tq, BooleanClause.Occur.SHOULD));
			}
		}
		IndexSearcher indexSearcher = this.obtainSearcher();
		int number = Math.min(20, titleNum * 2);
		TopDocs topDocs = indexSearcher.search(query, number);
		Highlighter highlighter = new Highlighter(htmlFormatter,
				new QueryScorer(query));
		ScoreDoc[] scoreDocs = topDocs.scoreDocs;
		if (topDocs == null || topDocs.totalHits <= 0)
			return null;
		// if no result found ,return null
		// log.info("Hit: " + topDocs.totalHits + " titleNum: " + titleNum);
		number = Math.min(number, topDocs.totalHits);
		Map<String, String> resultMap = new HashMap<String, String>();
		int i = 0;
		while (resultMap.size() < number) {
			Document document = indexSearcher.doc(scoreDocs[i].doc);
			float score = scoreDocs[i].score;
			String value = document.get(wordField);
			resultMap.put(value, String.valueOf(score));
			i++;
			if (i >= number)
				break;
		}
		number = resultMap.size();
		String[] list = new String[number * 2];
		i = 0;
		for (String key : resultMap.keySet()) {
			String highLight = highlighter.getBestFragment(analyzer, wordField,
					key);
			String scoreValue = resultMap.get(key);
			list[2 * i] = highLight;
			list[2 * i + 1] = scoreValue;
			i++;
		}
		return list;
	}

	// fill data to this memory resident cache
	public void fillLuceneDirectory(LuceneTermsInEs fieldInfo,
			String toReadField) throws IOException {
		Map<String, Analyzer> analyzerMap = new HashMap<String, Analyzer>();
		analyzerMap.put(wordField, analyzer);
		PerFieldAnalyzerWrapper wrapper = new PerFieldAnalyzerWrapper(
				new StandardAnalyzer(EsStaticValue.LuceneVersion), analyzerMap);
		IndexWriterConfig iwConfig = new IndexWriterConfig(
				EsStaticValue.LuceneVersion, wrapper);
		iwConfig.setOpenMode(OpenMode.CREATE_OR_APPEND);
		Directory dir = this.titleIndex;
		final IndexWriter writer = new IndexWriter(dir, iwConfig);
		synchronized (modifyCurrentIndexLock) {
			ensureOpen();
			IndexSearcher indexSearcher = obtainSearcher();
			final List<TermsEnum> termsEnums = new ArrayList<TermsEnum>();
			final IndexReader reader = searcher.getIndexReader();
			if (reader.maxDoc() > 0) {
				for (final AtomicReaderContext ctx : reader.leaves()) {
					Terms terms = ctx.reader().terms(wordField);
					if (terms != null)
						termsEnums.add(terms.iterator(null));
				}
			}
			try {
				LuceneFieldIterator iter = fieldInfo.iterator();
				String json = null;
				while ((json = iter
						.nextJsonWithinField(termsEnums, toReadField)) != null) {
					if ((json.equals("null")) || (StringUtil.isBlank(json)))
						continue;
					Document doc = new Document();
					JsonParser jsonParser = mapper.getJsonFactory()
							.createJsonParser(json);
					@SuppressWarnings("unchecked")
					Map<String, Object> map = mapper.readValue(jsonParser,
							Map.class);
					String word = (String) map.get("field2");
					String id = (String) map.get("field1");
					doc.add(new TextField(wordField, word, Field.Store.YES));
					doc.add(new TextField(idField, id, Field.Store.YES));
					writer.addDocument(doc);
				}
			} finally {
				log.info("Read title field finished!");
				releaseSearcher(indexSearcher);
			}
			writer.close();
			swapSearcher(dir);
		}
	}

	String[] analyze(Analyzer analyzer, String text, String keyword) {
		try {
			tree.clear();
			TokenStream tokenStream = analyzer.tokenStream(null,
					new StringReader(text));
			tokenStream.reset();
			while (tokenStream.incrementToken()) {
				CharTermAttribute charAttribute = tokenStream
						.getAttribute(CharTermAttribute.class);
				// OffsetAttribute offsetAttribute = tokenStream
				// .getAttribute(OffsetAttribute.class);
				TypeAttribute typeAtt = tokenStream
						.getAttribute(TypeAttribute.class);
				String type = typeAtt.type();
				if (type.equalsIgnoreCase(EsStaticValue.TYPE_HANZI)
						|| type.equalsIgnoreCase(EsStaticValue.TYPE_PINYIN)) {
					String key = charAttribute.toString();
					if (tree.get(key) != null) {
						int value = tree.get(key);
						tree.put(key, value + 1);
					} else
						tree.put(key, 1);
				}

			}
			tokenStream.close();
			int number = 0;
			StringBuilder builder = new StringBuilder();
			for (String key : tree.keySet()) {
				if (number == (tree.size() - 1))
					builder.append(key);
				else
					builder.append(key + ",");
				number++;
			}
			String termList = builder.toString();
			String[] prefixs = termList.split(",");
			List<String> result = new ArrayList<String>();
			for (String prefix : prefixs) {
				if (prefix.startsWith(keyword)
						&& !prefix.equalsIgnoreCase(keyword)) {
					result.add(prefix);
				}
			}
			if (result.size() > 0) {
				String[] strs = new String[result.size()];
				for (int i = 0; i < result.size(); i++) {
					strs[i] = result.get(i);
				}
				return strs;
			} else
				return null;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	private IndexSearcher obtainSearcher() {
		synchronized (searcherLock) {
			ensureOpen();
			searcher.getIndexReader().incRef();
			return searcher;
		}
	}

	private void releaseSearcher(final IndexSearcher aSearcher)
			throws IOException {
		// don't check if open - always decRef
		// don't decrement the private searcher - could have been swapped
		aSearcher.getIndexReader().decRef();
	}

	private void ensureOpen() {
		if (closed) {
			throw new AlreadyClosedException("SoulTitleCache has been closed");
		}
	}

	@Override
	public void close() throws IOException {
		synchronized (searcherLock) {
			ensureOpen();
			closed = true;
			if (searcher != null) {
				searcher.getIndexReader().close();
			}
			searcher = null;
		}
	}

	private void swapSearcher(final Directory dir) throws IOException {
		final IndexSearcher indexSearcher = createSearcher(dir);
		synchronized (searcherLock) {
			if (closed) {
				indexSearcher.getIndexReader().close();
				throw new AlreadyClosedException("searcher has been closed!");
			}
			if (searcher != null) {
				searcher.getIndexReader().close();
			}
			searcher = indexSearcher;
			this.titleIndex = dir;
		}
	}

	IndexSearcher createSearcher(final Directory dir) throws IOException {
		return new IndexSearcher(DirectoryReader.open(dir));
	}

	boolean isClosed() {
		return closed;
	}

}
