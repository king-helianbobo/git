package org.elasticsearch.plugin.analyzer;

import java.io.Reader;
import java.util.Set;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.Tokenizer;
import org.apache.lucene.analysis.standard.StandardFilter;
import org.elasticsearch.plugin.EsStaticValue;
import org.elasticsearch.plugin.tokenizer.BasicTokenizer;
import org.elasticsearch.plugin.tokenizer.PinyinTokenFilter;
import org.splitword.soul.analysis.BasicAnalysis;

public class SoulIndexAnalyzer extends Analyzer {

	boolean pstemming = EsStaticValue.pstemming;
	public Set<String> filter = EsStaticValue.stopWordsSet;

	public SoulIndexAnalyzer() {
		super();
	}

	@Override
	protected TokenStreamComponents createComponents(String fieldName,
			final Reader reader) {
		Tokenizer tokenizer = new BasicTokenizer(
				new BasicAnalysis(reader, true), reader, null, pstemming);
		TokenStream result = new StandardFilter(EsStaticValue.LuceneVersion,
				tokenizer);
		result = new PinyinTokenFilter(result, false, false);
		return new TokenStreamComponents(tokenizer, result);
	}
}
