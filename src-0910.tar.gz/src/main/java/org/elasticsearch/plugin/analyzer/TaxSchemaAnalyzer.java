package org.elasticsearch.plugin.analyzer;

import java.io.Reader;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.Tokenizer;
import org.apache.lucene.analysis.standard.StandardFilter;
import org.elasticsearch.plugin.EsStaticValue;
import org.elasticsearch.plugin.tokenizer.PinyinTokenFilter;
import org.elasticsearch.plugin.tokenizer.TaxSchemaTokenizer;
import org.elasticsearch.plugin.tokenizer.TaxSynonymFilter;
import org.splitword.soul.analysis.BasicAnalysis;

public class TaxSchemaAnalyzer extends Analyzer {

	public TaxSchemaAnalyzer() {
		super();
	}

	@Override
	protected TokenStreamComponents createComponents(String fieldName,
			final Reader reader) {
		Tokenizer tokenizer = new TaxSchemaTokenizer(new BasicAnalysis(reader,
				false), reader);
		TokenStream result = new StandardFilter(EsStaticValue.LuceneVersion,
				tokenizer);
		result = new PinyinTokenFilter(result, false, false);
		result = new TaxSynonymFilter(result);
		return new TokenStreamComponents(tokenizer, result);
	}
}
