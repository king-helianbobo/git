package org.elasticsearch.plugin.analyzer;

import java.io.Reader;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.Tokenizer;
import org.apache.lucene.analysis.standard.StandardFilter;
import org.elasticsearch.plugin.EsStaticValue;
import org.elasticsearch.plugin.tokenizer.BasicTokenizer;
import org.elasticsearch.plugin.tokenizer.PinyinTokenFilter;
import org.splitword.soul.analysis.Analysis;
import org.splitword.soul.analysis.BasicAnalysis;

public class SoulTitleAnalyzer extends Analyzer {

	boolean pstemming = EsStaticValue.pstemming;

	public SoulTitleAnalyzer() {
		super();
	}

	@Override
	protected TokenStreamComponents createComponents(String fieldName,
			final Reader reader) {
		Analysis analysis = new BasicAnalysis(reader, true);
		Tokenizer tokenizer = new BasicTokenizer(analysis, reader, null,
				pstemming);
		TokenStream result = new StandardFilter(EsStaticValue.LuceneVersion,
				tokenizer);
		result = new PinyinTokenFilter(result, false, false);
		return new TokenStreamComponents(tokenizer, result);
	}
}
