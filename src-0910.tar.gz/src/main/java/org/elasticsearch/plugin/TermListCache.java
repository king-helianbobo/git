package org.elasticsearch.plugin;

import java.io.IOException;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.lucene.index.Fields;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.MultiFields;
import org.apache.lucene.index.Terms;
import org.apache.lucene.index.TermsEnum;
import org.apache.lucene.util.BytesRef;
import org.elasticsearch.utility.ChineseHelper;
import org.elasticsearch.utility.CompactHashMap;
import org.splitword.soul.utility.StringUtil;

import com.elasticsearch.action.termlist.TermInfoPojo;

public class TermListCache {

	IndexReader reader = null;
	private static Log log = LogFactory.getLog(TermListCache.class);

	public TermListCache(IndexReader reader) {
		this.reader = reader;
	}

	public Map<String, TermInfoPojo> load(String... otherFields) {
		Map<String, TermInfoPojo> map = new CompactHashMap<String, TermInfoPojo>();
		try {
			Fields fields = MultiFields.getFields(reader);
			if (fields != null) {
				for (String expected : otherFields) {
					fillTermFreqMap(map, expected);
				}
			}
			return map;
		} catch (IOException e) {
			e.printStackTrace();
			map.clear();
			return null;
		}
	}

	private void fillTermFreqMap(Map<String, TermInfoPojo> map,
			String expectedField) throws IOException {
		Fields fields = MultiFields.getFields(reader);
		for (String field : fields) {
			if (field.charAt(0) == '_')
				continue;
			if (expectedField == null || field.equals(expectedField)) {
				log.info(field + " is loading!");
				Terms terms = fields.terms(field);
				if (terms != null) {
					TermsEnum termsEnum = terms.iterator(null);
					BytesRef text;
					while ((text = termsEnum.next()) != null) {
						// skip invalid terms
						if (termsEnum.docFreq() < 1)
							continue;
						if (termsEnum.totalTermFreq() < 1)
							continue;
						String str = text.utf8ToString();
						if (str == null || StringUtil.isBlank(str)
								|| !ChineseHelper.allChineseChar(str))
							continue;

						TermInfoPojo t = new TermInfoPojo();
						if (map.containsKey(str)) {
							int freq = termsEnum.docFreq()
									+ map.get(str).getDocFreq();
							t.docFreq(freq);
						} else
							t.docFreq(termsEnum.docFreq());
						if (map.containsKey(str)) {
							int freq = (int) (termsEnum.totalTermFreq() + map
									.get(str).getTotalFreq());
							t.totalFreq(freq);
						} else
							t.totalFreq((int) termsEnum.totalTermFreq());
						map.put(str, t);
					}
				}
			}
		}

	}
}
