package org.elasticsearch.plugin;

import static org.elasticsearch.common.xcontent.support.XContentMapValues.nodeStringValue;

import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.elasticsearch.ElasticsearchIllegalArgumentException;
import org.elasticsearch.common.Nullable;
import org.elasticsearch.common.joda.time.DateTime;
import org.elasticsearch.common.joda.time.Days;
import org.elasticsearch.common.joda.time.LocalDate;
import org.elasticsearch.common.joda.time.format.DateTimeFormat;
import org.elasticsearch.common.joda.time.format.DateTimeFormatter;
import org.elasticsearch.index.fielddata.ScriptDocValues;
import org.elasticsearch.index.fielddata.ScriptDocValues.Longs;
import org.elasticsearch.script.AbstractFloatSearchScript;
import org.elasticsearch.script.ExecutableScript;
import org.elasticsearch.script.NativeScriptFactory;

public class DateBoostScript extends AbstractFloatSearchScript {
	private static Log log = LogFactory.getLog(DateBoostScript.class);

	public static class Factory implements NativeScriptFactory {
		@Override
		public ExecutableScript newScript(@Nullable Map<String, Object> params) {
			if (params == null)
				throw new ElasticsearchIllegalArgumentException(
						"Missing parameters");
			String currentTime = nodeStringValue(params.get("time"), null);
			if (currentTime == null)
				throw new ElasticsearchIllegalArgumentException(
						"Missing time parameter");

			String fieldName = nodeStringValue(params.get("field"), null);
			if (fieldName == null)
				throw new ElasticsearchIllegalArgumentException(
						"Missing field parameter");

			return new DateBoostScript(fieldName, currentTime);
		}
	}

	private final String currentTime;
	private final String fieldName;

	public DateBoostScript(String fieldName, String time) {
		this.currentTime = time;
		this.fieldName = fieldName;
	}

	private float boost(long currentTime, long documentTime) {
		final float startA = 17.001f;
		final float endA = 1.001f;
		final float startDay = 1.0f;
		final float endDay = 2000.0f;
		DateTime currentDate = new DateTime(currentTime);
		DateTime documentDate = new DateTime(documentTime);
		int numDays = Days.daysBetween(new LocalDate(currentDate),
				new LocalDate(documentDate)).getDays();
		int days = Math.abs(numDays) + 1;
		// log.info("number of days = " + days);
		float dx;
		if (days <= endDay)
			dx = (days - startDay) * (endA - startA) / (endDay - startDay)
					+ startA;
		else
			dx = (float) (1.0f / (Math.log10(10 + days - endDay)));
		return dx;
	}

	@Override
	public float runAsFloat() {
		Float finalScore = null;
		ScriptDocValues.Longs name = (Longs) doc().get(fieldName);
		Long timeMillis = name.getValues().get(0);
		DateTime documentDate = new DateTime(timeMillis);
		DateTime currentDate = new DateTime(Long.valueOf(currentTime));
		DateTimeFormatter outputFormat = DateTimeFormat
				.forPattern("yyyy-MM-dd");
		float df = 1.0f;
		if (!documentDate.toString(outputFormat).equals("1970-01-01"))
			df = boost(currentDate.getMillis(), timeMillis);
		finalScore = score() * df;
		// log.info("documentDate=" + documentDate.toString(outputFormat)
		// + ",currentDate=" + currentDate.toString(outputFormat)
		// + ",boost=" + df + ",score=" + finalScore);
		return finalScore;
	}
}
