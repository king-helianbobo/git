package com.elasticsearch.action.statistic;

import org.elasticsearch.action.support.broadcast.BroadcastOperationRequest;

public class SuggestStatisticsRequest extends BroadcastOperationRequest {
}
