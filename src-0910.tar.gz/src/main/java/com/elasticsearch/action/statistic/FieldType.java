package com.elasticsearch.action.statistic;

import java.io.IOException;
import java.io.Serializable;
import java.util.List;

import org.elasticsearch.common.base.Joiner;
import org.elasticsearch.common.base.Objects;
import org.elasticsearch.common.collect.Lists;
import org.elasticsearch.common.inject.internal.ToStringBuilder;
import org.elasticsearch.common.io.stream.StreamInput;
import org.elasticsearch.common.io.stream.StreamOutput;
import org.elasticsearch.common.io.stream.Streamable;
import org.elasticsearch.common.xcontent.ToXContent;
import org.elasticsearch.common.xcontent.XContentBuilder;

import com.elasticsearch.action.suggest.ShardSuggestRequest;

public class FieldType implements Streamable, Serializable, ToXContent {

	private String field;
	private List<String> types = Lists.newArrayList();
	private String queryAnalyzer;
	private String indexAnalyzer;
	private boolean preservePositionIncrements = true;

	public FieldType() {
	}

	public FieldType(ShardSuggestRequest shardSuggestRequest) {
		this.field = shardSuggestRequest.field();
	}

	public String field() {
		return field;
	}

	public String[] types() {
		return types.toArray(new String[] {});
	}

	public String queryAnalyzer() {
		return queryAnalyzer;
	}

	public String indexAnalyzer() {
		return indexAnalyzer;
	}

	public boolean preservePositionIncrements() {
		return preservePositionIncrements;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final FieldType other = (FieldType) obj;

		return Objects.equal(this.field(), other.field())
				&& Objects.equal(this.queryAnalyzer(), other.queryAnalyzer())
				&& Objects.equal(this.indexAnalyzer(), other.indexAnalyzer())
				&& Objects.equal(this.types, other.types)
				&& Objects.equal(this.preservePositionIncrements(),
						other.preservePositionIncrements());
	}

	@Override
	public int hashCode() {
		int hashCode = this.field().hashCode();
		hashCode += this.types.hashCode();
		if (this.queryAnalyzer != null)
			hashCode += this.queryAnalyzer.hashCode();
		if (this.indexAnalyzer != null)
			hashCode += this.indexAnalyzer.hashCode();
		hashCode += Boolean.valueOf(preservePositionIncrements).hashCode();

		return hashCode;
	}

	@Override
	public String toString() {
		ToStringBuilder toStringBuilder = new ToStringBuilder(this.getClass())
				.add("field", this.field());

		toStringBuilder.add("preservePositionIncrements",
				this.preservePositionIncrements);
		if (queryAnalyzer != null && queryAnalyzer.equals(indexAnalyzer)) {
			toStringBuilder.add("analyzer", this.queryAnalyzer);
		} else {
			if (queryAnalyzer != null) {
				toStringBuilder.add("queryAnalyzer", queryAnalyzer);
			}
			if (indexAnalyzer != null) {
				toStringBuilder.add("indexAnalyzer", indexAnalyzer);
			}
		}

		if (types.size() > 0) {
			toStringBuilder.add("types", Joiner.on("-").join(types));
		}

		return toStringBuilder.toString();
	}

	@SuppressWarnings("unchecked")
	@Override
	public void readFrom(StreamInput in) throws IOException {
		field = in.readString();
		queryAnalyzer = in.readOptionalString();
		indexAnalyzer = in.readOptionalString();
		types = (List<String>) in.readGenericValue();
		preservePositionIncrements = in.readBoolean();
	}

	@Override
	public void writeTo(StreamOutput out) throws IOException {
		out.writeString(field);
		out.writeOptionalString(queryAnalyzer);
		out.writeOptionalString(indexAnalyzer);
		out.writeGenericValue(types);
		out.writeBoolean(preservePositionIncrements);
	}

	@Override
	public XContentBuilder toXContent(XContentBuilder builder, Params params)
			throws IOException {
		// builder.startObject(field);
		builder.field("field", field);
		if (queryAnalyzer != null && queryAnalyzer.equals(indexAnalyzer)) {
			builder.field("analyzer", this.queryAnalyzer);
		} else {
			if (queryAnalyzer != null)
				builder.field("queryAnalyzer", queryAnalyzer);
			if (indexAnalyzer != null)
				builder.field("indexAnalyzer", indexAnalyzer);
		}
		if (!preservePositionIncrements)
			builder.field("preservePositionIncrements",
					preservePositionIncrements);
		if (types.size() > 0)
			builder.field("types", types());
		// builder.endObject();
		return builder;
	}
}