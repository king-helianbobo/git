package com.elasticsearch.action.suggest;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.elasticsearch.action.ShardOperationFailedException;
import org.elasticsearch.action.support.broadcast.BroadcastOperationResponse;
import org.elasticsearch.common.io.stream.StreamInput;
import org.elasticsearch.common.io.stream.StreamOutput;

public class SuggestResponse extends BroadcastOperationResponse {

	private List<String> suggestList;
	private static Log log = LogFactory.getLog(SuggestResponse.class);

	public SuggestResponse() {
	}

	public SuggestResponse(List<String> suggestions, int totalShards,
			int successfulShards, int failedShards,
			List<ShardOperationFailedException> shardFailures) {
		super(totalShards, successfulShards, failedShards, shardFailures);
		this.suggestList = suggestions;
	}

	public List<String> suggestions() {
		return suggestList;
	}

	@Override
	public void readFrom(StreamInput in) throws IOException {
		super.readFrom(in);
		int n = in.readInt();
		if (n > 0) {
			suggestList = new LinkedList<String>();
			for (int i = 0; i < n; i++) {
				String text = in.readString();
				suggestList.add(text);
			}
			log.info("when read,suggestion list is:" + suggestList);
		} else
			suggestList = null;
	}

	@Override
	public void writeTo(StreamOutput out) throws IOException {
		super.writeTo(out);
		if (suggestList != null && suggestList.size() > 0) {
			out.writeInt(suggestList.size());
			for (int i = 0; i < suggestList.size(); i++) {
				out.writeString(suggestList.get(i));
			}
			log.info("when write,suggestion list is:" + suggestList);
		} else
			out.writeInt(0);
	}
}
