package com.elasticsearch.action.suggest;

import java.io.IOException;

import org.elasticsearch.action.support.broadcast.BroadcastShardOperationRequest;
import org.elasticsearch.common.io.stream.StreamInput;
import org.elasticsearch.common.io.stream.StreamOutput;

public class ShardSuggestRequest extends BroadcastShardOperationRequest {

	private int size = 10;
	private String field = null;
	private float similarity;
	private String term = null;
	private String suggestType = "suggest";

	// private String[] types = Strings.EMPTY_ARRAY;

	// private String queryAnalyzer = null;
	// private String indexAnalyzer = null;
	// private boolean preservePositionIncrements = true;

	public ShardSuggestRequest() {
	}

	public ShardSuggestRequest(String index, int shardId, SuggestRequest request) {
		super(index, shardId, request);
		size = request.size();
		field = request.field();
		term = request.term();
		similarity = request.similarity();
		suggestType = request.suggestType();
		// queryAnalyzer = request.queryAnalyzer();
		// indexAnalyzer = request.indexAnalyzer();
		// preservePositionIncrements = request.preservePositionIncrements();
		// types = request.types();
	}

	public int size() {
		return size;
	}

	public void size(int size) {
		this.size = size;
	}

	public String field() {
		return field;
	}

	public void field(String field) {
		this.field = field;
	}

	public float similarity() {
		return similarity;
	}

	public void similarity(float similarity) {
		this.similarity = similarity;
	}

	public String term() {
		return term;
	}

	public void term(String term) {
		this.term = term;
	}

	public String suggestType() {
		return suggestType;
	}

	public void suggestType(String suggestType) {
		this.suggestType = suggestType;
	}

	// public String[] types() {
	// return types;
	// }

	// public String queryAnalyzer() {
	// return queryAnalyzer;
	// }
	//
	// public void queryAnalyzer(String queryAnalyzer) {
	// this.queryAnalyzer = queryAnalyzer;
	// }
	//
	// public String indexAnalyzer() {
	// return indexAnalyzer;
	// }
	//
	// public void indexAnalyzer(String indexAnalyzer) {
	// this.indexAnalyzer = indexAnalyzer;
	// }
	//
	// public boolean preservePositionIncrements() {
	// return preservePositionIncrements;
	// }
	//
	// public void preservePositionIncrements(boolean
	// preservePositionIncrements) {
	// this.preservePositionIncrements = preservePositionIncrements;
	// }

	@Override
	public void readFrom(StreamInput in) throws IOException {
		super.readFrom(in);
		size = in.readInt();
		similarity = in.readFloat();
		field = in.readString();
		term = in.readString();
		suggestType = in.readString();
		// types = in.readStringArray();
		// preservePositionIncrements = in.readBoolean();
		// queryAnalyzer = in.readOptionalString();
		// indexAnalyzer = in.readOptionalString();
	}

	@Override
	public void writeTo(StreamOutput out) throws IOException {
		super.writeTo(out);
		out.writeInt(size);
		out.writeFloat(similarity);
		out.writeString(field);
		out.writeString(term);
		out.writeString(suggestType);
		// out.writeStringArrayNullable(types);
		// out.writeBoolean(preservePositionIncrements);
		// out.writeOptionalString(queryAnalyzer);
		// out.writeOptionalString(indexAnalyzer);
	}
}
