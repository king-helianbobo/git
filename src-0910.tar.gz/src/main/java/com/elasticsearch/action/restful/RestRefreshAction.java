package com.elasticsearch.action.restful;

import static org.elasticsearch.rest.RestRequest.Method.POST;
import static org.elasticsearch.rest.action.support.RestActions.buildBroadcastShardsHeader;

import java.io.IOException;
import java.util.Map;

import org.elasticsearch.client.Client;
import org.elasticsearch.common.Strings;
import org.elasticsearch.common.inject.Inject;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.xcontent.XContentBuilder;
import org.elasticsearch.common.xcontent.XContentFactory;
import org.elasticsearch.common.xcontent.XContentParser;
import org.elasticsearch.common.xcontent.support.XContentMapValues;
import org.elasticsearch.rest.BaseRestHandler;
import org.elasticsearch.rest.BytesRestResponse;
import org.elasticsearch.rest.RestChannel;
import org.elasticsearch.rest.RestController;
import org.elasticsearch.rest.RestRequest;
import org.elasticsearch.rest.RestResponse;
import org.elasticsearch.rest.RestStatus;
import org.elasticsearch.rest.action.support.RestBuilderListener;

import com.elasticsearch.action.refresh.RefreshRequest;
import com.elasticsearch.action.refresh.RefreshResponse;
import com.elasticsearch.action.refresh.SuggestRefreshAction;

public class RestRefreshAction extends BaseRestHandler {

	@Inject
	public RestRefreshAction(Settings settings, Client client,
			RestController controller) {
		super(settings, client);
		controller.registerHandler(POST, "/__suggestRefresh", this);
		controller.registerHandler(POST, "/{index}/__suggestRefresh", this);
	}

	@Override
	protected void handleRequest(RestRequest request, RestChannel channel,
			Client client) throws Exception {
		final String[] indices = Strings.splitStringByCommaToArray(request
				.param("index"));

		try {
			RefreshRequest refreshRequest = new RefreshRequest(indices);
			if (request.hasContent()) {
				XContentParser parser = XContentFactory.xContent(
						request.content()).createParser(request.content());
				Map<String, Object> parserMap = parser.mapAndClose();
				if (parserMap.containsKey("field")) {
					refreshRequest.field(XContentMapValues.nodeStringValue(
							parserMap.get("field"), "contenttitle"));
				}
				if (parserMap.containsKey("action")) {
					refreshRequest.action(XContentMapValues.nodeStringValue(
							parserMap.get("action"), "refresh"));
				}
				if (parserMap.containsKey("type")) {
					refreshRequest.setType(XContentMapValues.nodeStringValue(
							parserMap.get("type"), "suggest"));
				}
			}

			client.execute(SuggestRefreshAction.INSTANCE, refreshRequest,
					new RestBuilderListener<RefreshResponse>(channel) {
						@Override
						public RestResponse buildResponse(
								RefreshResponse response,
								XContentBuilder builder) throws Exception {
							builder.startObject();
							buildBroadcastShardsHeader(builder, response);
							if (response.resultMap() != null) {
								for (Map.Entry<String, Integer> t : response
										.resultMap().entrySet())
									builder.field(t.getKey(), t.getValue());
								builder.field("OK", true);
								builder.field("acknowledged", true);
							} else {
								builder.field("OK", false);
								builder.field("acknowledged", false);
							}
							builder.endObject();
							return new BytesRestResponse(RestStatus.OK, builder);
						}
					});
		} catch (IOException e) {
			channel.sendResponse(new BytesRestResponse(RestStatus.BAD_REQUEST,
					"Could not extract field"));

		}
	}
}
