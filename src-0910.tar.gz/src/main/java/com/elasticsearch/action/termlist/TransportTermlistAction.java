package com.elasticsearch.action.termlist;

import static org.elasticsearch.common.collect.Lists.newLinkedList;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReferenceArray;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.elasticsearch.ElasticsearchException;
import org.elasticsearch.action.ShardOperationFailedException;
import org.elasticsearch.action.support.DefaultShardOperationFailedException;
import org.elasticsearch.action.support.broadcast.BroadcastShardOperationFailedException;
import org.elasticsearch.action.support.broadcast.TransportBroadcastOperationAction;
import org.elasticsearch.cluster.ClusterService;
import org.elasticsearch.cluster.ClusterState;
import org.elasticsearch.cluster.block.ClusterBlockException;
import org.elasticsearch.cluster.block.ClusterBlockLevel;
import org.elasticsearch.cluster.routing.GroupShardsIterator;
import org.elasticsearch.cluster.routing.ShardRouting;
import org.elasticsearch.common.inject.Inject;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.index.service.IndexService;
import org.elasticsearch.indices.IndicesService;
import org.elasticsearch.threadpool.ThreadPool;
import org.elasticsearch.transport.TransportService;

import com.elasticsearch.action.service.ShardSuggestService;

/**
 * Term list index/indices action
 */
public class TransportTermlistAction
		extends
		TransportBroadcastOperationAction<TermlistRequest, TermlistResponse, ShardTermlistRequest, ShardTermlistResponse> {
	private static Log log = LogFactory.getLog(TransportTermlistAction.class);
	private final IndicesService indicesService;

	@Inject
	public TransportTermlistAction(Settings settings, ThreadPool threadPool,
			ClusterService clusterService, TransportService transportService,
			IndicesService indicesService) {
		super(settings, TermlistAction.NAME, threadPool, clusterService,
				transportService);
		this.indicesService = indicesService;
	}

	@Override
	protected String executor() {
		return ThreadPool.Names.GENERIC;
	}

	@Override
	protected TermlistRequest newRequest() {
		return new TermlistRequest();
	}

	@Override
	protected TermlistResponse newResponse(TermlistRequest request,
			AtomicReferenceArray shardsResponses, ClusterState clusterState) {
		int successfulShards = 0;
		int failedShards = 0;
		List<ShardOperationFailedException> shardFailures = null;
		Map<String, TermInfoPojo> map = new HashMap<String, TermInfoPojo>();
		for (int i = 0; i < shardsResponses.length(); i++) {
			Object shardResponse = shardsResponses.get(i);
			if (shardResponse instanceof BroadcastShardOperationFailedException) {
				failedShards++;
				if (shardFailures == null) {
					shardFailures = newLinkedList();
				}
				shardFailures
						.add(new DefaultShardOperationFailedException(
								(BroadcastShardOperationFailedException) shardResponse));
			} else {
				successfulShards++;
				if (shardResponse instanceof ShardTermlistResponse) {
					ShardTermlistResponse response = (ShardTermlistResponse) shardResponse;
					Map<String, TermInfoPojo> shardMap = response.getTermMap();
					if (shardMap != null)
						merge(map, shardMap);
				}
			}
		}
		map = truncate(map, request.getSize());
		return new TermlistResponse(shardsResponses.length(), successfulShards,
				failedShards, shardFailures, map);
	}

	@Override
	protected ShardTermlistRequest newShardRequest() {
		return new ShardTermlistRequest();
	}

	@Override
	protected ShardTermlistRequest newShardRequest(int numShards,
			ShardRouting shard, TermlistRequest request) {
		return new ShardTermlistRequest(shard.index(), shard.id(), request);
	}

	@Override
	protected ShardTermlistResponse newShardResponse() {
		return new ShardTermlistResponse();
	}

	/**
	 * The termlist request works against primary shards.
	 */
	@Override
	protected GroupShardsIterator shards(ClusterState clusterState,
			TermlistRequest request, String[] concreteIndices) {
		return clusterState.routingTable().activePrimaryShardsGrouped(
				concreteIndices, true);
	}

	@Override
	protected ClusterBlockException checkGlobalBlock(ClusterState state,
			TermlistRequest request) {
		return state.blocks()
				.globalBlockedException(ClusterBlockLevel.METADATA);
	}

	@Override
	protected ClusterBlockException checkRequestBlock(ClusterState state,
			TermlistRequest request, String[] concreteIndices) {
		return state.blocks().indicesBlockedException(
				ClusterBlockLevel.METADATA, concreteIndices);
	}

	@Override
	protected ShardTermlistResponse shardOperation(ShardTermlistRequest request)
			throws ElasticsearchException {
		logger.trace("Entered TransportTermListAction.shardOperation()");
		IndexService indexService = indicesService.indexServiceSafe(request
				.index());
		ShardSuggestService suggestShardService = indexService
				.shardInjectorSafe(request.shardId()).getInstance(
						ShardSuggestService.class);
		return suggestShardService.termList(request);

	}

	private void merge(Map<String, TermInfoPojo> map,
			Map<String, TermInfoPojo> shardMap) {
		for (Map.Entry<String, TermInfoPojo> entry : shardMap.entrySet()) {
			if (map.containsKey(entry.getKey())) {
				String key = entry.getKey();
				TermInfoPojo info = map.get(key);
				Integer docFreq = info.getDocFreq();
				if (docFreq != null) {
					if (entry.getValue().getDocFreq() != null) {
						info.docFreq(docFreq + entry.getValue().getDocFreq());
					}
				} else {
					if (entry.getValue().getDocFreq() != null) {
						info.docFreq(entry.getValue().getDocFreq());
					}
				}
				Integer totalFreq = info.getTotalFreq();
				if (totalFreq != null) {
					if (entry.getValue().getTotalFreq() != null) {
						info.totalFreq(totalFreq
								+ entry.getValue().getTotalFreq());
					}
				} else {
					if (entry.getValue().getTotalFreq() != null) {
						info.totalFreq(entry.getValue().getTotalFreq());
					}
				}
			} else {
				map.put(entry.getKey(), entry.getValue());
			}
		}
	}

	private Map<String, TermInfoPojo> truncate(
			Map<String, TermInfoPojo> source, Integer max) {
		if (max == null || max < 1) {
			return source;
		}
		int count = 0;
		Map<String, TermInfoPojo> target = new HashMap<String, TermInfoPojo>();
		for (Map.Entry<String, TermInfoPojo> entry : source.entrySet()) {
			if (count >= max) {
				break;
			}
			target.put(entry.getKey(), entry.getValue());
			count++;
		}
		return target;
	}

}