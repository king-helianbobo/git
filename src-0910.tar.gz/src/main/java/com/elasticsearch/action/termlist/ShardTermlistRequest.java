package com.elasticsearch.action.termlist;

import java.io.IOException;
import java.util.List;

import org.elasticsearch.action.support.broadcast.BroadcastShardOperationRequest;
import org.elasticsearch.common.io.stream.StreamInput;
import org.elasticsearch.common.io.stream.StreamOutput;

public class ShardTermlistRequest extends BroadcastShardOperationRequest {

	private String term = null;
	private String action = null; // "termlist" or "keywords"
	private Integer size = 0; // if less than or equal to 0, return all item
	private String[] fields = { "content" };

	ShardTermlistRequest() {
	}

	public ShardTermlistRequest(String index, int shardId,
			TermlistRequest request) {
		super(index, shardId, request);
		this.term = request.term();
		this.action = request.action();
		this.size = request.getSize();
		this.fields = request.fields();
	}

	public void term(String term) {
		this.term = term;
	}

	public String term() {
		return term;
	}

	public void setSize(Integer size) {
		this.size = size;
	}

	public Integer getSize() {
		return size;
	}

	public String action() {
		return action;
	}

	public void action(String action) {
		this.action = action;
	}

	public String[] fields() {
		return this.fields;
	}

	public void fields(List<String> fields) {
		this.fields = new String[fields.size()];
		for (int i = 0; i < fields.size(); i++)
			this.fields[i] = fields.get(i);
	}

	@Override
	public void readFrom(StreamInput in) throws IOException {
		super.readFrom(in);
		term = in.readString();
		action = in.readString();
		size = in.readInt();
		int number = in.readInt();
		fields = new String[number];
		for (int i = 0; i < number; i++) {
			fields[i] = in.readString();
		}
	}

	@Override
	public void writeTo(StreamOutput out) throws IOException {
		super.writeTo(out);
		out.writeString(term);
		out.writeString(action);
		out.writeInt(size);
		out.writeInt(fields.length);
		for (int i = 0; i < fields.length; i++) {
			out.writeString(fields[i]);
		}
	}
}