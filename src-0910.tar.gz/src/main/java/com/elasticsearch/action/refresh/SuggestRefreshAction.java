package com.elasticsearch.action.refresh;

import org.elasticsearch.action.ClientAction;
import org.elasticsearch.client.Client;

import com.elasticsearch.action.restful.RefreshRequestBuilder;

public class SuggestRefreshAction extends
		ClientAction<RefreshRequest, RefreshResponse, RefreshRequestBuilder> {

	public static final SuggestRefreshAction INSTANCE = new SuggestRefreshAction();
	public static final String NAME = "refreshAction";

	private SuggestRefreshAction() {
		super(NAME);
	}

	@Override
	public RefreshRequestBuilder newRequestBuilder(Client client) {
		return new RefreshRequestBuilder(client);
	}

	@Override
	public RefreshResponse newResponse() {
		return new RefreshResponse();
	}

}
