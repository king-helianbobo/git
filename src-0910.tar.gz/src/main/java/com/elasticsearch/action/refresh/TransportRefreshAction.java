package com.elasticsearch.action.refresh;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReferenceArray;

import org.elasticsearch.ElasticsearchException;
import org.elasticsearch.action.ShardOperationFailedException;
import org.elasticsearch.action.support.DefaultShardOperationFailedException;
import org.elasticsearch.action.support.broadcast.BroadcastShardOperationFailedException;
import org.elasticsearch.action.support.broadcast.TransportBroadcastOperationAction;
import org.elasticsearch.cluster.ClusterService;
import org.elasticsearch.cluster.ClusterState;
import org.elasticsearch.cluster.block.ClusterBlockException;
import org.elasticsearch.cluster.block.ClusterBlockLevel;
import org.elasticsearch.cluster.routing.GroupShardsIterator;
import org.elasticsearch.cluster.routing.ShardRouting;
import org.elasticsearch.common.inject.Inject;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.index.service.IndexService;
import org.elasticsearch.indices.IndicesService;
import org.elasticsearch.threadpool.ThreadPool;
import org.elasticsearch.transport.TransportService;

import com.elasticsearch.action.service.ShardSuggestService;

public class TransportRefreshAction
		extends
		TransportBroadcastOperationAction<RefreshRequest, RefreshResponse, ShardRefreshRequest, ShardRefreshResponse> {

	private final IndicesService indicesService;

	@Inject
	public TransportRefreshAction(Settings settings, ThreadPool threadPool,
			ClusterService clusterService, TransportService transportService,
			IndicesService indicesService) {
		super(settings, SuggestRefreshAction.NAME, threadPool, clusterService,
				transportService);
		this.indicesService = indicesService;
	}

	@Override
	protected String executor() {
		return ThreadPool.Names.INDEX;
	}

	@Override
	protected RefreshRequest newRequest() {
		return new RefreshRequest();
	}

	@Override
	protected RefreshResponse newResponse(RefreshRequest request,
			AtomicReferenceArray shardsResponses, ClusterState clusterState) {
		int successfulShards = 0;
		int failedShards = 0;
		List<ShardOperationFailedException> shardFailures = new LinkedList<ShardOperationFailedException>();
		Map<String, Integer> resultMap = new HashMap<String, Integer>();
		for (int i = 0; i < shardsResponses.length(); i++) {
			Object shardResponse = shardsResponses.get(i);
			if (shardResponse == null) {
				failedShards++;
			} else if (shardResponse instanceof BroadcastShardOperationFailedException) {
				failedShards++;
				shardFailures
						.add(new DefaultShardOperationFailedException(
								(BroadcastShardOperationFailedException) shardResponse));
			} else {
				successfulShards++;
				if (shardResponse instanceof ShardRefreshResponse) {
					ShardRefreshResponse response = (ShardRefreshResponse) shardResponse;
					Map<String, Integer> shardMap = response.getShardMap();
					if (shardMap != null)
						merge(resultMap, shardMap);
				}
			}
		}

		return new RefreshResponse(shardsResponses.length(), successfulShards,
				failedShards, shardFailures, resultMap);
	}

	@Override
	protected ShardRefreshRequest newShardRequest() {
		return new ShardRefreshRequest();
	}

	@Override
	protected ShardRefreshRequest newShardRequest(int numShards,
			ShardRouting shard, RefreshRequest request) {
		return new ShardRefreshRequest(shard.index(), shard.id(), request);
	}

	@Override
	protected ShardRefreshResponse newShardResponse() {
		return new ShardRefreshResponse();
	}

	@Override
	protected ShardRefreshResponse shardOperation(ShardRefreshRequest request)
			throws ElasticsearchException {
		logger.trace("Entered TransportSuggestRefreshAction.shardOperation()");
		IndexService indexService = indicesService.indexServiceSafe(request
				.index());
		ShardSuggestService suggestShardService = indexService
				.shardInjectorSafe(request.shardId()).getInstance(
						ShardSuggestService.class);
		return suggestShardService.refresh(request);
	}

	@Override
	protected GroupShardsIterator shards(ClusterState clusterState,
			RefreshRequest request, String[] concreteIndices) {
		return clusterService.operationRouting().searchShards(clusterState,
				request.indices(), concreteIndices, null, null);
	}

	@Override
	protected ClusterBlockException checkGlobalBlock(ClusterState state,
			RefreshRequest request) {
		return state.blocks()
				.globalBlockedException(ClusterBlockLevel.METADATA);
	}

	@Override
	protected ClusterBlockException checkRequestBlock(ClusterState state,
			RefreshRequest request, String[] concreteIndices) {
		return state.blocks().indicesBlockedException(
				ClusterBlockLevel.METADATA, concreteIndices);
	}

	private void merge(Map<String, Integer> map, Map<String, Integer> shardMap) {
		for (Map.Entry<String, Integer> entry : shardMap.entrySet()) {
			String key = entry.getKey();
			Integer number = map.get(key);
			if (number == null)
				map.put(entry.getKey(), entry.getValue());
			else {
				number += entry.getValue();
				map.put(key, number);
			}
		}
	}

}
