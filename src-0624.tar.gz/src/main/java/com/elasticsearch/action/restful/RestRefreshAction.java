package com.elasticsearch.action.restful;

import static org.elasticsearch.rest.RestRequest.Method.POST;
import static org.elasticsearch.rest.RestStatus.OK;
import static org.elasticsearch.rest.action.support.RestActions.buildBroadcastShardsHeader;

import java.io.IOException;
import java.util.Map;

import org.elasticsearch.action.ActionListener;
import org.elasticsearch.client.Client;
import org.elasticsearch.common.Strings;
import org.elasticsearch.common.inject.Inject;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.xcontent.XContentBuilder;
import org.elasticsearch.common.xcontent.XContentFactory;
import org.elasticsearch.common.xcontent.XContentParser;
import org.elasticsearch.common.xcontent.support.XContentMapValues;
import org.elasticsearch.rest.BaseRestHandler;
import org.elasticsearch.rest.RestChannel;
import org.elasticsearch.rest.RestController;
import org.elasticsearch.rest.RestRequest;
import org.elasticsearch.rest.XContentRestResponse;
import org.elasticsearch.rest.XContentThrowableRestResponse;
import org.elasticsearch.rest.action.support.RestXContentBuilder;

import com.elasticsearch.action.refresh.SuggestRefreshAction;
import com.elasticsearch.action.refresh.RefreshRequest;
import com.elasticsearch.action.refresh.RefreshResponse;

public class RestRefreshAction extends BaseRestHandler {

	@Inject
	public RestRefreshAction(Settings settings, Client client,
			RestController controller) {
		super(settings, client);
		controller.registerHandler(POST, "/__suggestRefresh", this);
		controller.registerHandler(POST, "/{index}/__suggestRefresh", this);
		// controller.registerHandler(POST, "/{index}/{type}/__suggestRefresh",
		// this);
	}

	@Override
	public void handleRequest(final RestRequest request,
			final RestChannel channel) {
		final String[] indices = Strings.splitStringByCommaToArray(request
				.param("index"));

		try {

			RefreshRequest refreshRequest = new RefreshRequest(indices);

			if (request.hasContent()) {
				XContentParser parser = XContentFactory.xContent(
						request.content()).createParser(request.content());
				Map<String, Object> parserMap = parser.mapAndClose();

				if (parserMap.containsKey("field")) {
					refreshRequest.field(XContentMapValues.nodeStringValue(
							parserMap.get("field"), "contenttitle"));
				}
				if (parserMap.containsKey("action")) {
					refreshRequest.action(XContentMapValues.nodeStringValue(
							parserMap.get("action"), "refresh"));
				}
				if (parserMap.containsKey("type")) {
					refreshRequest.setType(XContentMapValues.nodeStringValue(
							parserMap.get("type"), "suggest"));
				}
			}

			client.execute(SuggestRefreshAction.INSTANCE, refreshRequest,
					new ActionListener<RefreshResponse>() {
						@Override
						public void onResponse(RefreshResponse response) {
							try {
								XContentBuilder builder = RestXContentBuilder
										.restContentBuilder(request);
								builder.startObject();
								buildBroadcastShardsHeader(builder, response);
								if (response.resultMap() != null) {
									for (Map.Entry<String, Integer> t : response
											.resultMap().entrySet())
										builder.field(t.getKey(), t.getValue());
									builder.field("OK", true);
									builder.field("acknowledged", true);
								} else {
									builder.field("OK", false);
									builder.field("acknowledged", false);
								}
								builder.endObject();
								channel.sendResponse(new XContentRestResponse(
										request, OK, builder));
							} catch (Exception e) {
								onFailure(e);
							}
						}

						@Override
						public void onFailure(Throwable e) {
							try {
								channel.sendResponse(new XContentThrowableRestResponse(
										request, e));
							} catch (IOException e1) {
								logger.error("Failed to send failure response",
										e1);
							}
						}
					});

		} catch (IOException e) {
			try {
				channel.sendResponse(new XContentThrowableRestResponse(request,
						e));
			} catch (IOException e1) {
				logger.error("Failed to send failure response", e1);
			}
		}
	}

}
