package com.elasticsearch.action.refresh;

import java.io.IOException;

import org.elasticsearch.action.support.broadcast.BroadcastShardOperationRequest;
import org.elasticsearch.common.io.stream.StreamInput;
import org.elasticsearch.common.io.stream.StreamOutput;

public class ShardRefreshRequest extends BroadcastShardOperationRequest {

	private String field;
	private String action;
	private String type;

	public ShardRefreshRequest() {
	}

	public ShardRefreshRequest(String index, int shardId,
			RefreshRequest request) {
		super(index, shardId, request);
		field = request.field();
		action = request.action();
		type = request.getType();
	}

	@Override
	public void readFrom(StreamInput in) throws IOException {
		super.readFrom(in);
		field = in.readString();
		action = in.readString();
		type = in.readString();
	}

	@Override
	public void writeTo(StreamOutput out) throws IOException {
		super.writeTo(out);
		out.writeString(field);
		out.writeString(action);
		out.writeString(type);
	}

	@Override
	public String toString() {
		return index() + " " + shardId() + " " + field;
	}

	public String field() {
		return field;
	}

	public void field(String field) {
		this.field = field;
	}

	public String action() {
		return action;
	}

	public void action(String action) {
		this.action = action;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}
