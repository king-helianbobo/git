package com.elasticsearch.action.refresh;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.elasticsearch.action.ShardOperationFailedException;
import org.elasticsearch.action.support.broadcast.BroadcastOperationResponse;
import org.elasticsearch.common.io.stream.StreamInput;
import org.elasticsearch.common.io.stream.StreamOutput;

public class RefreshResponse extends BroadcastOperationResponse {

	private Map<String, Integer> map;

	public RefreshResponse() {
	}

	public Map<String, Integer> resultMap() {
		return this.map;
	}

	public RefreshResponse(int totalShards, int successfulShards,
			int failedShards,
			List<ShardOperationFailedException> shardFailures,
			Map<String, Integer> map) {
		super(totalShards, successfulShards, failedShards, shardFailures);
		this.map = map;
	}

	@Override
	public void readFrom(StreamInput in) throws IOException {
		super.readFrom(in);
		int n = in.readInt();
		if (n > 0) {
			map = new HashMap<String, Integer>();
			for (int i = 0; i < n; i++) {
				String text = in.readString();
				int num = in.readInt();
				map.put(text, num);
			}
		} else
			map = null;
	}

	@Override
	public void writeTo(StreamOutput out) throws IOException {
		super.writeTo(out);
		if (map != null && map.size() > 0) {
			out.writeInt(map.size());
			for (Map.Entry<String, Integer> t : map.entrySet()) {
				out.writeString(t.getKey());
				out.writeInt(t.getValue());
			}
		} else
			out.writeInt(0);
	}
}
