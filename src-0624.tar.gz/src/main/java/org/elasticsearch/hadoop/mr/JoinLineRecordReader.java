package org.elasticsearch.hadoop.mr;

import java.io.IOException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.RecordReader;
import org.apache.hadoop.mapreduce.TaskAttemptContext;

public class JoinLineRecordReader extends RecordReader<LongWritable, Text> {
	private static final Log log = LogFactory
			.getLog(JoinLineRecordReader.class);

	private LongWritable key = null;
	private Text value = null;
	JoinFileInputSplit split = null;
	private int totalLines;
	private int currentLine = 0;

	public void initialize(InputSplit genericSplit, TaskAttemptContext context)
			throws IOException {
		split = (JoinFileInputSplit) genericSplit;
		this.totalLines = split.getTotalLines();
		this.currentLine = 0;

	}

	public boolean nextKeyValue() throws IOException {
		if (this.currentLine < this.totalLines) {
			key = new LongWritable();
			key.set(currentLine);
			value = new Text();
			value.set(" ");
			currentLine++;
			return true;
		} else {
			key = null;
			value = null;
			return false;
		}
	}

	@Override
	public LongWritable getCurrentKey() {
		return key;
	}

	@Override
	public Text getCurrentValue() {
		return value;
	}
	public float getProgress() throws IOException {
		return Math.min(1.0f, (float) currentLine / (float) (totalLines));
	}

	@Override
	public void close() throws IOException {

	}

}
