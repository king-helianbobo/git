package org.elasticsearch.application.query;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.splitword.soul.utility.SoulArrays;
import org.testng.Assert;

public class ThreeTermQuery extends SoulQuery {

	private static final Log log = LogFactory.getLog(ThreeTermQuery.class);
	final int leastNumber = 4;
	List<String> keywords1 = null;
	List<String> keywords2 = null;
	List<String> keywords3 = null;
	Map<Integer, QueryPojo> nounWords = new HashMap<Integer, QueryPojo>();
	Map<Integer, List<String>> resultMap = new HashMap<Integer, List<String>>();

	public ThreeTermQuery(String index, String type, PostQuery postQuery) {
		super(index, type, postQuery);
	}

	private void fillThreeList(String queryStr) {
		fillBaseMap(queryStr);
		nounWords.clear();
		resultMap.clear();
		int number = fillNounWordMap(nounWords, resultMap);
		Assert.assertEquals(number, 3);
		keywords1 = resultMap.get(0);
		keywords2 = resultMap.get(1);
		keywords3 = resultMap.get(2);
		if (keywords1.size() > leastNumber)
			keywords1 = keywords1.subList(0, leastNumber);
		if (keywords2.size() > leastNumber)
			keywords2 = keywords2.subList(0, leastNumber);
		if (keywords3.size() > leastNumber)
			keywords3 = keywords3.subList(0, leastNumber);
		log.info(keywords1 + "/" + keywords2 + "/" + keywords3);
	}

	public Map<String, Object> pageQuery(String queryStr, String tag) {
		fillThreeList(queryStr);

		Map<String, Object> titleMap1 = SoulQueryUtil.createBooleanQueryMap(
				combineQueryTitle(keywords1, keywords2, keywords3), 1, "all",
				400.0f);

		Map<String, Object> titleMap2 = SoulQueryUtil.createBooleanQueryMap(
				combineQueryTitle(keywords1, keywords2), 1, "all", 3.0f);
		Map<String, Object> titleMap3 = SoulQueryUtil.createBooleanQueryMap(
				combineQueryTitle(keywords2, keywords3), 1, "all", 3.0f);
		Map<String, Object> titleMap4 = SoulQueryUtil.createBooleanQueryMap(
				combineQueryTitle(keywords1, keywords3), 1, "all", 3.0f);

		Map<String, Object> contentMap1 = SoulQueryUtil.createBooleanQueryMap(
				combineQueryContent(keywords1, keywords2, keywords3), 1, "all",
				300.0f);
		Map<String, Object> contentMap2 = SoulQueryUtil.createBooleanQueryMap(
				combineQueryContent(keywords2, keywords3), 1, "all", 300.0f);
		Map<String, Object> contentMap3 = SoulQueryUtil.createBooleanQueryMap(
				combineQueryContent(keywords1, keywords3), 1, "all", 300.0f);
		Map<String, Object> contentMap4 = SoulQueryUtil.createBooleanQueryMap(
				combineQueryContent(keywords1, keywords2), 1, "all", 300.0f);
		List<Object> finalArray = new ArrayList<Object>();
		finalArray.add(titleMap1);
		finalArray.add(titleMap2);
		finalArray.add(titleMap3);
		finalArray.add(titleMap4);
		finalArray.add(contentMap1);
		finalArray.add(contentMap2);
		finalArray.add(contentMap3);
		finalArray.add(contentMap4);

		QueryPojo pojo = getSinglePojo();
		if (pojo != null) {
			List<Object> array = termQueryListForTitle(resultMap.get(pojo
					.seqNumber()));
			Map<String, Object> singleMap = SoulQueryUtil
					.createBooleanQueryMap(array, 1, "all", 2.0f);
			finalArray.add(singleMap);

		}
		Map<String, Object> finalMap = SoulQueryUtil.createBooleanQueryMap(
				finalArray, 1, tag);
		return finalMap;
	}

	private List<List<String>> compareThreeList() {
		int total1 = 0;
		int total2 = 0;
		int total3 = 0;
		for (int i = 0; i < keywords1.size(); i++)
			total1 += termTotalFreq(keywords1.get(i));
		for (int i = 0; i < keywords2.size(); i++)
			total2 += termTotalFreq(keywords2.get(i));
		for (int i = 0; i < keywords3.size(); i++)
			total3 += termTotalFreq(keywords3.get(i));
		List<List<String>> result = new LinkedList<List<String>>();
		Map<Integer, Integer> map1 = new HashMap<Integer, Integer>();
		map1.put(1, total1);
		map1.put(2, total2);
		map1.put(3, total3);
		Map<Integer, List<String>> map2 = new HashMap<Integer, List<String>>();
		map2.put(1, keywords1);
		map2.put(2, keywords2);
		map2.put(3, keywords3);
		List<Map.Entry<Integer, Integer>> list1 = SoulArrays.sortMapByValue(
				map1, -1);
		for (Map.Entry<Integer, Integer> entry : list1) {
			int key = entry.getKey();
			result.add(map2.get(key));
		}
		log.info(result.get(0));
		log.info(result.get(1));
		log.info(result.get(2));
		return result;
	}

	public Map<String, Object> officialQuery(String queryStr, String tag) {
		fillThreeList(queryStr);
		List<Object> titleArray = combineQueryTitle(keywords1, keywords2,
				keywords3);
		Map<String, Object> titleMap = SoulQueryUtil.createBooleanQueryMap(
				titleArray, 1, "all", 4.0f);
		List<List<String>> result = compareThreeList();
		Assert.assertEquals(result.size(), 3);
		List<Object> titleArray2 = combineQueryTitle(result.get(0),
				result.get(1));
		Map<String, Object> titleMap2 = SoulQueryUtil.createBooleanQueryMap(
				titleArray2, 1, "all", 3.0f);
		List<Object> finalArray = new ArrayList<Object>();
		finalArray.add(titleMap);
		finalArray.add(titleMap2);
		QueryPojo pojo = getSinglePojo();
		if (pojo != null) {
			List<Object> array = termQueryListForTitle(resultMap.get(pojo
					.seqNumber()));
			Map<String, Object> singleMap = SoulQueryUtil
					.createBooleanQueryMap(array, 1, "all", 2.0f);
			finalArray.add(singleMap);

		}
		Map<String, Object> finalMap = SoulQueryUtil.createBooleanQueryMap(
				finalArray, 1, tag);
		return finalMap;
	}

	protected QueryPojo compareTwoTerms(List<QueryPojo> twoTerms) {
		int docfreq = 10000000;
		int pos = -1;
		for (int i = 0; i < twoTerms.size(); i++) {
			QueryPojo pojo = twoTerms.get(i);
			int tmpFreq = termTotalFreq(pojo.getName());
			if (tmpFreq < docfreq) {
				docfreq = tmpFreq;
				pos = i;
			}
		}
		return twoTerms.get(pos);
	}

	protected QueryPojo getSinglePojo() {
		if (nounWords.size() >= 2) {
			List<QueryPojo> pojoList = new LinkedList<QueryPojo>();
			for (Integer pos : nounWords.keySet()) {
				QueryPojo pojo = nounWords.get(pos);
				pojoList.add(pojo);
			}
			QueryPojo pojo = compareTwoTerms(pojoList);
			return pojo;
		} else if (nounWords.size() == 0) {
			List<QueryPojo> termList = new LinkedList<QueryPojo>();
			List<QueryPojo> vnTermList = new LinkedList<QueryPojo>();
			for (Integer pos : terms.keySet()) {
				QueryPojo pojo = terms.get(pos);
				String nature = pojo.getNature();
				if (nature.equals("vn"))
					vnTermList.add(pojo);
				else
					termList.add(pojo);
			}
			QueryPojo pojo = null;
			if (vnTermList.size() == 1)
				pojo = vnTermList.get(0);
			else if (vnTermList.size() == 0)
				pojo = compareTwoTerms(termList);
			else {
				pojo = compareTwoTerms(vnTermList);
			}
			log.info("expected String is \"" + pojo.getName() + "\"");
			return pojo;
		} else if (nounWords.size() == 1) {
			Set<Integer> set = nounWords.keySet();
			Iterator<Integer> iter = set.iterator();
			if (iter.hasNext()) {
				int pos = iter.next();
				return nounWords.get(pos);
			}
		}
		return null;
	}
}
