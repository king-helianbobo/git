package org.elasticsearch.application.query;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.elasticsearch.plugin.analyzer.BasicTokenizer;
import org.splitword.soul.keyword.KeyWordComputer;
import org.testng.Assert;

public class SoulQuery {
	protected PostQuery postQuery = null;
	protected String index = null;
	protected String type = null;
	protected final String titleField = "contenttitle";
	protected final String contentField = "content";
	protected final float singleTermTitleThreshold = 5000.0f;
	protected final float synonymExtensionThreshold = 800.0f;
	private static final Log log = LogFactory.getLog(SoulQuery.class);
	protected static Map<Integer, List<Map<String, Object>>> synonyms = new HashMap<Integer, List<Map<String, Object>>>();
	protected static Map<Integer, List<Map<String, Object>>> vectors = new HashMap<Integer, List<Map<String, Object>>>();
	protected static Map<Integer, QueryPojo> terms = new HashMap<Integer, QueryPojo>();
	protected static Map<Integer, List<Map<String, Object>>> posMaps = new HashMap<Integer, List<Map<String, Object>>>();

	/***************************** data member ****************************************/
	public SoulQuery(String index, String type, PostQuery postQuery) {
		this.index = index;
		this.type = type;
		this.postQuery = postQuery;
	}

	protected void fillBaseMap(String queryStr) {
		posMaps.clear();
		terms.clear();
		vectors.clear();
		synonyms.clear();
		String query = index + "/_analyze?analyzer=soul_query_nature&pretty";
		Map<String, Object> map = postQuery.post(query, queryStr);
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> tokenMaps = (List<Map<String, Object>>) map
				.get("tokens");
		for (int i = 0; i < tokenMaps.size(); i++) {
			Map<String, Object> tmp = tokenMaps.get(i);
			String type = (String) tmp.get("type");
			String token = (String) tmp.get("token");
			int position = (Integer) tmp.get("position");
			if (type.equals("null") || type.equals("w"))
				continue;
			List<Map<String, Object>> mapList = posMaps.get(position);
			if (mapList == null)
				mapList = new LinkedList<Map<String, Object>>();
			mapList.add(tmp);
			posMaps.put(position, mapList);
			if (type.equals(BasicTokenizer.TYPE_SYNONYM)) {
				List<Map<String, Object>> synonym1 = synonyms.get(position);
				if (synonym1 == null)
					synonym1 = new LinkedList<Map<String, Object>>();
				synonym1.add(tmp);
				synonyms.put(position, synonym1);
			} else if (type.equals(BasicTokenizer.TYPE_VECTOR)) {
				List<Map<String, Object>> vector1 = vectors.get(position);
				if (vector1 == null)
					vector1 = new LinkedList<Map<String, Object>>();
				vector1.add(tmp);
				vectors.put(position, vector1);
			} else {
				QueryPojo pojo = new QueryPojo(token, type, position);
				terms.put(position, pojo);
			}
		}
	}

	protected List<Object> combineQueryTitle(List<String> list1,
			List<String> list2, List<String> list3) {
		List<Object> array = new ArrayList<Object>();
		for (int i = 0; i < list1.size(); i++) {
			String str1 = list1.get(i);
			Map<String, Object> map1 = SoulQueryUtil.termQueryMap(titleField,
					str1);
			for (int j = 0; j < list2.size(); j++) {
				String str2 = list2.get(j);
				Map<String, Object> map2 = SoulQueryUtil.termQueryMap(
						titleField, str2);
				for (int k = 0; k < list3.size(); k++) {
					String str3 = list3.get(k);
					Map<String, Object> map3 = SoulQueryUtil.termQueryMap(
							titleField, str3);
					ArrayList<Object> titleArray = new ArrayList<Object>();
					titleArray.add(map1);
					titleArray.add(map2);
					titleArray.add(map3);
					Map<String, Object> titleMap = SoulQueryUtil
							.createBooleanQueryMap(titleArray,
									titleArray.size());
					array.add(titleMap);
				}
			}
		}
		return array;
	}

	protected List<Object> combineQueryTitle(List<String> list1,
			List<String> list2) {
		List<Object> array = new ArrayList<Object>();
		for (int i = 0; i < list1.size(); i++) {
			String str1 = list1.get(i);
			Map<String, Object> map1 = SoulQueryUtil.termQueryMap(titleField,
					str1);
			for (int j = 0; j < list2.size(); j++) {
				ArrayList<Object> titleArray = new ArrayList<Object>();
				String str2 = list2.get(j);
				Map<String, Object> map2 = SoulQueryUtil.termQueryMap(
						titleField, str2);
				titleArray.add(map1);
				titleArray.add(map2);
				Map<String, Object> titleMap = SoulQueryUtil
						.createBooleanQueryMap(titleArray, titleArray.size());
				array.add(titleMap);
			}
		}
		return array;
	}

	protected List<Object> combineQueryContent(List<String> list1,
			List<String> list2) {
		List<Object> array = new ArrayList<Object>();
		for (int i = 0; i < list1.size(); i++) {
			String str1 = list1.get(i);
			for (int j = 0; j < list2.size(); j++) {
				String str2 = list2.get(j);
				Map<String, Object> contentMap = SoulQueryUtil
						.spanNearQueryMap(12, contentField, str1, str2);
				array.add(contentMap);
			}
		}
		return array;
	}

	protected List<Object> combineQueryContent(List<String> list1,
			List<String> list2, List<String> list3) {
		List<Object> array = new ArrayList<Object>();
		for (int i = 0; i < list1.size(); i++) {
			String str1 = list1.get(i);
			for (int j = 0; j < list2.size(); j++) {
				String str2 = list2.get(j);
				for (int k = 0; k < list3.size(); k++) {
					String str3 = list3.get(k);
					Map<String, Object> contentMap = SoulQueryUtil
							.spanNearQueryMap(22, contentField, str1, str2,
									str3);
					array.add(contentMap);
				}

			}
		}
		return array;
	}

	public int termTotalFreq(String term) {
		Map<String, TermPojo> termPojoMap = KeyWordComputer.termPojoMap;
		TermPojo pojo = termPojoMap.get(term);
		if (pojo == null)
			return 0;
		else
			return pojo.totalFreq;
	}

	protected int fillNounWordMap(Map<Integer, QueryPojo> nounWords,
			Map<Integer, List<String>> resultMap) {
		Assert.assertTrue((terms.size() > 0));
		int i = 0;
		for (Integer pos : terms.keySet()) {
			QueryPojo pojo = terms.get(pos);
			pojo.seqNumber(i);
			String term = pojo.getName();
			String nature = pojo.getNature();
			if ((nature.startsWith("n") && !nature.equalsIgnoreCase("null"))
					|| nature.startsWith("j") || nature.startsWith("g")
					|| nature.equals("userwuxi") || nature.equals("rule"))
				nounWords.put(pos, pojo);
			List<Map<String, Object>> list1 = synonyms.get(pos);
			List<Map<String, Object>> list2 = vectors.get(pos);
			if (list1 != null && !list1.isEmpty()) {
				if (list2 != null && !list2.isEmpty())
					list1.addAll(list2);
			} else if (list2 != null && !list2.isEmpty()) {
				list1 = list2;
			}
			List<String> result = new LinkedList<String>();
			result.add(term);
			if (list1 != null && !list1.isEmpty())
				result.addAll(SoulQueryUtil.synonymList(list1, term, nature));
			resultMap.put(i++, result);
		}
		return resultMap.size();
	}

	/************************** base function **************************************************/

	public List<Object> singleQueryForTitleAndContent(
			List<Map<String, Object>> tokens, float ratio) {
		Assert.assertTrue(tokens.size() >= 1);
		Map<String, Object> tokenMap = tokens.get(0);
		String primeType = (String) tokenMap.get("type");
		String primeToken = (String) tokenMap.get("token");
		int documentFreq = termTotalFreq(primeToken);
		if ((documentFreq > 0)
				&& (documentFreq < singleTermTitleThreshold * ratio)) {
			List<String> firstWords = new LinkedList<String>();
			firstWords.add(primeToken);
			List<Map<String, Object>> subList = tokens
					.subList(1, tokens.size());
			List<String> result = SoulQueryUtil.synonymList(subList,
					primeToken, primeType);
			firstWords.addAll(result);
			return termQueryListForTitleAndContent(firstWords, ratio);
		} else {
			List<Object> array = new ArrayList<Object>();
			log.info(primeToken + " 's document frequency is " + documentFreq);
			Map<String, Object> map1 = SoulQueryUtil.termQueryMap(titleField,
					primeToken, 2.0f);
			Map<String, Object> map2 = SoulQueryUtil.termQueryMap(contentField,
					primeToken, 1.0f);
			array.add(map1);
			array.add(map2);
			return array;
		}
	}

	public List<Object> singleQueryForTitle(List<Map<String, Object>> tokens,
			float ratio) {
		Assert.assertTrue(tokens.size() >= 1);
		Map<String, Object> tokenMap = tokens.get(0);
		String primeType = (String) tokenMap.get("type");
		String primeToken = (String) tokenMap.get("token");
		int documentFreq = termTotalFreq(primeToken);
		if ((documentFreq > 0)
				&& (documentFreq < singleTermTitleThreshold * ratio)) {
			List<String> firstWords = new LinkedList<String>();
			firstWords.add(primeToken);
			List<Map<String, Object>> subList = tokens
					.subList(1, tokens.size());
			List<String> result = SoulQueryUtil.synonymList(subList,
					primeToken, primeType);
			firstWords.addAll(result);
			return termQueryListForTitle(firstWords);
		} else {
			List<Object> array = new ArrayList<Object>();
			log.info("[" + primeToken + "] document freq [" + documentFreq
					+ "]");
			Map<String, Object> map = SoulQueryUtil.termQueryMap(titleField,
					primeToken);
			array.add(map);
			return array;
		}
	}

	protected List<Object> termQueryListForTitleAndContent(
			List<String> firstWords, float ratio) {
		List<Object> array = new ArrayList<Object>();
		for (int i = 0; i < firstWords.size(); i++) {
			String token = firstWords.get(i);
			if (i == 0) {
				Map<String, Object> map1 = SoulQueryUtil.termQueryMap(
						titleField, token, 2.0f);
				Map<String, Object> map2 = SoulQueryUtil.termQueryMap(
						contentField, token, 1.5f);
				array.add(map1);
				array.add(map2);
			} else {
				int docFreq = termTotalFreq(token);
				if (docFreq >= synonymExtensionThreshold * ratio) {
					Map<String, Object> map1 = SoulQueryUtil.termQueryMap(
							titleField, token, 1.5f);
					array.add(map1);
				} else if ((docFreq > 0)
						&& (docFreq < synonymExtensionThreshold * ratio)) {
					Map<String, Object> map1 = SoulQueryUtil.termQueryMap(
							titleField, token, 1.1f);
					Map<String, Object> map2 = SoulQueryUtil.termQueryMap(
							contentField, token);
					array.add(map1);
					array.add(map2);
				}
			}
		}
		return array;
	}

	protected List<Object> termQueryListForTitle(List<String> firstWords) {
		List<Object> array = new ArrayList<Object>();
		for (int i = 0; i < firstWords.size(); i++) {
			String token = firstWords.get(i);
			if (i == 0) {
				Map<String, Object> map1 = SoulQueryUtil.termQueryMap(
						titleField, token, 2.0f);
				array.add(map1);
			} else {
				int docFreq = termTotalFreq(token);
				if (docFreq > 0) {
					Map<String, Object> map1 = SoulQueryUtil.termQueryMap(
							titleField, token, 1.5f);
					array.add(map1);
				}
			}
		}
		return array;
	}

	/*********************************************************************************/

}
