package org.elasticsearch.application.query;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.splitword.soul.utility.SoulArrays;
import org.testng.Assert;

public class LongTermQuery extends SoulQuery {

	private static final Log log = LogFactory.getLog(LongTermQuery.class);
	final int leastNumber = 4;
	List<String> keywords1 = null;
	List<String> keywords2 = null;
	List<String> keywords3 = null;
	List<String> keywords4 = null;
	Map<Integer, QueryPojo> nounWords = new HashMap<Integer, QueryPojo>();
	Map<Integer, List<String>> resultMap = new HashMap<Integer, List<String>>();

	public LongTermQuery(String index, String type, PostQuery postQuery) {
		super(index, type, postQuery);
	}

	private void fillThreeList(String queryStr) {
		fillBaseMap(queryStr);
		nounWords.clear();
		resultMap.clear();
		int number = fillNounWordMap(nounWords, resultMap);
		Assert.assertEquals(true, (number > 3));
	}

	public Map<String, Object> pageQuery(String queryStr, String tag) {
		fillThreeList(queryStr);
		List<Object> titleArray = combineQueryTitle(keywords1, keywords2,
				keywords3);
		List<Object> contentArray = combineQueryContent(keywords1, keywords2,
				keywords3);
		Map<String, Object> titleMap = SoulQueryUtil.createBooleanQueryMap(
				titleArray, 1, "all", 400.0f);
		Map<String, Object> contentMap = SoulQueryUtil.createBooleanQueryMap(
				contentArray, 1, "all", 300.0f);
		List<Object> finalArray = new ArrayList<Object>();
		finalArray.add(titleMap);
		finalArray.add(contentMap);
		Map<String, Object> finalMap = SoulQueryUtil.createBooleanQueryMap(
				finalArray, 1, tag);
		return finalMap;
	}

	private List<List<String>> fillThreeList() {
		Map<Integer, Integer> map1 = new HashMap<Integer, Integer>();
		Map<Integer, List<String>> map2 = new HashMap<Integer, List<String>>();
		for (int i = 0; i < resultMap.size(); i++) {
			List<String> keywords = resultMap.get(i);
			int totalNumber = 0;
			for (int j = 0; j < keywords.size(); j++)
				totalNumber += termTotalFreq(keywords.get(j));
			map1.put(i, totalNumber);
			map2.put(i, keywords);
		}
		List<List<String>> result = new LinkedList<List<String>>();
		List<Map.Entry<Integer, Integer>> list1 = SoulArrays.sortMapByValue(
				map1, -1);
		for (Map.Entry<Integer, Integer> entry : list1) {
			int key = entry.getKey();
			result.add(map2.get(key));
			if (result.size() >= 4)
				break;
		}
		keywords1 = result.get(0);
		keywords2 = result.get(1);
		keywords3 = result.get(2);
		keywords4 = result.get(3);
		if (keywords1.size() > leastNumber)
			keywords1 = keywords1.subList(0, leastNumber);
		if (keywords2.size() > leastNumber)
			keywords2 = keywords2.subList(0, leastNumber);
		if (keywords3.size() > leastNumber)
			keywords3 = keywords3.subList(0, leastNumber);
		if (keywords4.size() > leastNumber)
			keywords4 = keywords4.subList(0, leastNumber);

		return result;
	}

	public Map<String, Object> officialQuery(String queryStr, String tag) {
		fillThreeList(queryStr);
		fillThreeList();
		List<Object> titleArray = combineQueryTitle(keywords1, keywords2,
				keywords3);
		Map<String, Object> titleMap = SoulQueryUtil.createBooleanQueryMap(
				titleArray, 1, "all", 4.0f);
		List<Object> titleArray2 = combineQueryTitle(keywords1, keywords2);
		Map<String, Object> titleMap2 = SoulQueryUtil.createBooleanQueryMap(
				titleArray2, 1, "all", 3.0f);
		List<Object> titleArray3 = combineQueryTitle(keywords1, keywords3);
		Map<String, Object> titleMap3 = SoulQueryUtil.createBooleanQueryMap(
				titleArray3, 1, "all", 3.0f);
		List<Object> titleArray4 = combineQueryTitle(keywords2, keywords3);
		Map<String, Object> titleMap4 = SoulQueryUtil.createBooleanQueryMap(
				titleArray4, 1, "all", 3.0f);
		List<Object> finalArray = new ArrayList<Object>();

		Map<String, Object> map1 = SoulQueryUtil.createBooleanQueryMap(
				combineQueryTitle(keywords2, keywords3, keywords4), 1, "all",
				4.0f);
		Map<String, Object> map2 = SoulQueryUtil.createBooleanQueryMap(
				combineQueryTitle(keywords1, keywords3, keywords4), 1, "all",
				4.0f);
		Map<String, Object> map3 = SoulQueryUtil.createBooleanQueryMap(
				combineQueryTitle(keywords1, keywords2, keywords4), 1, "all",
				4.0f);
		finalArray.add(titleMap);
		finalArray.add(titleMap2);
		finalArray.add(titleMap3);
		finalArray.add(titleMap4);
		finalArray.add(map1);
		finalArray.add(map2);
		finalArray.add(map3);

		List<Object> array1 = termQueryListForTitle(keywords1);
		List<Object> array2 = termQueryListForTitle(keywords2);
		Map<String, Object> singleMap1 = SoulQueryUtil.createBooleanQueryMap(
				array1, 1, "all", 2.0f);
		Map<String, Object> singleMap2 = SoulQueryUtil.createBooleanQueryMap(
				array2, 1, "all", 1.8f);
		finalArray.add(singleMap1);
		finalArray.add(singleMap2);
		// QueryPojo pojo = getSinglePojo();
		// if (pojo != null) {
		// List<Object> array = termQueryListForTitle(resultMap.get(pojo
		// .seqNumber()));
		// Map<String, Object> singleMap = SoulQueryUtil
		// .createBooleanQueryMap(array, 1, "all", 2.0f);
		// finalArray.add(singleMap);
		//
		// }
		Map<String, Object> finalMap = SoulQueryUtil.createBooleanQueryMap(
				finalArray, 1, tag);
		return finalMap;
	}

	protected QueryPojo compareTermList(List<QueryPojo> twoTerms) {
		int docfreq = 10000000;
		int pos = -1;
		for (int i = 0; i < twoTerms.size(); i++) {
			QueryPojo pojo = twoTerms.get(i);
			int tmpFreq = termTotalFreq(pojo.getName());
			if (tmpFreq < docfreq) {
				docfreq = tmpFreq;
				pos = i;
			}
		}
		return twoTerms.get(pos);
	}

	protected QueryPojo getSinglePojo() {
		if (nounWords.size() >= 2) {
			List<QueryPojo> pojoList = new LinkedList<QueryPojo>();
			for (Integer pos : nounWords.keySet()) {
				QueryPojo pojo = nounWords.get(pos);
				pojoList.add(pojo);
			}
			QueryPojo pojo = compareTermList(pojoList);
			return pojo;
		} else if (nounWords.size() == 0) {
			List<QueryPojo> termList = new LinkedList<QueryPojo>();
			List<QueryPojo> vnTermList = new LinkedList<QueryPojo>();
			for (Integer pos : terms.keySet()) {
				QueryPojo pojo = terms.get(pos);
				String nature = pojo.getNature();
				if (nature.equals("vn"))
					vnTermList.add(pojo);
				else
					termList.add(pojo);
			}
			QueryPojo pojo = null;
			if (vnTermList.size() == 1)
				pojo = vnTermList.get(0);
			else if (vnTermList.size() == 0)
				pojo = compareTermList(termList);
			else {
				pojo = compareTermList(vnTermList);
			}
			log.info("expected String is \"" + pojo.getName() + "\"");
			return pojo;
		} else if (nounWords.size() == 1) {
			Set<Integer> set = nounWords.keySet();
			Iterator<Integer> iter = set.iterator();
			if (iter.hasNext()) {
				int pos = iter.next();
				return nounWords.get(pos);
			}
		}
		return null;
	}
}
