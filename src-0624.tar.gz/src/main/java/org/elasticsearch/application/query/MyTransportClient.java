package org.elasticsearch.application.query;

import static org.elasticsearch.index.query.QueryBuilders.matchAllQuery;
import static org.elasticsearch.index.query.QueryBuilders.simpleQueryString;
import static org.elasticsearch.index.query.QueryBuilders.termQuery;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.elasticsearch.action.index.IndexRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.hadoop.cfg.ConfigurationOptions;
import org.elasticsearch.hadoop.cfg.Settings;
import org.elasticsearch.hadoop.cfg.SettingsManager;
import org.elasticsearch.hadoop.mr.MapReduceWriter;
import org.elasticsearch.hadoop.rest.InitializationUtils;
import org.elasticsearch.hadoop.rest.RestClient;
import org.elasticsearch.hadoop.serailize.MapWritableIdExtractor;
import org.elasticsearch.hadoop.serailize.SerializationUtils;
import org.elasticsearch.index.query.MatchQueryBuilder;
import org.elasticsearch.index.query.MultiMatchQueryBuilder;
import org.elasticsearch.index.query.SimpleQueryStringBuilder;
import org.elasticsearch.search.SearchHit;

public class MyTransportClient {
	private final Log log = LogFactory.getLog(MyTransportClient.class);
	private RestClient restClient;
	TransportClient transportClient;
	private String indexName = "haha";
	private String typeName = "table";
	private String hostName = "localhost";
	private int port = 9300;

	private RestClient _GetRestClient() {
		Properties properties = new Properties();
		properties.put(ConfigurationOptions.ES_WRITE_OPERATION, "index");
		properties.put(ConfigurationOptions.ES_MAPPING_ID, "docno");
		String resource = this.indexName + "/" + this.typeName;
		properties.put(ConfigurationOptions.ES_RESOURCE, resource);
		properties.put("es.host", hostName);
		Settings settings = SettingsManager.loadFrom(properties);
		SerializationUtils.setValueWriterIfNotSet(settings,
				MapReduceWriter.class, log);
		InitializationUtils.setIdExtractorIfNotSet(settings,
				MapWritableIdExtractor.class, log);
		restClient = new RestClient(settings);
		return restClient;
	}

	public MyTransportClient(String hostName, String indexName, String typeName) {
		this.hostName = hostName;
		this.indexName = indexName;
		this.typeName = typeName;
		restClient = _GetRestClient();
		transportClient = new TransportClient()
				.addTransportAddress(new InetSocketTransportAddress(hostName,
						port));
	}

	public void putOperation(String id, Map<String, Object> map) {
		IndexRequestBuilder builders = transportClient.prepareIndex(indexName,
				typeName, id).setSource(map);
		transportClient.index(builders.request());
	}

	public void putOperation(String url, String content, String newword) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("url", url);
		map.put("content", content);
		map.put("newword", newword);
		StringBuilder builder = new StringBuilder();
		for (int i = 0; i < newword.length(); i++) {
			int num = (int) newword.charAt(i);
			String numStr = String.valueOf(num);
			builder.append(numStr);
		}
		String id = builder.toString();
		IndexRequestBuilder builders = transportClient.prepareIndex(indexName,
				typeName, id).setSource(map);
		transportClient.index(builders.request());
	}
	public void close() {
		transportClient.close();
		restClient.close();
	}

	public void simpleScrollQuery(String queryStr) {
		String field = "contenttitle";
		SimpleQueryStringBuilder strBuilder = simpleQueryString(queryStr)
				.analyzer("soul_query").field("content", 1.0f)
				.field(field, 2.0f)
				.defaultOperator(SimpleQueryStringBuilder.Operator.AND);
		SearchResponse searchResponse = null;
		int size = 0;
		long totalSize = 0;
		do {
			if (searchResponse == null)
				searchResponse = transportClient.prepareSearch(indexName)
						.setQuery(strBuilder).setSize(7)
						.setScroll(TimeValue.timeValueMinutes(4))
						.addHighlightedField(field)
						.addHighlightedField("content").execute().actionGet();
			else {
				searchResponse = transportClient
						.prepareSearchScroll(searchResponse.getScrollId())
						.setScroll(TimeValue.timeValueMinutes(4)).execute()
						.actionGet();
			}
			size += searchResponse.getHits().getHits().length;
			totalSize = searchResponse.getHits().getTotalHits();
			// log.info(searchResponse.getScrollId());
			log.info(size + "," + totalSize);
			for (SearchHit hit : searchResponse.getHits().getHits()) {
				if ((hit.getHighlightFields().get(field) != null)
						&& (hit.getHighlightFields().get("content") != null)) {
					log.info("\n{\n"
							+ hit.getHighlightFields().get(field).fragments()[0]
							+ "\n"
							+ hit.getHighlightFields().get("content")
									.fragments()[0] + "\n}");
				} else if (hit.getHighlightFields().get("content") != null)
					log.info(hit.getHighlightFields().get("content")
							.fragments()[0]);
				else if (hit.getHighlightFields().get(field) != null)
					log.info(hit.getHighlightFields().get(field).fragments()[0]);
				else {
					log.error("This should not happen!");
				}
			}
		} while (size < totalSize);
	}
	public void simpleMatchAllQuery() {
		SearchResponse searchResponse = transportClient
				.prepareSearch(indexName).setQuery(matchAllQuery())
				.setSize(50000).setVersion(true).get();
		// 必须设置获取版本为true，否则版本不对。
		String field = "newword";
		String field2 = "url";
		SoulFileWriter writer = new SoulFileWriter("/tmp/1.txt");
		log.info(searchResponse.getHits().hits().length);
		for (SearchHit hit : searchResponse.getHits().getHits()) {
			StringBuilder builder = new StringBuilder();
			String str = (String) hit.getSource().get(field);
			int freq = (int) hit.getVersion();
			String id = hit.getId();
			log.info(id);
			String nature = (String) hit.getSource().get(field2);
			if ((str.length() > 1) && (nature.equals("nw"))) {
				freq *= str.length();
				builder.append(str + "\t" + "rule" + "\t" + freq + "\n");
				log.info(builder.toString());
				writer.writeStr(builder.toString());
			}

		}
		writer.close();
	}

	public String simpleTermQuery(String queryStr) {
		String field = "contenttitle";
		SearchResponse searchResponse = transportClient
				.prepareSearch(indexName).setQuery(termQuery(field, queryStr))
				.addHighlightedField(field).get();
		log.info("******************* " + queryStr + " *******************");
		StringBuilder builder = new StringBuilder();
		for (SearchHit hit : searchResponse.getHits().getHits()) {
			String str = hit.getSource().get(field) + "\n";
			builder.append(str + "\n");
			log.info(str);
		}
		return builder.toString();
	}
	public String synonymQuery(String queryStr) {
		String field = "contenttitle";
		SearchResponse searchResponse = transportClient
				.prepareSearch(indexName)
				.setQuery(
						simpleQueryString(queryStr)
								.analyzer("soul_query")
								.field(field, 1.0f)
								.defaultOperator(
										SimpleQueryStringBuilder.Operator.OR))
				.addHighlightedField(field).get();
		log.info("******************* " + queryStr + " *******************");
		log.info(searchResponse.getHits().getHits().length);
		StringBuilder builder = new StringBuilder();
		for (SearchHit hit : searchResponse.getHits().getHits()) {
			String str = hit.getId() + ", " + hit.getScore() + ", "
					+ hit.getSource().get("url") + ", "
					+ hit.getSource().get(field) + ", "
					+ hit.getHighlightFields().get(field).fragments()[0];
			builder.append(str + "\n");
			log.info(str);
		}
		log.info("******************* " + queryStr + " *******************");
		return builder.toString();
	}

	public String simpleQueryStringQuery(String queryStr) {
		// 使用soul_query分完词后，建立boolean查询，此时与顺序无关
		SearchResponse searchResponse = transportClient
				.prepareSearch(indexName)
				.setQuery(
						simpleQueryString(queryStr)
								.analyzer("soul_query")
								.field("content", 1.0f)
								.field("contenttitle", 2.0f)
								.defaultOperator(
										SimpleQueryStringBuilder.Operator.AND))
				.get();
		log.info("******************* " + queryStr + " *******************");
		log.info(searchResponse.getHits().getHits().length);
		StringBuilder builder = new StringBuilder();
		for (SearchHit hit : searchResponse.getHits().getHits()) {
			String str = hit.getId() + ", " + hit.getScore() + ", "
					+ hit.getSource().get("url") + ", "
					+ hit.getSource().get("contenttitle");
			builder.append(str + "\n");
			log.info(str);
		}
		log.info("******************* " + queryStr + " *******************");
		return builder.toString();
	}

	private void logInfo(SearchHit hit, String field1, String field2) {
		log.info("分数： " + hit.getScore());
		StringBuilder builder = new StringBuilder();
		if ((hit.getHighlightFields().get(field1) != null)
				&& (hit.getHighlightFields().get(field2) != null)) {
			int frag1 = hit.getHighlightFields().get(field1).fragments().length;
			int frag2 = hit.getHighlightFields().get(field2).fragments().length;
			log.info("frag1=  " + frag1 + ", frag2 = " + frag2);
			builder.append("\n{\n");
			for (int i = 0; i < frag1; i++) {
				builder.append(hit.getHighlightFields().get(field1).fragments()[i]);
			}
			builder.append("\n");
			for (int i = 0; i < frag2; i++) {
				builder.append(hit.getHighlightFields().get(field2).fragments()[i]);
			}
			builder.append("\n}");
		} else if (hit.getHighlightFields().get(field2) != null) {
			int frag2 = hit.getHighlightFields().get(field2).fragments().length;
			builder.append("\n{\n");
			for (int i = 0; i < frag2; i++) {
				builder.append(hit.getHighlightFields().get(field2).fragments()[i]);
			}
			builder.append("\n}");
		}

		else if (hit.getHighlightFields().get(field1) != null) {
			int frag1 = hit.getHighlightFields().get(field1).fragments().length;
			builder.append("\n{\n");
			for (int i = 0; i < frag1; i++) {
				builder.append(hit.getHighlightFields().get(field1).fragments()[i]);
			}
			builder.append("\n}");
		} else {
			log.error("This should not happen!");
		}
		log.info(builder.toString());
	}

	public void multiMatchQuery(String queryStr) {
		MultiMatchQueryBuilder multiMatchQuery = new MultiMatchQueryBuilder(
				queryStr, "contenttitle", "content").analyzer("soul_query")
				.operator(MatchQueryBuilder.Operator.OR);
		multiMatchQuery.useDisMax(true);
		multiMatchQuery.minimumShouldMatch("10%");
		SearchResponse searchResponse = transportClient
				.prepareSearch(indexName).setQuery(multiMatchQuery)
				.addHighlightedField("contenttitle")
				.addHighlightedField("content").get();

		for (SearchHit hit : searchResponse.getHits().getHits()) {
			logInfo(hit, "contenttitle", "content");
		}
	}

	public List<String> getSuggestions(String inputStr) throws Exception {
		// SuggestRequestBuilder builder = new SuggestRequestBuilder(
		// transportClient).setIndices("sogou_spellcheck")
		// .field("content").term(inputStr).size(10).similarity(0.7f)
		// .suggestType("soul");
		// builder.preservePositionIncrements(true);
		// SuggestResponse suggestResponse = builder.execute().actionGet();
		// // assertThat(suggestResponse.getShardFailures(), is(emptyArray()));
		// log.info(suggestResponse.suggestions());
		// return suggestResponse.suggestions();
		List<String> resultStr = new LinkedList<String>();
		for (int i = 0; i < 4; i++) {
			String str = inputStr + RandomStringUtils.randomAlphabetic(5);
			resultStr.add(str);
		}
		log.info(resultStr);
		return resultStr;
	}
}
