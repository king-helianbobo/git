package org.elasticsearch.application.query;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.map.ObjectMapper;
import org.elasticsearch.plugin.analyzer.BasicTokenizer;
import org.splitword.soul.utility.StringUtil;
import org.splitword.soul.utility.WordAlter;

public class SoulQueryUtil {
	private static Log log = LogFactory.getLog(SoulQueryUtil.class);
	public static final String preTag = "<tag1 style=\"color:red\">";
	public static final String postTag = "</tag1>";
	public static final String titleField = "contenttitle";
	public static final String contentField = "content";
	public static final String urlField = "url";
	public static final String tagField = "tag";
	public static final String timeField = "time";
	private static final String[] tags = { "魅力锡城", "锡城资讯", "信息公开", "公共服务",
			"行政服务", "政民互动" };
	public static final int fragmentSize = 250;
	private static ObjectMapper mapper = new ObjectMapper();

	public static String termListJson(String term) {
		List<String> array = new ArrayList<String>();
		array.add(titleField);
		array.add(contentField);
		Map<String, Object> map2 = new HashMap<String, Object>();
		map2.put("fields", array);
		map2.put("size", 0);
		map2.put("action", "termlist");
		map2.put("term", term);
		try {
			String json = mapper.writeValueAsString(map2);
			return json;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}

	public static String suggestJson(String queryStr, String type,
			String field, int size) {
		Map<String, String> tmpMap = new HashMap<String, String>();
		tmpMap.put("term", queryStr);
		tmpMap.put("field", field);
		tmpMap.put("size", String.valueOf(size));
		tmpMap.put("type", type);
		try {
			String json = mapper.writeValueAsString(tmpMap);
			return json;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}

	public static String convertTag(String tagType) {
		String tag = "all";
		if (tagType.equalsIgnoreCase("tag1"))
			tag = tags[0];
		else if (tagType.equalsIgnoreCase("tag2"))
			tag = tags[1];
		else if (tagType.equalsIgnoreCase("tag3"))
			tag = tags[2];
		else if (tagType.equalsIgnoreCase("tag4"))
			tag = tags[3];
		else if (tagType.equalsIgnoreCase("tag5"))
			tag = tags[4];
		else if (tagType.equalsIgnoreCase("tag6"))
			tag = tags[5];
		else if (tagType.equalsIgnoreCase("first"))
			tag = "first";
		else {
			tag = "all";
		}
		return tag;
	}

	private static Map<String, Object> _queryStringMap(String queryStr) {
		Map<String, Object> map1 = new HashMap<String, Object>();
		List<String> array = new ArrayList<String>();
		array.add("content^1.0");
		array.add("contenttitle^3.0");
		Map<String, Object> map2 = new HashMap<String, Object>();
		map2.put("analyzer", "whitespace");
		map2.put("default_operator", "and");
		map2.put("fields", array);
		map2.put("query", queryStr);
		map1.put("query_string", map2);
		return map1;
	}

	public static Map<String, Object> simpleQueryStringMap(String field,
			List<String> fragments, String operator, String analyzer) {
		StringBuilder builder = new StringBuilder();
		for (int i = 0; i < fragments.size(); i++) {
			builder.append(fragments.get(i));
			builder.append(" ");
		}
		String queryStr = builder.toString();
		return _simpleQueryStringMap(field, queryStr, operator, analyzer);
	}

	public static Map<String, Object> simpleQueryStringMap(String field,
			String queryStr, String operator) {
		return _simpleQueryStringMap(field, queryStr, operator, "soul_query");
	}

	private static Map<String, Object> _simpleQueryStringMap(String field,
			String queryStr, String operator, String analyzer) {
		List<String> array = new ArrayList<String>();
		array.add(field);
		Map<String, Object> map2 = new HashMap<String, Object>();
		map2.put("analyzer", analyzer);
		map2.put("default_operator", operator);
		// map2.put("default_field", field);
		map2.put("fields", array);
		map2.put("query", queryStr);
		Map<String, Object> map1 = new HashMap<String, Object>();
		map1.put("simple_query_string", map2);
		return map1;
	}

	private static Map<String, Object> _spanTermQueryMap(String fieldName,
			String keyword) {
		Map<String, Object> map1 = new HashMap<String, Object>();
		map1.put(fieldName, keyword);
		Map<String, Object> termMap = new HashMap<String, Object>();
		termMap.put("span_term", map1);
		return termMap;
	}

	public static Map<String, Object> termQueryMap(String fieldName,
			String keyword) {
		return termQueryMap(fieldName, keyword, 1.0f);
	}

	public static Map<String, Object> termQueryMap(String fieldName,
			String keyword, float boost) {
		Map<String, Object> map1 = new HashMap<String, Object>();
		Map<String, Object> map2 = new HashMap<String, Object>();
		map2.put("value", keyword);
		map2.put("boost", boost);
		map1.put(fieldName, map2);
		Map<String, Object> termMap = new HashMap<String, Object>();
		termMap.put("term", map1);
		return termMap;
	}

	private static Map<String, Object> _termQueryMap(String fieldName,
			String keyword) {
		Map<String, Object> map1 = new HashMap<String, Object>();
		map1.put(fieldName, keyword);
		Map<String, Object> termMap = new HashMap<String, Object>();
		termMap.put("term", map1);
		return termMap;
	}

	public static Map<String, Object> spanNearQueryMap(String field,
			List<String> queryStrs) {
		String[] tmpStrs = new String[queryStrs.size()];
		for (int i = 0; i < queryStrs.size(); i++) {
			tmpStrs[i] = queryStrs.get(i);
		}
		return _spanNearQueryMap(field, tmpStrs);
	}

	private static Map<String, Object> _spanNearQueryMap(String field,
			String... queryStrs) {
		Map<String, Object> map1 = new HashMap<String, Object>();
		map1.put("slop", 0);
		map1.put("in_order", true);
		map1.put("collect_payloads", false);

		List<Map<String, Object>> array = new ArrayList<Map<String, Object>>();
		for (int i = 0; i < queryStrs.length; i++) {
			Map<String, Object> tmp = _spanTermQueryMap(field, queryStrs[i]);
			array.add(tmp);
		}
		map1.put("clauses", array);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("span_near", map1);
		return map;
	}

	public static Map<String, Object> spanNearQueryMap(int slop, String field,
			String... queryStrs) {
		Map<String, Object> map1 = new HashMap<String, Object>();
		map1.put("slop", slop);
		map1.put("in_order", false);
		map1.put("collect_payloads", false);
		List<Map<String, Object>> array = new ArrayList<Map<String, Object>>();
		for (int i = 0; i < queryStrs.length; i++) {
			Map<String, Object> tmp = _spanTermQueryMap(field, queryStrs[i]);
			array.add(tmp);
		}
		map1.put("clauses", array);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("span_near", map1);
		return map;
	}

	/*******************************************************************************/
	public static Map<String, Object> createBooleanQueryMap(
			List<Object> shouldList, int minimumMatch, String tag) {
		return createBooleanQueryMap(shouldList, minimumMatch, tag, 1.0f);
	}

	public static Map<String, Object> createBooleanQueryMap(
			List<Object> shouldList, int minimumMatch) {
		return createBooleanQueryMap(shouldList, minimumMatch, "all", 1.0f);
	}

	public static List<String> synonymList(
			List<Map<String, Object>> synonymTokens, String baseToken,
			String baseType) {
		List<String> firstWords = new LinkedList<String>();
		List<String> secondWords = new LinkedList<String>();
		for (int i = 0; i < synonymTokens.size(); i++) {
			Map<String, Object> tokenMap = synonymTokens.get(i);
			String type = (String) tokenMap.get("type");
			String token = (String) tokenMap.get("token");
			if (token.length() == 1)
				continue;
			if (type.equals(BasicTokenizer.TYPE_SYNONYM)) {
				firstWords.add(token);
			} else if (type.equals(BasicTokenizer.TYPE_VECTOR)
					&& (!firstWords.contains(token))) {
				if (baseType.startsWith("n")) {
					if (WordAlter.nounIntersection(baseToken, token, baseType))
						secondWords.add(token);
				} else if (baseType.startsWith("j")) {
					String common = WordAlter.commonSet(baseToken, token);
					if (baseToken.equals(common))
						firstWords.add(token);
				} else if (WordAlter.bIntersection(baseToken, token)) {
					secondWords.add(token);
				}
			} else {
				continue;
			}
		}
		if (!secondWords.isEmpty()) {
			firstWords.addAll(secondWords);
		}
		return firstWords;
	}

	public static Map<String, Object> createBooleanQueryMap(
			List<Object> shouldList, int minimumMatch, String tag, float boost) {
		Map<String, Object> map = new HashMap<String, Object>();
		Map<String, Object> map3 = new HashMap<String, Object>();
		map3.put("should", shouldList);
		if (tag.equals("all")) {
			// do nothing
		} else {
			List<Object> array = new ArrayList<Object>();
			array.add(_termQueryMap("tag", tag));
			map3.put("must", array);
		}
		map3.put("minimum_should_match", minimumMatch);
		map3.put("boost", boost);
		map.put("bool", map3);
		return map;
	}

	/******************************************************************************************/

	public static String complexQueryJson(Map<String, Object> queryMap,
			int from, int size) {
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("query", queryMap);
		result.put("highlight", createHighLigthQuery("contenttitle", "content"));
		result.put("from", from);
		result.put("size", size);
		try {
			String json = mapper.writeValueAsString(result);
			return json;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}

	/******************************************************************************************/
	public static String simpleQueryStringJson(String queryStr, int from,
			int size, String tag) {
		Map<String, Object> map1 = simpleQueryStringMap("content", queryStr,
				"and");
		Map<String, Object> map2 = simpleQueryStringMap("contenttitle",
				queryStr, "or");
		List<Object> array1 = new ArrayList<Object>();
		array1.add(map1);
		array1.add(map2);
		array1.add(_termQueryMap("contenttitle.untouched^4.0", queryStr));
		Map<String, Object> queryMap = createBooleanQueryMap(array1, 1, tag);
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("query", queryMap);
		result.put("highlight", createHighLigthQuery("contenttitle", "content"));
		result.put("size", size);
		result.put("from", from);
		try {
			String json = mapper.writeValueAsString(result);
			return json;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}

	public static String spanNearQueryJson(String queryStr, String tag,
			int from, int size, String... queryStrs) {
		Map<String, Object> map1 = _spanNearQueryMap("content", queryStrs);
		Map<String, Object> map2 = _spanNearQueryMap("contenttitle", queryStrs);
		List<Object> array1 = new ArrayList<Object>();
		array1.add(map1);
		array1.add(map2);
		array1.add(_termQueryMap("contenttitle.untouched^4.0", queryStr));
		Map<String, Object> queryMap = createBooleanQueryMap(array1, 1, tag);
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("query", queryMap);
		result.put("highlight", createHighLigthQuery("contenttitle", "content"));
		result.put("size", size);
		result.put("from", from);
		try {
			String json = mapper.writeValueAsString(result);
			return json;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}

	public static String queryStringJson(String queryStr, String tag, int from,
			int size, String... queryStrs) {
		List<Object> array = new ArrayList<Object>();
		for (int i = 0; i < queryStrs.length; i++) {
			Map<String, Object> map = _queryStringMap(queryStrs[i]);
			array.add(map);
		}
		array.add(_termQueryMap("contenttitle.untouched^4.0", queryStr));
		Map<String, Object> queryMap = createBooleanQueryMap(array, 1, tag);
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("query", queryMap);
		result.put("highlight", createHighLigthQuery("contenttitle", "content"));
		result.put("size", size);
		result.put("from", from);
		try {
			String json = mapper.writeValueAsString(result);
			return json;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}

	public static String simpleQueryStringJson(String queryStr) {
		return simpleQueryStringJson(queryStr, 0, 10, "all");
	}

	public static Map<String, Object> createHighLigthQuery(String... fields) {
		Map<String, Object> tagMap = new HashMap<String, Object>();
		List<String> tag1 = new ArrayList<String>();
		tag1.add(preTag);
		List<String> tag2 = new ArrayList<String>();
		tag2.add(postTag);
		tagMap.put("pre_tags", tag1);
		tagMap.put("post_tags", tag2);
		Map<String, Object> map3 = new HashMap<String, Object>();
		for (int i = 0; i < fields.length; i++) {
			String field = fields[i];
			Map<String, Object> tmp = new HashMap<String, Object>();
			if (field.equals("contenttitle")) {
				tmp.put("number_of_fragments", 0);
			} else if (field.equals("content")) {
				tmp.put("number_of_fragments", 3);
				tmp.put("fragment_size", fragmentSize);
			} else {
			}
			map3.put(field, tmp);
		}
		tagMap.put("fields", map3);
		return tagMap;
	}

	public static String formatHighLightContent(String content) {
		int startPos1 = 0;
		int endPos1 = content.indexOf(SoulQueryUtil.preTag);
		int startPos2 = content.lastIndexOf(SoulQueryUtil.postTag)
				+ SoulQueryUtil.postTag.length();
		if ((endPos1 < 0) || (startPos2 < 0)) {
			endPos1 = content.length();
			startPos2 = 0;
		}
		int endPos2 = content.length() - 1;
		for (int i = 0; i < endPos1; i++) {
			char c = content.charAt(i);
			if (!Character.isLetterOrDigit(c))
				startPos1++;
			else
				break;
		}
		for (int i = content.length() - 1; i >= startPos2; i--) {
			char c = content.charAt(i);
			if (!Character.isLetterOrDigit(c))
				endPos2--;
			else
				break;
		}
		String result = "..." + content.substring(startPos1, endPos2 + 1)
				+ "...";
		return result;
	}

	private static List<Object> keywordsArray(String keywords) {
		List<Object> array = new ArrayList<Object>();
		if (StringUtil.isBlank(keywords) || keywords.equalsIgnoreCase("null"))
			return array;
		String[] strs = keywords.split("\t");
		for (String str : strs) {
			array.add(str);
		}
		return array;
	}

	private static List<Map<String, Object>> sourceArray(String source) {
		List<Map<String, Object>> array = new ArrayList<Map<String, Object>>();
		if (StringUtil.isBlank(source) || source.equalsIgnoreCase("null"))
			return array;
		String[] strs = source.split("\t");
		for (String str : strs) {
			int begin = str.indexOf('(');
			int end = str.lastIndexOf(')');
			Map<String, Object> tmp = new HashMap<String, Object>();
			if (end >= 0 && begin >= 0) {
				String url = str.substring(begin + 1, end);
				String tag = str.substring(0, begin);
				tmp.put("title", tag);
				tmp.put("url", "http://" + url);
				array.add(tmp);
			} else {
				// do nothing ,ignore empty url
			}
		}
		return array;
	}

	@SuppressWarnings("unchecked")
	public static String constructJsonResult(Map<String, Object> map, int from) {
		try {
			map = (Map<String, Object>) map.get("hits");
			List<Map<String, Object>> hits = (List<Map<String, Object>>) map
					.get("hits");
			int totalSize = (Integer) map.get("total");
			List<Map<String, Object>> array = new ArrayList<Map<String, Object>>();
			for (int i = 0; i < hits.size(); i++) {
				Map<String, Object> map1 = hits.get(i);
				double score = (Double) map1.get("_score");
				Map<String, Object> sourceMap = (Map<String, Object>) map1
						.get("_source");
				Map<String, Object> lightMap = (Map<String, Object>) map1
						.get("highlight");
				String url = (String) sourceMap.get(urlField);
				String titleStr = (String) sourceMap.get(titleField);
				String contentStr = null;
				String srcContent = (String) sourceMap.get(contentField);
				if (lightMap != null) {
					List<String> titles = (List<String>) lightMap
							.get(titleField);
					if (titles != null)
						titleStr = titles.get(0);
					List<String> contents = (List<String>) lightMap
							.get(contentField);
					if (contents != null)
						contentStr = contents.get(0);
				}
				if (contentStr == null) {
					int size = (srcContent.length() < SoulQueryUtil.fragmentSize) ? srcContent
							.length() : SoulQueryUtil.fragmentSize;
					contentStr = srcContent.substring(0, size);
				}
				Map<String, Object> result2 = new HashMap<String, Object>();
				String tmpContent = SoulQueryUtil
						.formatHighLightContent(contentStr);
				result2.put(titleField, titleStr);
				result2.put(contentField, tmpContent);
				result2.put(urlField, url);
				result2.put("score", score);
				String source = (String) sourceMap.get("source");
				result2.put("source", sourceArray(source));
				String keywords = (String) sourceMap.get("keywords");
				result2.put("keywords", keywordsArray(keywords));
				result2.put(tagField, (String) sourceMap.get(tagField));
				result2.put(timeField, (String) sourceMap.get("postTime"));
				array.add(result2);
			}
			Map<String, Object> result = new HashMap<String, Object>();
			result.put("count", totalSize);
			result.put("from", from);
			result.put("size", hits.size());
			result.put("pageList", array);
			String resultJson = mapper.writeValueAsString(result);
			log.info("result: " + totalSize + "/" + from + "/" + hits.size());
			// log.info(resultJson);
			return resultJson;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}
}
