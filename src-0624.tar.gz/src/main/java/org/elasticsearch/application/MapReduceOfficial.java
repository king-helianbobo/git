package org.elasticsearch.application;

import java.io.IOException;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.MapWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.lib.input.NLineInputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.map.ObjectMapper;
import org.elasticsearch.hadoop.cfg.ConfigurationOptions;
import org.elasticsearch.hadoop.mr.ESOutputFormat;
import org.elasticsearch.hadoop.util.WritableUtils;

public class MapReduceOfficial extends Configured implements Tool {

	private static final Log log = LogFactory.getLog(MapReduceOfficial.class);
	// static KeyWordComputer kwe = new KeyWordComputer(20);
	static ObjectMapper mapper = new ObjectMapper();
	// private static BasicAnalysis analysis = null;
	static int i = 0;

	public static class JsonMapper extends
			Mapper<LongWritable, Text, LongWritable, MapWritable> {

		protected void setup(Context context) throws IOException,
				InterruptedException {
			// analysis = new BasicAnalysis(true);
			Configuration conf = context.getConfiguration();
			FileAppender fa = new FileAppender();
			fa.setName("FileLogger");
			fa.setFile("/tmp/3.log");
			fa.setLayout(new PatternLayout("%d %-5p [%c{1}] %m%n"));
			fa.setThreshold(Level.INFO);
			fa.setAppend(true);
			fa.activateOptions();
			Logger.getRootLogger().getLoggerRepository().resetConfiguration();
			Logger.getRootLogger().addAppender(fa);
		}

		@Override
		protected void map(LongWritable key, Text value, Context context)
				throws IOException, InterruptedException {
			String line = value.toString();
			JsonParser jsonParser = mapper.getJsonFactory().createJsonParser(
					line);
			@SuppressWarnings("unchecked")
			Map<String, Object> entry = mapper.readValue(jsonParser, Map.class);
			String title = (String) entry.get("contenttitle");
			String content = (String) entry.get("content");
			entry.put("keywords", "Hello World");
			// entry.put("keywords", computeKeywords(title, content));
			context.write(key, (MapWritable) WritableUtils.toWritable(entry));
		}
	}

	public int run(String[] args) throws Exception {
		Configuration conf = getConf();
		conf.set(ConfigurationOptions.ES_WRITE_OPERATION, "index");
		conf.set(ConfigurationOptions.ES_MAPPING_ID, "id");
		conf.set(ConfigurationOptions.ES_RESOURCE, "official_mini/table");
		conf.set(ConfigurationOptions.ES_UPSERT_DOC, "false");
		conf.set(ConfigurationOptions.ES_HOST, args[0]);
		conf.setBoolean("mapred.map.tasks.speculative.execution", false);
		conf.setBoolean("mapred.reduce.tasks.speculative.execution", false);
		conf.setInt("mapreduce.input.lineinputformat.linespermap", 70000);
		Job job = new Job(conf);
		// job.setInputFormatClass(TextInputFormat.class);
		job.setInputFormatClass(NLineInputFormat.class);
		job.setOutputFormatClass(ESOutputFormat.class);
		job.setMapOutputValueClass(MapWritable.class);
		job.setMapperClass(JsonMapper.class);
		job.setNumReduceTasks(0);
		NLineInputFormat.addInputPath(job, new Path(args[1]));
		// ESTextInputFormat.addInputPath(job, new Path(args[1]));
		job.setJarByClass(MapReduceOfficial.class);
		job.setJobName("MapReduceOfficial");
		boolean success = job.waitForCompletion(true);
		return success ? 0 : 1;
	}

	public static void main(String[] args) throws Exception {
		int ret = ToolRunner.run(new MapReduceOfficial(), args);
		System.exit(ret);
	}
}