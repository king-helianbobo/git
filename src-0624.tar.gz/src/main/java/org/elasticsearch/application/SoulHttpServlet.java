package org.elasticsearch.application;

import java.io.IOException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.elasticsearch.application.client.LionHttpClient;
import org.elasticsearch.application.client.PageHttpClient;
import org.elasticsearch.application.client.SoulHttpClient;

public class SoulHttpServlet {
	private static final Log log = LogFactory.getLog(SoulHttpServlet.class);
	private SoulHttpClient httpClient = null;
	private LionHttpClient lionClient = null;
	private PageHttpClient pageClient = null;

	public SoulHttpServlet(String url, String index, String type) {
		httpClient = new SoulHttpClient(url, index, type);
		lionClient = new LionHttpClient(url, index, type);
		pageClient = new PageHttpClient(url, index, type);
	}

	private enum SoulMethod {
		BASE, NLP, MYPAGE
	}

	public String processRequest(String input, String strMethod,
			String strNature, String from, String size, String tagType)
			throws IOException {
		SoulMethod method = SoulMethod.valueOf(strMethod.toUpperCase());
		String json = null;
		switch (method) {
		case NLP:
			// request from test
			if (from != null && size != null && tagType != null) {
				int start = Integer.valueOf(from);
				int len = Integer.valueOf(size);
				json = httpClient
						.complexQuerySearch(input, start, len, tagType);
			}
			break;
		case MYPAGE:
			// request from page
			if (from != null && size != null && tagType != null) {
				int start = Integer.valueOf(from);
				int len = Integer.valueOf(size);
				json = pageClient
						.pageClientSearch(input, start, len, tagType);
			}
			break;
		case BASE: // request from ajax
			json = lionClient.suggestSearch(input);
		default: {
			// do nothing
			break;
		}
		}
		return json;
	}
}
