package org.elasticsearch.module;

import org.elasticsearch.common.inject.AbstractModule;

import com.elasticsearch.action.service.ShardSuggestService;


public class ShardSuggestModule extends AbstractModule {

    @Override
    protected void configure() {
        bind(ShardSuggestService.class).asEagerSingleton();
    }

}
