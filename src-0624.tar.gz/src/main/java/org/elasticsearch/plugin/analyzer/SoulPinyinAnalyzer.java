package org.elasticsearch.plugin.analyzer;

import java.io.Reader;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.Tokenizer;
import org.apache.lucene.analysis.standard.StandardFilter;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.plugin.EsStaticValue;
import org.splitword.soul.analysis.BasicAnalysis;

public class SoulPinyinAnalyzer extends Analyzer {

	private static Log log = LogFactory.getLog(SoulPinyinAnalyzer.class);

	public SoulPinyinAnalyzer(Settings settings) {
		log.info("SoulPinyinAnalyzer is added!");
	}

	public SoulPinyinAnalyzer() {
	}

	@Override
	protected TokenStreamComponents createComponents(String fieldName,
			Reader reader) {
		Tokenizer tokenizer = new BasicTokenizer(new BasicAnalysis(reader),
				reader, null, EsStaticValue.pstemming);
		// first split this sentence ,then use filter to convert each term
		TokenStream result = new StandardFilter(EsStaticValue.LuceneVersion,
				tokenizer);
		result = new PinyinTokenFilter(result, true, true);
		// edge each token , pinyin must have whitespace between them
		// 台湾(taiwan) convert to tai wan
		result = new EdgeNGramTokenFilter(result,
				EdgeNGramTokenFilter.Side.FRONT, 3);
		// result = new SoulEdgeNGramTokenFilter(result,
		// SoulEdgeNGramTokenFilter.Side.TWOSIDE, 2);
		return new TokenStreamComponents(tokenizer, result);
	}
}
