package org.elasticsearch.plugin.analyzer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.lucene.analysis.Tokenizer;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
import org.elasticsearch.hadoop.util.StringUtils;
import org.elasticsearch.plugin.PorterStemmer;
import org.splitword.soul.analysis.Analysis;
import org.splitword.soul.domain.Term;
import org.splitword.soul.domain.TermNature;

public class BasicTokenizer extends Tokenizer {

	private static Log log = LogFactory.getLog(BasicTokenizer.class);
	// current word
	private final CharTermAttribute termAtt = addAttribute(CharTermAttribute.class);
	// current word's offset at sentence
	private final OffsetAttribute offsetAtt = addAttribute(OffsetAttribute.class);
	// word's number, 1st word,2nd word and so on
	private final PositionIncrementAttribute posAttr = addAttribute(PositionIncrementAttribute.class);
	private final TypeAttribute typeAtt = addAttribute(TypeAttribute.class);
	protected Analysis analysis = null; // analysis tool
	private Set<String> filter = null; // stop words
	private boolean bStem = false;// English word stemming
	private final PorterStemmer stemmer = new PorterStemmer();
	public static final String TYPE_WORD = "term";
	public static final String TYPE_HANZI = "hanzi";
	public static final String TYPE_SYNONYM = "synonym";
	public static final String TYPE_PINYIN = "pinyin";
	public static final String TYPE_VECTOR = "vector";

	public BasicTokenizer(Analysis analy, Reader input, Set<String> filter,
			boolean pstemming) {
		super(input);
		this.analysis = analy;
		this.filter = filter;
		this.bStem = pstemming;
	}

	@Override
	public final boolean incrementToken() throws IOException {
		clearAttributes();
		int position = 0;
		Term term = null;
		String name = null;
		int length = 0;
		boolean flag = true;
		int numWhiteSpace = 0;
		do {
			term = analysis.next();
			if (term == null) {
				break;
			}
			name = term.getName();
			length = name.length();
			if (bStem && term.getTermNatures().termNatures[0] == TermNature.EN) {
				name = stemmer.stem(name);// stemming
				term.setName(name);
			}
			if (filter != null && filter.contains(name)) {
				if (numWhiteSpace > 0) {
					position++;
					numWhiteSpace = 0;
				}
				position++; // keep its position
				continue;
			} else if (!StringUtils.hasText(name)) {
				numWhiteSpace++;
				continue; // set continuous whiteSpace as one,keep its position
			} else {
				if (numWhiteSpace > 0) {
					position++;
					numWhiteSpace = 0;
				}
				position++;
				flag = false;
			}
		} while (flag);
		if (term != null) {
			posAttr.setPositionIncrement(position);
			termAtt.setEmpty().append(term.getName());
			offsetAtt.setOffset(term.getOffe(), term.getOffe() + length);
			if (analysis.bNature) {
				String nature = term.getNatrue().natureStr;
				String termName = term.getName();
				typeAtt.setType(nature);

			} else
				typeAtt.setType(TYPE_WORD);
			return true;
		} else {
			return false;
		}
	}

	// must override this method
	// otherwise it will be fail when batch processing index
	@Override
	public void reset() throws IOException {
		super.reset();
		analysis.resetContent(new BufferedReader(input));
	}

}
