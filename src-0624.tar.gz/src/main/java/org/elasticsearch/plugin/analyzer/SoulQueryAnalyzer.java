package org.elasticsearch.plugin.analyzer;

import java.io.Reader;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.Tokenizer;
import org.apache.lucene.analysis.standard.StandardFilter;
import org.elasticsearch.plugin.EsStaticValue;
import org.splitword.soul.analysis.BasicAnalysis;

public class SoulQueryAnalyzer extends Analyzer {

	public SoulQueryAnalyzer() {
		super();
	}

	@Override
	protected TokenStreamComponents createComponents(String fieldName,
			final Reader reader) {
		Tokenizer tokenizer = new BasicTokenizer(
				new BasicAnalysis(reader, true), reader,
				EsStaticValue.stopWordsSet, EsStaticValue.pstemming);
		TokenStream result = new StandardFilter(EsStaticValue.LuceneVersion,
				tokenizer);
		result = new SynonymTokenFilter(result, true, false);
		return new TokenStreamComponents(tokenizer, result);
	}
}
