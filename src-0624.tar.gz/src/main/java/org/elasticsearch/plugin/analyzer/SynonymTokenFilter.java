package org.elasticsearch.plugin.analyzer;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.lucene.analysis.TokenFilter;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
import org.elasticsearch.plugin.EsStaticValue;
import org.splitword.soul.word2Vec.WordEntry;

public class SynonymTokenFilter extends TokenFilter {
	private static Log log = LogFactory.getLog(PinyinTokenFilter.class);
	private int totalNumber = 1;
	private int tokenStart;
	private int tokenEnd;
	private int position = 1;
	private int curNumber = 0;
	private final CharTermAttribute termAtt = addAttribute(CharTermAttribute.class);
	private final OffsetAttribute offsetAtt = addAttribute(OffsetAttribute.class);
	private final TypeAttribute typeAtt = addAttribute(TypeAttribute.class);
	private final PositionIncrementAttribute posAtt = addAttribute(PositionIncrementAttribute.class);

	private List<String> synonymList = null;
	private List<WordEntry> vectorList = null;
	private String primeToken = null;
	private String tokenType = null;

	private Map<String, List<String>> synonymTree = null;
	private Map<String, List<WordEntry>> vectorTree = null;

	public SynonymTokenFilter(TokenStream input) { // accept one token stream
		super(input);
		EsStaticValue.loadData();
		synonymTree = EsStaticValue.synonymTree;
		vectorTree = EsStaticValue.vectorTree;
	}

	public SynonymTokenFilter(TokenStream input, boolean bSynonym,
			boolean bVector) {
		// accept one token stream and synonym tree
		super(input);
		if (bSynonym || bVector) {
			EsStaticValue.loadData();
			if (bSynonym)
				synonymTree = EsStaticValue.synonymTree;
			if (bVector)
				vectorTree = EsStaticValue.vectorTree;
		}
	}

	@Override
	public final boolean incrementToken() throws IOException {
		while (true) {
			if (primeToken == null) {
				if (!input.incrementToken()) {// no more tokens
					return false;
				} else {
					int curTermLength = termAtt.length();
					char[] curTermBuffer = new char[curTermLength];
					System.arraycopy(termAtt.buffer(), 0, curTermBuffer, 0,
							curTermLength);
					primeToken = new String(curTermBuffer);
					tokenType = typeAtt.type();
					position = posAtt.getPositionIncrement();
					totalNumber = 1;
					if (synonymTree != null) {
						synonymList = new LinkedList<String>();
						List<String> list = synonymTree.get(primeToken);
						if (list != null && !list.isEmpty()) {
							for (int j = 0; j < list.size(); j++)
								synonymList.add(list.get(j));
							totalNumber += synonymList.size();
						} else
							synonymList = null;
					} else {
						synonymList = null;
					}
					if (vectorTree != null) {
						List<WordEntry> entrys = vectorTree.get(primeToken);
						vectorList = new LinkedList<WordEntry>();
						if (entrys != null && !entrys.isEmpty()) {
							for (int j = 0; j < entrys.size(); j++) {
								WordEntry value = entrys.get(j);
								vectorList.add(value);
							}
						}
						if (!vectorList.isEmpty()) {
							totalNumber += (vectorList.size());
						} else {
							vectorList = null;
						}
					} else {
						vectorList = null;
					}
					tokenStart = offsetAtt.startOffset();
					tokenEnd = offsetAtt.endOffset();
					curNumber = 0; // first time we get equivalent Term
				}
			}
			if (curNumber < totalNumber) {
				if (curNumber == 0) {
					clearAttributes();
					offsetAtt.setOffset(tokenStart, tokenEnd);
					termAtt.append(primeToken);
					posAtt.setPositionIncrement(position);
					typeAtt.setType(tokenType);
				} else if (synonymList != null) {
					clearAttributes();
					offsetAtt.setOffset(tokenStart, tokenEnd);
					String text = synonymList.remove(0);
					termAtt.append(text);
					typeAtt.setType(BasicTokenizer.TYPE_SYNONYM);
					posAtt.setPositionIncrement(0);
					if (synonymList.size() == 0)
						synonymList = null;
				} else if (vectorList != null) {
					clearAttributes();
					offsetAtt.setOffset(tokenStart, tokenEnd);
					WordEntry entry = vectorList.remove(0);
					String name = entry.name;
					termAtt.append(name);
					typeAtt.setType(BasicTokenizer.TYPE_VECTOR);
					posAtt.setPositionIncrement(0);
					if (vectorList.size() == 0)
						vectorList = null;
				}
				curNumber++;
				return true;
			} else
				primeToken = null;
		}
	}

	@Override
	public void reset() throws IOException {
		super.reset();
		primeToken = null;
	}
}
