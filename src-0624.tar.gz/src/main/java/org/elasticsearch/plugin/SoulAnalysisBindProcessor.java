package org.elasticsearch.plugin;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.elasticsearch.index.analysis.AnalysisModule;
import org.elasticsearch.plugin.analyzer.SoulIndexAnalyzerProvider;
import org.elasticsearch.plugin.analyzer.SoulNatureAnalyzerProvider;
import org.elasticsearch.plugin.analyzer.SoulPinyinAnalyzerProvider;
import org.elasticsearch.plugin.analyzer.SoulQueryAnalyzerProvider;
import org.elasticsearch.plugin.analyzer.SoulTitleAnalyzerProvider;

public class SoulAnalysisBindProcessor
		extends
			AnalysisModule.AnalysisBinderProcessor {
	private static Log log = LogFactory.getLog(SoulAnalysisBindProcessor.class);
	@Override
	public void processAnalyzers(AnalyzersBindings analyzersBindings) {
		analyzersBindings.processAnalyzer("soul_index",
				SoulIndexAnalyzerProvider.class);
		analyzersBindings.processAnalyzer("soul_query",
				SoulQueryAnalyzerProvider.class);
		analyzersBindings.processAnalyzer("soul_query_nature",
				SoulNatureAnalyzerProvider.class);
		analyzersBindings.processAnalyzer("soul_pinyin",
				SoulPinyinAnalyzerProvider.class);
		analyzersBindings.processAnalyzer("soul_title",
				SoulTitleAnalyzerProvider.class);
		super.processAnalyzers(analyzersBindings);
	}
}
