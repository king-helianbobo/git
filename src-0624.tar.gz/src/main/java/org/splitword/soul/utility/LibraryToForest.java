package org.splitword.soul.utility;

import java.io.BufferedReader;
import java.io.IOException;

public class LibraryToForest {
	/**
	 * 
	 * @author LiuBo
	 * @since 2014年1月14日
	 * @param br
	 * @param forest
	 * @return
	 * @throws Exception
	 *             Forest
	 */
	public static Forest makeLibrary(BufferedReader br, Forest forest)
			throws Exception {
		if (br == null)
			return forest;
		try {
			String temp = null;
			while ((temp = br.readLine()) != null) {
				if (StringUtil.isBlank(temp))
					continue;
				insertWord(forest, temp);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			br.close();
		}
		return forest;
	}

	public static void insertWord(Forest forest, TrieValue value) {
		_insertWord(forest, value.getKeyword(), value.getParamers());
	}

	/**
	 * insert one word
	 * 
	 * @param forest
	 * @param temp
	 */
	public static void insertWord(WoodInterface forest, String tmp) {
		String[] param = tmp.split("\\s+");
		for (int i = 0; i < param.length; i++) {
			if (StringUtil.isBlank(param[i]))
				try {
					throw new IOException("library error ,locate in " + tmp);
				} catch (IOException e) {
					e.printStackTrace();
				}
			else
				param[i] = WordAlter.alterAlphaAndNumber(param[i]);
		}
		String[] resultParams = new String[param.length - 1];
		for (int j = 1; j < param.length; j++) {
			resultParams[j - 1] = param[j];
		}
		_insertWord(forest, param[0], resultParams);
	}

	private static void _insertWord(WoodInterface forest, String key,
			String[] param) {
		WoodInterface branch = forest;
		char[] chars = key.toCharArray();
		for (int i = 0; i < chars.length; i++) {
			if (i + 1 == chars.length) {
				branch.add(new Branch(chars[i], 3, param));
				// 插入的是Branch，而不是Forest，Forest是Trie树的最外一层
			} else {
				branch.add(new Branch(chars[i], 1, null));
			}
			branch = branch.get(chars[i]);
		}
	}

	/**
	 * delete one word
	 * 
	 * @param forest
	 * @param temp
	 */
	public static void removeWord(Forest forest, String word) {
		WoodInterface branch = forest;
		char[] chars = WordAlter.alterAlphaAndNumber(word).toCharArray();
		for (int i = 0; i < chars.length; i++) {
			if (branch == null)
				return;
			if (chars.length == i + 1) {
				branch.add(new Branch(chars[i], -1, null));
			}
			branch = branch.get(chars[i]);
		}
	}
}