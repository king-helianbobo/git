package org.splitword.soul.utility;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.splitword.soul.domain.Term;
import org.splitword.soul.domain.TermNature;
import org.splitword.soul.domain.TermNatures;
import org.splitword.soul.library.CompanyAttrLib;
import org.splitword.soul.library.NatureLibrary;
import org.splitword.soul.recognition.ForeignNameRecognition;

public class TermUtil {
	private static Log log = LogFactory.getLog(TermUtil.class);
	private static final HashMap<String, int[]> companyMap = CompanyAttrLib
			.getCompanyMap();

	/**
	 * 将两个数词/量词term合并为一个全新的term
	 */
	public static Term makeNewNumTerm(Term from, Term to,
			TermNatures termNatures) {
		Term term = new Term(from.getName() + to.getName(), from.getOffe(),
				termNatures);
		term.getTermNatures().numNature = from.getTermNatures().numNature;
		TermUtil.termLink(term, to.getTo());
		TermUtil.termLink(term.getFrom(), term);
		return term;
	}

	public static void termLink(Term from, Term to) {
		if (from == null || to == null)
			return;
		from.setTo(to);
		to.setFrom(from);
	}

	/**
	 * 将一个term插入到链表中的对应位置
	 */
	public static void insertTerm(Term[] terms, Term term) {
		// 插入到最后面
		Term temp = terms[term.getOffe()];
		term.setNext(null);
		if (temp == null) {
			terms[term.getOffe()] = term;
		} else {
			Term last = temp;
			while ((temp = temp.getNext()) != null) {
				last = temp;
			}
			last.setNext(term);
		}
	}

	/**
	 * 将两个term插入到链表
	 */
	public static void insertTerm(Term[] terms, Term tmpTerm1, Term tmpTerm2) {
		int startOffe = tmpTerm1.getOffe();
		int endOffe = tmpTerm2.getOffe() + tmpTerm2.getName().length() - 1;
		TermUtil.termLink(terms[startOffe].getFrom(), tmpTerm1);
		TermUtil.termLink(tmpTerm1, tmpTerm2);
		TermUtil.termLink(tmpTerm2, terms[endOffe].getTo());
		terms[startOffe] = tmpTerm1;
		terms[endOffe] = tmpTerm2;
	}

	public static void insertTerm(Term[] terms, List<Term> tempList,
			TermNatures nr) { // nr defaults to TermNatures.NR
		StringBuilder sb = new StringBuilder();
		int offe = tempList.get(0).getOffe();
		for (Term term : tempList) {
			sb.append(term.getName());
			terms[term.getOffe()] = null;
		}
		Term term = new Term(sb.toString(), offe, nr);
		terms[term.getOffe()] = term;
	}

	protected static Term setToAndfrom(Term to, Term from) {
		from.setTo(to);
		to.setFrom(from);
		return from;
	}

	// set new word's nature
	public static void parseNewWordNature(Term term) {
		if (!TermNature.NW.equals(term.getNatrue())) {
			return;
		}
		String name = term.getName();
		if (name.length() <= 3) {
			return;
		}
		// if this term is foreign name
		if (ForeignNameRecognition.isFName(name)) {
			term.setNature(NatureLibrary.getNature("nrf"));
			return;
		}
		List<Term> subTerm = term.getSubTermList();
		term.setSubTermList(subTerm);
		Term first = subTerm.get(0);
		Term last = subTerm.get(subTerm.size() - 1);
		int[] is = companyMap.get(first.getName()); // is organization?
		is = companyMap.get(last.getName());
		int all = 0;
		if (is != null)
			all += is[1];
		if (all > 1000) {
			term.setNature(NatureLibrary.getNature("nt"));
			return;
		}
	}

	/**
	 * 从from到to生成term列表
	 * 
	 * @param terms
	 * @param from
	 * @param to
	 * @return
	 */
	public static List<Term> getSubTermList(Term from, Term to) {
		List<Term> subTerm = new ArrayList<Term>();
		StringBuilder builder = new StringBuilder();
		builder.append("subTermList: ");
		while ((from = from.getTo()) != to) {
			builder.append(from.getName() + " ");
			subTerm.add(from);
		}
		log.info(builder.toString());
		return subTerm;
	}
}
