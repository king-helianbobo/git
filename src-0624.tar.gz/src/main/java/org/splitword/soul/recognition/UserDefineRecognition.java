package org.splitword.soul.recognition;

import org.splitword.soul.domain.Term;
import org.splitword.soul.domain.TermNature;
import org.splitword.soul.domain.TermNatures;
import org.splitword.soul.utility.Forest;
import org.splitword.soul.utility.TermUtil;
import org.splitword.soul.utility.WoodInterface;

public class UserDefineRecognition {
	private Term[] terms = null;
	// private WoodInterface forest = UserDefineLibrary.userDefineForest1;
	private WoodInterface forest = null;
	private WoodInterface branch = forest;
	private int startOffe = -1;
	private int endOffe = -1;
	private String tmpNature;

	public UserDefineRecognition(Term[] terms) {
		this.terms = terms;
	}

	public UserDefineRecognition() {
		reset();
	}

	public UserDefineRecognition(Term[] terms, Forest forest) {
		this.terms = terms;
		if (forest != null) {
			this.forest = forest;
			branch = this.forest;
		}
		reset();
	}
	public void resetData(Term[] terms, Forest forest) {
		this.terms = terms;
		if (forest != null) {
			this.forest = forest;
			branch = this.forest;
		}
		reset();
	}

	public void recognition() { // 识别用户自定义词典中的词
		if (branch == null) {
			return;
		}
		int length = terms.length - 1;
		boolean flag = true;
		for (int i = 0; i < length; i++) {
			if (terms[i] == null)
				continue;
			if (branch == forest)
				flag = false;
			else
				flag = true;

			branch = termStatus(branch, terms[i]);
			if (branch == null) {
				if (startOffe != -1) {
					i = startOffe;
				}
				reset();
			} else if (branch.getStatus() == 3) { // term 存在于用户词典
				endOffe = i;
				tmpNature = branch.getParams()[0];
				// tempFreq = ObjectBean.getInt(branch.getParams()[1], 50);
				if (startOffe != -1 && startOffe < endOffe) {
					i = startOffe;
					makeNewTerm();
					reset();
				} else
					reset();
			} else if (branch.getStatus() == 2) {
				endOffe = i;
				if (startOffe == -1) {
					startOffe = i;
				} else {
					tmpNature = branch.getParams()[0];
					if (flag) // 如果不在树的顶层
						makeNewTerm();
				}
			} else if (branch.getStatus() == 1) {
				if (startOffe == -1) {
					startOffe = i;
				}
			}
		}
		if (startOffe != -1 && startOffe < endOffe) {
			makeNewTerm();
		}
	}

	private void makeNewTerm() {
		StringBuilder sb = new StringBuilder();
		for (int j = startOffe; j <= endOffe; j++) { // 注意，这里是小于等于关系
			if (terms[j] == null) {
				continue;
			} else {
				sb.append(terms[j].getName());
			}
		}
		TermNatures termNatures = new TermNatures(new TermNature(tmpNature, 1));
		Term term = new Term(sb.toString(), startOffe, termNatures);
		term.setNature(termNatures.termNatures[0].natureInLib);
		term.selfScore = -1 * sb.toString().length();
		TermUtil.insertTerm(terms, term);
	}

	private void reset() {
		startOffe = -1;
		endOffe = -1;
		tmpNature = null;
		branch = forest;
	}

	/***
	 * termStatus (传入一个term 返回这个term的状态)
	 * 
	 * @param branch
	 * @param term
	 * @return
	 * @author liubo
	 * @date 2014年4月1日 下午4:31:26
	 */
	private WoodInterface termStatus(WoodInterface branch, Term term) {
		String name = term.getName();
		for (int j = 0; j < name.length(); j++) {
			branch = branch.get(name.charAt(j));
			if (branch == null) {
				return null;
			}
		}
		return branch;
	}

}
