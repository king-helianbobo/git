package org.splitword.soul.recognition;

import java.util.LinkedList;
import java.util.List;

import org.splitword.soul.domain.NatureInLib;
import org.splitword.soul.domain.Term;
import org.splitword.soul.domain.TermNature;
import org.splitword.soul.domain.TermNatures;
import org.splitword.soul.utility.MathUtil;

public class NatureRecognition {
	// private static final Log log =
	// LogFactory.getLog(NatureRecognition.class);
	private NatureTerm root = new NatureTerm(TermNature.BEGIN);
	private NatureTerm[] end = { new NatureTerm(TermNature.END) };
	private List<Term> terms = null;
	private NatureTerm[][] natureTermTable = null;

	public NatureRecognition(List<Term> terms) {
		this.terms = terms;
		natureTermTable = new NatureTerm[terms.size() + 1][];
		natureTermTable[terms.size()] = end;
	}

	/**
	 * 词性识别，不一定有用，对vn型的动词，希望获得的是vn，而不是v. 对既是副词d，又是动词v的词，将其词性设为副词，而不管频率。
	 */
	public void recognition() {
		int length = terms.size();
		for (int i = 0; i < length; i++) {
			Term term = terms.get(i);
			TermNatures natures = term.getTermNatures();
			TermNature[] termNatures = natures.termNatures;
			List<String> natureStrs = new LinkedList<String>();
			for (int j = 0; j < termNatures.length; j++) {
				natureStrs.add(termNatures[j].natureInLib.natureStr);
			}
			if (natureStrs.contains("vn") && natureStrs.contains("v")) {
				for (int j = 0; j < termNatures.length; j++) {
					termNatures[j].natureInLib = new NatureInLib("vn");
				}
			} else if (natureStrs.contains("d") && natureStrs.contains("v")) {
				for (int j = 0; j < termNatures.length; j++) {
					termNatures[j].natureInLib = new NatureInLib("d");
				}
			}
			natureTermTable[i] = getNatureTerm(termNatures);
		}
		walk();
	}

	public void walk() {
		int length = natureTermTable.length - 1;
		setScore(root, natureTermTable[0]);
		for (int i = 0; i < length; i++) {
			for (int j = 0; j < natureTermTable[i].length; j++) {
				setScore(natureTermTable[i][j], natureTermTable[i + 1]);
			}
		}
		optimalRoot();
	}

	private void setScore(NatureTerm natureTerm, NatureTerm[] natureTerms) {
		for (int i = 0; i < natureTerms.length; i++) {
			natureTerms[i].setScore(natureTerm);
		}
	}

	private NatureTerm[] getNatureTerm(TermNature[] termNatures) {
		NatureTerm[] natureTerms = new NatureTerm[termNatures.length];
		for (int i = 0; i < natureTerms.length; i++) {
			natureTerms[i] = new NatureTerm(termNatures[i]);
		}
		return natureTerms;
	}

	/**
	 * 获得最可能的词性列表
	 */
	private void optimalRoot() {
		NatureTerm to = end[0];
		NatureTerm from = null;
		int index = natureTermTable.length - 1;
		while ((from = to.from) != null && index > 0) {
			int i = --index;
			terms.get(i).setNature(from.termNature.natureInLib);
			to = from;
		}
	}

	public class NatureTerm {

		public TermNature termNature;
		public double score = 0;
		public double selfScore;
		public NatureTerm from;

		protected NatureTerm(TermNature termNature) {
			this.termNature = termNature;
			selfScore = termNature.frequency + 1;
		}

		public void setScore(NatureTerm natureTerm) {
			double tmpScore = MathUtil.compuNatureFreq(natureTerm, this);
			if (from == null || tmpScore > score) { // 取最大值，因为其结果总大于0
				this.score = tmpScore;
				this.from = natureTerm;
			}
		}

		@Override
		public String toString() {
			return termNature.natureInLib.natureStr + "/" + selfScore;
		}

	}
}
