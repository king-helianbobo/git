package org.splitword.soul.library;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.splitword.soul.utility.Forest;
import org.splitword.soul.utility.IOUtil;
import org.splitword.soul.utility.LibraryToForest;
import org.splitword.soul.utility.MyStaticValue;
import org.splitword.soul.utility.StringUtil;
import org.splitword.soul.utility.TrieValue;
import org.splitword.soul.utility.WordAlter;

public class UserDefineLibrary {
	private static Log log = LogFactory.getLog(UserDefineLibrary.class);
	public static List<Forest> forests = null;
	public static Forest ambiguityForest = null;
	static {
		initUserLibrary();
		initAmbiguityLibrary();
	}

	/**
	 * 
	 * @author LiuBo
	 * @since 2014年1月15日
	 * @param key
	 * @param nature
	 * @param freq
	 *            void
	 */
	public static void insertWordToUserDefineLibrary(String key, String nature,
			int freq) {
		String[] paramers = new String[2];
		paramers[0] = WordAlter.alterAlphaAndNumber(nature);
		paramers[1] = String.valueOf(freq);
		TrieValue value = new TrieValue(WordAlter.alterAlphaAndNumber(key),
				paramers);
		Forest forest = forests.get(0);
		LibraryToForest.insertWord(forest, value);
	}

	private static boolean isOverlap(String str1, String str2) {
		int len1 = str1.length();
		int len2 = str2.length();
		int len = Math.min(len1, len2);
		for (int i = 1; i <= len; i++) {
			if (str1.substring(0, i).equals(str2.substring(len2 - i)))
				return true;
			if (str2.substring(0, i).equals(str1.substring(len1 - i)))
				return true;
		}
		return false;
	}

	private static void checkAmbiguity(BufferedReader br) throws Exception {
		Map<Integer, String> tree = new TreeMap<Integer, String>();
		int i = 0;
		String temp = null;
		while ((temp = br.readLine()) != null) {
			if (StringUtil.isBlank(temp))
				continue;
			String[] param = temp.split("\\s+");
			tree.put(i, param[0]);
			for (int j = 0; j < param.length; j++) {
				if (StringUtil.isBlank(param[j]))
					throw new IOException("ambiguity library error,locate in "
							+ (i + 1) + " line!");
			}
			++i;
		}
		int size = i;
		for (i = 0; i < size; i++) {
			String stri = tree.get(i);
			for (int j = i + 1; j < size; j++) {
				String strj = tree.get(j);
				if (isOverlap(stri, strj)) {
					log.error("word " + stri + " conflict with " + strj);
				}
			}
		}
	}

	/**
	 * load ambiguity sentence library
	 */
	private static void initAmbiguityLibrary() {
		try {
			BufferedReader reader = MyStaticValue.ambiguityLibraryReader();
			// checkAmbiguity(reader);
			// 检查文件是否合法，它不应该再引入歧义，任意两个词之间不应该有重叠
			ambiguityForest = LibraryToForest.makeLibrary(reader, new Forest());
			reader.close();
		} catch (Exception e) {
			log.error("init ambiguity library error.");
			e.printStackTrace();
		}

	}

	// 加载用户自定义词典和补充词典
	private static void initUserLibrary() {
		try {
			forests = new LinkedList<Forest>();
			Forest userDefineForest1 = new Forest();
			loadLibrary(userDefineForest1,
					MyStaticValue.userDefineLibrary1Reader());
			Forest userDefineForest2 = new Forest();
			loadLibrary(userDefineForest2,
					MyStaticValue.userDefineLibrary2Reader());
			Forest userDefineForest3 = new Forest();
			loadLibrary(userDefineForest3,
					MyStaticValue.userDefineLibrary3Reader());
			forests.add(userDefineForest2);
			forests.add(userDefineForest1);
			forests.add(userDefineForest3);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void loadLibrary(Forest forest, BufferedReader br) {
		String temp = null;
		TrieValue value = null;
		try {
			while ((temp = br.readLine()) != null) {
				if (StringUtil.isBlank(temp)) {
					continue;
				} else {
					String[] strs = WordAlter.alterAlphaAndNumber(temp).split(
							"\\s+");
					if (strs.length % 2 == 0)
						throw new IOException("library error ,locate in "
								+ temp);
					for (int i = 0; i < strs.length; i++) {
						if (StringUtil.isBlank(strs[i]))
							throw new IOException("library error ,locate in "
									+ temp);
					}
					if (strs.length != 3) {
						// "userDefine" would be default termNature
						value = new TrieValue(strs[0], "userDefine", "1000");
					} else
						value = new TrieValue(strs[0], strs[1], strs[2]);
					LibraryToForest.insertWord(forest, value);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			IOUtil.close(br);
			br = null;
		}
	}

	public static void removeWordInForest(Forest forest, String word) {
		if (forest == null)
			forest = forests.get(0);
		LibraryToForest.removeWord(forest, word);
	}

}
