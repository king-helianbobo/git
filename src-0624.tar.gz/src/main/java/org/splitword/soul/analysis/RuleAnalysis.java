package org.splitword.soul.analysis;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.splitword.soul.domain.Term;
import org.splitword.soul.domain.ViterbiGraph;
import org.splitword.soul.recognition.AsianNameRecognition;
import org.splitword.soul.recognition.ForeignNameRecognition;
import org.splitword.soul.recognition.NatureRecognition;
import org.splitword.soul.recognition.NumberRecognition;
import org.splitword.soul.recognition.RuleRecogntion;
import org.splitword.soul.recognition.UserDefineRecognition;
import org.splitword.soul.utility.Forest;
import org.splitword.soul.utility.MyStaticValue;

public class RuleAnalysis extends Analysis {

	private static Log log = LogFactory.getLog(RuleAnalysis.class);
	private UserDefineRecognition userDefineRecognition = new UserDefineRecognition();
	private boolean bRule = false;

	@Override
	protected List<Term> getResult(final ViterbiGraph graph) {
		Merger merger = new Merger() {
			@Override
			public List<Term> merge() {
				graph.walkPath();// construct optimal path
				if (graph.hasPerson && MyStaticValue.allowNameRecognize) {
					new AsianNameRecognition(graph.terms).recognition();
					graph.walkPathByScore();
					AsianNameRecognition.nameAmbiguity(graph.terms);
					new ForeignNameRecognition(graph.terms).recognition();
					graph.walkPathByScore();
				}
				if (graph.hasNum) // recognize consecutive numbers
					NumberRecognition.recognition(graph.terms);
				if (forests == null) {
					userDefineRecognize(graph, null);
				} else {
					// only use base array and wuxi.dic from sogou
					for (int i = 0; i < 2; i++) {
						Forest forest = forests.get(i);
						if (forest == null)
							continue;
						userDefineRecognize(graph, forest);
					}
				}
				if (bRule)
					RuleRecogntion.recognition(graph.terms);
				if (bNature) { // nature recognition
					List<Term> result = getResult();
					new NatureRecognition(result).recognition();
				}
				return getResult();
			}

			private void userDefineRecognize(final ViterbiGraph graph,
					Forest forest) {
				userDefineRecognition.resetData(graph.terms, forest);
				userDefineRecognition.recognition();
				graph.rmLittlePath();
				graph.walkPathByScore();
			}

			private List<Term> getResult() {
				List<Term> result = new ArrayList<Term>();
				int length = graph.terms.length - 1;
				for (int i = 0; i < length; i++) {
					if (graph.terms[i] != null) {
						result.add(graph.terms[i]);
					}
				}
				return result;
			}
		};
		return merger.merge();
	}

	public List<Term> parse(String str) {
		return this.parseStr(str);
	}

	public RuleAnalysis(boolean bNature, boolean bRule) {
		this.bNature = bNature;
		this.bRule = bRule;
	}
}
