package org.splitword.soul.domain;

import org.splitword.soul.library.NatureLibrary;

public class TermNature {
	public static final TermNature BEGIN = new TermNature("始##始", 1);
	public static final TermNature END = new TermNature("末##末", 1);
	public static final TermNature M = new TermNature("m", 1);
	public static final TermNature EN = new TermNature("en", 1);
	public static final TermNature userDefine = new TermNature("userDefine", 1);
	public static final TermNature NR = new TermNature("nr", 1);
	// Chinese, Korea or Foreign Name
	public static final TermNature NRF = new TermNature("nrf", 1);
	// foreign name
	public static final TermNature NT = new TermNature("nt", 1);// organization
	public static final TermNature NW = new TermNature("nw", 1); // new word
	public static final TermNature NULL = new TermNature("null", 1);

	public NatureInLib natureInLib;
	public int frequency;

	public TermNature(String natureStr, int frequency) {
		this.natureInLib = NatureLibrary.getNature(natureStr);
		this.frequency = frequency;
	}

	public static TermNature[] setNatureStrToArray(String natureStr, String word) {
		natureStr = natureStr.substring(1, natureStr.length() - 1);
		String[] split = natureStr.split(",");
		String[] strs = null;
		Integer frequency = null;
		TermNature[] all = new TermNature[split.length];
		for (int i = 0; i < split.length; i++) {
			strs = split[i].split("=");
			frequency = Integer.parseInt(strs[1]);
			all[i] = new TermNature(strs[0].trim(), frequency);
		}
		return all;
	}

	@Override
	public String toString() {
		return this.natureInLib.natureStr + "/" + frequency;
	}
}
