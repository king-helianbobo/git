package org.splitword.soul.keyword;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.elasticsearch.application.query.TermPojo;
import org.elasticsearch.plugin.EsStaticValue;
import org.junit.Assert;
import org.splitword.lionsoul.jcseg.util.ChineseHelper;
import org.splitword.soul.analysis.BasicAnalysis;
import org.splitword.soul.domain.KeyWord;
import org.splitword.soul.domain.Term;
import org.splitword.soul.utility.MyStaticValue;
import org.splitword.soul.utility.StringUtil;

public class KeyWordComputer {
	private final static Log log = LogFactory.getLog(KeyWordComputer.class);
	private int nKeyword = 10;
	public static int totalDocumentFreq = 860000;
	private static final Map<String, Double> natureScore = new HashMap<String, Double>();
	public static Map<String, TermPojo> termPojoMap = new TreeMap<String, TermPojo>();
	private static boolean loaded = false;
	private static final Lock LOCK = new ReentrantLock();

	public KeyWordComputer(int nKeyword) {
		this.nKeyword = nKeyword;
	}

	public KeyWordComputer() {
	}

	public String computeKeywords(String title, String content) {
		List<KeyWord> keywords = this.computeTfIdf(title, content);
		StringBuilder builder = new StringBuilder();
		if (keywords.isEmpty())
			return "null";
		else {
			for (KeyWord word : keywords)
				builder.append(word.toString() + "\t");
			return builder.toString();
		}
	}

	private static void loadData() {
		if (loaded)
			return;
		LOCK.lock();
		if (loaded) {
			LOCK.unlock();
			return;
		}
		try {
			loadFreqMap();
			loaded = true;
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			LOCK.unlock();
		}
	}

	private static void loadFreqMap() throws IOException {
		BufferedReader br = MyStaticValue.termPojoReader();
		String temp = null;
		int maxDocFreq = -1;
		while ((temp = br.readLine()) != null) {
			String result = temp.trim();
			String[] texts = result.split("\\s+");
			Assert.assertEquals(texts.length, 6);
			String name = texts[0];
			String nature = texts[1];
			int docFreq = Integer.valueOf(texts[2]);
			int totalFreq = Integer.valueOf(texts[3]);
			int titleFreq = Integer.valueOf(texts[4]);
			int contentFreq = Integer.valueOf(texts[5]);
			TermPojo pojo = new TermPojo(name, nature, docFreq, totalFreq,
					titleFreq, contentFreq);
			Assert.assertTrue(termPojoMap.get(name) == null);
			Assert.assertTrue(totalFreq == (titleFreq + contentFreq));
			if (docFreq > maxDocFreq)
				maxDocFreq = docFreq;
			termPojoMap.put(name, pojo);
		}
		totalDocumentFreq = (maxDocFreq + 1000);
		log.info("totalDocument freq is " + totalDocumentFreq);
		br.close();
	}

	static {
		// loadData();
		// 忽略标点符号，生僻词，数词
		natureScore.put("null", 0.0);
		natureScore.put("w", 0.0);
		natureScore.put("en", 0.0);
		natureScore.put("m", 0.0);
		// 降低习惯用语，形容词，助词，介词，语气词，连词的权重
		natureScore.put("l", 0.0);
		natureScore.put("a", 0.0);
		natureScore.put("u", 0.0);
		natureScore.put("p", 0.0);
		natureScore.put("x", 0.0);
		natureScore.put("y", 0.0);
		natureScore.put("z", 0.0);
		natureScore.put("c", 0.0);
		// 动词，代词
		natureScore.put("v", 0.0);
		natureScore.put("vn", 0.0);
		natureScore.put("vd", 0.0);
		natureScore.put("r", 0.0);
		// 名词性Term
		natureScore.put("nr", 1.0);
		natureScore.put("nrf", 1.0);
		natureScore.put("nw", 3.0);
		natureScore.put("nt", 3.0);
		natureScore.put("nz", 3.0);
		natureScore.put("rule", 2.0);
		natureScore.put("userwuxi", 3.0);

	}

	/******************************* private function **********************************/
	private List<KeyWord> computeTfIdf(String title, String content) {
		if (StringUtil.isBlank(title))
			title = "#";
		if (StringUtil.isBlank(content))
			content = "#";
		BasicAnalysis analysis = new BasicAnalysis(true);
		List<Term> parse1 = analysis.parse(title);
		List<Term> parse2 = analysis.parse(content);
		List<Term> list = new LinkedList<Term>();
		list.addAll(parse1);
		list.addAll(parse2);
		int titleSize = parse1.size();
		return computeArticleTfIdf(list, titleSize);
	}

	private int termDocumentFreq(String name) {
		loadData(); // load frequency map
		if (!termPojoMap.containsKey(name))
			return 0;
		else {
			TermPojo pojo = termPojoMap.get(name);
			int docFreq = pojo.getDocFreq();
			return docFreq;
		}
	}

	private List<KeyWord> computeArticleTfIdf(List<Term> parse, int titleSize) {
		Map<String, KeyWord> kwMap = new HashMap<String, KeyWord>();
		int size = parse.size();
		for (int i = 0; i < parse.size(); i++) {
			// first appearance position as weight coefficients
			Term term = parse.get(i);
			double weight = 0.0;
			if (i < titleSize)
				weight = computeWeight(term, true, i, size);
			else
				weight = computeWeight(term, false, i, size);
			if (weight <= 0.000001f)
				continue;
			KeyWord keyword = kwMap.get(term.getName());
			if (keyword == null) {
				int docFreq = termDocumentFreq(term.getName());
				if (docFreq <= 5) // ignore occasional term
					continue;
				final double totalFreq = (double) totalDocumentFreq;
				double idf = Math.log(0.001 * totalFreq + 1000.0 * totalFreq
						/ ((double) docFreq + 1.0));
				keyword = new KeyWord(term.getName(), idf, weight);
				kwMap.put(term.getName(), keyword);
			} else {
				keyword.increTermFreq();
			}
		}
		double maxRatio = -100.0;
		double minRatio = 100.0;
		for (String name : kwMap.keySet()) {
			KeyWord keyword = kwMap.get(name);
			int freq = keyword.getTermFreq();
			double ratio = (double) freq / (double) size;
			if (ratio > maxRatio)
				maxRatio = ratio;
			if (ratio < minRatio)
				minRatio = ratio;
		}
		for (String name : kwMap.keySet()) {
			KeyWord keyword = kwMap.get(name);
			int freq = keyword.getTermFreq();
			double ratio = (double) freq / (double) size;
			double termFreq = (ratio - minRatio) * (4.2 - 0.1)
					/ (maxRatio - minRatio) + 0.1;
			keyword.score(termFreq);
		}
		Set<KeyWord> treeSet = new TreeSet<KeyWord>(kwMap.values());
		List<KeyWord> arrayList = new ArrayList<KeyWord>(treeSet);
		List<KeyWord> result = new ArrayList<KeyWord>();
		for (int i = 0; i < arrayList.size(); i++) {
			KeyWord kw = arrayList.get(i);
			String stri = kw.toString();
			boolean contain = true;
			for (int j = 0; j < arrayList.size(); j++) {
				if (i == j)
					continue;
				String strj = arrayList.get(j).toString();
				Assert.assertTrue(!stri.equals(strj));
				if (strj.indexOf(stri) >= 0) {
					contain = false;
				}
			}
			if (contain)
				result.add(kw);
		}
		if (result.size() <= nKeyword)
			return result;
		else
			return result.subList(0, nKeyword);
	}

	boolean passThisTerm(String name) {
		if (!ChineseHelper.allChineseChar(name))
			return false;
		for (int i = 0; i < name.length(); i++) {
			String c = String.valueOf(name.charAt(i));
			if (EsStaticValue.stopWordsSet.contains(c)) {
				return false;
			}
		}
		return true;
	}

	private double computeWeight(Term term, boolean belongTitle, int seqNumber,
			int totalNumber) {
		String name = term.getName().trim();
		if (name.length() < 2) {
			return 0;
		} else if (!passThisTerm(name))
			return 0;
		String pos = term.getNatrue().natureStr;
		Double posScore = natureScore.get(pos);
		if (posScore == null && pos.startsWith("n")) {
			posScore = (double) 1.0f;
		} else if (posScore == null)
			return 0;
		else if (posScore < 0.00001f) {
			return 0;
		}
		if (belongTitle) {
			return 3 * posScore;
		} else {
			double score = (totalNumber - seqNumber) / (double) totalNumber;
			double normalized = 0.4 + 0.6 * score;
			return normalized * posScore;
		}
	}
}
