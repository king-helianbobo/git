package org.soul.elasticsearch.test;

import static org.elasticsearch.common.xcontent.XContentFactory.jsonBuilder;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.io.MapWritable;
import org.elasticsearch.action.admin.indices.create.CreateIndexResponse;
import org.elasticsearch.action.admin.indices.exists.indices.IndicesExistsResponse;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.elasticsearch.common.xcontent.XContentBuilder;
import org.elasticsearch.hadoop.cfg.ConfigurationOptions;
import org.elasticsearch.hadoop.cfg.Settings;
import org.elasticsearch.hadoop.cfg.SettingsManager;
import org.elasticsearch.hadoop.mr.MapReduceWriter;
import org.elasticsearch.hadoop.rest.InitializationUtils;
import org.elasticsearch.hadoop.rest.RestClient;
import org.elasticsearch.hadoop.serailize.IndexCommand;
import org.elasticsearch.hadoop.serailize.MapWritableIdExtractor;
import org.elasticsearch.hadoop.serailize.SerializationUtils;
import org.elasticsearch.hadoop.util.BytesArray;
import org.elasticsearch.hadoop.util.WritableUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class SogouSpellCheckTest {
	private final Log log = LogFactory.getLog(SogouSpellCheckTest.class);
	private RestClient client;
	private Settings settings;
	TransportClient transportClient;
	private String indexName = "spellcheck";
	private String typeName = "table";
	// private String hostName = "192.168.50.75";
	private String hostName = "localhost";
	private int port = 9300;

	@Before
	public void startNode() throws Exception {
		transportClient = new TransportClient()
				.addTransportAddress(new InetSocketTransportAddress(hostName,
						port));
		Properties properties = new Properties();
		properties.put(ConfigurationOptions.ES_WRITE_OPERATION, "index");
		properties.put(ConfigurationOptions.ES_MAPPING_ID, "number");
		properties.put(ConfigurationOptions.ES_RESOURCE, indexName + "/"
				+ typeName);
		properties.put("es.host", hostName);
		settings = SettingsManager.loadFrom(properties);
		SerializationUtils.setValueWriterIfNotSet(settings,
				MapReduceWriter.class, log);
		InitializationUtils.setIdExtractorIfNotSet(settings,
				MapWritableIdExtractor.class, log);
		client = new RestClient(settings);
	}

	@Test
	public void createIndexAndFillData() {
		createIndexMapping();
		try {
			fillIndexData();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void createIndexMapping() {
		try {
			IndicesExistsResponse existsResponse = transportClient.admin()
					.indices().prepareExists(indexName).execute().actionGet();
			if (existsResponse.isExists()) { // if index exist, delete it
				transportClient.admin().indices().prepareDelete(indexName)
						.execute().actionGet();
			}

			XContentBuilder builder = (XContentBuilder) jsonBuilder()
					.startObject().startObject("settings")
					.startObject("analysis").startObject("analyzer")
					.startObject("default").field("type", "whitespace")
					.endObject().endObject().endObject().endObject();

			String settings = builder.string();
			log.info(settings);
			CreateIndexResponse createIndexResponse = transportClient.admin()
					.indices().prepareCreate(indexName).setSource(settings)
					.execute().actionGet();
			assertThat(createIndexResponse.isAcknowledged(), is(true));
			transportClient.admin().cluster().prepareHealth(indexName)
					.setWaitForGreenStatus().execute().actionGet();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	@After
	public void closeResources() {
		transportClient.close();
		client.close();
	}

	private void fillIndexData() throws Exception {
		IndexCommand command = new IndexCommand(settings);
		InputStream in = new FileInputStream("/mnt/f/tmp/Sogou.dic");
		BufferedReader reader = new BufferedReader(new InputStreamReader(in,
				"UTF-8"));
		final int size = 100;
		int startNumber = 0;
		List<String> result;
		BytesArray data = new BytesArray(160 * 1024);
		while ((result = readOneLine(reader, size)) != null) {
			for (int i = 0; i < result.size(); i++) {
				Map<String, String> entry = new HashMap<String, String>();
				entry.put("number", String.valueOf(startNumber++));
				entry.put("content", result.get(i));
				MapWritable wr = (MapWritable) WritableUtils.toWritable(entry);
				int entrySize = command.prepare(wr);
				if (entrySize + data.size() > data.capacity()) {
					client.bulk(settings.getIndexType(), data.bytes(),
							data.size());
					data.reset();
				}
				command.write(wr, data);
			}
		}
		client.bulk(settings.getIndexType(), data.bytes(), data.size());
	}
	public static List<String> readOneLine(BufferedReader reader, int size)
			throws IOException {
		String temp = null;
		List<String> entry = new LinkedList<String>();
		int n = 0;
		while ((temp = reader.readLine()) != null) {
			temp = temp.trim();
			entry.add(temp);
			n++;
			if (n >= size)
				break;
		}
		if (entry.size() > 0)
			return entry;
		else
			return null;
	}
}
