package org.soul.lucene.test;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.core.WhitespaceTokenizer;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
import org.elasticsearch.plugin.EsStaticValue;
import org.elasticsearch.plugin.PinyinAnalyzer;
import org.elasticsearch.plugin.analyzer.EdgeNGramTokenFilter;
import org.elasticsearch.plugin.analyzer.PinyinTokenFilter;
import org.elasticsearch.plugin.analyzer.SoulIndexAnalyzer;
import org.splitword.lionsoul.jcseg.util.PinyinFormat;
import org.splitword.lionsoul.jcseg.util.PinyinHelper;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class NewPinyinTest {

	private Log log = LogFactory.getLog(NewPinyinTest.class);
	String[] stopWords = {"and", "of", "the", "to", "is", "their", "can",
			"all", "i", "in"};

	TokenStream result = null;
	@Test
	public void getPinYinTest() {
		String src = "沈从文";
		StringBuilder pinyinBuf = new StringBuilder();
		PinyinFormat outputFormat = PinyinFormat.WITHOUT_TONE;
		try {
			for (int i = 0; i < src.length(); i++) {
				String[] pinYins = PinyinHelper.convertToPinyinArray(
						src.charAt(i), outputFormat);
				if (pinYins != null && pinYins.length > 0) {// Chinese words
					for (int j = 0; j < pinYins.length; j++)
						pinyinBuf.append(pinYins[j] + " ");
					// pinyinBuf.append(pinYins[0] + " ");
				} else {// not Chinese words
					pinyinBuf.append(src.charAt(i));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		log.info(pinyinBuf.toString());
	}

	@Test
	public void TestSoulIndexAnalyzer() {
		Analyzer analyzer = new SoulIndexAnalyzer();
		String text4 = "沈从文 兴业银行 中华人民共和国";
		analyze(analyzer, text4);
		String text5 = "军官服现役和服预备役的最高年龄由《中华人民共和国现役军官法》和《中华人民共和国预备役军官法》规定。";
		analyze(analyzer, text5);
	}

	@Test
	public void TestPinyinAnalyzer() {
		Analyzer analyzer = new PinyinAnalyzer();
		String text4 = "沈从文 兴业银行 中华人民共和国 mm";
		analyze(analyzer, text4);
	}
	@Test
	public void TestAnalyzer() {
		String text1 = "沈从文 厦门 长春 长大";
		Reader reader = new StringReader(text1);
		result = new WhitespaceTokenizer(EsStaticValue.LuceneVersion, reader);
		result = new PinyinTokenFilter(result);
		result = new EdgeNGramTokenFilter(result,
				EdgeNGramTokenFilter.Side.FRONT, 2, 20);
		OffsetAttribute offsetAttribute = result
				.addAttribute(OffsetAttribute.class);
		CharTermAttribute charTermAttribute = result
				.addAttribute(CharTermAttribute.class);
		try {
			result.reset();
			while (result.incrementToken()) {
				int startOffset = offsetAttribute.startOffset();
				int endOffset = offsetAttribute.endOffset();
				String term = charTermAttribute.toString();
				log.info("\"" + term + "\"" + " start = " + startOffset
						+ ",end = " + endOffset);
			}
			result.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	@BeforeMethod
	public void beforeMethod() {
	}

	@AfterMethod
	public void afterMethod() {
	}

	@BeforeClass
	public void beforeClass() {

	}

	@AfterClass
	public void afterClass() {
	}

	void analyze(Analyzer analyzer, String text) {
		try {
			TokenStream tokenStream = analyzer.tokenStream("content",
					new StringReader(text));
			tokenStream.reset();
			while (tokenStream.incrementToken()) {
				CharTermAttribute charAttribute = tokenStream
						.getAttribute(CharTermAttribute.class);
				OffsetAttribute offsetAttribute = tokenStream
						.getAttribute(OffsetAttribute.class);
				PositionIncrementAttribute posAttr = tokenStream
						.getAttribute(PositionIncrementAttribute.class);
				log.info("[" + offsetAttribute.startOffset() + ","
						+ offsetAttribute.endOffset() + ","
						+ charAttribute.toString() + ","
						+ posAttr.getPositionIncrement() + "]");
			}
			tokenStream.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
