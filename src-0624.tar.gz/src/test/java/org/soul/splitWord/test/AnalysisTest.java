package org.soul.splitWord.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.elasticsearch.plugin.EsStaticValue;
import org.splitword.soul.analysis.BasicAnalysis;
import org.splitword.soul.domain.Term;
import org.splitword.soul.keyword.WordExtract;
import org.splitword.soul.library.UserDefineLibrary;
import org.splitword.soul.utility.DictionaryReader;
import org.splitword.soul.utility.FilterModifyWord;
import org.splitword.soul.utility.MyStaticValue;
import org.splitword.soul.utility.StringUtil;
import org.testng.annotations.Test;

public class AnalysisTest {
	private final Log log = LogFactory.getLog(AnalysisTest.class);

	@Test
	public void basicSplitTest() {
		BasicAnalysis analysis = new BasicAnalysis(true);
		String[] texts = {
				"斯大林和老毛一样都是红色暴君，希特勒是个杀人魔王，巴洛斯说俞志龙和陈举亚是南京维数公司的,协会主席亚拉·巴洛斯说他们开始寻找野生金刚鹦鹉,补办结婚证，蠡园中学,驾驶证丢了，驾驶证更换服务，我家住在木樨苑的左家里",
				"结婚的和尚未结婚的和尚不是一类和尚,5.14公顷，三十.一四平方公里不等于.14平方米,《三国志》是一本史书，我整天去她们家吃“霸王餐”，\"牡丹亭\"是本戏剧吗？三十.一四《太阁立志传》是一本史书，我整天去她们家吃“太阁立志传xx”，\"太阁立志\"是本戏剧吗？三十点一四等于30.14",
				"无锡市夹城里中心小学 扬北、梁园、银杏苑、谈渡、纳新社居委、夹城社居委、木樨苑、家乐花园、振新路、南洋花园、金乐华庭、健康一村13-44号、51-71号、80-91号、小木桥南、开源路、前坭、后坭、积善里、宝善里、冰池头、健康二村、建筑新村、西水东城一期 无锡市扬名中心小学本部 逸常里（8-9号）、 清二村（除虞湾里、邓湾里、纪巷、糜巷、杜巷、严巷、小朱巷外）畅舜苑、扬名村（清扬路以西）、金星村北（盛新桥310—315、401—411、609—615、701—711、802—829）、曹张新村、盛新里、红星苑、锡星苑、新世纪公寓 无锡市花园实验小学 清扬新村1－236号、水仙里、塘泾新村、翠云新村、南长街335-698、教育宿舍、动力家舍、清一村（东、西、新坝头、大车口、马家庄、东夹里）、南扬新村、清名新村、清名二村、清二村（虞湾里、邓湾里、杜巷、纪巷、严巷、小朱巷、糜巷）、永泰新村、永泰二村、高巷、奚家弄1-29、铁匠弄等地",
				"保安服务需要什么程序文件吗,歌唱梅花谣？",
				"几年来王玉兰与博爱车队义务接送高考生一百多名,一直协助斯诺登的维基解密",
				"例如我们叫布什总统，为何不叫乔治总统。我们说爱因斯坦，而不是叫他阿尔伯特。",
				"，没有批准,安全监控",
				"哆啦Ａ梦是个玩具，什么是哆啦a梦？",
				"B超更x-射线有关系吗？",
				"漂亮mm打拳皇ova很厉害",
				"为确保2014无锡国际马拉松赛安全顺利举办，维护道路交通安全，根据《中华人民共和国道路交通安全法》等法律、法规的规定，决定于2014年4月12日、13日对太湖大道、隐秀路、环湖路、建筑路、梁湖路、犊山大坝、十里芳堤、鼋渚路、山水东路、震泽路、缘溪道、高浪路、吴都路、丰润道、和风路、清舒道、立德道、观山路、立信大道、蠡湖大道、金石路、万顺道、大剧院路、丝竹路、金城西路、蠡溪路、望山路等相关比赛道路实施临时交通限制措施，现就有关事宜通告如下：一、2014无锡国际马拉松赛比赛线路和方向：赛道1（全程马拉松）：太湖大道隐秀路口（起点）——太湖大道——梁湖路——建筑路——环湖路（永固路口折返）——犊山大坝——十里芳堤——鼋渚路——山水东路——震泽路——缘溪道——高浪路——江南大学北门——江南大学校区——江南大学东门——吴都路——丰润道——和风路——清舒道——吴都路——立德道——观山路——立信大道——吴都路——蠡湖大道——金石路——万顺道——大剧院路——蠡湖大桥东匝道——蠡湖大桥——金城西路——蠡溪路——隐秀路——望山路（240米折返）——隐秀路——隐秀路中南西路口（终点）。赛道2（半程马拉松）：太湖大道隐秀路口（起点）——太湖大道——梁湖路——建筑路——环湖路（永固路口折返）——犊山大坝——十里芳堤——鼋渚路——山水东路——高浪路——金石路——金石路匝道——丝竹路（240米折返）——金石路匝道——蠡湖大桥——金城西路——蠡溪路——隐秀路——隐秀路中南西路口（终点）。赛道3（迷你马拉松）：太湖大道隐秀路口（起点）——太湖大道——环湖路——望山路——隐秀路——隐秀路中南西路口（终点）。",
				"【信息与服发局】旅游文化产业相关工作 目标任务：全年旅游文化产业产值增长 20% 以上；" };
		for (String str : texts) {
			List<Term> parse = analysis.parse(str);
			log.info(parse);
		}
	}

	// @Test
	public void keywordExtractTest() {
		BasicAnalysis analysis = new BasicAnalysis(true);
		String text = "查询编号： WX20131021036 信件标题： 有可能偷排污水 信件内容： 在我们这边宏源技校，现在是保利地产，原学校宿舍后面我看见工人排了一根下水管，做得很隐密。我不知道他们排的水是不是雨水还是污水，排水管往河里排有没有通过你们，因为我们那里的河今己年水质才好一点，如偷排希望你们查看一下对我们老百姓有一个交待。 信件分类： 咨询 内容分类： 环境市容 接收时间： 2013-10-21 11:20:44 接收部门： 市环保局 答复时间： 2013-10-21 13:05:04 答复部门： 市环保局 处理结果： 经环境监察人员现场查看，投诉人反映的校舍旁有新安装一根排水管，经向项目管理人员了解，该排水管是建筑方提前铺设，原本计划用于新建房地产项目中挖地基进行排水作业，目前还未使用，现场已要求企业不得将建设过程中可能产生的污水通过该排水管排往河道内。大队将做好对该建设项目的监察工作，如发现违法排污现象，将依法进行处理，建议投诉人留下联系方式，以便于大队及时将调查情况回复投诉人，如有情况反映，可第一时间联系新区环保热线电话（15251524891）。 满意度评价： 满意";
		List<Term> parse = analysis.parse(text);
		log.info(parse);
		StringBuilder builder = new StringBuilder();
		for (int i = 0; i < parse.size(); i++) {
			Term term = parse.get(i);
			String name = term.getName();
			String nature = term.getNatrue().natureStr;
			if (StringUtil.isBlank(nature) || StringUtil.isBlank(name))
				continue;
			if (nature.equals("null"))
				continue;
			if (nature.startsWith("vn") || nature.startsWith("n")) {
				log.info(term);
				builder.append(name);
				builder.append("\t");
			}

		}
		log.info(builder.toString());
		WordExtract extractor = new WordExtract();// use text rank algorithm
		extractor.setPrecisionHigh();
		Map<String, Integer> map = extractor.extract(builder.toString(), 10);
		for (String str : map.keySet())
			log.info(str + "," + map.get(str));
	}

	@Test
	public void stopWordTest() {
		String parseStr = "哆啦Ａ梦是个玩具";
		Set<String> hs = EsStaticValue.stopWordsSet;
		try {
			BasicAnalysis analysis = new BasicAnalysis(new StringReader(
					parseStr));
			Term next = null;
			while ((next = analysis.next()) != null) {
				if (!hs.contains(next.getName())) {
					log.info("[" + next.getName() + "] not skipped");
				} else {
					log.info("[" + next.getName() + "] will skip");
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// @Test
	public void userDefineLibraryTest() {
		BasicAnalysis analysis = new BasicAnalysis(true);
		String str = "soul中文分词是一个不错的系统";
		UserDefineLibrary.insertWordToUserDefineLibrary("soul中文分词",
				"userDefine", 1000);
		List<Term> terms = analysis.parse(str);
		log.info(terms);
		UserDefineLibrary.removeWordInForest(null, "soul中文分词");
		terms = analysis.parse(str);
		log.info(terms);
		str = "上海电力a与2012年财务报表";
		UserDefineLibrary.insertWordToUserDefineLibrary("上海电力Ａ", "词性", 1000);
		terms = analysis.parse(str);
		log.info(terms);
	}

	// @Test
	public void FilterAndUpdateNatureTest() {
		BasicAnalysis analysis = new BasicAnalysis(true);
		HashMap<String, String> updateDic = new HashMap<String, String>();
		updateDic.put("停用词", "userDefine"); // userDefine TermNature
		updateDic.put("并且", "_stop");// use termNature _stop
		updateDic.put("12345", "number");// 数字
		updateDic.put("但是", FilterModifyWord._stop);
		updateDic.put("，", FilterModifyWord._stop);
		FilterModifyWord.setUpdateDic(updateDic);
		List<Term> parse = analysis
				.parse("过滤停用词，并且修正词12345为用户自定义词性，但是必须设置停用词词典");
		parse = FilterModifyWord.modifResult(parse);
		log.info(parse);
	}

}
