package com.soul.elasticsearch.test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import junit.framework.Assert;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.io.MapWritable;
import org.elasticsearch.hadoop.cfg.ConfigurationOptions;
import org.elasticsearch.hadoop.cfg.Settings;
import org.elasticsearch.hadoop.cfg.SettingsManager;
import org.elasticsearch.hadoop.mr.MapReduceWriter;
import org.elasticsearch.hadoop.rest.InitializationUtils;
import org.elasticsearch.hadoop.rest.RestClient;
import org.elasticsearch.hadoop.serailize.MapWritableIdExtractor;
import org.elasticsearch.hadoop.serailize.SerializationUtils;
import org.elasticsearch.hadoop.serailize.UpdateCommand;
import org.elasticsearch.hadoop.util.BytesArray;
import org.elasticsearch.hadoop.util.WritableUtils;
import org.splitword.soul.utility.OfficialChars;
import org.splitword.soul.utility.WordAlter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

public class OfficialUpdateTest {
	private Log log = LogFactory.getLog(OfficialUpdateTest.class);

	private RestClient client;
	private Settings settings;

	@BeforeClass
	public void startNode() throws Exception {
		Properties properties = new Properties();
		properties.put(ConfigurationOptions.ES_WRITE_OPERATION, "update");
		properties.put(ConfigurationOptions.ES_MAPPING_ID, "id");
		String resource = OfficialDataTest.indexName + "/"
				+ OfficialDataTest.typeName;
		properties.put(ConfigurationOptions.ES_RESOURCE, resource);
		properties.put(ConfigurationOptions.ES_HOST, OfficialDataTest.hostName);
		properties.put(ConfigurationOptions.ES_UPSERT_DOC, false);
		settings = SettingsManager.loadFrom(properties);
		SerializationUtils.setValueWriterIfNotSet(settings,
				MapReduceWriter.class, log);
		InitializationUtils.setIdExtractorIfNotSet(settings,
				MapWritableIdExtractor.class, log);
		client = new RestClient(settings);
	}

	@AfterClass
	public void closeResources() {
		client.close();
	}

	// @Test(enabled = true)
	public void testMethod1() throws Exception {
		updateIndexData(OfficialDataTest.sourcePath);
	}

	private Map<String, String> updateThisEntry(Map<String, String> entry) {
		String titleField = "contenttitle";
		String contentField = "content";
		String title = entry.get(titleField);
		String url = entry.get("url");
		String content = entry.get(contentField);
		int invalidCharCount = 0;
		for (int j = 0; j < title.length(); j++) {
			char c = title.charAt(j);
			if (!WordAlter.isLetterOrDigit(c)) {
				invalidCharCount++;
			}
		}
		if (invalidCharCount > 0) {
			log.info("title has invalid chars : " + url + "," + title);
		}
		StringBuilder builder = new StringBuilder();
		for (int j = 0; j < url.length() - 1; j++) {
			char c1 = url.charAt(j);
			char c2 = url.charAt(j + 1);
			if ((c1 == '\\') && (Character.isLetterOrDigit(c2))) {
				builder.append('\\');
				builder.append('\\');
			} else
				builder.append(c1);
		}
		builder.append(url.charAt(url.length() - 1));
		entry.put("url", builder.toString());
		entry.put("id", builder.toString().toLowerCase());
		String result = OfficialChars.removeTimeInContent(title, content);
		String contentConverted = OfficialChars.convertInvalidChars(result);
		String titleConverted = OfficialChars.convertInvalidChars(title);
		entry.put(contentField, contentConverted);
		entry.put(titleField, titleConverted);
		Map<String, String> doc = new HashMap<String, String>();
		log.info(entry.get("id"));
		doc.put("id", entry.get("id"));
		doc.put("keywords", "哈哈\t我逗你玩呢\t只是个测试");
		return doc;
	}

	private void updateIndexData(String path) throws Exception {
		UpdateCommand command = new UpdateCommand(settings);
		TestDataReader reader = new TestDataReader(path, "utf-8");
		List<Map<String, String>> result = null;
		BytesArray data = new BytesArray(256 * 1024);
		while ((result = reader.nextData(20, TestDataReader.OfficialFormat)) != null) {
			for (int i = 0; i < result.size(); i++) {
				Map<String, String> tmpEntry = result.get(i);
				Map<String, String> entry = updateThisEntry(tmpEntry);
				Assert.assertEquals(2, entry.size());
				MapWritable writable = (MapWritable) WritableUtils
						.toWritable(entry);
				int entrySize = command.prepare(writable);
				log.info(entrySize + "," + data.size() + "," + data.capacity()
						+ "," + entry.get("id"));
				if (entrySize + data.size() > data.capacity()) {
					client.bulk(settings.getIndexType(), data.bytes(),
							data.size());
					data.reset();
				}
				command.write(writable, data);
			}
		}
		client.bulk(settings.getIndexType(), data.bytes(), data.size());
		data.reset();
	}

}
