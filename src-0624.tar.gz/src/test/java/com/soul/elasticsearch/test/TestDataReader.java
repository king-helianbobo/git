package com.soul.elasticsearch.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.map.ObjectMapper;
import org.elasticsearch.application.query.SoulFileWriter;
import org.splitword.soul.utility.StringUtil;

public class TestDataReader {
	private static Log log = LogFactory.getLog(TestDataReader.class);
	private InputStream in = null;
	private BufferedReader br = null;
	private List<String> paths; // file path list
	private String CHAR_CODING = "gbk";
	public static String OfficialFormat = "official";
	public static String SogouFormat = "sogou";
	public static String JsonFormat = "json";

	String[] preTags = { "<contenttitle>", "<content>", "<url>", "<tag>",
			"<source>" };
	String[] postTags = { "</contenttitle>", "</content>", "</url>", "</tag>",
			"</source>" };

	private void setPaths(String directory) {
		paths = new LinkedList<String>();
		File file = new File(directory);
		if (file.isFile()) {
			paths.add(directory);
		} else if (file.isDirectory()) {
			File[] files = file.listFiles();
			Set<String> set = new TreeSet<String>();
			for (int i = 0; i < files.length; i++) {
				if (files[i].getName().trim().endsWith(".txt")
						&& files[i].isFile()) {
					set.add(files[i].getAbsolutePath());
				}
			}
			Iterator<String> iter = set.iterator();
			while (iter.hasNext())
				paths.add(iter.next());
			for (int i = 0; i < paths.size(); i++)
				log.info(paths.get(i));
		} else {
			log.error(directory + " is not legal!");
		}
	}

	public TestDataReader(String directory, String coding) {
		this.CHAR_CODING = coding;
		this.setPaths(directory);
	}

	public TestDataReader(String directory) {
		this.setPaths(directory);
	}

	public void convertToJson(String filePath, String format)
			throws IOException {
		SoulFileWriter writer = new SoulFileWriter(filePath);
		List<Map<String, String>> result = null;
		ObjectMapper mapper = new ObjectMapper();
		int docnumber = 0;
		while ((result = nextData(20, format)) != null) {
			for (int i = 0; i < result.size(); i++) {
				Map<String, String> tmpEntry = result.get(i);
				Map<String, String> entry = DataUtility
						.checkThisEntry(tmpEntry);
				if (entry == null)
					continue;
				else {
					docnumber++;
					String resultJson = mapper.writeValueAsString(entry);
					writer.writeWithNewLine(resultJson);
					log.info("doc number is " + docnumber);
				}
			}
		}
		writer.close();
	}

	public List<Map<String, String>> nextData(final int number, String format)
			throws IOException {
		if (br == null) {
			if (paths.isEmpty())
				return null;
			else {
				String path = paths.remove(0);
				in = new FileInputStream(path);
				br = new BufferedReader(new InputStreamReader(in, CHAR_CODING));
			}
		}
		List<Map<String, String>> products = null;
		if (format.equalsIgnoreCase(OfficialFormat))
			products = generateOfficialData(number);
		else if (format.equalsIgnoreCase(SogouFormat))
			products = generateSogouData(number);
		else if (format.equalsIgnoreCase(JsonFormat))
			products = generateJsonData(number);
		else
			throw new IOException("format:[" + format + "] unlegal!");
		while (products.size() < number) {
			int size = products.size();
			if (paths.size() > 0) {
				String path = paths.remove(0);
				in = new FileInputStream(path);
				br = new BufferedReader(new InputStreamReader(in, CHAR_CODING));
				if (format.equalsIgnoreCase(OfficialFormat))
					products.addAll(generateOfficialData(number - size));
				else if (format.equalsIgnoreCase(SogouFormat))
					products.addAll(generateSogouData(number - size));
				else if (format.equalsIgnoreCase(JsonFormat))
					products.addAll(generateJsonData(number - size));
				else
					throw new IOException("format:[" + format + "] unlegal!");
			} else {
				if (products.size() > 0)
					return products;
				else
					return null;
			}
		}
		return products;
	}

	private List<Map<String, String>> generateJsonData(int size)
			throws IOException {
		List<Map<String, String>> products = new ArrayList<Map<String, String>>();
		String temp = null;
		int n = 0;
		ObjectMapper mapper = new ObjectMapper();
		while ((temp = br.readLine()) != null) {
			temp = temp.trim();
			if (StringUtil.isBlank(temp))
				continue;
			JsonParser jsonParser = mapper.getJsonFactory().createJsonParser(
					temp);
			@SuppressWarnings("unchecked")
			Map<String, String> entry = mapper.readValue(jsonParser, Map.class);
			if (!entry.isEmpty()) {
				products.add(entry);
				n++;
			}
			if (n == size)
				break;
		}
		if (temp == null)
			br = null;
		return products;
	}

	private List<Map<String, String>> generateOfficialData(int size)
			throws IOException {
		List<Map<String, String>> products = new ArrayList<Map<String, String>>();
		String temp = null;
		int n = 0;
		Map<String, String> tmpMap = null;
		while ((temp = br.readLine()) != null) {
			temp = temp.trim();
			if (StringUtil.isBlank(temp))
				continue;
			if (temp.startsWith("<doc>")) {
				tmpMap = new HashMap<String, String>();
				continue;
			} else if (temp.startsWith(preTags[2])) {
				int end = temp.lastIndexOf(postTags[2]);
				if (end >= 0) {
					String str = temp.substring(preTags[2].length(), end);
					if (str.length() > 0) {
						tmpMap.put(DataUtility.urlField, str);
					} else
						tmpMap.put(DataUtility.urlField, "null");
				}
			} else if (temp.startsWith(preTags[0])) {
				int end = temp.lastIndexOf(postTags[0]);
				if (end >= 0) {
					String str = temp.substring(preTags[0].length(), end);
					if (str.length() > 0)
						tmpMap.put(DataUtility.titleField, str);
					else
						tmpMap.put(DataUtility.titleField, "null");
				}
			} else if (temp.startsWith(preTags[1])) {
				int end = temp.lastIndexOf(postTags[1]);
				if (end >= 0) {
					String str = temp.substring(preTags[1].length(), end);
					if (str.length() > 0)
						tmpMap.put(DataUtility.contentField, str);
					else
						tmpMap.put(DataUtility.contentField, "null");
				}
			} else if (temp.startsWith(preTags[3])) {
				int end = temp.lastIndexOf(postTags[3]);
				if (end >= 0) {
					String str = temp.substring(preTags[3].length(), end);
					if (str.length() > 0)
						tmpMap.put("tag", str);
					else
						tmpMap.put("tag", "null");
				}
			} else if (temp.startsWith(preTags[4])) {
				int end = temp.lastIndexOf(postTags[4]);
				if (end >= 0) {
					String str = temp.substring(preTags[4].length(), end);
					if (str.length() > 0)
						tmpMap.put("source", str);
					else
						tmpMap.put("source", "null");
				}
			} else if (temp.startsWith("<TimeStamp>")) {
				int end = temp.lastIndexOf("</TimeStamp>");
				if (end >= 0) {
					String str = temp.substring("<TimeStamp>".length(), end);
					if (str.length() > 0)
						tmpMap.put("postTime", str);
					else
						tmpMap.put("postTime", "null");
				}
			} else if (temp.startsWith("</doc>")) {
				if (!tmpMap.isEmpty()) {
					// Assert.assertEquals(6, tmpMap.size());
					products.add(tmpMap);
					n++;
				}
				if (n == size)
					break;
			} else {
				log.info(temp);
				continue;
			}
		}
		if (temp == null)
			br = null;
		return products;
	}

	private List<Map<String, String>> generateSogouData(int size)
			throws IOException {
		List<Map<String, String>> products = new ArrayList<Map<String, String>>();
		String temp = null;
		int n = 0;
		Map<String, String> tmpMap = null;
		while ((temp = br.readLine()) != null) {
			temp = temp.trim();
			if (StringUtil.isBlank(temp))
				continue;
			if (temp.startsWith("<doc>")) {
				tmpMap = new HashMap<String, String>();
				continue;
			} else if (temp.startsWith("<contenttitle>")) {
				int end = temp.lastIndexOf("</contenttitle>");
				if (end >= 0) {
					String content = temp.substring("<contenttitle>".length(),
							end);
					if (content.length() > 0)
						tmpMap.put("contenttitle", content);
					else
						tmpMap.put("contenttitle", "null");
				}
			} else if (temp.startsWith("<content>")) {
				int end = temp.lastIndexOf("</content>");
				if (end >= 0) {
					String content = temp.substring("<content>".length(), end);
					if (content.length() > 0)
						tmpMap.put("content", content);
					else
						tmpMap.put("content", "null");
				}
			} else if (temp.startsWith("<url>")) {
				int end = temp.lastIndexOf("</url>");
				if (end >= 0) {
					String content = temp.substring("<url>".length(), end);
					if (content.length() > 0)
						tmpMap.put("url", content);
					else
						tmpMap.put("url", "null");
				}
			} else if (temp.startsWith("<docno>")) {
				int end = temp.lastIndexOf("</docno>");
				if (end >= 0) {
					String content = temp.substring("<docno>".length(), end);
					if (content.length() > 0)
						tmpMap.put("docno", content);
					else
						tmpMap.put("docno", "null");
				}
			} else if (temp.startsWith("</doc>")) {
				Map<String, String> result = addTimeToMap(tmpMap);
				if (result != null) {
					products.add(result);
					n++;
				}
				if (n == size)
					break;
			} else {
				log.info(temp);
				continue;
			}
		}
		if (temp == null)
			br = null;
		return products;
	}

	private Map<String, String> addTimeToMap(Map<String, String> docMap) {
		String[] tags = { "锡城资讯", "信息公开", "行政服务", "政民互动", "其他" };
		Random random = new Random(System.currentTimeMillis());
		for (String str : docMap.values()) {
			if (str.equals("null"))
				return null;
		}
		HashMap<String, String> element = new HashMap<String, String>();
		element.put("url", docMap.get("url"));
		element.put("docno", docMap.get("docno"));
		element.put("contenttitle", docMap.get("contenttitle"));
		element.put("content", docMap.get("content"));
		element.put("postTime", generateRandomDate());
		int tag = Math.abs(random.nextInt()) % 5;
		element.put("tag", tags[tag]);
		return element;
	}

	private static String generateRandomDate() {
		StringBuilder builder = new StringBuilder();
		builder.append("2013-");
		// get month
		String str1 = RandomStringUtils.random(1, "01");
		if (str1.equals("1"))
			builder.append(str1 + RandomStringUtils.random(1, "012"));
		else
			builder.append(str1 + RandomStringUtils.random(1, "123456789"));
		// get day
		builder.append("-");
		str1 = RandomStringUtils.random(1, "012");
		if (str1.equals("0"))
			builder.append(str1 + RandomStringUtils.random(1, "123456789"));
		else
			builder.append(str1 + RandomStringUtils.random(1, "0123456789"));
		builder.append(" ");
		// get hours
		str1 = RandomStringUtils.random(1, "012");
		if (str1.equals("2"))
			builder.append(str1 + RandomStringUtils.random(1, "0123"));
		else
			builder.append(str1 + RandomStringUtils.random(1, "0123456789"));
		builder.append(":");
		// get minutes
		str1 = RandomStringUtils.random(1, "012345");
		builder.append(str1 + RandomStringUtils.random(1, "0123456789"));
		builder.append(":");
		// get seconds
		str1 = RandomStringUtils.random(1, "012345");
		builder.append(str1 + RandomStringUtils.random(1, "0123456789"));
		return builder.toString();
	}
}
