package com.soul.elasticsearch.test;

import java.util.Map;

import junit.framework.Assert;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.splitword.soul.utility.OfficialChars;
import org.splitword.soul.utility.WordAlter;

public class DataUtility {
	private static Log log = LogFactory.getLog(DataUtility.class);
	public final static String titleField = "contenttitle";
	public final static String contentField = "content";
	public final static String urlField = "url";
	public final static String idField = "id";

	public static Map<String, String> checkThisEntry(Map<String, String> entry) {
		String title = entry.get(titleField);
		String content = entry.get(contentField);
		String url = entry.get(urlField);
		StringBuilder builder = new StringBuilder();
		final String header = "http://";
		int j = url.indexOf(header);
		if (j >= 0)
			j += header.length();
		else if (!url.startsWith("www")) {
			log.error("unlegal url: " + url);
			return null;
		} else {
			j = 0;
		}
		int number = 0;
		builder.append(header);
		for (; j < url.length() - 1; j++) {
			char c1 = url.charAt(j);
			char c2 = url.charAt(j + 1);
			if ((c1 == '\\') && (Character.isLetterOrDigit(c2))) {
				log.error("unlegal url : " + url + "," + title);
				return null;
			} else if ((c1 == '/') && (c2 == '/')) {
				builder.append(c1);
				j += 1; // skip c2
				number++;
			} else
				builder.append(c1);
		}
		builder.append(url.charAt(url.length() - 1));
		String result = builder.toString();
		Assert.assertEquals(true, (number == 0 || number == 1));
		String content1 = OfficialChars.removeTimeInContent(title, content);
		String content2 = OfficialChars.convertInvalidChars(content1);
		String title2 = OfficialChars.convertInvalidChars(title);
		entry.put(contentField, content2);
		entry.put(titleField, title2);
		entry.put(urlField, result);
		entry.put(idField, result.toLowerCase());// convert id to lower case
		return entry;
	}

	public static int invalidCharCount(String content) {
		int count = 0;
		for (int j = 0; j < content.length(); j++) {
			char c = content.charAt(j);
			if (!WordAlter.isLetterOrDigit(c))
				count++;
		}
		return count;
	}

}
