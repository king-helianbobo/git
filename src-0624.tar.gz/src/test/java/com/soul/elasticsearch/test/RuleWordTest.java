package com.soul.elasticsearch.test;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import junit.framework.Assert;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.elasticsearch.application.query.ExtractUtil;
import org.elasticsearch.application.query.SoulFileWriter;
import org.splitword.lionsoul.jcseg.util.ChineseHelper;
import org.splitword.soul.analysis.BasicAnalysis;
import org.splitword.soul.analysis.RuleAnalysis;
import org.splitword.soul.domain.Term;
import org.splitword.soul.utility.OfficialChars;
import org.splitword.soul.utility.SoulArrays;
import org.splitword.soul.utility.StringUtil;
import org.testng.annotations.Test;

public class RuleWordTest {
	private static final Log log = LogFactory.getLog(RuleWordTest.class);

	@Test
	public void documentFreqTest() throws Exception {
		List<Map<String, String>> resultMap = null;
		BasicAnalysis analysis = new BasicAnalysis(true);
		Map<String, Integer> freqMap = new TreeMap<String, Integer>();
		Map<String, Integer> docMap = new TreeMap<String, Integer>();
		Map<String, Integer> titleMap = new TreeMap<String, Integer>();
		Map<String, Integer> contentMap = new TreeMap<String, Integer>();
		Map<String, Map<String, Integer>> natureMap = new TreeMap<String, Map<String, Integer>>();
		SoulFileWriter freqWriter = new SoulFileWriter("/tmp/freq1.txt");
		TestDataReader reader = new TestDataReader(OfficialDataTest.sourcePath,
				"utf-8");
		int document = 0;

		while ((resultMap = reader.nextData(10, TestDataReader.OfficialFormat)) != null) {
			for (int i = 0; i < resultMap.size(); i++) {
				Map<String, String> entry = resultMap.get(i);
				String title = entry.get(DataUtility.titleField);
				String content = entry.get(DataUtility.contentField);
				String tmpStr = OfficialChars.removeTimeInContent(title,
						content);
				String title1 = OfficialChars.convertInvalidChars(title);
				String content1 = OfficialChars.convertInvalidChars(tmpStr);
				List<Term> parse1 = analysis.parse(title1);
				List<Term> parse2 = analysis.parse(content1);
				List<Term> list = new LinkedList<Term>();
				list.addAll(parse1);
				list.addAll(parse2);
				document++;
				int titleSize = parse1.size();
				Map<String, Integer> tmp = new TreeMap<String, Integer>();
				for (int j = 0; j < list.size(); j++) {
					Term term = list.get(j);
					String name = term.getName();
					String natureStr = term.getNatrue().natureStr;
					if (!StringUtil.isBlank(name)
							&& !StringUtil.isBlank(natureStr)) {
						tmp.put(name, 1);
						if (freqMap.get(name) == null)
							freqMap.put(name, 1);
						else {
							int num = freqMap.get(name);
							freqMap.put(name, num + 1);
						}
						Map<String, Integer> map = natureMap.get(name);
						if (map == null)
							map = new TreeMap<String, Integer>();
						if (map.get(natureStr) == null)
							map.put(natureStr, 1);
						else {
							int num = map.get(natureStr);
							map.put(natureStr, num + 1);
						}
						natureMap.put(name, map);
						if (j < titleSize) {
							if (titleMap.get(name) == null)
								titleMap.put(name, 1);
							else {
								int num = titleMap.get(name);
								titleMap.put(name, num + 1);
							}
						} else {
							if (contentMap.get(name) == null)
								contentMap.put(name, 1);
							else {
								int num = contentMap.get(name);
								contentMap.put(name, num + 1);
							}
						}
						int a = freqMap.get(name);
						int b = (contentMap.get(name) == null) ? 0 : contentMap
								.get(name);
						int c = (titleMap.get(name) == null) ? 0 : titleMap
								.get(name);
						Assert.assertTrue(a == (b + c));
					}
				}
				for (String name : tmp.keySet()) {
					if (docMap.get(name) == null)
						docMap.put(name, 1);
					else {
						int num = docMap.get(name);
						docMap.put(name, num + 1);
					}
				}
				log.info("I has processed " + document + " documents.");
			}
		}
		Map<String, String> lastMap = decideTermNature(freqMap, natureMap);
		Assert.assertEquals(natureMap.size(), freqMap.size());
		Assert.assertEquals(lastMap.size(), freqMap.size());
		for (String key : lastMap.keySet()) {
			String natureStr = lastMap.get(key);
			int a1 = docMap.get(key);
			int a2 = freqMap.get(key);
			int a3 = (titleMap.get(key) == null) ? 0 : titleMap.get(key);
			int a4 = (contentMap.get(key) == null) ? 0 : contentMap.get(key);
			String line = key + "\t" + natureStr + "\t" + a1 + "\t" + a2 + "\t"
					+ a3 + "\t" + a4;
			if (!StringUtil.isBlank(natureStr))
				freqWriter.writeWithNewLine(line);
			else {
				Assert.assertEquals(1, 0);
			}
		}
		freqWriter.close();
	}

	// @Test
	public void ruleRecognitionTest() throws Exception {
		List<Map<String, String>> resultMap = null;
		// RuleAnalysis analysis = new RuleAnalysis(true, true);
		BasicAnalysis analysis = new BasicAnalysis(true);
		Map<String, Integer> freqMap = new TreeMap<String, Integer>();
		Map<String, Map<String, Integer>> natureMap = new TreeMap<String, Map<String, Integer>>();
		SoulFileWriter freqWriter = new SoulFileWriter("/tmp/freq3.txt");
		SoulFileWriter ruleWriter = new SoulFileWriter("/tmp/rule3.txt");
		TestDataReader reader = new TestDataReader(OfficialDataTest.sourcePath,
				"utf-8");
		int document = 0;
		while ((resultMap = reader.nextData(10, TestDataReader.OfficialFormat)) != null) {
			for (int i = 0; i < resultMap.size(); i++) {
				Map<String, String> entry = resultMap.get(i);
				String title = entry.get(DataUtility.titleField);
				String content = entry.get(DataUtility.contentField);
				String tmpStr = OfficialChars.removeTimeInContent(title,
						content);
				String title1 = OfficialChars.convertInvalidChars(title);
				String content1 = OfficialChars.convertInvalidChars(tmpStr);
				List<Term> parse1 = analysis.parse(title1);
				List<Term> parse2 = analysis.parse(content1);
				List<Term> list = new LinkedList<Term>();
				list.addAll(parse1);
				list.addAll(parse2);
				document++;
				for (int j = 0; j < list.size(); j++) {
					Term term = list.get(j);
					String name = term.getName();
					String natureStr = term.getNatrue().natureStr;
					if (ChineseHelper.allChineseChar(name)
							&& (name.length() >= 2)) {
						if (freqMap.get(name) == null)
							freqMap.put(name, 1);
						else {
							int num = freqMap.get(name);
							freqMap.put(name, num + 1);
						}
						Map<String, Integer> map = natureMap.get(name);
						if (map == null)
							map = new TreeMap<String, Integer>();
						if (map.get(natureStr) == null)
							map.put(natureStr, 1);
						else {
							int num = map.get(natureStr);
							map.put(natureStr, num + 1);
						}
						natureMap.put(name, map);
						// log.info(name + "," + natureStr);
					}
				}
				log.info("I has processed " + document + " documents.");
			}
		}
		Map<String, String> lastNatureMap = decideTermNature(freqMap, natureMap);
		Assert.assertEquals(natureMap.size(), freqMap.size());
		Assert.assertEquals(lastNatureMap.size(), freqMap.size());
		for (String key : lastNatureMap.keySet()) {
			String natureStr = lastNatureMap.get(key);
			String line = key + "\t" + natureStr + "\t" + freqMap.get(key);
			if (natureStr != null && natureStr.equals("rule")) {
				ruleWriter.writeWithNewLine(line);
			} else if (natureStr != null && !StringUtil.isBlank(natureStr)) {
				freqWriter.writeWithNewLine(line);
			} else {
				// this should not happen
				Assert.assertEquals(1, 0);
			}
		}
		ruleWriter.close();
		freqWriter.close();
	}

	private Map<String, String> decideTermNature(Map<String, Integer> freqMap,
			Map<String, Map<String, Integer>> natureMap) {
		Map<String, String> lastMap = new TreeMap<String, String>();
		for (String key : freqMap.keySet()) {
			Map<String, Integer> map = natureMap.get(key);
			if (map.size() > 1 && map.containsKey("rule"))
				map.remove("rule");
			// first remove rule nature,then judge below
			if (map.containsKey("nr") && map.containsKey("nrf")
					&& map.size() > 2) {
				map.remove("nr");
				map.remove("nrf");
			} else if (map.containsKey("nr") && map.containsKey("nrf")) {
				int nr1 = map.get("nr");
				int nrf1 = map.get("nrf");
				if (nr1 >= nrf1)
					lastMap.put(key, "nr");
				else
					lastMap.put(key, "nrf");
				continue;
			} else if (map.containsKey("nr") && map.size() > 1) {
				map.remove("nr");
			} else if (map.containsKey("nrf") && map.size() > 1) {
				map.remove("nrf");
			}

			if (map.size() > 1 && map.containsKey("n"))
				map.remove("n");
			// remove nature "n"
			if (map.size() > 1) {
				List<Map.Entry<String, Integer>> list = SoulArrays
						.sortMapByValue(map, 1);
				lastMap.put(key, list.get(0).getKey());
			} else {
				Assert.assertEquals(1, map.size());
				String natureStr = ExtractUtil.setToString(map.keySet(), false);
				lastMap.put(key, natureStr);
			}
		}
		return lastMap;
	}

	// @Test
	@SuppressWarnings("resource")
	public void extractTest2() {
		BasicAnalysis analysis = new BasicAnalysis(true);
		SoulFileWriter writer = new SoulFileWriter("/mnt/f/tmp/a.txt");
		Map<String, Integer> freqMap = new TreeMap<String, Integer>();
		Map<String, String> natureMap = new TreeMap<String, String>();
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					new FileInputStream("library/freq3.txt"), "utf-8"));
			String temp = null;
			while ((temp = reader.readLine()) != null) {
				String[] strs = temp.split("\t");
				String str1 = strs[0].trim();
				String str2 = strs[1].trim();
				String str3 = strs[2].trim();
				natureMap.put(str1, str2);
				freqMap.put(str1, Integer.valueOf(str3));
			}
			log.info(freqMap.size());
			reader = new BufferedReader(new InputStreamReader(
					new FileInputStream("library/rule3.txt"), "utf-8"));
			int num = 0;
			while ((temp = reader.readLine()) != null) {
				String[] strs = temp.split("\t");
				String str1 = strs[0].trim();
				String str2 = strs[1].trim();
				String str3 = strs[2].trim();
				boolean result = includeThisStr(analysis, freqMap, temp, 4);
				if (result) {
					StringBuilder builder = new StringBuilder();
					builder.append(str1 + "\t" + str2 + "\t" + str3 + "\n");
					num++;
					writer.writeStr(builder.toString());
				}
			}
			log.info("Total Word count is " + num);
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	boolean includeThisStr(BasicAnalysis analysis,
			Map<String, Integer> freqMap, String temp, int leastNum) {
		String[] strs = temp.split("\t");
		String str1 = strs[0].trim();
		String str3 = strs[2].trim();
		List<Term> parse = analysis.parse(str1);
		final String userWuxi = "userwuxi";
		final int threshold = 800;
		if (parse.size() == 1) {
			return false;
		} else if (parse.size() == 2) {
			Assert.assertEquals(true, (str1.length() >= leastNum));
			String string1 = parse.get(0).getName();
			String string2 = parse.get(1).getName();
			String nature1 = parse.get(0).getNatrue().natureStr;
			String nature2 = parse.get(1).getNatrue().natureStr;

			if (nature1.equals(userWuxi) && nature2.equals(userWuxi)) {
				log.info("two terms all wuxis: " + str1 + parse);
				return false;
			} else if (nature1.equals(userWuxi)) {
				if (freqMap.get(string2) != null) {
					int freq = freqMap.get(string2);
					if (freq > threshold) {
						log.info("one term is wuxis: " + str1 + parse);
						return false;
					}
				}
			} else if (nature2.equals(userWuxi)) {
				if (freqMap.get(string1) != null) {
					int freq = freqMap.get(string1);
					if (freq > threshold) {
						log.info("one term is wuxis: " + str1 + parse);
						return false;
					}
				}
			} else {
				List<String> list = new ArrayList<String>();
				list.add("vn");
				list.add("v");
				if (list.contains(nature1) && list.contains(nature2)) {
					log.info("two terms all vns: " + str1 + parse);
					return false;
				}
			}
			if (freqMap.get(string1) != null && freqMap.get(string2) != null) {
				int freq1 = freqMap.get(string1);
				int freq2 = freqMap.get(string2);
				if (freq1 > 500 && freq2 > 500 && Integer.valueOf(str3) < 4) {
					log.info("two terms all freqs: " + str1 + parse);
					return false;// not include this string
				}
				if (freq1 * freq2 > 160 * 10000 && Integer.valueOf(str3) < 3) {
					log.info("two terms all cross: " + str1 + parse);
					return false;// not include this string
				}
			}
			return true;
		} else if (parse.size() == 3) {
			Assert.assertEquals(true, (str1.length() >= leastNum));
			String string1 = parse.get(0).getName();
			String string2 = parse.get(1).getName();
			String string3 = parse.get(2).getName();
			if (string1.length() > 1 && string2.length() > 1
					&& string3.length() > 1) {
				log.info("three terms " + str1 + parse);
				return false;
			} else
				return true;
		} else {
			return true;
		}
	}

	// @Test
	public void stopwordTest() {
		String writePath = "/mnt/f/tmp/b1.txt";
		String readPath1 = "library/freq7.txt";
		String readPath2 = "library/rule7.txt";
		final String splitTag = "\t";
		final int threshold = 4;
		RuleAnalysis analysis = new RuleAnalysis(true, true);
		SoulFileWriter writer = new SoulFileWriter(writePath);
		String temp = null;
		Map<String, Integer> freqMap = new TreeMap<String, Integer>();
		Map<String, String> natureMap = new TreeMap<String, String>();
		Set<String> stopWords = new TreeSet<String>();
		try {
			@SuppressWarnings("resource")
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					new FileInputStream(readPath1), "utf-8"));
			while ((temp = reader.readLine()) != null) {
				String[] strs = temp.split(splitTag);
				String str1 = strs[0].trim();
				String str2 = strs[1].trim();
				String str3 = strs[2].trim();
				natureMap.put(str1, str2);
				freqMap.put(str1, Integer.valueOf(str3));
			}
			reader = new BufferedReader(new InputStreamReader(
					new FileInputStream("library/stopWord.dic"), "utf-8"));
			while ((temp = reader.readLine()) != null) {
				if (StringUtil.isBlank(temp))
					continue;
				String str = temp.trim();
				if (ChineseHelper.allChineseChar(str)) {
					log.info(str);
					stopWords.add(str);
				}
			}
			log.info(freqMap.size());
			reader = new BufferedReader(new InputStreamReader(
					new FileInputStream(readPath2), "utf-8"));
			while ((temp = reader.readLine()) != null) {
				String[] strs = temp.split(splitTag);
				String str1 = strs[0].trim();
				String str2 = strs[1].trim();
				Assert.assertEquals(true, str2.equals("rule"));
				Integer freq = Integer.valueOf(strs[2].trim());
				List<Term> parse = analysis.parse(str1);
				int containNum = 0;
				if (parse.size() > 1) {
					for (int j = 0; j < parse.size(); j++) {
						Term tmp = parse.get(j);
						String name = tmp.getName();
						if (stopWords.contains(name) && name.length() >= 1)
							containNum++;
						else if (freqMap.containsKey(name)
								&& freqMap.get(name) >= 10)
							containNum++;
					}
					if (containNum == parse.size())
						log.info(str1 + "," + parse);
					else if (freq >= threshold) {
						writer.writeWithNewLine(temp);
					}
				}
			}
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
