package com.elasticsearch.keyword;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.elasticsearch.query.SoulFileWriter;
import com.splitword.soul.utility.StringUtil;

public class OfficialKeywords {

	private static final Map<String, List<String>> keywordMap = new HashMap<String, List<String>>();
	private static final Map<String, List<Map<String, List<String>>>> map = new HashMap<String, List<Map<String, List<String>>>>();

	private static final String subjectOneStart = "<subjectone>";
	private static final String subjectOneEnd = "</subjectone>";

	private static final String subjectTwoStart = "<subjecttwo>";
	private static final String subjectTwoEnd = "</subjecttwo>";
	private static final String keywordsStart = "<keywords>";
	private static final String keywordsEnd = "</keywords>";
	private static OutputStream out;
	private static BufferedWriter bw;
	private static int firstNum = 0;
	private static int secondNum = 0;
	private static int unmatchNum = 0;
	private static int totalNum = 0;

	public static void main(String[] args) throws IOException {
		SoulFileWriter writer = new SoulFileWriter("/mnt/e/clientData/out1.txt");
		ExtractUsefulData.readFile("/mnt/e/clientData/out.txt", writer);
		writer.close();
		out = new FileOutputStream("/mnt/e/clientData/result.txt");
		bw = new BufferedWriter(new OutputStreamWriter(out, "utf-8"));

		readKeyWord();
		readSort();
		readData();
		out.close();
		bw.close();
		System.out.println("total num: " + totalNum + " , first num: "
				+ firstNum + " , second num: " + secondNum + " , unmatch num: "
				+ unmatchNum);
	}

	public static void readKeyWord() {
		try {
			File file = new File("/mnt/e/clientData/keyword.txt");
			if (file.isFile() && file.exists()) {
				InputStreamReader read = new InputStreamReader(
						new FileInputStream(file));
				BufferedReader reader = new BufferedReader(read);
				String lineText = null;
				while ((lineText = reader.readLine()) != null) {
					if (StringUtil.isBlank(lineText))
						continue;
					String[] temp = lineText.split("[:]");
					String key = temp[0];
					List<String> valueList = new ArrayList<String>();
					String[] valueTmp = temp[1].split(" ");
					if (null != valueTmp) {
						for (String t : valueTmp) {
							valueList.add(t.trim());
						}
					}
					keywordMap.put(key, valueList);
				}
				reader.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void readSort() {
		try {
			File file = new File("/mnt/e/clientData/sort.txt");
			if (file.isFile() && file.exists()) {
				InputStreamReader read = new InputStreamReader(
						new FileInputStream(file));
				BufferedReader bufferedReader = new BufferedReader(read);
				String lineText = null;
				while ((lineText = bufferedReader.readLine()) != null) {
					if (StringUtil.isBlank(lineText))
						continue;
					String[] strs = lineText.split("[:]");
					String firstKey = strs[0];
					String[] values = strs[1].split("[,]");
					if (values != null && values.length > 0) {
						List<Map<String, List<String>>> list = new ArrayList<Map<String, List<String>>>();
						for (String t : values) {
							String[] internalTmp = t.split("[|]");
							String internalKey = internalTmp[0];
							String internalValue1 = internalTmp[1];
							Map<String, List<String>> internalMap = new HashMap<String, List<String>>();
							List<String> valueList = getDataFromMap(internalValue1);
							if (null != valueList && valueList.size() > 0) {
								internalMap.put(internalKey, valueList);
								list.add(internalMap);
							}
						}
						map.put(firstKey, list);
					}
				}
				bufferedReader.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void readData() {
		try {
			File file = new File("/mnt/e/clientData/test.txt");
			if (file.isFile() && file.exists()) {
				InputStreamReader read = new InputStreamReader(
						new FileInputStream(file));
				BufferedReader bufferedReader = new BufferedReader(read);
				String lineStr = null;
				int i = 0;
				while ((lineStr = bufferedReader.readLine()) != null) {
					if ("--".equals(lineStr))
						continue;
					List<String> linkList = new LinkedList<String>();
					while (i <= 2) {
						linkList.add(lineStr);
						lineStr = bufferedReader.readLine();
						i++;
					}
					dealLinkList(linkList);
					totalNum++;
					i = 0;
				}
				read.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void dealLinkList(List<String> linkList) {
		if (null == linkList || linkList.size() != 3)
			return;
		String subjectOne = extract(linkList.get(0), subjectOneStart,
				subjectOneEnd);
		String subjectTwo = extract(linkList.get(1), subjectTwoStart,
				subjectTwoEnd);
		String keyword = extract(linkList.get(2), keywordsStart, keywordsEnd);
		List<Map<String, List<String>>> first = map.get(subjectOne);
		if (null != first && first.size() > 0) {
			for (int i = 0; i < first.size(); i++) {
				List<String> keywords = first.get(i).get(subjectTwo);
				if (null != keywords && keywords.size() > 0) {
					deal(keywords, keyword, subjectOne, subjectTwo);
					return;
				}
			}
			finalDo(subjectOne, subjectTwo, keyword);
			secondNum++;
		}
		finalDo(subjectOne, subjectTwo, keyword);
		firstNum++;
		finalDo(subjectOne, subjectTwo, keyword);
	}

	private static void deal(List<String> keywords, String keyword,
			String subjectOne, String subjectTwo) {
		if (null == keyword || "".equals(keyword))
			finalDo(subjectOne, subjectTwo, keyword);

		String[] temp = keyword.split("、");
		StringBuilder sb = new StringBuilder();
		boolean firstWord = true;
		for (String t : temp) {
			if (!keywords.contains(t.trim())) {
				if (!firstWord)
					sb.append("、");
				else
					firstWord = false;
				sb.append(t);
			} else
				continue;
		}
		if (null != sb.toString() && !"".equals(sb.toString())) {
			finalDo(subjectOne, subjectTwo, sb.toString());
			unmatchNum++;
		}
	}

	private static void finalDo(String subjectOne, String subjectTwo,
			String keyword) {
		try {
			bw.append(subjectOneStart + subjectOne + subjectOneEnd + "\n");
			bw.append(subjectTwoStart + subjectTwo + subjectTwoEnd + "\n");
			bw.append(keywordsStart + keyword + keywordsEnd + "\n");
			bw.append("=========================================================\n");
			bw.flush();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// 文秘工作|35,应急管理|N,政务督查|35,电子政务|29,保密工作|35,信访|35,参事、文史|26,机关事务|35,其他|综合、行政事务
	private static List<String> getDataFromMap(String value) {
		if (null == value || "N".equalsIgnoreCase(value) || "".equals(value))
			return null;
		String[] temp = value.split("、");
		List<String> resultList = new ArrayList<String>();
		for (String t : temp) {
			List<String> list = getData(t);
			if (list != null)
				resultList.addAll(list);
		}
		return resultList;
	}

	private static List<String> getData(String key) {
		for (Entry<String, List<String>> entry : keywordMap.entrySet()) {
			List<String> valueList = entry.getValue();
			String key1 = entry.getKey();
			String[] tmpStrs = key1.split("[|]");
			if (null == tmpStrs || tmpStrs.length <= 0)
				continue;
			for (String t : tmpStrs) {
				if (t.equalsIgnoreCase(key))
					return valueList;
			}
		}
		return null;
	}

	private static String extract(String content, String startTag, String endTag) {
		int start = -1;
		int end = -1;
		StringBuilder builder = new StringBuilder();
		start = content.indexOf(startTag);
		end = content.indexOf(endTag, start);
		if (start >= 0 && end >= 0) {
			String key = content.substring(start + startTag.length(), end);
			builder.append(key);
		}
		return builder.toString();
	}
}
