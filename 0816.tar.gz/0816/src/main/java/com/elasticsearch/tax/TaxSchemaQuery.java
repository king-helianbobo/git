package com.elasticsearch.tax;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import com.elasticsearch.query.SoulQueryUtil;

public class TaxSchemaQuery {
	private static final Log log = LogFactory.getLog(TaxSchemaQuery.class);

	public static Map<String, Object> schemaQueryMap(
			Map<String, List<String>> schemaMap, List<String> tokenList) {
		// entity not exist, just schema map
		Map<String, List<String>> map = greenFields(schemaMap, tokenList);
		List<String> greenFields = map.get("greenFields");
		List<Map<String, Object>> array = tmpSchemaArray(map, tokenList);
		Map<String, Object> map2 = TaxQueryMap.tableMap(TaxFinalVal.indexOne,
				tokenList);
		if (map2 != null)
			array.add(map2);
		Map<String, Object> queryMap = SoulQueryUtil.createBooleanQueryMap(
				array, 1);
		Map<String, Object> tmpMap = new HashMap<String, Object>();
		if (greenFields != null)
			tmpMap.put("greenFields", greenFields);
		if (queryMap != null)
			tmpMap.put("queryMap", queryMap);
		return tmpMap;
	}

	private static List<Map<String, Object>> tmpSchemaArray(
			Map<String, List<String>> map, List<String> tokenList) {
		List<Map<String, Object>> arrayMap = new LinkedList<Map<String, Object>>();
		List<String> realTokens = map.get("realTokens");
		List<String> tables = map.get("tableList");
		List<String> otherFields = map.get("otherFields");
		if (realTokens == null)
			// if real tokens not exist
			return arrayMap;
		if (tables != null) {
			Map<String, Object> tjMap = TaxQueryMap
					.tableMap(tables, realTokens);
			if (tjMap != null)
				arrayMap.add(tjMap);
		}
		if (otherFields != null) {
			for (String token : realTokens) {
				for (String field : otherFields) {
					Map<String, Object> tjMap = TaxQueryFields.eachToken(field,
							token);
					if (tjMap != null)
						arrayMap.add(tjMap);
				}
			}
		}
		return arrayMap;
	}

	private static Map<String, List<String>> greenFields(
			Map<String, List<String>> schemaMap, List<String> tokenList) {
		List<String> tableList = new LinkedList<String>();
		List<String> fieldList = new LinkedList<String>();
		List<String> realTokens = new LinkedList<String>();
		for (String str : tokenList) {
			if (schemaMap.containsKey(str)) {
				List<String> list = schemaMap.get(str);
				for (String field : list) {
					String[] strs = field.split("[.]");
					String tableName = strs[0];
					if (field.endsWith(".all")) {
						if (!tableList.contains(tableName))
							tableList.add(tableName);
					} else {
						fieldList.add(field);
						// greenList.add(field);
					}
				}
			} else
				realTokens.add(str);
		}
		List<String> list1 = new LinkedList<String>();
		List<String> list2 = new LinkedList<String>();
		for (String str : fieldList) {
			String[] strs = str.split("[.]");
			String tableName = strs[0];
			if (!tableList.contains(tableName))
				list2.add(str);
			if (!list1.contains(str))
				list1.add(str);
		}
		Map<String, List<String>> resultMap = new HashMap<String, List<String>>();
		if (list2.size() > 0)
			resultMap.put("otherFields", list2);
		if (list1.size() > 0)
			resultMap.put("greenFields", list1);
		if (tableList.size() > 0)
			resultMap.put("tableList", tableList);
		if (realTokens.size() > 0)
			resultMap.put("realTokens", realTokens);
		return resultMap;
	}
}
