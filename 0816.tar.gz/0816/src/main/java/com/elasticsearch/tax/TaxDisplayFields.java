package com.elasticsearch.tax;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import junit.framework.Assert;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class TaxDisplayFields {

	private static final Log log = LogFactory.getLog(TaxDisplayFields.class);

	private static List<String> greenFields(String tableName,
			List<String> greenFields) {
		List<String> result = new LinkedList<String>();
		if (greenFields == null)
			return result;
		for (String realField : greenFields) {
			log.info(realField);
			String[] strs = realField.split("[.]");
			String table = strs[0];
			String field = strs[1];
			if (table.equalsIgnoreCase(tableName))
				result.add(field);
		}
		return result;
	}

	public static List<String> displayFields(Map<String, Object> sourceMap,
			List<String> greenFields, String tableName, String mode) {
		List<String> list1 = new LinkedList<String>();
		List<String> greenList = greenFields(tableName, greenFields);
		if (mode.equals("person")) {
			List<String> displayFields = new LinkedList<String>();
			displayFields.add("SWGLM");
			displayFields.add(TaxFinalVal.addedField);
			displayFields.add("NSR_MC");
			displayFields.add("SIJMSSRE_JE");
			displayFields.add("YINGNSE_JE");
			displayFields.add("YIJSE_JE");
			displayFields.add("纳税尊重(个人)");
			displayFields.add("纳税尊重(企业)");
			for (String str : greenList) {
				if (!displayFields.contains(str))
					displayFields.add(str);
			}
			Assert.assertEquals(tableName, "A10");
			list1.addAll(displayFields);
			list1.add(0, String.valueOf(list1.size()));
		} else if (mode.equals("company")) {
			List<String> displayFields = new LinkedList<String>();
			displayFields.add("SWGLM");
			displayFields.add("LSNSR_MC");
			displayFields.add("SFSSQ_QSRQ");
			displayFields.add("SFSSQ_ZZRQ");
			displayFields.add("JK_QX");
			displayFields.add("SB_RQ");
			displayFields.add("YZFS_RQ");
			displayFields.add("KCSE_JE");
			displayFields.add("纳税尊重(企业)");
			for (String str : greenList) {
				if (!displayFields.contains(str))
					displayFields.add(str);
			}
			Assert.assertEquals(tableName, "A04");
			list1.addAll(displayFields);
			list1.add(0, String.valueOf(list1.size()));
		} else if (mode.equals("singleCompany") && tableName.equals("A01")) {
			List<String> displayFields = new LinkedList<String>();
			displayFields.add("SWGLM");
			displayFields.add("NSR_MC");
			displayFields.add("ZCDZ");
			list1.addAll(displayFields);
			list1.add(0, String.valueOf(list1.size()));
		} else if (mode.equals("singleCompany") && tableName.equals("A02")) {
			List<String> displayFields = new LinkedList<String>();
			displayFields.add("SBFS_DM");
			displayFields.add("ZSFS_DM");
			displayFields.add("JKFS_DM");
			list1.addAll(displayFields);
			list1.add(0, String.valueOf(list1.size()));
		} else {
			List<String> listII = whichFields(tableName);
			list1.addAll(listII);
			for (String str : greenList) {
				if (!list1.contains(str))
					list1.add(str);
			}
			List<String> list2 = new LinkedList<String>();
			for (String resultField : sourceMap.keySet()) {
				String[] strs = resultField.split("[.]");
				String field = strs[1];
				if (!list1.contains(field))
					list2.add(field);
			}
			int listSize = list1.size();
			list1.addAll(list2);
			list1.add(0, String.valueOf(listSize));
			// log.info(list1);
		}
		return list1;
	}

	private static List<String> whichFields(String tableName) {
		Map<String, List<String>> fieldsMap = TaxFinalVal.fieldsMap();
		List<String> displayFields = fieldsMap.get(tableName + "#display");
		Map<String, Object> defMap = TaxFinalVal.defMap().get(tableName);
		if (displayFields == null) {
			List<String> tmpList = new LinkedList<String>();
			for (String field : defMap.keySet()) {
				tmpList.add(field);
			}
			displayFields = tmpList;
		}
		return displayFields;
	}
}
