package com.elasticsearch.tax;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.elasticsearch.query.SoulQueryUtil;
import com.splitword.soul.utility.StringUtil;

public class TaxQueryMap {

	private static final Log log = LogFactory.getLog(TaxQueryMap.class);

	// query all tables belong to this index
	public static Map<String, Object> tableMap(String indexName,
			List<String> tokenList) {
		List<String> tables = TaxFinalVal.indexTypeMap().get(indexName);
		Set<String> tableSet = new TreeSet<String>();
		for (String str : tables)
			tableSet.add(str);
		return tableMap(tableSet, tokenList);
	}

	// query all tables belong to this index
	public static Map<String, Object> tableMap(List<String> tables,
			List<String> tokenList) {
		Set<String> tableSet = new TreeSet<String>();
		for (String str : tables)
			tableSet.add(str);
		return tableMap(tableSet, tokenList);
	}

	// query tokens in table set
	public static Map<String, Object> tableMap(Set<String> tables,
			List<String> tokenList) {
		Map<String, List<String>> fieldsMap = TaxFinalVal.fieldsMap();
		List<Map<String, Object>> lastArray = new ArrayList<Map<String, Object>>();
		for (String tableName : tables) { // for each table
			List<Map<String, Object>> arrayForEachTable = new ArrayList<Map<String, Object>>();
			// for each table ,first get all real fields
			List<String> realFields = TaxQueryFields.realFieldList(tableName,
					fieldsMap);
			// log.info(realFields);
			for (String token : tokenList) {
				List<Map<String, Object>> array = new ArrayList<Map<String, Object>>();
				for (String realField : realFields) {
					// log.info(token + "," + realField);
					Map<String, Object> tmpMap = TaxQueryFields.eachToken(
							realField, token);
					if (tmpMap != null)
						array.add(tmpMap);
				}
				Map<String, Object> map1 = SoulQueryUtil.createBooleanQueryMap(
						array, 1);
				if (map1 != null)
					arrayForEachTable.add(map1);
			}
			// must satisfy all, else not match
			Map<String, Object> mapHaha = SoulQueryUtil.createBooleanQueryMap(
					arrayForEachTable, arrayForEachTable.size());
			Map<String, Object> mapForThisTable = TaxQueryUtil
					.queryMapWithFilter(mapHaha, tableName);
			lastArray.add(mapForThisTable);
		}
		Map<String, Object> lastMap = SoulQueryUtil.createBooleanQueryMap(
				lastArray, 1);
		return lastMap;
	}

	public static boolean existEntity(Map<String, List<String>> resultMap,
			List<String> tokenList) {
		List<String> realTokens = new LinkedList<String>();
		Set<String> tables = new HashSet<String>();
		for (String str : tokenList) {
			if (resultMap.containsKey(str)) {
				List<String> fields = resultMap.get(str);
				for (String field : fields) {
					String[] strs = field.split("[.]");
					tables.add(strs[0]);
				}
				continue;
			} else
				realTokens.add(str);
		}

		for (String str : realTokens) {
			if (StringUtil.isBlank(str))
				continue;
			if (TaxFinalVal.companyMap().get(str) != null)
				return true;
			else if (TaxFinalVal.personMap().get(str) != null)
				return true;
		}
		return false;
	}

	// we use LinkedHashMap because it could keep insert order
	@SuppressWarnings("unchecked")
	public static Map<String, Object> checkMap(Map<String, Object> map1,
			List<TaxPojo> pojoList, List<String> greenFields, String mode) {
		Map<String, Object> resultMap = new LinkedHashMap<String, Object>();
		String tableName = (String) map1.get("_type");
		resultMap.put("tableName", TaxFinalVal.tableMap().get(tableName));
		Map<String, Object> lightMap = (Map<String, Object>) map1
				.get("highlight");
		Map<String, Object> sourceMap = (Map<String, Object>) map1
				.get("_source");
		// must remove this field
		sourceMap.remove(TaxFinalVal.sortDate);
		List<String> list1 = TaxDisplayFields.displayFields(sourceMap,
				greenFields, tableName, mode);
		int listSize = Integer.valueOf(list1.remove(0));
		Map<String, Object> defMap = TaxFinalVal.defMap().get(tableName);
		for (int i = 0; i < list1.size(); i++) {
			String field = list1.get(i);
			if (mode.equals("person") && field.equals("纳税尊重(个人)")) {
				if (sourceMap.containsKey(TaxFinalVal.realPaid)
						&& sourceMap.containsKey(TaxFinalVal.shouldPaid)) {
					String str1 = (String) sourceMap.get(TaxFinalVal.realPaid);
					String str2 = (String) sourceMap
							.get(TaxFinalVal.shouldPaid);
					boolean bPass = TaxPostFilter.checkPaid(str1, str2);
					if (bPass)
						resultMap.put(field, SoulQueryUtil.preTag + "正常缴纳"
								+ SoulQueryUtil.postTag);
					else
						resultMap.put(field, SoulQueryUtil.preTag + "未缴纳"
								+ SoulQueryUtil.postTag);
					String swglm = (String) sourceMap.get("A10.SWGLM");
					String value1 = TaxFinalVal.respectMap().get(swglm);
					resultMap.put(list1.get(i + 1), SoulQueryUtil.preTag
							+ value1 + SoulQueryUtil.postTag);
				}
				i++;
				continue;
			} else if (mode.equals("company") && field.equals("纳税尊重(企业)")) {
				if (sourceMap.containsKey(TaxFinalVal.realDate)
						&& sourceMap.containsKey(TaxFinalVal.shouldDate)) {
					String str1 = (String) sourceMap.get(TaxFinalVal.realDate);
					String str2 = (String) sourceMap
							.get(TaxFinalVal.shouldDate);
					boolean value = TaxPostFilter.checkDate(str1, str2);
					if (value)
						resultMap.put(field, SoulQueryUtil.preTag + "正常缴纳"
								+ SoulQueryUtil.postTag);
					else
						resultMap.put(field, SoulQueryUtil.preTag + "未缴纳"
								+ SoulQueryUtil.postTag);
				}
				continue;
			}
			Map<String, String> typeInfo = (Map<String, String>) defMap
					.get(field);
			String chineseFieldName = typeInfo.get("chineseFieldName");
			String resultField = tableName + "." + field;
			if (!sourceMap.containsKey(resultField))
				continue;
			String resultStr = (String) sourceMap.get(resultField);
			String anotherStr = null;
			if (lightMap != null && lightMap.containsKey(resultField)) {
				List<String> tmpList = (List<String>) lightMap.get(resultField);
				anotherStr = tmpList.get(0);
			} else if (greenFields == null
					|| !greenFields.contains(resultField)) {
				// log.info(anotherStr + "," + resultStr);
				anotherStr = ESMapUtility.colorSourceString(resultStr,
						pojoList, "red");
				// log.info(anotherStr + "," + resultStr);
			} else {
				anotherStr = ESMapUtility.colorSourceString(resultStr,
						pojoList, "red");
				// String type = greenFields.get(0);
				// if (type.equals("table")) {
				// // log.info(anotherStr + "," + resultStr);
				// // neither match or not, color source string
				// anotherStr = SoulQueryUtil.greenPreTag + resultStr
				// + SoulQueryUtil.greenPostTag;
				// // log.info(anotherStr + "," + resultStr);
				// } else {
				// anotherStr = ESMapUtility.colorSourceString(resultStr,
				// pojoList, "green");
				// }
			}
			if (i < listSize)
				resultMap.put(chineseFieldName, anotherStr);
			else {
				// log.info(anotherStr);
				if (!resultStr.equals(anotherStr)) {
					resultMap.put(chineseFieldName, anotherStr);
				}
			}
		}
		return resultMap;
	}

}
