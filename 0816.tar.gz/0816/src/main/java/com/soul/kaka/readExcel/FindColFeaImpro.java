package com.soul.kaka.readExcel;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.splitword.lionsoul.jcseg.util.ChineseHelper;

public class FindColFeaImpro {
	private static String fileName = "";

	public static void main(String[] args) throws FileNotFoundException,
			IOException {
		String testDataPath = "加工测试数据4";
		listDirectory(testDataPath);
	}

	private static void listDirectory(String path)
			throws FileNotFoundException, IOException {
		File dir = new File(path);
		File file[] = dir.listFiles();
		for (int j = 0; j < file.length; j++) {
			if (file[j].isDirectory()) {
				listDirectory(file[j].getAbsolutePath());
			} else if (file[j].getName().endsWith("xls")) {
				String xlsFileName = file[j].getName();
				fileName = xlsFileName.substring(0, xlsFileName.length() - 4);
				FileOutputStream xlsColFeaOut = new FileOutputStream(
						"zhouqiOutput/taxColFeaImpro/" + fileName + ".txt");
				BufferedWriter xlsColFeaBw = new BufferedWriter(
						new OutputStreamWriter(xlsColFeaOut, "UTF-8"));
				String[][] excelRowCol = ExtractExcelDataKaka.getData(file[j],
						0);
				findColFeature(excelRowCol, xlsColFeaBw);

				xlsColFeaBw.flush();

				try {
					if (xlsColFeaOut != null) {
						xlsColFeaOut.close();
					}
					if (xlsColFeaBw != null) {
						xlsColFeaBw.close();
					}
				} catch (IOException e) {
					e.printStackTrace();
				}

			} else {
				System.out.println("do nothing");
			}
		}
	}

	private static void findColFeature(String[][] excelRowCol,
			BufferedWriter xlsColFeaBw) throws IOException {

		for (int j = 0; j < excelRowCol[0].length; j++) {
			if (excelRowCol[2][j].equals("string")) {
				stringColFeature(excelRowCol, xlsColFeaBw, j);
			} else if (excelRowCol[2][j].equals("integer")) {
				intColFeature(excelRowCol, xlsColFeaBw, j);
			} else if (excelRowCol[2][j].equals("float")) {
				floatColFeature(excelRowCol, xlsColFeaBw, j);
			} else {
				continue;
			}
			System.out.println(excelRowCol[1][j]);
		}
	}

	private static void floatColFeature(String[][] excelRowCol,
			BufferedWriter xlsColFeaBw, int j) throws IOException {
		float min = 0.0f;
		float max = 0.0f;
		for (int i = 3; i < excelRowCol.length; i++) {
			String tempStr = excelRowCol[i][j];
			if (tempStr == null || tempStr.equals("")) {
				continue;
			}
			float tempFlo = Float.valueOf(tempStr).floatValue();
			if (tempFlo > max) {
				max = tempFlo;
			}
			if (tempFlo < min) {
				min = tempFlo;
			}
		}

		StringBuilder colFeature = new StringBuilder();
		colFeature.append(excelRowCol[0][j] + "(" + excelRowCol[1][j] + ");");
		colFeature.append("float;");
		colFeature.append("max_value=" + max + ",");
		colFeature.append("max_value=" + min + "\n");
		String colFeaStr = colFeature.toString();
		xlsColFeaBw.append(colFeaStr);
	}

	private static void intColFeature(String[][] excelRowCol,
			BufferedWriter xlsColFeaBw, int j) throws IOException {
		List<String> columnList = new ArrayList<String>();
		Set<String> columnSet = new LinkedHashSet<String>();
		Map<String, Integer> columnMap = new HashMap<String, Integer>();
		for (int i = 3; i < excelRowCol.length; i++) {
			String tempStr = excelRowCol[i][j];
			if (tempStr == null || tempStr.equals("")) {
				continue;
			}
			columnList.add(tempStr);
			columnSet.add(tempStr);
			Integer count = columnMap.get(tempStr);
			if (count == null) {
				columnMap.put(tempStr, 1);
			} else {
				columnMap.put(tempStr, count + 1);
			}
		}
		int colMapSize = columnMap.size();

		if (colMapSize <= 10) {
			StringBuilder colFeature = new StringBuilder();
			colFeature.append(excelRowCol[0][j] + "(" + excelRowCol[1][j]
					+ ");");
			colFeature.append("enum;");
			for (Map.Entry<String, Integer> entry : columnMap.entrySet()) {
				String key = entry.getKey();
				colFeature.append(key + ",");
			}
			int length = colFeature.length();
			String colFeaStr = colFeature.substring(0, length - 1) + "\n";
			xlsColFeaBw.append(colFeaStr);
		} else {
			int min = 0;
			int max = 0;
			Iterator<String> it = columnSet.iterator();
			while (it.hasNext()) {
				String tempStr = it.next();
				int tempFlo = Integer.valueOf(tempStr).intValue();
				if (tempFlo > max) {
					max = tempFlo;
				}
				if (tempFlo < min) {
					min = tempFlo;
				}
			}
			StringBuilder colFeature = new StringBuilder();
			colFeature.append(excelRowCol[0][j] + "(" + excelRowCol[1][j]
					+ ");");
			colFeature.append("integer;");
			colFeature.append("max_value=" + max + ",");
			colFeature.append("min_value=" + min + "\n");
			String colFeaStr = colFeature.toString();
			xlsColFeaBw.append(colFeaStr);
		}
	}

	private static void stringColFeature(String[][] excelRowCol,
			BufferedWriter xlsColFeaBw, int j) throws IOException {
		List<String> columnList = new ArrayList<String>();
		Set<String> columnSet = new LinkedHashSet<String>();
		Map<String, Integer> columnMap = new HashMap<String, Integer>();
		for (int i = 3; i < excelRowCol.length; i++) {
			String tempStr = excelRowCol[i][j];
			if (tempStr == null || tempStr.equals("")) {
				continue;
			}
			columnList.add(tempStr);
			columnSet.add(tempStr);
			Integer count = columnMap.get(tempStr);
			if (count == null) {
				columnMap.put(tempStr, 1);
			} else {
				columnMap.put(tempStr, count + 1);
			}
		}

		int flag = 0;
		int numAll = 0;
		int letterAll = 0;
		int colSetSize = columnSet.size();
		int colMapSize = columnMap.size();
		String firstColData = columnList.get(0);
		Iterator<String> it = columnSet.iterator();
		

		while (it.hasNext()) {
			String tempStr = it.next();
			if (ChineseHelper.containChineseChar(tempStr)) {
				flag = 1;
				break;
			} else {
				if (ChineseHelper.allNumerical(tempStr)) {
					numAll++;
				} else if (allLetter(tempStr)) {
					letterAll++;
				}
			}
		}

		if (flag == 0) {
			if (numAll == colSetSize) {
				flag = 2;
			} else if (letterAll == colSetSize) {
				flag = 3;
			} else {
				flag = 4;
			}
		}

		switch (flag) {
		case 1: {
			StringBuilder colFeature = new StringBuilder();
			colFeature.append(excelRowCol[0][j] + "(" + excelRowCol[1][j]
					+ ");");
			colFeature.append("others\n");
			xlsColFeaBw.append(colFeature);
			break;
		}
		case 2: {
			if (colMapSize <= 10) {
				StringBuilder colFeature = new StringBuilder();
				colFeature.append(excelRowCol[0][j] + "(" + excelRowCol[1][j]
						+ ");");
				colFeature.append("enum;");
				for (Map.Entry<String, Integer> entry : columnMap.entrySet()) {
					String key = entry.getKey();
					colFeature.append(key + ",");
				}
				int length = colFeature.length();
				String colFeaStr = colFeature.substring(0, length - 1) + "\n";
				xlsColFeaBw.append(colFeaStr);
			} else {
				Integer length = findLength(columnSet, firstColData);
				String prefix = findPrefix(columnSet, firstColData);
				String common = findCommon(columnSet, firstColData);
				String suffix = findSuffix(columnSet, firstColData);
				StringBuilder colFeature = new StringBuilder();
				colFeature.append(excelRowCol[0][j] + "(" + excelRowCol[1][j]
						+ ");");
				colFeature.append("number;");
				colFeature.append("length=" + length + ",");
				colFeature.append("prefix=" + prefix + ",");
				colFeature.append("common=" + common + ",");
				colFeature.append("suffix=" + suffix + "\n");
				xlsColFeaBw.append(colFeature);
			}
			break;
		}

		case 3: {
			if (colMapSize <= 10) {
				StringBuilder colFeature = new StringBuilder();
				colFeature.append(excelRowCol[0][j] + "(" + excelRowCol[1][j]
						+ ");");
				colFeature.append("enum;");
				for (Map.Entry<String, Integer> entry : columnMap.entrySet()) {
					String key = entry.getKey();
					colFeature.append(key + ",");
				}
				int length = colFeature.length();
				String colFeaStr = colFeature.substring(0, length - 1) + "\n";
				xlsColFeaBw.append(colFeaStr);
			} else {
				Integer length = findLength(columnSet, firstColData);
				String prefix = findPrefix(columnSet, firstColData);
				String common = findCommon(columnSet, firstColData);
				String suffix = findSuffix(columnSet, firstColData);
				StringBuilder colFeature = new StringBuilder();
				colFeature.append(excelRowCol[0][j] + "(" + excelRowCol[1][j]
						+ ");");
				colFeature.append("alpha;");
				colFeature.append("length=" + length + ",");
				colFeature.append("prefix=" + prefix + ",");
				colFeature.append("common=" + common + ",");
				colFeature.append("suffix=" + suffix + "\n");
				xlsColFeaBw.append(colFeature);
			}
			break;
		}

		case 4: {
			if (colMapSize <= 10) {
				StringBuilder colFeature = new StringBuilder();
				colFeature.append(excelRowCol[0][j] + "(" + excelRowCol[1][j]
						+ ");");
				colFeature.append("enum;");
				for (Map.Entry<String, Integer> entry : columnMap.entrySet()) {
					String key = entry.getKey();
					colFeature.append(key + ",");
				}
				int length = colFeature.length();
				String colFeaStr = colFeature.substring(0, length - 1) + "\n";
				xlsColFeaBw.append(colFeaStr);
			} else {
				Integer length = findLength(columnSet, firstColData);
				String prefix = findPrefix(columnSet, firstColData);
				String common = findCommon(columnSet, firstColData);
				String suffix = findSuffix(columnSet, firstColData);
				StringBuilder colFeature = new StringBuilder();
				colFeature.append(excelRowCol[0][j] + "(" + excelRowCol[1][j]
						+ ");");
				colFeature.append("alphanum;");
				colFeature.append("length=" + length + ",");
				colFeature.append("prefix=" + prefix + ",");
				colFeature.append("common=" + common + ",");
				colFeature.append("suffix=" + suffix + "\n");
				xlsColFeaBw.append(colFeature);
			}
			break;
		}

		default:
			String colName = excelRowCol[0][j] + "(" + excelRowCol[1][j] + "--"
					+ excelRowCol[2][j] + ")";
			String colFeature = colName + "的特征是: 列中某一行中存在其他情况\n";
			xlsColFeaBw.append(colFeature);
		}
	}

	public static boolean allLetter(String str) {
		for (int i = str.length(); --i >= 0;) {
			if (!Character.isLetter(str.charAt(i))) {
				return false;
			}
		}
		return true;
	}

	private static Integer findLength(Set<String> columnSet, String firstColData) {
		int length = firstColData.length();
		Iterator<String> it = columnSet.iterator();
		while (it.hasNext()) {
			String tempStr = it.next();
			int tempLen = tempStr.length();
			if (tempLen != length) {
				return null;
			}
		}
		return Integer.valueOf(length);
	}

	private static String findPrefix(Set<String> columnSet, String firstColData) {
		String prefix = null;
		for (int i = firstColData.length(); i > 0; i--) {
			String comparedStr = firstColData.substring(0, i);
			Iterator<String> it = columnSet.iterator();
			boolean flag = false;
			while (it.hasNext()) {
				String tempStr = it.next();
				if (!tempStr.startsWith(comparedStr)) {
					flag = true;
					break;
				}
			}
			if (flag == true) {
				continue;
			} else {
				prefix = comparedStr;
				break;
			}
		}
		return prefix;
	}

	private static String findCommon(Set<String> columnSet, String firstColData) {
		String common = null;
		int len = firstColData.length();
		Set<String> commonSet = new LinkedHashSet<String>();
		if (len >= 4) {
			for (int i = 0; i < len - 1; i++) {
				for (int j = i + 1; j < len; j++) {
					String comparedStr = firstColData.substring(i, j + 1);
					Iterator<String> it = columnSet.iterator();
					boolean flag = true;
					while (it.hasNext()) {
						String tempStr = it.next();
						if (!tempStr.contains(comparedStr)) {
							flag = false;
							break;
						}
					}

					if (flag == true) {
						commonSet.add(comparedStr);
					}
				}
			}
		}
		
		if (commonSet.size() > 0) {
			int maxLeng=0;
			for (String str : commonSet) {
                 if(maxLeng<str.length()){
                	 common=str;
                	 maxLeng=str.length();
                 }
			}
		}
		return common;
	}

	private static String findSuffix(Set<String> columnSet, String firstColData) {
		String suffix = null;
		for (int i = 0; i < firstColData.length(); i++) {
			String comparedStr = firstColData.substring(i,
					firstColData.length());
			Iterator<String> it = columnSet.iterator();
			boolean flag = false;
			while (it.hasNext()) {
				String tempStr = it.next();
				if (!tempStr.endsWith(comparedStr)) {
					flag = true;
					break;
				}
			}
			if (flag == true) {
				continue;
			} else {
				suffix = comparedStr;
				break;
			}
		}
		return suffix;
	}
}
