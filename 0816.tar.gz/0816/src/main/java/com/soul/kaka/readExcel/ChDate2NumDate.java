package com.soul.kaka.readExcel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ChDate2NumDate {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<String> chdList = new ArrayList<String>();
		chdList.add("十月");
		chdList.add("一九九零年");
		chdList.add("十月一日");
		chdList.add("十月十五日");
		chdList.add("10月十五日");
		chdList.add("十月15日");
		chdList.add("二零一四年十月一日");
		chdList.add("二零一四年10月一日");
		chdList.add("二零一四年9月1日");
		chdList.add("2014年10月一日");
		chdList.add("二零一四年十一月");
		chdList.add("明年十一月");
		chdList.add("今年十一月");
		chdList.add("后年十一月5日");

		for (String dateStr : chdList) {
			System.out.println(dateStr);
			String numDateStr = chDate2NumDate(dateStr);
			System.out.println(numDateStr);
			System.out.println();
		}

	}

	public static String chDate2NumDate(String dateStr) {
		String numDateStr = "";
		Map<String, String> numDateMap = new HashMap<String, String>();

		List<String> digitNumList = new ArrayList<String>();
		digitNumList.add("0");
		digitNumList.add("1");
		digitNumList.add("2");
		digitNumList.add("3");
		digitNumList.add("4");
		digitNumList.add("5");
		digitNumList.add("6");
		digitNumList.add("7");
		digitNumList.add("8");
		digitNumList.add("9");

		List<String> chNumList = new ArrayList<String>();

		chNumList.add("零");
		chNumList.add("一");
		chNumList.add("二");
		chNumList.add("三");
		chNumList.add("四");
		chNumList.add("五");
		chNumList.add("六");
		chNumList.add("七");
		chNumList.add("八");
		chNumList.add("九");
		chNumList.add("十");
		chNumList.add("百");
		chNumList.add("千");

		Map<String, String> yearPrefMap = new HashMap<String, String>();
		yearPrefMap.put("前", "2012");
		yearPrefMap.put("去", "2013");
		yearPrefMap.put("今", "2014");
		yearPrefMap.put("明", "2015");
		yearPrefMap.put("后", "2016");

		for (int i = 0; i < dateStr.length(); i++) {
			char bit = dateStr.charAt(i);
			String tempStr = "";
			if (bit == '年') {
				int temp = i;
				boolean isChNum = true;
				while (temp > 0) {
					temp--;
					char tempBit = dateStr.charAt(temp);
					String tempBitStr = tempBit + "";
					if (yearPrefMap.keySet().contains(tempBitStr.trim())) {
						tempStr=yearPrefMap.get(tempBitStr.trim());
						isChNum=false;
                        break;
					} else {
						if (chNumList.contains(tempBitStr.trim())) {
							tempStr = tempBitStr.trim() + tempStr;
						} else if (digitNumList.contains(tempBitStr.trim())) {
							tempStr = tempBitStr.trim() + tempStr;
							isChNum = false;
						} else {
							break;
						}
					}
				}

				if (isChNum) {
					String segNum = chYearNum2Digit(tempStr) + "";
					numDateMap.put(bit + "", segNum);
				} else {
					numDateMap.put(bit + "", tempStr);
				}

			} else if (bit == '月' || bit == '日') {
				int temp = i;
				boolean isChNum = true;
				while (temp > 0) {
					temp--;
					char tempBit = dateStr.charAt(temp);
					String tempBitStr = tempBit + "";
					if (chNumList.contains(tempBitStr.trim())) {
						tempStr = tempBitStr.trim() + tempStr;
					} else if (digitNumList.contains(tempBitStr.trim())) {
						tempStr = tempBitStr.trim() + tempStr;
						isChNum = false;
					} else {
						break;
					}
				}

				if (isChNum) {
					String segNum = ChNum2MathNum.chnNum2Digit(tempStr) + "";
					if (digitNumList.contains(segNum))
						numDateMap.put(bit + "", "0" + segNum);
					else
						numDateMap.put(bit + "", segNum);
				} else {
					if (digitNumList.contains(tempStr))
						numDateMap.put(bit + "", "0" + tempStr);
					else
						numDateMap.put(bit + "", tempStr);
				}
			} else {
				continue;
			}
		}

		if (numDateMap.get("年") != null) {
			numDateStr = numDateStr + numDateMap.get("年") + "年";
		}
		if (numDateMap.get("月") != null) {
			numDateStr = numDateStr + numDateMap.get("月") + "月";
		}
		if (numDateMap.get("日") != null) {
			numDateStr = numDateStr + numDateMap.get("日") + "日";
		}

		return numDateStr;
	}

	public static String chYearNum2Digit(String chYearNum) {
		String digitNum = "";

		Map<String, String> numMap = new HashMap<String, String>();
		numMap.put("零", "0");
		numMap.put("一", "1");
		numMap.put("二", "2");
		numMap.put("三", "3");
		numMap.put("四", "4");
		numMap.put("五", "5");
		numMap.put("六", "6");
		numMap.put("七", "7");
		numMap.put("八", "8");
		numMap.put("九", "9");

		for (int i = 0; i < chYearNum.length(); i++) {
			char ch = chYearNum.charAt(i);
			digitNum = digitNum + numMap.get(ch + "");
		}

		return digitNum;
	}

}
