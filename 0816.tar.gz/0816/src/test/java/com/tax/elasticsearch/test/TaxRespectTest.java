package com.tax.elasticsearch.test;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.elasticsearch.common.joda.time.DateTime;
import org.testng.annotations.Test;

import com.elasticsearch.query.SoulFileWriter;
import com.elasticsearch.tax.TaxDataReader;
import com.elasticsearch.tax.TaxFinalVal;
import com.elasticsearch.tax.TaxPostFilter;
import com.splitword.soul.utility.StringUtil;

public class TaxRespectTest {
	private static final Log log = LogFactory.getLog(TaxRespectTest.class);

	@Test
	public void testMethod1() throws JsonParseException, JsonMappingException,
			IOException {
		SoulFileWriter writer3 = new SoulFileWriter("/tmp/1.txt");
		SoulFileWriter writer2 = new SoulFileWriter("/tmp/2.txt");
		Map<String, Integer> swglmMap1 = new HashMap<String, Integer>();
		Map<String, Integer> swglmMap2 = new HashMap<String, Integer>();
		Map<String, List<Map<String, String>>> resultMap = TaxDataReader
				.readTableData("liuboOutput/result.txt");
		for (String tableName : resultMap.keySet()) {
			if (!tableName.equals("A10") && !tableName.equals("A04"))
				continue;
			List<Map<String, String>> list = resultMap.get(tableName);
			for (int i = 0; i < list.size(); i++) {
				Map<String, String> map = list.get(i);
				String str1 = null;
				String str2 = null;
				if (tableName.equals("A10")) {
					String swglm = map.get("SWGLM");
					String zjh = map.get("SFZHM");
					String key = swglm + "#" + zjh;
					String date1 = map.get("SFSSQ_QSRQ");
					String date2 = map.get("SFSSQ_ZZRQ");

					DateTime dt1 = TaxPostFilter.convertDate(date1);
					DateTime dt2 = TaxPostFilter.convertDate(date2);
					TaxPostFilter.outputDate(dt1, dt2);
					str2 = map.get("YINGNSE_JE");
					str1 = map.get("YIJSE_JE");
					TaxPostFilter.checkPaid(str1, str2);

				} else if (tableName.equals("A04")) {
					String swglm = map.get("SWGLM");
					str1 = map.get("YZFS_RQ");
					str2 = map.get("JK_QX");
					if (TaxPostFilter.checkDate(str1, str2)) {// not out date
						Integer number1 = swglmMap1.get(swglm);
						if (number1 == null)
							swglmMap1.put(swglm, 1);
						else
							swglmMap1.put(swglm, number1 + 1);
						Integer number2 = swglmMap2.get(swglm);
						if (number2 == null)
							swglmMap2.put(swglm, 0);
					} else {// out date
						Integer number2 = swglmMap2.get(swglm);
						if (number2 == null)
							swglmMap2.put(swglm, 1);
						else
							swglmMap2.put(swglm, number2 + 1);
						Integer number1 = swglmMap2.get(swglm);
						if (number1 == null)
							swglmMap1.put(swglm, 0);
					}
					String date1 = map.get("SFSSQ_QSRQ");
					String date2 = map.get("SFSSQ_ZZRQ");
					DateTime dt1 = TaxPostFilter.convertDate(date1);
					DateTime dt2 = TaxPostFilter.convertDate(date2);
					TaxPostFilter.outputDate(dt1, dt2);
				}
				if (StringUtil.isNotBlank(str1) && StringUtil.isNotBlank(str2))
					writer3.writeWithNewLine(str1 + "," + str2);
				else if (StringUtil.isNotBlank(str1)) {
					log.info("single line " + str1);
					writer3.writeWithNewLine(str1);
				} else if (StringUtil.isNotBlank(str2)) {
					log.info("single line " + str2);
					writer3.writeWithNewLine(str2);
				}
			}
		}
		for (String key : swglmMap1.keySet()) {
			List<String> companys = TaxFinalVal.companyMap().get(key);
			Integer value1 = swglmMap1.get(key);
			Integer value2 = swglmMap2.get(key);
			log.info(companys + "," + value1 + "," + value2);
			writer2.writeWithNewLine(key + "," + value1 + "," + value2);
		}
		writer3.close();
		writer2.close();
	}
}
