package com.tax.elasticsearch.test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.ImmutableSettings;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.junit.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.elasticsearch.query.SoulFileWriter;
import com.elasticsearch.tax.TaxDataReader;
import com.elasticsearch.tax.TaxFinalVal;
import com.splitword.lionsoul.jcseg.util.ChineseHelper;
import com.splitword.soul.utility.StringUtil;

public class ForeignKeyTest {
	private static final Log log = LogFactory.getLog(ForeignKeyTest.class);

	final String[] fields = { "B01.DJZCLX_DM", "B02.RYLX_DM", "B03.SWJG_DM",
			"B04.ZSXM_DM" };
	private static List<String> expectedFields = new LinkedList<String>();

	@BeforeClass
	public void startTest() {
		for (int i = 0; i < fields.length; i++) {
			expectedFields.add(fields[i]);
		}
	}

	private boolean specialColumn(List<Map<String, String>> list, String key) {
		Map<String, Integer> colMap = new HashMap<String, Integer>();
		for (int i = 0; i < list.size(); i++) {
			Map<String, String> map = list.get(i);
			String value = map.get(key);
			Integer count = colMap.get(value);
			if (count == null)
				colMap.put(value, 1);
			else
				colMap.put(value, count + 1);
		}
		for (String keyStr : colMap.keySet()) {
			Integer value = colMap.get(keyStr);
			if (value.intValue() > 1) {
				return false;
			}
		}
		return true;
	}

	@Test
	public void testMethod1() throws JsonParseException, JsonMappingException,
			IOException {
		SoulFileWriter writer = new SoulFileWriter("/tmp/1.txt");
		Map<String, List<Map<String, String>>> resultMap = TaxDataReader
				.readTableData("liuboOutput/result.txt");
		for (String tableName : resultMap.keySet()) {
			if (!tableName.startsWith("B"))
				continue;
			List<Map<String, String>> list = resultMap.get(tableName);
			Map<String, String> map1 = list.get(0);
			List<String> fieldList = new LinkedList<String>();
			for (String keyStr : map1.keySet()) {
				if (keyStr.equals("tableName") || keyStr.equals("lineNumber"))
					continue;
				if (specialColumn(list, keyStr)) {
					fieldList.add(keyStr);
					log.info(tableName + "," + keyStr);
				}
			}
			for (int i = 0; i < list.size(); i++) {
				Map<String, String> map = list.get(i);
				StringBuilder builder = new StringBuilder();
				for (String field : fieldList) {
					String value = map.get(field);
					if (!ChineseHelper.containChineseChar(value))
						value = tableName + "#" + value;
					builder.append(value + "\t");
				}
				writer.writeWithNewLine(builder.toString());
			}
		}
		writer.close();
	}

	// @Test
	public void testMethod2() throws JsonParseException, JsonMappingException,
			IOException {

		Map<String, List<Map<String, String>>> resultMap = TaxDataReader
				.readTableData("liuboOutput/result.txt");
		Map<String, List<Map<String, String>>> mapA = new LinkedHashMap<String, List<Map<String, String>>>();
		Map<String, List<Map<String, String>>> mapB = new LinkedHashMap<String, List<Map<String, String>>>();

		for (String tableName : resultMap.keySet()) {
			if (tableName.startsWith("B"))
				mapB.put(tableName, resultMap.get(tableName));
			else if (tableName.startsWith("A"))
				mapA.put(tableName, resultMap.get(tableName));
			else
				Assert.assertEquals(0, 1);
		}
		Map<String, Map<String, Object>> defMap = TaxFinalVal.defMap();
		Map<String, List<String>> linkedMap = new LinkedHashMap<String, List<String>>();
		for (String tableA : mapA.keySet()) {
			Map<String, Object> defA = defMap.get(tableA);
			for (String fieldA : defA.keySet()) {
				List<Map<String, String>> resultList = mapA.get(tableA);
				List<String> list1 = columnList(fieldA, resultList);
				if (checkList(defA, fieldA, list1)) {
					List<String> result = checkRelation(list1, mapB);
					if (!result.isEmpty()) {
						List<String> list2 = new LinkedList<String>();
						for (String str : result) {
							if (!list2.contains(str))
								list2.add(str);
						}
						linkedMap.put(tableA + "." + fieldA, list2);
					}
				}
			}
		}
		SoulFileWriter writer = new SoulFileWriter("/tmp/2.txt");

		for (String key : linkedMap.keySet()) {
			List<String> list = new LinkedList<String>();
			for (String str : linkedMap.get(key)) {
				if (expectedFields.contains(str))
					list.add(str);
			}
			log.info(key + "," + list);
			StringBuilder builder = new StringBuilder();
			builder.append(translateKey(key) + ",[");
			for (int i = 0; i < list.size(); i++) {
				String value = translateKey(list.get(i));
				if (i == 0)
					builder.append(value);
				else
					builder.append("\t" + value);
			}
			builder.append("]");
			log.info(builder.toString());
		}
		writer.close();
	}

	private String translateKey(String key) {
		String tableName = key.split("[.]")[0];
		String field = key.split("[.]")[1];
		String chinseTableName = TaxFinalVal.tableMap().get(tableName);
		Map<String, Map<String, Object>> defMap = TaxFinalVal.defMap();
		Map<String, Object> def1 = defMap.get(tableName);
		@SuppressWarnings("unchecked")
		Map<String, String> typeInfo = (Map<String, String>) def1.get(field);
		String chineseFieldName = (String) typeInfo.get("chineseFieldName");
		String result = chinseTableName + "#" + chineseFieldName;
		return result;
	}

	private boolean checkList(Map<String, Object> defMap, String field,
			List<String> list) {
		if (list == null || list.isEmpty())
			return false;
		for (int i = 0; i < list.size(); i++) {
			String str = list.get(i);
			if (StringUtil.isNotBlank(str)
					&& ChineseHelper.containChineseChar(str))
				return false;
		}
		@SuppressWarnings("unchecked")
		Map<String, String> typeInfo = (Map<String, String>) defMap.get(field);
		String dataType = typeInfo.get("dataType");
		if (dataType.equals("float") || dataType.equals("integer")
				|| dataType.equals("date") || dataType.equals("datetime"))
			return false;
		else
			return true;
	}

	private List<String> checkRelation(List<String> list,
			Map<String, List<Map<String, String>>> mapB) {
		List<String> temp = new LinkedList<String>();
		for (String tableB : mapB.keySet()) {
			Map<String, Object> defB = TaxFinalVal.defMap().get(tableB);
			for (String fieldB : defB.keySet()) {
				List<Map<String, String>> resultList = mapB.get(tableB);
				List<String> list2 = columnList(fieldB, resultList);
				if (!checkList(defB, fieldB, list2))
					continue;
				if (subsetRelation(list, list2)) {
					// @SuppressWarnings("unchecked")
					// Map<String, String> typeInfo = (Map<String, String>) defB
					// .get(fieldB);
					// String chineseFieldName =
					// typeInfo.get("chineseFieldName");
					// log.info(fieldB + "," + chineseFieldName);
					temp.add(tableB + "." + fieldB);
				}
			}
		}
		return temp;
	}

	private boolean subsetRelation(List<String> list1, List<String> list2) {
		// check list1 is list2's subset or not
		if (list1 == null || list1.isEmpty() || list2 == null
				|| list2.isEmpty())
			return false;
		List<String> temp = new ArrayList<String>();
		for (String str : list1) {
			if (StringUtil.isNotBlank(str) && list2.contains(str))
				temp.add(str);
		}
		if (temp.equals(list1))
			return true;
		else
			return false;
	}

	private List<String> columnList(String columnName,
			List<Map<String, String>> resultList) {
		List<String> list = new LinkedList<String>();
		for (int i = 0; i < resultList.size(); i++) {
			Map<String, String> map1 = resultList.get(i);
			String value = map1.get(columnName);
			if (StringUtil.isNotBlank(value))
				list.add(value);
		}
		return list;
	}

	// *************************************************************************************************//
	// *************************************************************************************************//
	// *************************************************************************************************//
	private static void checkFields(String tableName, List<String> fields,
			Map<String, List<String>> fieldsMap) {
		List<String> integerFields = fieldsMap.get(tableName + "#integer");
		List<String> floatFields = fieldsMap.get(tableName + "#float");
		List<String> dateFields = fieldsMap.get(tableName + "#date");
		List<String> dateTimeFields = fieldsMap.get(tableName + "#datetime");
		List<String> chineseFields = fieldsMap.get(tableName + "#chinese");
		List<String> wordFields = fieldsMap.get(tableName + "#word");
		int number = 0;
		if (integerFields != null) {
			number += integerFields.size();
			for (String str : integerFields) {
				Assert.assertTrue(fields.contains(str));
			}
		}
		if (floatFields != null) {
			number += floatFields.size();
			for (String str : floatFields) {
				Assert.assertTrue(fields.contains(str));
			}
		}
		if (dateFields != null) {
			number += dateFields.size();
			for (String str : dateFields) {
				Assert.assertTrue(fields.contains(str));
			}
		}
		if (dateTimeFields != null) {
			number += dateTimeFields.size();
			for (String str : dateTimeFields) {
				Assert.assertTrue(fields.contains(str));
			}
		}
		if (chineseFields != null) {
			number += chineseFields.size();
			for (String str : chineseFields) {
				Assert.assertTrue(fields.contains(str));
			}
		}
		if (wordFields != null) {
			number += wordFields.size();
			for (String str : wordFields) {
				Assert.assertTrue(fields.contains(str));
			}
		}
		Assert.assertEquals(number, fields.size());
	}
}
