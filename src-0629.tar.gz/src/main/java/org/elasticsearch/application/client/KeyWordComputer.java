package org.elasticsearch.application.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.elasticsearch.application.query.TermPojo;
import org.junit.Assert;
import org.splitword.soul.utility.MyStaticValue;

public class KeyWordComputer {
	private final static Log log = LogFactory.getLog(KeyWordComputer.class);
	private int nKeyword = 10;
	public static int totalDocumentFreq = 860000;
	private static final Map<String, Double> natureScore = new HashMap<String, Double>();
	public static Map<String, TermPojo> termPojoMap = new TreeMap<String, TermPojo>();
	private static boolean loaded = false;
	private static final Lock LOCK = new ReentrantLock();

	public KeyWordComputer(int nKeyword) {
		this.nKeyword = nKeyword;
	}

	public KeyWordComputer() {
	}

	private static void loadData() {
		if (loaded)
			return;
		LOCK.lock();
		if (loaded) {
			LOCK.unlock();
			return;
		}
		try {
			loadFreqMap();
			loaded = true;
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			LOCK.unlock();
		}
	}

	private static void loadFreqMap() throws IOException {
		BufferedReader br = MyStaticValue.termPojoReader();
		String temp = null;
		int maxDocFreq = -1;
		while ((temp = br.readLine()) != null) {
			String result = temp.trim();
			String[] texts = result.split("\\s+");
			Assert.assertEquals(texts.length, 6);
			String name = texts[0];
			String nature = texts[1];
			int docFreq = Integer.valueOf(texts[2]);
			int totalFreq = Integer.valueOf(texts[3]);
			int titleFreq = Integer.valueOf(texts[4]);
			int contentFreq = Integer.valueOf(texts[5]);
			TermPojo pojo = new TermPojo(name, nature, docFreq, totalFreq,
					titleFreq, contentFreq);
			Assert.assertTrue(termPojoMap.get(name) == null);
			Assert.assertTrue(totalFreq == (titleFreq + contentFreq));
			if (docFreq > maxDocFreq)
				maxDocFreq = docFreq;
			termPojoMap.put(name, pojo);
		}
		totalDocumentFreq = (maxDocFreq + 1000);
		log.info("totalDocument freq is " + totalDocumentFreq);
		br.close();
	}

	static {
		// loadData();
		// 忽略标点符号，生僻词，数词
		natureScore.put("null", 0.0);
		natureScore.put("w", 0.0);
		natureScore.put("en", 0.0);
		natureScore.put("m", 0.0);
		// 降低习惯用语，形容词，助词，介词，语气词，连词的权重
		natureScore.put("l", 0.0);
		natureScore.put("a", 0.0);
		natureScore.put("u", 0.0);
		natureScore.put("p", 0.0);
		natureScore.put("x", 0.0);
		natureScore.put("y", 0.0);
		natureScore.put("z", 0.0);
		natureScore.put("c", 0.0);
		// 动词，代词
		natureScore.put("v", 0.0);
		natureScore.put("vn", 0.0);
		natureScore.put("vd", 0.0);
		natureScore.put("r", 0.0);
		// 名词性Term
		natureScore.put("nr", 1.0);
		natureScore.put("nrf", 1.0);
		natureScore.put("nw", 3.0);
		natureScore.put("nt", 3.0);
		natureScore.put("nz", 3.0);
		natureScore.put("rule", 2.0);
		natureScore.put("userwuxi", 3.0);

	}

}
