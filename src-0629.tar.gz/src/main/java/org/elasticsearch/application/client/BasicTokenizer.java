package org.elasticsearch.application.client;

public class BasicTokenizer {
	public static final String TYPE_WORD = "term";
	public static final String TYPE_HANZI = "hanzi";
	public static final String TYPE_SYNONYM = "synonym";
	public static final String TYPE_PINYIN = "pinyin";
	public static final String TYPE_VECTOR = "vector";
}
