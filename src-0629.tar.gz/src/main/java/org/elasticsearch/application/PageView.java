package org.elasticsearch.application;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.hadoop.yarn.webapp.MimeType;
import org.apache.hadoop.yarn.webapp.WebAppException;
import org.apache.hadoop.yarn.webapp.view.TextView;
import org.splitword.soul.utility.IOUtil;

import com.google.inject.Inject;

public class PageView extends TextView {
	@Inject
	protected PageView(ViewContext ctx, String contentType) {
		super(ctx, MimeType.HTML);
	}

	public String readFileToString(String path, String coding) {
		InputStream resourceAsStream = null;
		try {
			LOG.info(path + "," + root_url(path));
			resourceAsStream = new FileInputStream(root_url(path));
			resourceAsStream.available();
			return IOUtil.getContent(resourceAsStream, coding);
		} catch (Exception e) {
			return String.valueOf("Error: 404, File Not Found!");
		} finally {
			if (resourceAsStream != null) {
				try {
					resourceAsStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	@Override
	public void render() {
		String result = readFileToString("library/pageIndex.html", "UTF-8");
		try {
			writer().write(result);
			writer().println();
		} catch (Exception e) {
			throw new WebAppException(e);
		}
	}
}
