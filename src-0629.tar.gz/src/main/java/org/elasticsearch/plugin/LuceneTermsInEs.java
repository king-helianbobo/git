package org.elasticsearch.plugin;

import java.io.IOException;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.MultiFields;
import org.apache.lucene.index.Term;
import org.apache.lucene.index.Terms;
import org.apache.lucene.index.TermsEnum;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.util.BytesRef;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.map.ObjectMapper;

public class LuceneTermsInEs {
	private static Log log = LogFactory.getLog(LuceneTermsInEs.class);
	private IndexReader reader;
	private IndexSearcher searcher;
	// private String toReadField;
	private String idField = "_uid";
	private String sourceField = "_source";
	private ObjectMapper mapper = new ObjectMapper();

	public LuceneTermsInEs(IndexReader reader) {
		this.reader = reader;
		this.searcher = new IndexSearcher(this.reader);
	}

	public LuceneTermsInEs(IndexReader reader, String idField,
			String sourceField) {
		this.reader = reader;
		this.searcher = new IndexSearcher(this.reader);
		this.idField = idField;
		this.sourceField = sourceField;
	}

	public final LuceneFieldIterator iterator() throws IOException {
		return new LuceneFieldIterator();
	}

	public final class LuceneFieldIterator {
		private final BytesRef text = new BytesRef();
		private final TermsEnum termsIterator;
		private long freq;

		LuceneFieldIterator() throws IOException {
			Terms terms = MultiFields.getTerms(reader, idField);
			// id field must be distinct, this is most important
			if (terms != null) {
				termsIterator = terms.iterator(null);
			} else {
				termsIterator = null;
			}
		}

		public long weight() {
			return freq;
		}

		public String nextJsonWithinField(List<TermsEnum> termsEnums,
				String toReadField) throws IOException {
			if (termsIterator == null)
				return null;
			else {
				BytesRef currentTerm = null;
				Map<String, String> resultMap = new HashMap<String, String>();
				terms: while ((currentTerm = termsIterator.next()) != null) {
					freq = termsIterator.docFreq();
					if (freq < 1)
						continue;
					text.copyBytes(currentTerm);
					if (termsEnums != null && !termsEnums.isEmpty()) {
						for (TermsEnum te : termsEnums) {
							if (te.seekExact(currentTerm))
								continue terms;
						}
					}
					String word = text.utf8ToString();
					Term term = new Term(idField, word);
					Query termQuery = new TermQuery(term);
					TopDocs topDocs = searcher.search(termQuery, 10);
					ScoreDoc[] scoreDocs = topDocs.scoreDocs;
					if (topDocs == null || topDocs.totalHits <= 0)
						continue;
					// totalHits must be 1,so no need to use "for loop"
					// because idField must be different from each other
					Document doc = searcher.doc(scoreDocs[0].doc);
					// List<IndexableField> fields = doc.getFields();
					resultMap.put("field1", doc.get(idField));
					String value = null;
					if ((value = doc.get(sourceField)) == null) {
						BytesRef bytes = doc.getBinaryValue(sourceField);
						if (bytes == null)
							continue terms;
						JsonParser jsonParser = mapper.getJsonFactory()
								.createJsonParser(bytes.utf8ToString());
						@SuppressWarnings("unchecked")
						Map<String, String> map = mapper.readValue(jsonParser,
								Map.class);
						Set<String> keySet = map.keySet();
						if (!keySet.contains(toReadField))
							continue terms;
						else if ((value = map.get(toReadField)) == null)
							continue terms;
						else {
							resultMap.put("field2", value);
							// log.info("Fill Lucene json: " + value);
						}
					} else {
						resultMap.put("field2", value);
					}
					String json = mapper.writeValueAsString(resultMap);
					resultMap.clear();
					return json;
				}
				return null;
			}
		}

		public String nextJson(List<TermsEnum> termsEnums, String titleField,
				String contentField) throws IOException {
			if (termsIterator == null)
				return null;
			else {
				BytesRef currentTerm = null;
				Map<String, String> resultMap = new HashMap<String, String>();
				terms: while ((currentTerm = termsIterator.next()) != null) {
					freq = termsIterator.docFreq();
					if (freq < 1)
						continue;
					text.copyBytes(currentTerm);
					if (termsEnums != null && !termsEnums.isEmpty()) {
						for (TermsEnum te : termsEnums) {
							if (te.seekExact(currentTerm))
								continue terms;
						}
					}
					String word = text.utf8ToString();
					Term term = new Term(idField, word);
					Query termQuery = new TermQuery(term);
					TopDocs topDocs = searcher.search(termQuery, 10);
					ScoreDoc[] scoreDocs = topDocs.scoreDocs;
					if (topDocs == null || topDocs.totalHits <= 0)
						continue;
					// totalHits must be 1,so no need to use "for loop"
					// because idField must be different from each other
					Document doc = searcher.doc(scoreDocs[0].doc);
					// List<IndexableField> fields = doc.getFields();
					resultMap.put("field1", doc.get(idField));
					if (doc.get(sourceField) == null) {
						BytesRef bytes = doc.getBinaryValue(sourceField);
						if (bytes == null)
							continue terms;
						JsonParser jsonParser = mapper.getJsonFactory()
								.createJsonParser(bytes.utf8ToString());
						@SuppressWarnings("unchecked")
						Map<String, String> map = mapper.readValue(jsonParser,
								Map.class);
						Set<String> keySet = map.keySet();
						if (!keySet.contains(titleField)
								|| !keySet.contains(contentField))
							continue terms;
						else if (map.get(titleField) == null)
							continue terms;
						else if (map.get(contentField) == null)
							continue terms;
						else {
							resultMap.put("title", map.get(titleField));
							resultMap.put("content", map.get(contentField));
							// log.info("Fill Lucene json: "
							// + resultMap.get("title") + "/"
							// + resultMap.get("content").length());
						}
					} else {
						// resultMap.put("field2", value);
					}
					String json = mapper.writeValueAsString(resultMap);
					resultMap.clear();
					return json;
				}
				return null;
			}
		}

		public Comparator<BytesRef> getComparator() {
			if (termsIterator == null) {
				return null;
			} else {
				return termsIterator.getComparator();
			}
		}
	}
}
