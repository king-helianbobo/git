package org.apache.hadoop.yarn.webapp.view;

import org.apache.hadoop.classification.InterfaceAudience;

@InterfaceAudience.LimitedPrivate({ "YARN", "MapReduce" })
public class HeaderBlock extends HtmlBlock {

	@Override
	protected void render(Block html) {
		String loggedIn = "";
		if (request().getRemoteUser() != null) {
			loggedIn = "Logged in as: " + request().getRemoteUser();
		}
		html.div("#header.ui-widget").div("#user")._(loggedIn)._().div("#logo")
				.img("/static/hadoop-st.png")._().h1($(TITLE))._();
	}
}
