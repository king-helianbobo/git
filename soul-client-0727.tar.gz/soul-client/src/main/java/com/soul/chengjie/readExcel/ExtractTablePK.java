package com.soul.chengjie.readExcel;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.splitword.lionsoul.jcseg.util.ChineseHelper;

public class ExtractTablePK {

	private static Map<String, ArrayList<String>> tableMap = new HashMap<String, ArrayList<String>>();
	private static Map<String, String> tableSignatureMap = new HashMap<String, String>();
	private static Map<String, HashMap<String, String>> columnSignatureMap = new HashMap<String, HashMap<String, String>>();
	private static Map<String, HashMap<String, ArrayList<String>>> fieldData = new HashMap<String, HashMap<String, ArrayList<String>>>();
	//private static final String strType = "string";
	private static Map<String,PKEntity> singleKey = new HashMap<String,PKEntity>();
	private static Map<String,PKEntity> combKey = new HashMap<String,PKEntity>();
	
	private static List<String> SWGLMList = new ArrayList<String>();
	private static String fileName = "";
	
	private static List<String> typeList = new ArrayList<String>();
	
	static{
		typeList.add("string");
		typeList.add("date");
		typeList.add("integer");
		
		SWGLMList.add("SWGLM");
		SWGLMList.add("SKF_GLM");
	}

	public static void main(String[] args) throws FileNotFoundException,
			IOException {
		listDirectory("加工测试数据4/test");

		streamlineTableColumn();
		
		for(Entry<String, ArrayList<String>> entry : tableMap.entrySet()){
			String tableSignature = entry.getKey();
			/*if("A09".equals(tableSignature.trim()))
				calData4IndividualTax();*/
			
			
			checkRelationshipBetweenTable(tableSignature);
			
			/*ArrayList<String> columnList = entry.getValue();
			checkSinglePK(tableSignature,columnList);
			checkCombinationPK_2(tableSignature,columnList);*/
		}
		
		/*if(singleKey.size() > 0){
			for(Entry<String, PKEntity> entry : singleKey.entrySet()){
				String tableSignature = entry.getKey();
				System.out.println(tableSignature + "(" + tableSignatureMap.get(tableSignature)+ ")" + " single key: ");
				
				ArrayList<String> singleKeys = entry.getValue().getPKList();
				
				for(String key : singleKeys){
					System.out.print(key + "(" + columnSignatureMap.get(tableSignature).get(key) + ")" + "\t");
				}
				
				System.out.println();
			}
		}*/
		
		if(combKey.size() > 0){
			for(Entry<String, PKEntity> entry : combKey.entrySet()){
				String tableSignature = entry.getKey();
				
				//
				System.out.println(tableSignature + "("
						+ tableSignatureMap.get(tableSignature) + ")"
						+ " single key: ");

				ArrayList<String> singleKeys = entry.getValue().getPKList();

				if (null != singleKeys && singleKeys.size() > 0) {
					for (String key : singleKeys) {
						if (SWGLMList.contains(key))
							System.out.print(key + "(" + columnSignatureMap.get(tableSignature).get(key) + ")" + "\t");
					}
					System.out.println();
				}

				//
				System.out.println(tableSignature + "("
						+ tableSignatureMap.get(tableSignature) + ")"
						+ " combination key: ");

				ArrayList<String> combiKeys = entry.getValue()
						.getCompositePKList_2();

				if (null != combiKeys && combiKeys.size() > 0) {
					for (String key : combiKeys) {
						String[] temp_key = key.split("[|]");
						if (null != temp_key && temp_key.length == 2) {
							if (isContainSWGLM(temp_key)) {
								for (String temp : temp_key) {
									System.out.print(temp + "(" + columnSignatureMap.get(tableSignature).get(temp) + ")" + "  ");
								}
								System.out.print("\t\t");
							}
						}
					}
					System.out.println();
				}
				
				//
				
				ArrayList<String> combiKeys_1 = entry.getValue().getCompositePKList_3();
				if(null != combiKeys_1 && combiKeys_1.size() > 0){
					System.out.println(tableSignature + "(" + tableSignatureMap.get(tableSignature)+ ")" + " combination key(length is 3): ");
					for(String key : combiKeys_1){
						String[] temp_key = key.split("[|]");
						if(null != temp_key && temp_key.length == 3){
							if (isContainSWGLM(temp_key)) {
								for (String temp : temp_key) {
									System.out.print(temp + "(" + columnSignatureMap.get(tableSignature).get(temp) + ")" + "  ");
								}
								System.out.print("\t\t");
							}
						}
					}
					System.out.println();
				}
				
				
				//
				
				ArrayList<String> combiKeys_2 = entry.getValue().getCompositePKList_4();
				if(null != combiKeys_2 && combiKeys_2.size() > 0){
					System.out.println(tableSignature + "(" + tableSignatureMap.get(tableSignature) + ")" + " combination key(length is 4): ");
					for(String key : combiKeys_2){
						String[] temp_key = key.split("[|]");
						if(null != temp_key && temp_key.length == 4){
							if (isContainSWGLM(temp_key)) {
								for (String temp : temp_key) {
									System.out.print(temp + "(" + columnSignatureMap.get(tableSignature).get(temp) + ")" + "  ");
								}
								System.out.print("\t\t");
							}
						}
					}
					System.out.println();
				}
			}
		}
	}
	
	private static void checkRelationshipBetweenTable(String tableSignature) {
		// TODO Auto-generated method stub
		ArrayList<String> columnList = tableMap.get(tableSignature);
		for(Entry<String, ArrayList<String>> entry : tableMap.entrySet()){
			String tableSignature_1 = entry.getKey();
			ArrayList<String> t1_t2 = new ArrayList<String>();
			ArrayList<String> t2_t1 = new ArrayList<String>();
			
			if(tableSignature.trim().equals(tableSignature_1.trim()))
				continue;
			
			ArrayList<String> columnList_1 = tableMap.get(tableSignature_1);
			
			List<String> relateList = Utilitys.sameElement(columnList, columnList_1);
			
			if(null != relateList && relateList.size() > 0){
				/*System.out.println(tableSignature + "(" + tableSignatureMap.get(tableSignature) + ")"
										+ " and " + tableSignature_1 + "(" + tableSignatureMap.get(tableSignature_1) + ")" + " retale column is : ");*/
				for(String s : relateList){
					checkRelationshipBetweenTable_1(s,relateList,tableSignature,tableSignature_1,t1_t2,t2_t1);
					
					/*ArrayList<String> columnDataList = fieldData.get(tableSignature).get(s);
					ArrayList<String> columnDataList_1 = fieldData.get(tableSignature_1).get(s);
					
					if(Utilitys.isSubsetOf(columnDataList, columnDataList_1)){
						System.out.println(tableSignature + "(" + tableSignatureMap.get(tableSignature) + ")'s " + s + " is "
								+ tableSignature_1 + "(" + tableSignatureMap.get(tableSignature_1) + ")'s subset!");
					}else if(Utilitys.isSubsetOf(columnDataList_1, columnDataList)){
						System.out.println(tableSignature_1 + "(" + tableSignatureMap.get(tableSignature_1) + ")'s " + s + " is "
								+ tableSignature + "(" + tableSignatureMap.get(tableSignature) + ")'s subset!");
					}*/
					
					//System.out.print(s + "(" + columnSignatureMap.get(tableSignature).get(s) + ")" + "\t");
				}
				//System.out.println("\n");
				
				
				if(t1_t2.size() > 0){
					for(String str : t1_t2){						
						System.out.println(tableSignature + "'s " + str + " is " + tableSignature_1 + "'s subset!");
						System.out.println("---------------------------------------------------------------------------");
					}
				}else if(t2_t1.size() > 0){
					for(String str : t2_t1){						
						System.out.println(tableSignature_1 + "'s " + str + " is " + tableSignature + "'s subset!");
						System.out.println("---------------------------------------------------------------------------");
					}
				}
			}
		}
	}

	private static void checkRelationshipBetweenTable_1(String s,
			List<String> relateList, String tableSignature,
			String tableSignature_1,ArrayList<String> t1_t2,ArrayList<String> t2_t1) {
		// TODO Auto-generated method stub
		ArrayList<String> columnDataList_f = fieldData.get(tableSignature).get(s);
		ArrayList<String> columnDataList_f_1 = fieldData.get(tableSignature_1).get(s);
		
		for(String s1 : relateList){
			if(s1.trim().equals(s.trim()))
				continue;
			ArrayList<String> columnDataList_s = fieldData.get(tableSignature).get(s1);
			ArrayList<String> columnDataList_s_1 = fieldData.get(tableSignature_1).get(s1);
			
			ArrayList<String> tempDataList = new ArrayList<String>();
			
			for(int i=0;i<columnDataList_f.size();i++){
				if(null != columnDataList_f.get(i) && !"".equals(columnDataList_f.get(i)) &&
					null != columnDataList_s.get(i) && !"".equals(columnDataList_s)){
					tempDataList.add(columnDataList_f.get(i) + "|" + columnDataList_s.get(i));
				}
			}
			
			ArrayList<String> tempDataList_1 = new ArrayList<String>();
			
			for(int i=0;i<columnDataList_f_1.size();i++){
				if(null != columnDataList_f_1.get(i) && !"".equals(columnDataList_f_1.get(i)) &&
						null != columnDataList_s_1.get(i) && !"".equals(columnDataList_s_1)){
						tempDataList_1.add(columnDataList_f_1.get(i) + "|" + columnDataList_s_1.get(i));
					}
			}
			
			if(Utilitys.isSubsetOf(tempDataList, tempDataList_1)){
				String temp = s + "|" + s1;
				if(isContain4TwoColumn(temp,t1_t2))
					t1_t2.add(temp);
				//System.out.println(tableSignature + "'s " + (s + "|" + s1) + " is " + tableSignature_1 + "'s subset!");
				//System.out.println("-------------------------------------------------------------------------------------");
			}else if(Utilitys.isSubsetOf(tempDataList_1, tempDataList)){
				
				String temp = s + "|" + s1;
				if(isContain4TwoColumn(temp,t2_t1))
					t2_t1.add(temp);
				
				//System.out.println(tableSignature_1 + "'s " + (s + "|" + s1) + " is " + tableSignature + "'s subset!");
				//System.out.println("-------------------------------------------------------------------------------------");
			}
		
			if(relateList.size() >= 3){
				
			}
		}
	}

	private static void calData4IndividualTax() {
		// TODO Auto-generated method stub
		ArrayList<String> SFSSQ_QSRQ = fieldData.get("A09").get("SFSSQ_QSRQ");
		ArrayList<String> SFSSQ_ZZRQ = fieldData.get("A09").get("SFSSQ_ZZRQ");
		
		if(SFSSQ_ZZRQ.size() != SFSSQ_QSRQ.size())
			return;
		
		for(int i=0;i<SFSSQ_ZZRQ.size();i++){
			String QSRQ = SFSSQ_QSRQ.get(i);
			String ZZRQ = SFSSQ_ZZRQ.get(i);
			
			String[] QSRQ_t = QSRQ.split("[-]");
			String[] ZZRQ_t = ZZRQ.split("[-]");
			
			if(QSRQ_t.length == ZZRQ_t.length && ZZRQ_t.length == 3){
				String year_q = QSRQ_t[0];
				String month_q = QSRQ_t[1];
				String day_q = QSRQ_t[2];
				
				String year_z = ZZRQ_t[0];
				String month_z = ZZRQ_t[1];
				String day_z = ZZRQ_t[2];
				
				if(year_q.trim().equals(year_z.trim())){
					if(month_q.trim().equals(month_z.trim())){
						if(!day_q.trim().equals(day_z.trim())){
							int diff_day = Integer.valueOf(day_z) - Integer.valueOf(day_q);
							if(28 <= diff_day && diff_day <= 31)
								System.out.println("start at " + month_q + " and end at " + month_z);
						}
					}else{
						if(day_q.trim().equals(day_z.trim())){
							System.out.println("start at " + month_q + " and end at " + month_z);
						}
					}
				}else{
					if(month_q.trim().equals(month_z.trim()) && day_q.trim().equals(day_z.trim())){
						System.out.println("start at " + year_q + " and end at " + year_z);
					}
				}
			}
		}
	}

	private static boolean isContainSWGLM(String[] temp_key) {
		// TODO Auto-generated method stub
		for(String temp : temp_key){
			if(SWGLMList.contains(temp.trim()))
				return true;
			else
				continue;
		}
		
		return false;
	}

	/**
	 * obtain the table combination(the length is not more than 4) pk 
	 * @param tableSignature
	 * @param columnList
	 */
	private static void checkCombinationPK_2(String tableSignature,
			ArrayList<String> columnList) {
		// TODO Auto-generated method stub
		
		ArrayList<String> combiPKS = new ArrayList<String>();
		ArrayList<String> combiPKS_1 = new ArrayList<String>();
		ArrayList<String> combiPKS_2 = new ArrayList<String>();
		
		if(null == columnList || columnList.size() < 1)
			return;
		
		for(String column : columnList){
			if(!isSinglePK(column,tableSignature))
				checkCombinationPK_2_1(tableSignature,column,columnList,combiPKS,combiPKS_1,combiPKS_2);
		}
		PKEntity entity = singleKey.get(tableSignature);
		if(null != entity){
			entity.setCompositePKList_2(combiPKS);
			entity.setCompositePKList_3(combiPKS_1);
			entity.setCompositePKList_4(combiPKS_2);
		}
		else{
			entity = new PKEntity();
			entity.setTableSignature(tableSignature);
			entity.setCompositePKList_2(combiPKS);
			entity.setCompositePKList_3(combiPKS_1);
			entity.setCompositePKList_4(combiPKS_2);
			entity.setStatus(0);
			
			//throw new NullPointerException("the pkEntity is null.");
		}
		combKey.put(tableSignature, entity);
	}

	private static boolean isSinglePK(String column,String tableSignature) {
		// TODO Auto-generated method stub
		
		if(null == singleKey || singleKey.size() < 0)
			return false;
		
		PKEntity entity = singleKey.get(tableSignature);
		if(null == entity)
			return false;
		ArrayList<String> singleKeys = entity.getPKList();
		if(null == singleKeys || singleKeys.size() < 0)
			return false;
		
		return singleKeys.contains(column.trim());
	}

	/**
	 * 
	 * @param tableSignature
	 * @param column
	 * @param columnList
	 * @param combiPKS
	 */
	private static void checkCombinationPK_2_1(String tableSignature,
			String column, ArrayList<String> columnList,ArrayList<String> combiPKS,ArrayList<String> combiPKS_1,ArrayList<String> combiPKS_2) {
		// TODO Auto-generated method stub
		ArrayList<String> columnDataList = fieldData.get(tableSignature).get(column);
		for(String column_1 : columnList){
			if(column.trim().equals(column_1.trim()) || isSinglePK(column_1,tableSignature))
				continue;
			
			ArrayList<String> columnDataList_1 = fieldData.get(tableSignature).get(column_1);
			
			if(columnDataList.size() != columnDataList_1.size())
				continue;
			
			if((!Utilitys.isHasBlankEle(columnDataList) /*&& !Utilitys.isHasDuplicate(columnDataList)*/) && 
					(!Utilitys.isHasBlankEle(columnDataList_1) /*&& !Utilitys.isHasDuplicate(columnDataList_1)*/)){
				ArrayList<String> tempDataList = new ArrayList<String>();
				
				for(int i=0;i<columnDataList.size();i++){
					tempDataList.add(columnDataList.get(i).trim() + "|" + columnDataList_1.get(i).trim());
				}
				
				if(!Utilitys.isHasBlankEle(tempDataList) && !Utilitys.isHasDuplicate(tempDataList)){
					String combiPK = column + "|" + column_1;
					
					if(isContain4TwoColumn(combiPK,combiPKS))
						combiPKS.add(combiPK);
				}
			}
		
			checkCombinationPK_2_1_1(tableSignature,column,column_1,columnList,combiPKS_1,combiPKS_2); //combination pk,the length is 3
		
		}
	}

	private static void checkCombinationPK_2_1_1(String tableSignature,
			String column, String column_1, ArrayList<String> columnList,ArrayList<String> combiPKS_1,ArrayList<String> combiPKS_2) {
		// TODO Auto-generated method stub
		ArrayList<String> columnDataList = fieldData.get(tableSignature).get(column);
		ArrayList<String> columnDataList_1 = fieldData.get(tableSignature).get(column_1);
		for(String column_2 : columnList){
			if(column_2.trim().equals(column.trim()) || column_2.trim().equals(column_1.trim()) || isSinglePK(column_2,tableSignature))
				continue;
			ArrayList<String> columnDataList_2 = fieldData.get(tableSignature).get(column_2);
			
			if(columnDataList.size() != columnDataList_1.size() || columnDataList_2.size() != columnDataList.size() || 
					columnDataList_2.size() != columnDataList_1.size())
				continue;
			
			if((!Utilitys.isHasBlankEle(columnDataList) /*&& !Utilitys.isHasDuplicate(columnDataList)*/) && 
					(!Utilitys.isHasBlankEle(columnDataList_1) /*&& !Utilitys.isHasDuplicate(columnDataList_1)*/)
					&& (!Utilitys.isHasBlankEle(columnDataList_2) /*&& !Utilitys.isHasDuplicate(columnDataList_2)*/)){
				ArrayList<String> tempDataList = new ArrayList<String>();
				
				for(int i=0;i<columnDataList.size();i++){
					//System.out.println(tableSignature + " , " + column + " , " + column_1 + " , " + column_2);
					tempDataList.add(columnDataList.get(i).trim() + "|" + columnDataList_1.get(i).trim() + "|" + columnDataList_2.get(i).trim());
				}
				
				if(!Utilitys.isHasBlankEle(tempDataList) && !Utilitys.isHasDuplicate(tempDataList)){
					String combiPK = column + "|" + column_1 + "|" + column_2;
					
					if(isContain4TwoColumn(combiPK,combiPKS_1))
						combiPKS_1.add(combiPK);
				}
			}
			
			checkCombinationPK_2_1_1_1(tableSignature,column,column_1,column_2,columnList,combiPKS_2); //combination pk,the length is 4
		}
	}

	private static void checkCombinationPK_2_1_1_1(String tableSignature,
			String column, String column_1, String column_2,
			ArrayList<String> columnList, ArrayList<String> combiPKS_2) {
		// TODO Auto-generated method stub
		ArrayList<String> columnDataList = fieldData.get(tableSignature).get(column);
		ArrayList<String> columnDataList_1 = fieldData.get(tableSignature).get(column_1);
		ArrayList<String> columnDataList_2 = fieldData.get(tableSignature).get(column_2);
		
		for(String column_3 : columnList){
			if(column_3.trim().equals(column.trim()) || column_3.trim().equals(column_1.trim()) || column_3.trim().equals(column_2.trim()) || isSinglePK(column_3,tableSignature))
				continue;
			ArrayList<String> columnDataList_3 = fieldData.get(tableSignature).get(column_3);
			
			if(columnDataList.size() != columnDataList_1.size() || columnDataList_2.size() != columnDataList.size() ||
					columnDataList_2.size() != columnDataList_1.size() || columnDataList_3.size() != columnDataList.size() || 
					columnDataList_3.size() != columnDataList_1.size() || columnDataList_3.size() != columnDataList_2.size())
				continue;
			
			if((!Utilitys.isHasBlankEle(columnDataList) /*&& !Utilitys.isHasDuplicate(columnDataList)*/) && 
					(!Utilitys.isHasBlankEle(columnDataList_1) /*&& !Utilitys.isHasDuplicate(columnDataList_1)*/)
					&& (!Utilitys.isHasBlankEle(columnDataList_2) /*&& !Utilitys.isHasDuplicate(columnDataList_2)*/
					&&(!Utilitys.isHasBlankEle(columnDataList_3)))){
				ArrayList<String> tempDataList = new ArrayList<String>();
				
				for(int i=0;i<columnDataList.size();i++){
					tempDataList.add(columnDataList.get(i).trim() + "|" + columnDataList_1.get(i).trim() + "|" + columnDataList_2.get(i).trim() + "|" + columnDataList_3.get(i).trim());
				}
				
				
				/*if("SWGLM".equals(column.trim()) && "SFSSQ_QSRQ".equals(column_1.trim()) 
						&& "SFSSQ_ZZRQ".equals(column_2.trim()) && "SFZHM".equals(column_3.trim()))
					Utilitys.outPutSameElement(tempDataList);*/
				
				if(!Utilitys.isHasBlankEle(tempDataList) && !Utilitys.isHasDuplicate(tempDataList)){
					String combiPK = column + "|" + column_1 + "|" + column_2 + "|" + column_3;
					
					if(isContain4TwoColumn(combiPK,combiPKS_2))
						combiPKS_2.add(combiPK);
				}
			}
		}
	}

	private static ArrayList<String> changeArrayToArrayList(String[] array){
		ArrayList<String> list = new ArrayList<String>();
		
		if(array == null || array.length < 0)
			return null;
		for(String s : array){
			list.add(s);
		}
		
		return list;
	}
	
	private static boolean isContain4TwoColumn(String combiPK,
			ArrayList<String> combiPKS) {
		// TODO Auto-generated method stub
		if(combiPKS.size() < 0)
			return true;
		
		for(String pk : combiPKS){
			ArrayList<String> pkList = changeArrayToArrayList(pk.split("[|]"));
			Collections.sort(pkList);
			ArrayList<String> combiPKList = changeArrayToArrayList(combiPK.split("[|]"));
			Collections.sort(combiPKList);
			
			if(pkList.size() != combiPKList.size())
				return false;
	
			if(ifEqual(pkList,combiPKList))
				return false;
			else
				continue;
		    /*Iterator<String> chk_it = pkList.iterator();  
		    while(chk_it.hasNext()){  
		        String pk_it = chk_it.next();  
		        if(combiPKList.contains(pk_it)){
		        	combiPKList.remove(pk_it); //have error
		        	chk_it.remove();
		        }
		        else
		        	continue;
		    }  */
		}
		
		return true;
	}

	private static boolean ifEqual(ArrayList<String> pkList,
			ArrayList<String> combiPKList) {
		// TODO Auto-generated method stub
		for(int i=0;i<pkList.size();i++){
			if(pkList.get(i).trim().equals(combiPKList.get(i).trim()))
				continue;
			else
				return false;
		}
		
		return true;
	}

	/**
	 * obtain the table single pk
	 * @param tableSignature
	 * @param columnList
	 */
	private static void checkSinglePK(String tableSignature,
			ArrayList<String> columnList) {
		// TODO Auto-generated method stub
		ArrayList<String> singlePKS = new ArrayList<String>();
		if(null == columnList || columnList.size() < 1)
			return;
		
		for(String column : columnList){
			ArrayList<String> columnDataList = fieldData.get(tableSignature).get(column);
			if(!Utilitys.isHasBlankEle(columnDataList) && !Utilitys.isHasDuplicate(columnDataList)){
				singlePKS.add(column);
			}
		}
		
		if(null != singlePKS && singlePKS.size() > 0){
			PKEntity entity = new PKEntity();
			entity.setTableSignature(tableSignature);
			entity.setStatus(0);
			entity.setPKList(singlePKS);
			singleKey.put(tableSignature, entity);
			
		}
	}

	private static void listDirectory(String path)
			throws FileNotFoundException, IOException {
		File dir = new File(path);
		File file[] = dir.listFiles();
		for (int j = 0; j < file.length; j++) {
			if (file[j].isDirectory()) {
				listDirectory(file[j].getAbsolutePath());
			} else if (file[j].getName().endsWith("xls")) {
				String[][] result = Utilitys.getData(file[j], 0);
				fileName = file[j].getName();

				dealResult(result);

			}
		}
	}

	private static void dealResult(String[][] result) {
		int rowLength = result.length;
		int columnLength = result[0].length;
		String tableName = fileName.split("[.]")[1].trim();
		String tableSingnature = fileName.split("[.]")[0].trim();

		tableSignatureMap.put(tableSingnature, tableName);

		ArrayList<String> columnList = new ArrayList<String>();
		ArrayList<String> dataList = null;
		HashMap<String, ArrayList<String>> dataMap = new HashMap<String, ArrayList<String>>();
		HashMap<String, String> columnMap = new HashMap<String, String>();
		for (int i = 0; i < rowLength; i++) {
			for (int j = 1; /* ignore first column */j < columnLength/*
																	 * result[i].
																	 * length
																	 */; j++) {
				if (i == 0) {
					if (null != result[2][j] && typeList.contains(result[2][j].trim()))
						columnList.add(result[0][j]);
				}

				if (i == 1) {
					columnMap.put(result[0][j], result[1][j]);
				}

				if (i >= 3) {
					if (null != result[2][j] && typeList.contains(result[2][j].trim())) {
						if (null == dataMap.get(result[0][j])) {
							dataList = new ArrayList<String>();
							dataList.add(result[i][j]);
							dataMap.put(result[0][j], dataList);
						} else {
							dataList = dataMap.get(result[0][j]);
							dataList.add(result[i][j]);
							dataMap.put(result[0][j], dataList);
						}
					}
				}
			}
		}
		tableMap.put(tableSingnature, columnList);
		fieldData.put(tableSingnature, dataMap);
		columnSignatureMap.put(tableSingnature, columnMap);
	}

	private static void streamlineTableColumn() {
		// TODO Auto-generated method stub
		for (Entry<String, HashMap<String, ArrayList<String>>> entry : fieldData
				.entrySet()) {
			String tableName = entry.getKey();
			HashMap<String, ArrayList<String>> dataMap = entry.getValue();

			streamlineTableColumn_1(tableName, dataMap);
		}
	}

	private static void streamlineTableColumn_1(String tableName,
			HashMap<String, ArrayList<String>> dataMap) {
		// TODO Auto-generated method stub
		for (Entry<String, ArrayList<String>> entry : dataMap.entrySet()) {
			String columnName = entry.getKey();
			ArrayList<String> columnDataList = entry.getValue();

			if (!Utilitys.isLegal(columnDataList) || Utilitys.isExclude(columnName)) {
				tableMap.get(tableName).remove(columnName);
			}
		}
	}
}