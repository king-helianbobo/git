package com.soul.kaka.readExcel;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.mortbay.log.Log;

import com.splitword.soul.utility.StringUtil;
import com.soul.kaka.readExcel.ExtractSegmentData;
import com.soul.kaka.readExcel.ExtractExcelDataKaka;

;

public class ExtractLineContentData {

	private static Map<String, Integer> segmentMap = new HashMap<String, Integer>();
	private static Map<String, Integer> wordSegMap = new HashMap<String, Integer>();
	private static FileOutputStream lineSegmentOut;
	private static BufferedWriter lineSegmentBw;
	private static FileOutputStream wordSegOut;
	private static BufferedWriter wordSegBw;
	private static HashSet standardSet;
	private static ObjectMapper mapper = new ObjectMapper();

	static {
		try {
			lineSegmentOut = new FileOutputStream(
					"zhouqiOutput/official-07-22Result/segmentResult.txt");
			lineSegmentBw = new BufferedWriter(new OutputStreamWriter(
					lineSegmentOut, "utf-8"));
			wordSegOut = new FileOutputStream(
					"zhouqiOutput/official-07-22Result/wordSegResult.txt");
			wordSegBw = new BufferedWriter(new OutputStreamWriter(wordSegOut,
					"utf-8"));
		} catch (FileNotFoundException | UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @param args
	 * @throws IOException
	 * @throws JsonMappingException
	 * @throws JsonParseException
	 */
	public static void main(String[] args) throws JsonParseException,
			JsonMappingException, IOException {
		// TODO Auto-generated method stub
		standardSet=createStandardSet("library/synonym-new.txt");
		listDirectory("zhouqiOutput/official-07-22");
		ExtractSegmentData.outPutSegmentMapToTxt(segmentMap, lineSegmentBw);
		ExtractExcelDataKaka.outPutWordMapToTxt(wordSegMap, wordSegBw);
		close();
	}

	private static void close() {
		try {
			if (lineSegmentOut != null) {
				lineSegmentOut.close();
			}
			if (lineSegmentBw != null) {
				lineSegmentBw.close();
			}

			if (wordSegOut != null) {
				wordSegOut.close();
			}
			if (wordSegBw != null) {
				wordSegBw.close();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void listDirectory(String filepath)
			throws FileNotFoundException, IOException {
		File dir = new File(filepath);
		File file[] = dir.listFiles();

		for (int j = 0; j < file.length; j++) {
			if (file[j].isDirectory()) {
				listDirectory(file[j].getAbsolutePath());
			} else if (file[j].getName().endsWith("txt")) {

				String filename = file[j].getName();
				readSegmentData("zhouqiOutput/official-07-22/" + filename);
				// readWordSegData("zhouqiOutput/contentTest/"+filename);
			} else {
				System.out.println("do nothing");
			}
		}
	}

	// private static void readWordSegData(String path){
	//
	// }

	

	private static void readSegmentData(String path) throws JsonParseException,
			JsonMappingException, IOException {

		BufferedReader reader = new BufferedReader(new InputStreamReader(
				new FileInputStream(path), "UTF-8"));
		String temp = null;
		while ((temp = reader.readLine()) != null) {
			temp = temp.trim();
			if (StringUtil.isBlank(temp))
				continue;
			JsonParser jsonParser = mapper.getJsonFactory().createJsonParser(
					temp);
			@SuppressWarnings("unchecked")
			Map<String, String> entry = mapper.readValue(jsonParser, Map.class);
			String contentAndTitle = entry.get("contenttitle") + "  "
					+ entry.get("content");
			System.out.println("charCount = " + contentAndTitle.length());
			char[] chLine = ExtractSegmentData.getTextData(contentAndTitle);

			// 大于等于2小于等于6的segmentData的提取
			 ArrayList<String> segmentList = ExtractSegmentData.makeSegment(chLine);
			 ExtractSegmentData.countSegmentMap(segmentList, segmentMap);
			 System.out.println("segmentMap size  = " + segmentMap.size());
			 
			// 大于等于2小于等于6的迭代的wordSegData的提取
			ArrayList<String> wordSeg = ExtractExcelDataKaka.makeGroup(chLine,standardSet);
			ExtractExcelDataKaka.countWordMap(wordSeg, wordSegMap);
			System.out.println("wordSegMap size  = " + wordSegMap.size());
		}
		reader.close();

	}
	
	private static HashSet<String> createStandardSet(String standardTextPath)
			throws IOException {
		HashSet<String> standardSet = new HashSet<String>();

		BufferedReader reader = new BufferedReader(new InputStreamReader(
				new FileInputStream(standardTextPath), "UTF-8"));
		String temp = null;
		while ((temp = reader.readLine()) != null) {
			temp = temp.trim();
			if (StringUtil.isBlank(temp))
				continue;
			else {
				String[] str = temp.split(",");
				for (int i = 0; i < str.length; i++) {
					standardSet.add(str[i].trim());
				}
			}
		}
		reader.close();
		// System.out.println(standardSet.size());
		return standardSet;
	}

}
