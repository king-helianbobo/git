package com.soul.kaka.readExcel;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;

import com.splitword.soul.utility.StringUtil;

public class classifyContentSegData {

    private static Map<String,Integer> segmentMap2=new HashMap<String, Integer>();
    private static Map<String,Integer> segmentMap3=new HashMap<String, Integer>();
    private static Map<String,Integer> segmentMap4=new HashMap<String, Integer>();
    private static Map<String,Integer> segmentMap5=new HashMap<String, Integer>();
    private static Map<String,Integer> segmentMap6=new HashMap<String, Integer>();

    private static Map<String,Integer> segmentMapFilter2=new HashMap<String, Integer>();
    private static Map<String,Integer> segmentMapFilter3=new HashMap<String, Integer>();
    
    private static FileOutputStream segmentOut2;
	private static BufferedWriter segmentBw2;
	private static FileOutputStream segmentOut3;
	private static BufferedWriter segmentBw3;
	private static FileOutputStream segmentOut4;
	private static BufferedWriter segmentBw4;
	private static FileOutputStream segmentOut5;
	private static BufferedWriter segmentBw5;
	private static FileOutputStream segmentOut6;
	private static BufferedWriter segmentBw6;
	
	private static FileOutputStream segmentFilterOut2;
	private static BufferedWriter segmentFilterBw2;
	private static FileOutputStream segmentFilterOut3;
	private static BufferedWriter segmentFilterBw3;

//	static int total=0;
	
	static {
		try {
			segmentOut2 = new FileOutputStream(
					"zhouqiOutput/official-07-22Result/categorySeg2.txt");
			segmentBw2 = new BufferedWriter(new OutputStreamWriter(
					segmentOut2, "utf-8"));
			segmentOut3 = new FileOutputStream(
					"zhouqiOutput/official-07-22Result/categorySeg3.txt");
			segmentBw3 = new BufferedWriter(new OutputStreamWriter(
					segmentOut3, "utf-8"));
			segmentOut4 = new FileOutputStream(
					"zhouqiOutput/official-07-22Result/categorySeg4.txt");
			segmentBw4 = new BufferedWriter(new OutputStreamWriter(
					segmentOut4, "utf-8"));
			segmentOut5 = new FileOutputStream(
					"zhouqiOutput/official-07-22Result/categorySeg5.txt");
			segmentBw5 = new BufferedWriter(new OutputStreamWriter(
					segmentOut5, "utf-8"));
			segmentOut6 = new FileOutputStream(
					"zhouqiOutput/official-07-22Result/categorySeg6.txt");
			segmentBw6 = new BufferedWriter(new OutputStreamWriter(
					segmentOut6, "utf-8"));
			
			segmentFilterOut2 = new FileOutputStream(
					"zhouqiOutput/official-07-22Result/categorySegFilter2.txt");
			segmentFilterBw2 = new BufferedWriter(new OutputStreamWriter(
					segmentFilterOut2, "utf-8"));
			segmentFilterOut3 = new FileOutputStream(
					"zhouqiOutput/official-07-22Result/categorySegFilter3.txt");
			segmentFilterBw3 = new BufferedWriter(new OutputStreamWriter(
					segmentFilterOut3, "utf-8"));
			
		} catch (FileNotFoundException | UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * @param args
	 * @throws IOException
	 * @throws FileNotFoundException
	 */
	public static void main(String[] args) throws FileNotFoundException, IOException {
		// TODO Auto-generated method stub

		readSegmentData("zhouqiOutput/official-07-22Result/segmentResult.txt");
		outPutSegmentMapToTxt(segmentMap2,segmentBw2);
		outPutSegmentMapToTxt(segmentMap3,segmentBw3);
		outPutSegmentMapToTxt(segmentMap4,segmentBw4);
		outPutSegmentMapToTxt(segmentMap5,segmentBw5);
		outPutSegmentMapToTxt(segmentMap6,segmentBw6);
		
		outPutSegmentMapToTxt(segmentMapFilter2,segmentFilterBw2);
		outPutSegmentMapToTxt(segmentMapFilter3,segmentFilterBw3);
//		int sum=segmentMap2.size()+segmentMap3.size()+segmentMap4.size()+segmentMap5.size()+segmentMap6.size();
//		System.out.println("sum="+sum);
//		System.out.println("total="+total);
		close();
	}
	
	private static void close() throws IOException{
		if(segmentOut2!=null){
			segmentOut2.close();
		}
		if(segmentBw2!=null){
			segmentBw2.close();
		}
		
		if(segmentOut3!=null){
			segmentOut3.close();
		}
		if(segmentBw3!=null){
			segmentBw3.close();
		}
		
		if(segmentOut4!=null){
			segmentOut4.close();
		}
		if(segmentBw4!=null){
			segmentBw4.close();
		}
		
		if(segmentOut5!=null){
			segmentOut5.close();
		}
		if(segmentBw5!=null){
			segmentBw5.close();
		}
		
		if(segmentOut6!=null){
			segmentOut6.close();
		}
		if(segmentBw6!=null){
			segmentBw6.close();
		}
		
		if(segmentFilterOut2!=null){
			segmentFilterOut2.close();
		}
		if(segmentFilterBw2!=null){
			segmentFilterBw2.close();
		}
		
		if(segmentFilterOut3!=null){
			segmentFilterOut3.close();
		}
		if(segmentFilterBw3!=null){
			segmentFilterBw3.close();
		}
	}

	private static void readSegmentData(String path) throws JsonParseException,
			JsonMappingException, IOException {

		BufferedReader reader = new BufferedReader(new InputStreamReader(
				new FileInputStream(path), "UTF-8"));
		
		String temp = null;
		while ((temp = reader.readLine()) != null) {
//			total++;
			temp = temp.trim();
			if (StringUtil.isBlank(temp))
				continue;
			else{
				String[] str = temp.split(":");
				
				String key=str[0].trim();
				int length=key.length();
				Integer value=Integer.valueOf(str[1].trim());
				int num=value.intValue();
				if(length==2){
					segmentMap2.put(key, value);
					if(num>=5){
						segmentMapFilter2.put(key, value);
					}
				}else if(length==3){
					segmentMap3.put(key, value);
					if(num>=10){
						segmentMapFilter3.put(key, value);
					}
				}else if(length==4){
					segmentMap4.put(key, value);
					
				}else if(length==5){
					segmentMap5.put(key, value);
					
				}else{
					segmentMap6.put(key, value);
					
				}

			}

		}
		reader.close();

	}
	
	private static void outPutSegmentMapToTxt(Map<String, Integer> map,
			BufferedWriter segmentBw) throws IOException {

		for (Map.Entry<String, Integer> entry : map.entrySet()) {
			String key = entry.getKey();
			Integer value = entry.getValue();
			String outStr = key + ":  " + value + "\n";
			segmentBw.append(outStr);
		}

		segmentBw.flush();
	}

}
