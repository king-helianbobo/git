package com.soul.kaka.readExcel;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.splitword.lionsoul.jcseg.util.ChineseHelper;

public class ExtractSpeSegData {

	private static FileOutputStream speSegmentOut;
	private static BufferedWriter speSegmentBw;
	private static Map<String, Integer> speSegmentMap=new HashMap<String, Integer>();
	
	static{
		try{
			speSegmentOut = new FileOutputStream(
					"zhouqiOutput/speSegText/speSegResult.txt");
			speSegmentBw = new BufferedWriter(new OutputStreamWriter(
					speSegmentOut, "utf-8"));
		}catch(FileNotFoundException | UnsupportedEncodingException e){
			e.printStackTrace();
		}
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		readAndWriteSpeText("zhouqiOutput/testFiles");
		outPutSpeSegMapToTxt(speSegmentMap,speSegmentBw);
		close();
	}
	
	private static void close() throws IOException{
		if(speSegmentOut!=null	){
			speSegmentOut.close();
		}
		if(speSegmentBw!=null){
			speSegmentBw.close();
		}
	}

	private static void readAndWriteSpeText(String path)
			throws FileNotFoundException, IOException {
		File dir = new File(path);
		File file[] = dir.listFiles();

		for (int j = 0; j < file.length; j++) {
			if (file[j].isDirectory()) {
				readAndWriteSpeText(file[j].getAbsolutePath());
			} else if (file[j].getName().endsWith("txt")) {
				String filename = file[j].getName();
				char[] result = getTextData(file[j]);

				ArrayList<String> speSegmentList = makeSpeSegment(result);
				countSpeSegmentMap(speSegmentList,speSegmentMap);

			} else {
				System.out.println("do nothing");
			}
		}

	}
	
	public static void outPutSpeSegMapToTxt(Map<String, Integer> map,
			BufferedWriter wordSegmentBw) throws IOException {

		for (Map.Entry<String, Integer> entry : map.entrySet()) {
			String key = entry.getKey();
			Integer value = entry.getValue();
			String outStr = key + ":  " + value + "\n";
			wordSegmentBw.append(outStr);
		}

		wordSegmentBw.flush();
	}
	
	public static void countSpeSegmentMap(ArrayList<String> speSegmentList,Map<String, Integer> speSegmentMap) {
		for (int i = 0; i < speSegmentList.size(); i++) {
			String keyStr = (String) speSegmentList.get(i);
			Integer count = speSegmentMap.get(keyStr);
			if (count == null)
				speSegmentMap.put(keyStr, 1);
			else
				speSegmentMap.put(keyStr, count + 1);
		}
	}
	
	public static ArrayList<String> makeSpeSegment(char[] result) {
		ArrayList<String> speSegmentList = new ArrayList<String>();

		int i = 0;
		while (true) {
			if (result[i] == '終') {
				break;
			}

			if (result[i] == '《' || result[i] == '\"' || result[i] == '“') {
				char startChar = result[i];
				int start = i;
				int end = 0;
				i++;
				
				if (result[i] == '終') {
					break;
				}
				if (!ChineseHelper.isChineseChar(result[i])) {
					i++;
					continue;
				}
				
				i++;
				if (result[i] == '終') {
					break;
				}
				if (!ChineseHelper.isChineseChar(result[i])) {
					i++;
					continue;
				}else {
					for (int k = 1; k <= 5; k++) {
						 end=i+k;
                         if(result[i+k]=='終'){
                        	 break;
                         }
                         
                         if((startChar=='《'  && result[i+k]=='》')  || (startChar=='\"'  && result[i+k]=='\"') ||(startChar=='“'  && result[i+k]=='”') ){
                        	
                        	 String str=new String(result,start,end-start+1);
                        	 speSegmentList.add(str);
                        	 break;
                         }
					}
					if(result[end]=='終'){
                   	 break;
                    }
					i=end+1;
				}
			}else{
				i++;
			}
		}

		return speSegmentList;
	}

	private static char[] getTextData(File file) throws FileNotFoundException,
			IOException {
		char[] chTxt = new char[50000];
		InputStreamReader isr = new InputStreamReader(new FileInputStream(file));
		int length = isr.read(chTxt);
		chTxt[length] = '終';

		if (isr != null) {
			isr.close();
		}

		return chTxt;
	}
}