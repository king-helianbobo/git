package com.elasticsearch.keyword.compare;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.elasticsearch.application.query.SoulFileWriter;

public class ExtractUsefulData {
	private static final String regEx = "[\u4e00-\u9fa5]";

	public static void readFile(String path, SoulFileWriter writer) {
		try {
			File file = new File(path);
			if (file.isFile() && file.exists()) {
				InputStreamReader reader = new InputStreamReader(
						new FileInputStream(file));
				BufferedReader bufferedReader = new BufferedReader(reader);
				String lineTxt = null;
				int i = 0;
				while ((lineTxt = bufferedReader.readLine()) != null) {
					if ("--".equals(lineTxt))
						continue;

					while (i < 2) {
						lineTxt += "\n" + bufferedReader.readLine();
						i++;
					}
					Pattern p = Pattern.compile(regEx);
					Matcher m = p.matcher(lineTxt);
					if (m.find()) {
						StringBuilder sb = new StringBuilder();
						sb.append(lineTxt.replaceAll("\\t", "、") + "\n");
						sb.append("--\n");
						writer.writeStr(sb.toString());
						writer.flush();
					}
					i = 0;
				}
				reader.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
