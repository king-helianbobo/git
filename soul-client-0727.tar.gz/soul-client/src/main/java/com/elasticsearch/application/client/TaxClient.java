package com.elasticsearch.application.client;

import java.io.Closeable;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.httpclient.HostConfiguration;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.URI;
import org.apache.commons.httpclient.params.HttpClientParams;
import org.apache.commons.httpclient.params.HttpConnectionManagerParams;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.ObjectMapper;

import com.elasticsearch.application.TaxDataReader;
import com.elasticsearch.application.query.PostQuery;
import com.elasticsearch.application.query.SoulQueryUtil;

public class TaxClient implements Closeable {

	protected String url = null;
	protected String index = null;
	private static ObjectMapper mapper = new ObjectMapper();
	protected PostQuery postQuery = null;
	private static final Log log = LogFactory.getLog(TaxClient.class);

	public static Map<String, Map<String, Object>> tableDefMap = null;
	public static Map<String, Map<String, List<String>>> tableFieldsMap = null;
	static {
		try {
			tableDefMap = TaxDataReader.readDefData("liuboOutput/def.txt");
			tableFieldsMap = TaxQueryUtil.generateList();
			log.info("resultMap.size() = " + tableDefMap.size());
		} catch (JsonParseException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public TaxClient(String url, String index) {
		HttpClientParams params = new HttpClientParams();
		params.setConnectionManagerTimeout(20 * 1000);
		HttpClient client = new HttpClient(params);
		HostConfiguration hostConfig = new HostConfiguration();
		this.url = url;
		this.index = index;
		// this.type = type;
		try {
			hostConfig.setHost(new URI(this.url, false));
		} catch (IOException ex) {
			throw new IllegalArgumentException("Invalid target URI " + url, ex);
		}
		client.setHostConfiguration(hostConfig);
		HttpConnectionManagerParams connectionParams = client
				.getHttpConnectionManager().getParams();
		// make sure to disable Nagle's protocol
		connectionParams.setTcpNoDelay(true);
		this.postQuery = new PostQuery(client);
	}

	protected List<Map<String, Object>> primeTokenList(String queryStr) {
		String query = index + "/_analyze?analyzer=soul_query_nature&pretty";
		Map<String, Object> map = postQuery.post(query, queryStr);
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> tokenMaps = (List<Map<String, Object>>) map
				.get("tokens");
		return tokenMaps;
	}

	protected Map<Integer, List<Map<String, Object>>> secondTokenList(
			List<Map<String, Object>> tokenMaps) {
		Map<Integer, List<Map<String, Object>>> posMaps = new HashMap<Integer, List<Map<String, Object>>>();
		for (int i = 0; i < tokenMaps.size(); i++) {
			Map<String, Object> tmp = tokenMaps.get(i);
			String type = (String) tmp.get("type");
			int position = (Integer) tmp.get("position");
			if (type.equals("null") || type.equals("w"))
				continue;
			List<Map<String, Object>> mapList = posMaps.get(position);
			if (mapList == null)
				mapList = new LinkedList<Map<String, Object>>();
			mapList.add(tmp);
			posMaps.put(position, mapList);
		}
		if (posMaps.isEmpty())
			return null;
		else {
			Map<Integer, List<Map<String, Object>>> result = new HashMap<Integer, List<Map<String, Object>>>();
			Set<String> set = new HashSet<String>();
			for (Integer pos : posMaps.keySet()) {
				List<Map<String, Object>> list = posMaps.get(pos);
				String key = (String) list.get(0).get("token");
				if (!set.contains(key)) {
					set.add(key);
					result.put(pos, list);
				}
			}
			return result;
		}
	}

	@Override
	public void close() {
		postQuery.close();
	}

	private Map<String, Object> termQueryMap(String token,
			Map<String, Object> defMap, Map<String, List<String>> fieldsMap) {
		List<Map<String, Object>> array = new ArrayList<Map<String, Object>>();
		List<String> chineseFields = null;
		List<String> integerFields = null;
		List<String> floatFields = null;
		List<String> commonFields = null;
		if (fieldsMap != null) {
			chineseFields = fieldsMap.get("chinese");
			integerFields = fieldsMap.get("integer");
			floatFields = fieldsMap.get("float");
		}
		for (String field : defMap.keySet()) {
			Map<String, Object> map1 = null;
			if (floatFields != null && floatFields.contains(field)) {
				if (TaxQueryUtil.isFloat(token)) {
					map1 = SoulQueryUtil.termQueryMap(field, token);
				} else
					map1 = null;
			} else if (integerFields != null && integerFields.contains(field)) {
				if (TaxQueryUtil.isInteger(token)) {
					map1 = SoulQueryUtil.termQueryMap(field, token);
				} else
					map1 = null;
			} else
				map1 = SoulQueryUtil.termQueryMap(field, token);
			if (map1 != null)
				array.add(map1);
		}
		return SoulQueryUtil.createBooleanQueryMap(array, 1, "all");
	}

	public String taxSearchMultiType(String queryStr, int from, int size) {
		String url = index + "/_search?pretty=true";
		List<Map<String, Object>> primeTokens = primeTokenList(queryStr);
		Map<Integer, List<Map<String, Object>>> tokens = secondTokenList(primeTokens);
		if (tokens == null || tokens.isEmpty())
			return null;
		List<Map<String, Object>> array1 = new ArrayList<Map<String, Object>>();
		for (String tableName : tableDefMap.keySet()) {
			if (!tableFieldsMap.containsKey(tableName))
				continue;
			Map<String, Object> defMap = tableDefMap.get(tableName);
			Map<String, List<String>> fieldsMap = tableFieldsMap.get(tableName);
			List<Map<String, Object>> array = new ArrayList<Map<String, Object>>();
			for (Integer position : tokens.keySet()) {
				List<Map<String, Object>> tmpList = tokens.get(position);
				String token = (String) tmpList.get(0).get("token");
				log.info(token);
				array.add(termQueryMap(token, defMap, fieldsMap));
			}
			Map<String, Object> queryMap1 = SoulQueryUtil
					.createBooleanQueryMap(array, array.size(), "all");
			Map<String, Object> queryMap = queryMapWithFilter(queryMap1,
					tableName);
			array1.add(queryMap);
		}
		Map<String, Object> lastMap = SoulQueryUtil.createBooleanQueryMap(
				array1, 1, "all");
		String json = TaxQueryUtil.queryJson(lastMap, from, size);
		log.info(json);
		// log.info(url);
		Map<String, Object> map = postQuery.post(url, json);
		return constructJsonResult(map, from, tableDefMap);
	}

	public static Map<String, Object> queryMapWithFilter(
			Map<String, Object> queryMap, String tableName) {
		Map<String, Object> filter = new HashMap<String, Object>();
		Map<String, Object> tmp1 = new HashMap<String, Object>();
		tmp1.put("value", tableName);
		filter.put("type", tmp1);
		Map<String, Object> query = new HashMap<String, Object>();
		query.put("query", queryMap);
		Map<String, Object> filteredQuery = new HashMap<String, Object>();
		filteredQuery.put("query", queryMap);
		filteredQuery.put("filter", filter);
		Map<String, Object> tmp2 = new HashMap<String, Object>();
		tmp2.put("filtered", filteredQuery);
		return tmp2;
	}

	public static String queryJsonWithFilter(Map<String, Object> queryMap,
			int from, int size) {
		Map<String, Object> filter = new HashMap<String, Object>();
		Map<String, Object> tmp1 = new HashMap<String, Object>();
		tmp1.put("value", "A01");
		filter.put("type", tmp1);

		Map<String, Object> query = new HashMap<String, Object>();
		query.put("query", queryMap);

		Map<String, Object> filteredQuery = new HashMap<String, Object>();
		filteredQuery.put("query", queryMap);
		filteredQuery.put("filter", filter);
		Map<String, Object> tmp2 = new HashMap<String, Object>();
		tmp2.put("filtered", filteredQuery);
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("query", tmp2);
		result.put("from", from);
		result.put("size", size);
		try {
			String json = mapper.writeValueAsString(result);
			return json;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	public static String constructJsonResult(Map<String, Object> resultMap,
			int from, Map<String, Map<String, Object>> tableDefMap) {
		try {
			resultMap = (Map<String, Object>) resultMap.get("hits");
			if (resultMap == null)
				return null;
			List<Map<String, Object>> hits = (List<Map<String, Object>>) resultMap
					.get("hits");
			int totalSize = (Integer) resultMap.get("total");
			log.info(totalSize);
			List<Map<String, Object>> array = new ArrayList<Map<String, Object>>();
			for (int i = 0; i < hits.size(); i++) {
				Map<String, Object> map1 = hits.get(i);
				String map1Json = mapper.writeValueAsString(map1);
				log.info(map1Json);
				String tableName = (String) map1.get("_type");
				// double score = (Double) map1.get("_score");
				Map<String, Object> sourceMap = (Map<String, Object>) map1
						.get("_source");
				Map<String, Object> result2 = new LinkedHashMap<String, Object>();
				Map<String, Object> defMap = tableDefMap.get(tableName);
				result2.put("表名", tableName);
				for (String field : defMap.keySet()) {
					// log.info("field = " + field);
					String str = (String) sourceMap.get(field);
					Map<String, String> typeInfo = (Map<String, String>) defMap
							.get(field);
					String chineseFieldName = typeInfo.get("chineseFieldName");
					result2.put(chineseFieldName, str);
				}
				array.add(result2);
			}
			Map<String, Object> result = new HashMap<String, Object>();
			result.put("count", totalSize);
			result.put("size", hits.size());
			result.put("from", from);
			result.put("pageList", array);
			String resultJson = mapper.writeValueAsString(result);
			// log.info(resultJson);
			return resultJson;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}
}
