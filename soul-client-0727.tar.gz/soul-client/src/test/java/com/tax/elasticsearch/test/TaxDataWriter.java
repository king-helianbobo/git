package com.tax.elasticsearch.test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import junit.framework.Assert;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.map.ObjectMapper;
import org.elasticsearch.common.joda.FormatDateTimeFormatter;
import org.elasticsearch.common.joda.Joda;
import org.elasticsearch.common.joda.time.DateTime;
import org.elasticsearch.common.joda.time.Period;
import org.elasticsearch.common.joda.time.format.DateTimeFormat;
import org.elasticsearch.common.joda.time.format.DateTimeFormatter;

import com.splitword.lionsoul.jcseg.util.ChineseHelper;
import com.splitword.soul.utility.StringUtil;

public class TaxDataWriter {
	private static final Log log = LogFactory.getLog(TaxDataWriter.class);
	private static ObjectMapper mapper = new ObjectMapper();
	private static final String splitTag = "[.]";
	private static final FormatDateTimeFormatter formatter = Joda
			.forPattern("yy-MM-dd HH:mm:ss||yyyy-MM-dd||yyyy-MM-dd HH:mm||yyyyMMdd");

	public final static String suffixTag = ".000000";

	public static List<String> tableData(String fileName, List<String[]> result)
			throws IOException {
		String[] parts = fileName.split(splitTag);
		log.info(fileName);
		List<String> list = new ArrayList<String>();
		String[] values0 = result.get(0);
		String[] values1 = result.get(1);
		String[] values2 = result.get(2);

		// check below three lines
		for (int j = 0; j < values0.length; j++) {
			if (values0[j].equals("")) {
				Assert.assertEquals(values1[j], "");
				Assert.assertEquals(values2[j], "");
			} else
				Assert.assertEquals(values1[j].isEmpty(), false);
			if (values1[j].equals("")) {
				Assert.assertEquals(values0[j], "");
				Assert.assertEquals(values2[j], "");
			} else
				Assert.assertEquals(values0[j].isEmpty(), false);
		}
		for (int i = 3; i < result.size(); i++) {
			Map<String, String> tmp = new LinkedHashMap<String, String>();
			// must use linkedHashMap
			tmp.put("tableName", parts[0]);
			tmp.put("lineNumber", String.valueOf(i - 2));
			String[] valueII = result.get(i);
			for (int j = 0; j < valueII.length; j++) {
				String fieldName = values0[j];
				if (fieldName.equals(""))
					continue;
				String cellValue = valueII[j];
				if (values2[j].equals("string")) {
					if (cellValue.contains(suffixTag)) {
						Assert.assertEquals(true, cellValue.endsWith(suffixTag));
						cellValue = cellValue.substring(0, cellValue.length()
								- suffixTag.length());
					}
				} else if (values2[j].equals("integer")) {
					if (cellValue.contains(suffixTag)) {
						log.info(cellValue);
						Assert.assertEquals(true, cellValue.endsWith(suffixTag));
						cellValue = cellValue.substring(0, cellValue.length()
								- suffixTag.length());
					}
				} else if (values2[j].equals("date")) {
					if (cellValue.contains("月")
							&& (cellValue.contains("上午") || cellValue
									.contains("下午"))) {
						DateTimeFormatter outputFormat = DateTimeFormat
								.forPattern("yyyy-MM-dd HH:mm:ss");
						String time = JodaTimeTest.checkThisString(cellValue);
						DateTime dt1 = formatter.parser().parseDateTime(time);
						cellValue = dt1.toString(outputFormat);
					} else if (cellValue.contains(suffixTag)) {
						Assert.assertEquals(true, cellValue.endsWith(suffixTag));
						DateTimeFormatter outputFormat = DateTimeFormat
								.forPattern("yyyy-MM-dd");
						DateTime date = convertDate(cellValue);
						int year = date.getYear();
						if (year >= 2100 || year <= 1900) {
							String temp = cellValue.substring(0,
									cellValue.length() - suffixTag.length());
							Assert.assertEquals(8, temp.length());
							FormatDateTimeFormatter formatter = Joda
									.forPattern("yyyyMMdd");
							date = formatter.parser().parseDateTime(temp);
							cellValue = date.toString(outputFormat);
						} else
							cellValue = date.toString(outputFormat);
					} else if (cellValue.contains(".")) {
						DateTimeFormatter outputFormat = DateTimeFormat
								.forPattern("yyyy-MM-dd HH:mm:ss.SSS");
						DateTime date = convertDate(cellValue);
						cellValue = date.toString(outputFormat);
						cellValue = cellValue.substring(0,
								cellValue.length() - 4);
						log.info(cellValue);
					} else if (!StringUtil.isBlank(cellValue)) {
						if (ChineseHelper.allNumerical(cellValue)) {
							Assert.assertEquals(8, cellValue.length());
							FormatDateTimeFormatter formatter = Joda
									.forPattern("yyyyMMdd");
							DateTime dt3 = formatter.parser().parseDateTime(
									cellValue);
							DateTimeFormatter outputFormat = DateTimeFormat
									.forPattern("yyyy-MM-dd");
							cellValue = dt3.toString(outputFormat);
						} else {
							Assert.assertEquals(true, cellValue.contains("年")
									&& cellValue.contains("月"));
							Assert.assertEquals(true,
									values1[j].contains("所属期"));
							DateTimeFormatter outputFormat = DateTimeFormat
									.forPattern("yyyy-MM");
							int year = cellValue.indexOf("年");
							int month = cellValue.indexOf("月");
							String monthStr = cellValue.substring(year + 1,
									month);
							year = Integer
									.valueOf(cellValue.substring(0, year));
							month = Integer.valueOf(monthStr);
							DateTime dt3 = new DateTime(year, month, 1, 1, 1);
							cellValue = dt3.toString(outputFormat);
						}
					}
					// log.info(values0[j] + "," + values1[j] + "," + value);
				}
				tmp.put(fieldName, cellValue);
			}
			String json = mapper.writeValueAsString(tmp);
			list.add(json);
		}
		return list;
	}

	private static DateTime convertDate(String cellValue) {
		String[] strs = cellValue.split("[.]");
		int numberDays = Integer.valueOf(strs[0]);
		DateTime dt = new DateTime(1899, 12, 30, 0, 0, 0, 0);
		DateTime date = dt.plus(Period.days(numberDays));
		float fracRatio = Float.valueOf("0." + strs[1]);

		int millis = (int) (24.0f * 3600.0f * 1000.0f * fracRatio);
		log.info(fracRatio + ", " + millis);
		date = date.plus(Period.millis(millis));
		return date;
	}

	public static String tableDefinition(String fileName, List<String[]> result)
			throws IOException {
		String[] parts = fileName.split(splitTag);
		String[] values0 = result.get(0);
		String[] values1 = result.get(1);
		String[] values2 = result.get(2);
		Map<String, Object> map2 = new LinkedHashMap<String, Object>();
		for (int i = 0; i < values0.length; i++) {
			String fieldName = values0[i];
			if (StringUtil.isBlank(fieldName))
				continue;
			Map<String, String> tmp = new LinkedHashMap<String, String>();
			tmp.put("chineseFieldName", values1[i]);
			tmp.put("dataType", values2[i]);
			map2.put(fieldName, tmp);
		}
		map2.put("chineseTableName", parts[1]);
		Map<String, Object> map = new LinkedHashMap<String, Object>();
		map.put(parts[0], map2);
		String json = mapper.writeValueAsString(map);
		return json;
	}

}
