package com.tax.elasticsearch.test;

import java.util.LinkedHashMap;
import java.util.Map;

public class ESMapUtil {
	public static Map<String, Object> settingMap() {
		Map<String, Object> tmp1 = new LinkedHashMap<String, Object>();
		tmp1.put("refresh_interval", 10);
		tmp1.put("number_of_replicas", 1);
		Map<String, Object> tmp2 = new LinkedHashMap<String, Object>();
		tmp2.put("index", tmp1);
		return tmp2;
	}

	public static Map<String, Object> untouchedMap(String fieldName,
			String analyzer) {
		Map<String, Object> tmp1 = new LinkedHashMap<String, Object>();
		tmp1.put("type", "string");
		tmp1.put("index_analyzer", analyzer);

		Map<String, Object> tmp2 = new LinkedHashMap<String, Object>();
		tmp2.put("type", "string");
		tmp2.put("index", "not_analyzed");

		Map<String, Object> second = new LinkedHashMap<String, Object>();
		second.put(fieldName, tmp1);
		second.put("untouched", tmp2);

		Map<String, Object> first = new LinkedHashMap<String, Object>();
		first.put("type", "multi_field");
		first.put("fields", second);
		return first;
	}
}
