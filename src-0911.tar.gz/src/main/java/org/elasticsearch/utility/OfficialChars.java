package org.elasticsearch.utility;

import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.splitword.soul.library.InitDictionary;
import org.splitword.soul.utility.StringUtil;

public class OfficialChars {
	private static Log log = LogFactory.getLog(OfficialChars.class);
	private static final Map<String, String> firstLevel = new TreeMap<String, String>();
	private static final Map<String, String> secondLevel = new TreeMap<String, String>();
	static final String blankChars[] = { "∴", "∞", "॰", "°", "゜", "❯", "∩",
			"＼", "∨", "ⅹ", "÷", "◎", "﹥", "", "⌥", "↑", "↓", "", "→", "⥛",
			"➥", "∥", "╳", "┼", "├", "┤", "┬", "┴", "∀", "≮", "⇋", "∑", "≈",
			"∈" };
	static final String removeChars[] = { "®", "ͧ", "ͬ", "¾", "²", "³", " ⷲ" };

	private static void init1() {
		firstLevel.put("Ⅰ", "一");
		firstLevel.put("Ⅱ", "二");
		firstLevel.put("Ⅲ", "三");
		firstLevel.put("Ⅳ", "四");
		firstLevel.put("Ⅴ", "五");
		firstLevel.put("Ⅵ", "六");
		firstLevel.put("Ⅶ", "七");
		firstLevel.put("Ⅷ", "八");
		firstLevel.put("Ⅸ", "九");
		firstLevel.put("Ⅹ", "十");
		firstLevel.put("Ⅺ", "十一");
		firstLevel.put("Ⅻ", "十二");

		firstLevel.put("⑴", "(1)");
		firstLevel.put("⑵", "(2)");
		firstLevel.put("⑶", "(3)");
		firstLevel.put("⑷", "(4)");
		firstLevel.put("⑸", "(5)");
		firstLevel.put("⑹", "(6)");
		firstLevel.put("⑺", "(7)");
		firstLevel.put("⑻", "(8)");
		firstLevel.put("⑼", "(9)");
		firstLevel.put("⑽", "(10)");
		firstLevel.put("⑾", "(11)");
		firstLevel.put("⑿", "(12)");
		firstLevel.put("⒀", "(13)");
		firstLevel.put("⒁", "(14)");
		firstLevel.put("⒂", "(15)");
		firstLevel.put("⒃", "(16)");
		firstLevel.put("⒄", "(17)");
		firstLevel.put("⒅", "(18)");

		firstLevel.put("①", "(1)");
		firstLevel.put("②", "(2)");
		firstLevel.put("③", "(3)");
		firstLevel.put("④", "(4)");
		firstLevel.put("⑤", "(5)");
		firstLevel.put("⑥", "(6)");
		firstLevel.put("⑦", "(7)");
		firstLevel.put("⑧", "(8)");
		firstLevel.put("⑨", "(9)");
		firstLevel.put("⑩", "(10)");
		firstLevel.put("⑪", "(11)");
		firstLevel.put("⑫", "(12)");

		firstLevel.put("⒈", "1. ");
		firstLevel.put("⒉", "2. ");
		firstLevel.put("⒊", "3. ");
		firstLevel.put("⒋", "4. ");
		firstLevel.put("⒌", "5. ");
		firstLevel.put("⒍", "6. ");
		firstLevel.put("⒎", "7. ");
		firstLevel.put("⒏", "8. ");
		firstLevel.put("⒐", "9. ");
		firstLevel.put("⒑", "10. ");
		firstLevel.put("⒛", "20. ");

		firstLevel.put("㈠", "(1)");
		firstLevel.put("㈡", "(2)");
		firstLevel.put("㈢", "(3)");
		firstLevel.put("㈣", "(4)");
		firstLevel.put("㈤", "(5)");
		firstLevel.put("㈥", "(6)");
		firstLevel.put("㈦", "(7)");
		firstLevel.put("㈧", "(8)");
		firstLevel.put("㈨", "(9)");
		firstLevel.put("㈩", "(10)");
	}

	private static void init2() {
		secondLevel.put("㎝", "cm");
		secondLevel.put("№", "No");
		secondLevel.put("㎡", "平方米");
		secondLevel.put("", ".");
		secondLevel.put("・", ".");
		secondLevel.put("★", "★");
		secondLevel.put("☆", "★");
		secondLevel.put("○", "0");
		secondLevel.put("〇", "0");
		secondLevel.put("※", "※");
		secondLevel.put("□", "□");
		secondLevel.put("■", "■");
		secondLevel.put("◇", "◇");
		secondLevel.put("◆", "◆");
		secondLevel.put("′", "\"");
		secondLevel.put("＇", "\"");
		secondLevel.put("｀", "\"");
		secondLevel.put("″", "\"");
		secondLevel.put("＂", "\"");
		secondLevel.put("｜", "|");
		secondLevel.put("│", "|");
		secondLevel.put("＠", "@");
		secondLevel.put("﹫", "@");
		secondLevel.put("＃", "#");
		secondLevel.put("﹩", "$");
		secondLevel.put("﹪", "%");
		secondLevel.put("＆", "&");
		secondLevel.put("", "");
		secondLevel.put("￥", "￥");
		secondLevel.put("━", "-");
		secondLevel.put("─", "-");
		secondLevel.put("┄", "-");
		secondLevel.put("——", "-");
		secondLevel.put("＿", "-");
		secondLevel.put("˭", "=");
		secondLevel.put("⾧", "长");
		secondLevel.put("⼯", "工");
		secondLevel.put("⾨", "门");

		secondLevel.put("{", "《");
		secondLevel.put("}", "》");
		secondLevel.put("｛", "《");
		secondLevel.put("｝", "》");
		secondLevel.put("‹", "《");
		secondLevel.put("›", "》");
		secondLevel.put("︵", "《");
		secondLevel.put("︶", "》");
		secondLevel.put("︷", "《");
		secondLevel.put("︸", "》");
		secondLevel.put("︹", "《");
		secondLevel.put("︺", "》");
		secondLevel.put("︽", "《");
		secondLevel.put("︾", "》");
		secondLevel.put("︿", "《");
		secondLevel.put("﹀", "》");
		secondLevel.put("﹃", "《");
		secondLevel.put("﹄", "》");
		secondLevel.put("﹁", "《");
		secondLevel.put("﹂", "》");
		secondLevel.put("«", "《");
		secondLevel.put("»", "》");
		secondLevel.put("<", "《");
		secondLevel.put(">", "》");
		secondLevel.put("〉", "《");
		secondLevel.put("〈", "》");
		secondLevel.put("┘", "】");
		secondLevel.put("┐", "】");
		secondLevel.put("└", "【");
		secondLevel.put("┌", "【");
		secondLevel.put("〖", "【");
		secondLevel.put("〗", "】");
		secondLevel.put("〔", "【");
		secondLevel.put("〕", "】");
		secondLevel.put("[", "【");
		secondLevel.put("]", "】");
		secondLevel.put("『", "【");
		secondLevel.put("』", "】");
		secondLevel.put("「", "【");
		secondLevel.put("」", "】");
		secondLevel.put("︻", "【");
		secondLevel.put("︼", "】");
		secondLevel.put("﹝", "【");
		secondLevel.put("﹞", "】");
		secondLevel.put("（", "(");
		secondLevel.put("）", ")");
	}

	static {
		init1();
		init2();
	}

	public static String removeConsecutiveWhiteSpaces(String sentence) {
		int numWhiteSpace = 0;
		StringBuilder builder = new StringBuilder();
		char prevChar = ' ';
		for (int i = 0; i < sentence.length(); i++) {
			char c = sentence.charAt(i);
			String str = String.valueOf(c);
			if (StringUtil.isBlank(str))
				numWhiteSpace += 1;
			else {
				if (numWhiteSpace > 0) {
					if (WordAlter.isLetterOrDigit(c)
							&& WordAlter.isLetterOrDigit(prevChar)) {
						builder.append(" ");
					}
					numWhiteSpace = 0;
				} else if (Character.isDigit(prevChar)
						&& (str.equals("、") || str.equals(","))) {
					builder.append(" ");
					prevChar = ' ';
					numWhiteSpace = 1;
					continue;
				}
				prevChar = c;
				builder.append(c);
				numWhiteSpace = 0;
			}
		}
		return builder.toString();
	}

	// 移除空白，仅仅对标题这样做。
	public static String removeWhiteSpaces(String sentence) {
		StringBuilder builder = new StringBuilder();
		for (int i = 0; i < sentence.length(); i++) {
			char c = sentence.charAt(i);
			String str = String.valueOf(c);
			if (StringUtil.isNotBlank(str))
				builder.append(c);
		}
		return builder.toString();
	}

	public static String convertInvalidChars(String sentence) {
		StringBuilder builder = new StringBuilder();
		for (int i = 0; i < sentence.length(); i++) {
			char c = sentence.charAt(i);
			int charNum = (int) c;
			if (charNum == 65533) {
				continue;
			} else if (InitDictionary.systemChars[c] > 0) { // Chinese char
				builder.append(c);
			} else if ((charNum < 256) && (charNum >= 0)) { // ASCII
				if ((charNum <= 126) && (charNum >= 32)) {
					// printable character
					builder.append(c);
				} else
					builder.append(" ");
			} else if (OfficialChars.bParticularChar(c)) {
				String str = particularTreat(String.valueOf(c));
				builder.append(str);
			} else if (Character.isLetterOrDigit(c)) {
				builder.append(c);
			} else {
				builder.append(" ");
				// replace invalid char with whitespace
			}
		}
		String result = builder.toString();
		return result;
		// return removeConsecutiveWhiteSpaces(result);
	}

	private static String particularTreat(String sentence) {
		StringBuilder builder = new StringBuilder();
		terms: for (int i = 0; i < sentence.length(); i++) {
			char c = sentence.charAt(i);
			String str = String.valueOf(c);
			int charNum = (int) c;
			if (charNum == 8211) {
				builder.append("-");
			} else if (charNum == 8226) {
				builder.append(".");
			} else if (charNum == 9670) {
				builder.append("◆");
			} else if (charNum == 8224) {
				builder.append("□");
			} else if (firstLevel.containsKey(str))
				builder.append(firstLevel.get(str));
			else if (secondLevel.containsKey(str))
				builder.append(secondLevel.get(str));
			else {
				for (int j = 0; j < blankChars.length; j++) {
					if (blankChars[j].equals(str)) {
						builder.append(" ");
						continue terms;
					}
				}
				for (int j = 0; j < removeChars.length; j++) {
					if (removeChars[j].equals(str))
						continue terms;
				}
				builder.append(" ");
			}
		}
		return builder.toString();
	}

	public static boolean bParticularChar(char c) {
		String str = String.valueOf(c);
		if (firstLevel.containsKey(str) || secondLevel.containsKey(str))
			return true;
		else if (firstLevel.values().contains(str)
				|| secondLevel.values().contains(str)) {
			return true;
		} else {
			for (int i = 0; i < blankChars.length; i++) {
				if (blankChars[i].equals(str))
					return true;
			}
			for (int i = 0; i < removeChars.length; i++) {
				if (removeChars[i].equals(str))
					return true;
			}
			return false;
		}
	}

	// 对content进行检查，如果修改了content的内容，则返回修改后的内容,
	// 如果没有修改，则返回原先的content
	public static String removeTimeInContent(final String title, String content) {
		final String time1 = "发布时间";
		final String time2 = "修改时间";
		final String time3 = "浏览次数";
		String result = null;
		int titlePos = content.indexOf(title);
		if (titlePos < 0)
			result = content;
		else {
			String original = content;
			content = content.substring(titlePos + title.length());
			if ((content.indexOf(time1) < 0) || (content.indexOf(time2) < 0)
					|| (content.indexOf(time3) < 0)) {
				result = original;
			} else {
				int pos = content.indexOf(time3);
				int endPos = pos + time3.length() + 1;
				for (int j = pos + time3.length() + 1; j < content.length(); j++) {
					char c = content.charAt(j);
					if (Character.isDigit(c)) {
						endPos++;
						continue;
					} else
						break;
				}
				result = content.substring(endPos);
				if (result.length() < 25)
					result = original;
			}
		}
		return result.trim();
	}
}
