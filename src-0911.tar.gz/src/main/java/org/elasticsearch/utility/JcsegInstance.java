package org.elasticsearch.utility;

import org.splitword.soul.jcseg.JcSegment;

public class JcsegInstance {
	private static final JcSegment jcSegment = new JcSegment();

	public static JcSegment instance() {
		return jcSegment;
	}
}
