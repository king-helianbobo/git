package org.elasticsearch.hadoop.mr;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.JobContext;
import org.apache.hadoop.mapreduce.RecordReader;
import org.apache.hadoop.mapreduce.TaskAttemptContext;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.util.LineReader;

public class JoinNLineInputFormat extends FileInputFormat<LongWritable, Text> {
	public static final String LINES_PER_MAP = "mapreduce.input.lineinputformat.linespermap";

	public RecordReader<LongWritable, Text> createRecordReader(
			InputSplit genericSplit, TaskAttemptContext context)
			throws IOException {
		context.setStatus(genericSplit.toString());
		return new JoinLineRecordReader();
	}

	/**
	 * Logically splits the set of input files for the job, splits N lines of
	 * the input as one split.
	 * 
	 * @see FileInputFormat#getSplits(JobContext)
	 */
	public List<InputSplit> getSplits(JobContext job) throws IOException {
		List<InputSplit> splits = new ArrayList<InputSplit>();
		int numLinesPerSplit = getNumLinesPerSplit(job);
		Configuration conf = job.getConfiguration();
		for (FileStatus status : listStatus(job)) {
			List<JoinFileInputSplit> list = getSplitsForFile(status, conf,
					numLinesPerSplit);
			int n = list.size();
			for (int i = 0; i < n; i++) {
				JoinFileInputSplit split1 = list.get(i);
				Path file1 = split1.getPath();
				long start1 = split1.getStart();
				long length1 = split1.getLength();
				int lines1 = split1.getTotalLines();
				String[] hosts1 = new String[] {};
				for (int j = i; j < n; j++) {
					JoinFileInputSplit split2 = list.get(j);
					long start2 = split2.getStart();
					long length2 = split2.getLength();
					int lines2 = split2.getTotalLines();
					if (i != j) {
						JoinFileInputSplit mySplit = new JoinFileInputSplit(
								file1, start1, length1, hosts1, i, j, start2,
								length2, (lines1 + lines2));
						splits.add(mySplit);
					} else {
						JoinFileInputSplit mySplit = new JoinFileInputSplit(
								file1, start1, length1, hosts1, i, j, start2,
								length2, lines1);
						splits.add(mySplit);
					}
				}
			}
		}
		return splits;
	}

	private static List<JoinFileInputSplit> getSplitsForFile(FileStatus status,
			Configuration conf, int numLinesPerSplit) throws IOException {
		List<JoinFileInputSplit> splits = new ArrayList<JoinFileInputSplit>();
		Path fileName = status.getPath();
		if (status.isDir()) {
			throw new IOException("Not a file: " + fileName);
		}
		FileSystem fs = fileName.getFileSystem(conf);
		LineReader lr = null;
		try {
			FSDataInputStream in = fs.open(fileName);
			lr = new LineReader(in, conf);
			Text line = new Text();
			int numLines = 0;
			long begin = 0;
			long length = 0;
			int num = -1;
			while ((num = lr.readLine(line)) > 0) {
				numLines++;
				length += num;
				if (numLines == numLinesPerSplit) {
					splits.add(createFileSplit(fileName, begin, length,
							numLines));
					begin += length;
					length = 0;
					numLines = 0;
				}
			}
			if (numLines != 0) {
				splits.add(createFileSplit(fileName, begin, length, numLines));
			}
		} finally {
			if (lr != null) {
				lr.close();
			}
		}
		return splits;
	}

	/***
	 * JoinNLineInputFormat uses LineRecordReader, which always reads (and
	 * consumes) at least one character out of its upper split boundary. So to
	 * make sure that each mapper gets N lines, we move back the upper split
	 * limits of each split by one character here.
	 */
	private static JoinFileInputSplit createFileSplit(Path fileName,
			long begin, long length, int numLines) {
		if (begin == 0)
			return new JoinFileInputSplit(fileName, begin, length - 1,
					new String[] {}, numLines);
		else
			return new JoinFileInputSplit(fileName, begin - 1, length,
					new String[] {}, numLines);
	}

	public static void setNumLinesPerSplit(Job job, int numLines) {
		job.getConfiguration().setInt(LINES_PER_MAP, numLines);
	}

	public static int getNumLinesPerSplit(JobContext job) {
		return job.getConfiguration().getInt(LINES_PER_MAP, 1);
	}
}