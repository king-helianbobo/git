package org.elasticsearch.plugin.analyzer;

import java.io.Reader;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.Tokenizer;
import org.apache.lucene.analysis.standard.StandardFilter;
import org.elasticsearch.plugin.EsStaticValue;
import org.elasticsearch.plugin.tokenizer.BasicTokenizer;
import org.elasticsearch.plugin.tokenizer.SynonymTokenFilter;
import org.splitword.soul.analysis.BasicAnalysis;

public class SoulNatureAnalyzer extends Analyzer {

	public SoulNatureAnalyzer() {
		super();
	}

	@Override
	protected TokenStreamComponents createComponents(String fieldName,
			final Reader reader) {
		Tokenizer tokenizer = new BasicTokenizer(
				new BasicAnalysis(reader, true), reader, null,
				EsStaticValue.pstemming);
		TokenStream result = new StandardFilter(EsStaticValue.LuceneVersion,
				tokenizer);
		result = new SynonymTokenFilter(result);
		return new TokenStreamComponents(tokenizer, result);
	}
}
