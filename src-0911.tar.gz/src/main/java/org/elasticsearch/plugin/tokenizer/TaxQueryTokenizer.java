package org.elasticsearch.plugin.tokenizer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.lucene.analysis.Tokenizer;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
import org.elasticsearch.utility.ChineseHelper;
import org.elasticsearch.utility.WordAlter;
import org.junit.Assert;
import org.splitword.soul.analysis.BasicAnalysis;
import org.splitword.soul.domain.Term;
import org.splitword.soul.utility.StringUtil;

public class TaxQueryTokenizer extends Tokenizer {

	class TokenPojo {
		private String type = null;
		private String name = null;

		TokenPojo(String name, String type) {
			this.name = name;
			this.type = type;
		}

		public String name() {
			return name;
		}

		public String type() {
			return type;
		}
	}

	private static Log log = LogFactory.getLog(TaxQueryTokenizer.class);
	private final CharTermAttribute termAtt = addAttribute(CharTermAttribute.class);
	private final OffsetAttribute offsetAtt = addAttribute(OffsetAttribute.class);
	private final PositionIncrementAttribute posAttr = addAttribute(PositionIncrementAttribute.class);
	private final TypeAttribute typeAtt = addAttribute(TypeAttribute.class);
	protected BasicAnalysis analysis = null; // analysis tool
	private BufferedReader br = null;
	private List<TokenPojo> tokenList = new LinkedList<TokenPojo>();

	private int startOffset = 0;
	int bChars = 0;
	int bHanzi = 0;

	public TaxQueryTokenizer(BasicAnalysis analy, Reader input) {
		super(input);
		this.analysis = analy;
	}

	@Override
	public final boolean incrementToken() throws IOException {
		clearAttributes();
		int position = 0;
		TokenPojo token = null;
		int tokenLen = 0;
		boolean flag = true;
		int numWhiteSpace = 0;
		do {
			token = next();
			if (token == null)
				break;
			tokenLen = token.name().length();
			if (StringUtil.isBlank(token.name())) {
				numWhiteSpace++;
				continue; // set continuous whiteSpace as one,keep its position
			} else {
				if (numWhiteSpace > 0) {
					position++;
					numWhiteSpace = 0;
				}
				position++;
				flag = false;
			}
		} while (flag);
		if (token != null) {
			posAttr.setPositionIncrement(position);
			termAtt.setEmpty().append(token.name());
			offsetAtt.setOffset(startOffset, startOffset + tokenLen);
			// typeAtt.setType(EsStaticValue.TYPE_WORD);
			typeAtt.setType(token.type());
			startOffset += tokenLen;
			return true;
		} else
			return false;
	}

	// must override this method
	// otherwise it will be fail when batch processing index
	@Override
	public void reset() throws IOException {
		super.reset();
		br = new BufferedReader(input);
		clear();
	}

	public TokenPojo next() throws IOException {
		if (!tokenList.isEmpty()) {
			TokenPojo pojo = tokenList.remove(0); // get and remove
			return pojo;
		}
		String temp = br.readLine(); // read next line
		if (StringUtil.isBlank(temp))
			return null;
		List<String> result1 = analysisSentence(temp);
		List<TokenPojo> result = analysisList(result1);
		tokenList.addAll(result);
		if (!tokenList.isEmpty()) {
			TokenPojo pojo = tokenList.remove(0); // get then remove
			return pojo;
		} else
			return null;
	}

	private List<TokenPojo> analysisList(List<String> strs) {
		List<TokenPojo> result = new LinkedList<TokenPojo>();
		for (int i = 0; i < strs.size(); i++) {
			String keyword = strs.get(i);
			if (ChineseHelper.containChineseChar(keyword)) {
				List<Term> terms = analysis.parse(keyword);
				for (Term term : terms) {
					String token = term.getName();
					TokenPojo pojo = new TokenPojo(token,
							term.getNatrue().natureStr);
					result.add(pojo);
					// typeList.add(term.getNatrue().natureStr);
				}
			} else {
				if (allNumber(keyword)) {
					TokenPojo pojo = new TokenPojo(keyword, "number");
					result.add(pojo);
				} else {
					TokenPojo pojo = new TokenPojo(keyword, "string");
					result.add(pojo);
				}
			}
		}
		return result;
		// List<Integer> positionList = new LinkedList<Integer>();
		// for (int i = 0; i < result.size(); i++) {
		// String str = result.get(i);
		// if (str.equalsIgnoreCase("年") || str.equalsIgnoreCase("年度")
		// || str.equalsIgnoreCase("月份") || str.equalsIgnoreCase("月")
		// || str.equalsIgnoreCase("日"))
		// positionList.add(i);
		// }
		//
		// if (positionList.isEmpty())
		// return result;
		// else {
		// List<String> lastResult1 = new LinkedList<String>();
		// List<String> lastResult2 = new LinkedList<String>();
		// for (int i = 0; i < result.size(); i++) {
		// String str1 = result.get(i);
		// if (allNumber(str1) && positionList.contains(i + 1)) {
		// lastResult1.add(str1 + result.get(i + 1));
		// i++; // skip one position
		// } else
		// lastResult2.add(str1);
		// }
		// if (lastResult1.size() > 0) {
		// List<String> lastResult = checkList(lastResult1);
		// lastResult.addAll(lastResult2);
		// return lastResult;
		// } else
		// return lastResult2;
		// }
	}

	private List<String> analysisSentence(String sentence) {
		List<String> result = new LinkedList<String>();
		StringBuilder builder = new StringBuilder();
		for (int i = 0; i < sentence.length(); i++) {
			char charC = sentence.charAt(i);
			if (ChineseHelper.isChineseChar(charC)
					|| String.valueOf(charC).equals("(")
					|| String.valueOf(charC).equals(")")) {
				if (bChars > 0) {
					result.add(builder.toString());
					builder = new StringBuilder();
					Assert.assertTrue(bHanzi == 0);
					bHanzi = 1;
				} else {
					bHanzi++;
				}
				bChars = 0;
				builder.append(charC);
			} else if (isCharOrNumber(charC)) {
				if (bHanzi > 0) {
					result.add(builder.toString());
					builder = new StringBuilder();
					Assert.assertTrue(bChars == 0);
					bChars = 1;
				} else {
					bChars++;
				}
				bHanzi = 0;
				builder.append(charC);
			} else {
				if (bHanzi > 0 || bChars > 0) {
					result.add(builder.toString());
					builder = new StringBuilder();
				}
				bHanzi = 0;
				bChars = 0;
			}
		}
		if (builder != null) {
			String str = builder.toString();
			if (StringUtil.isNotBlank(str))
				result.add(str);
		}
		return result;
	}

	private List<String> checkList(List<String> lastResult1) {
		List<String> yearList = new LinkedList<String>();
		List<String> monthList = new LinkedList<String>();
		List<String> dayList = new LinkedList<String>();
		for (String str : lastResult1) {
			if (str.endsWith("年") || str.endsWith("年度")) {
				if (str.endsWith("年度"))
					str = str.replace("年度", "年");
				yearList.add(str);
			} else if (str.endsWith("月") || str.endsWith("月份")) {
				if (str.endsWith("月份"))
					str = str.replace("月份", "月");
				monthList.add(str);
			} else if (str.endsWith("日"))
				dayList.add(str);
		}
		if (yearList.isEmpty())
			yearList.add(" ");
		if (monthList.isEmpty())
			monthList.add(" ");
		if (dayList.isEmpty())
			dayList.add(" ");
		List<String> result = new LinkedList<String>();
		for (String str1 : yearList)
			for (String str2 : monthList)
				for (String str3 : dayList) {
					StringBuilder builder = new StringBuilder();
					builder.append(str1);
					builder.append(str2);
					builder.append(str3);
					String value = builder.toString().replaceAll(" ", "");
					result.add(value);
				}
		return result;
	}

	void clear() {
		bHanzi = 0;
		bChars = 0;
		startOffset = 0;
	}

	private boolean isNumber(char charC) {
		int charNum = (int) charC;
		boolean value = false;
		if (charNum >= WordAlter.MinQuanJiaoNumber
				&& charNum <= WordAlter.MaxQuanJiaoNumber) {
			value = true;
		} else if (charNum >= 48 && charNum <= 57) {
			value = true;
		}
		return value;
	}

	private boolean allNumber(String str) {
		for (int i = 0; i < str.length(); i++) {
			char c = str.charAt(i);
			if (!isNumber(c))
				return false;
		}
		return true;
	}

	private boolean isCharOrNumber(char charC) {
		int charNum = (int) charC;
		char[] keepChars = { '.', '-', ':', '﹕', '︰', '—', '_', '﹪', '%', '/',
				'~' };
		boolean value = false;

		if (charNum >= WordAlter.MinQuanJiaoAlpha
				&& charNum <= WordAlter.MaxQuanJiaoAlpha) {
			value = true;
		} else if (charNum >= WordAlter.MinQuanJiaoAlpha_UPPER
				&& charNum <= WordAlter.MaxQuanJiaoAlpha_UPPER) {
			value = true;
		} else if (charNum >= WordAlter.MinAsciiAlpha
				&& charNum <= WordAlter.MaxAsciiAlpha) {
			value = true;
		} else if (charNum >= WordAlter.MinAsciiAlpha + 32
				&& charNum <= WordAlter.MaxAsciiAlpha + 32) {
			// a-z
			value = true;
		} else if (charNum >= WordAlter.MinQuanJiaoNumber
				&& charNum <= WordAlter.MaxQuanJiaoNumber) {
			value = true;
		} else if (charNum >= 48 && charNum <= 57) {
			value = true;
		} else {
			for (char keepChar : keepChars) {
				if (charC == keepChar)
					value = true;
			}
		}
		return value;
	}

}
