package org.elasticsearch.plugin.tokenizer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.lucene.analysis.Tokenizer;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
import org.elasticsearch.hadoop.util.StringUtils;
import org.elasticsearch.plugin.EsStaticValue;
import org.elasticsearch.plugin.PorterStemmer;
import org.splitword.soul.analysis.Analysis;
import org.splitword.soul.domain.Term;
import org.splitword.soul.domain.TermNature;

public class TaxIndexTokenizer extends Tokenizer {

	private static Log log = LogFactory.getLog(TaxIndexTokenizer.class);

	private final CharTermAttribute termAtt = addAttribute(CharTermAttribute.class);
	private final OffsetAttribute offsetAtt = addAttribute(OffsetAttribute.class);
	private final PositionIncrementAttribute posAttr = addAttribute(PositionIncrementAttribute.class);
	private final TypeAttribute typeAtt = addAttribute(TypeAttribute.class);
	protected Analysis analysis = null; // analysis tool
	// private Set<String> filter = null; // stop words
	private boolean bStem = false;// English word stemming
	private final PorterStemmer stemmer = new PorterStemmer();
	private List<Term> subTerms = null;

	public TaxIndexTokenizer(Analysis analy, Reader input) {
		super(input);
		this.analysis = analy;
		this.bStem = true;
	}

	@Override
	public final boolean incrementToken() throws IOException {
		clearAttributes();
		int position = 0;
		Term term = null;
		String name = null;
		int length = 0;
		boolean flag = true;
		int numWhiteSpace = 0;
		if (subTerms != null) {
			Term subTerm = subTerms.remove(0);
			posAttr.setPositionIncrement(0);
			String token = subTerm.getName();
			termAtt.setEmpty().append(token);
			offsetAtt.setOffset(subTerm.getOffe(),
					subTerm.getOffe() + token.length());
			typeAtt.setType("subterm");
			if (subTerms.isEmpty())
				subTerms = null;
			return true;
		}
		do {
			term = analysis.next();
			if (term == null) {
				break;
			}
			name = term.getName();
			length = name.length();
			if (bStem && term.getTermNatures().termNatures[0] == TermNature.EN) {
				name = stemmer.stem(name);// stemming
				term.setName(name);
			}
			if (!StringUtils.hasText(name)) {
				numWhiteSpace++;
				continue; // set continuous whiteSpace as one,keep its position
			} else {
				if (numWhiteSpace > 0) {
					position++;
					numWhiteSpace = 0;
				}
				position++;
				flag = false;
			}
		} while (flag);
		if (term != null) {
			posAttr.setPositionIncrement(position);
			termAtt.setEmpty().append(term.getName());
			offsetAtt.setOffset(term.getOffe(), term.getOffe() + length);
			if (analysis.bNature()) {
				String nature = term.getNatrue().natureStr;
				typeAtt.setType(nature);
			} else
				typeAtt.setType(EsStaticValue.TYPE_WORD);
			if (term.getSubTermList() != null)
				subTerms = term.getSubTermList();
			return true;
		} else {
			return false;
		}
	}

	// must override this method
	// otherwise it will be fail when batch processing index
	@Override
	public void reset() throws IOException {
		super.reset();
		analysis.resetContent(new BufferedReader(input));
	}

}
