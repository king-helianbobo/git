package org.elasticsearch.index.mapper.preanalyzed;

import java.io.IOException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.analysis.tokenattributes.FlagsAttribute;
import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
import org.apache.lucene.analysis.tokenattributes.PayloadAttribute;
import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
import org.apache.lucene.util.BytesRef;
import org.elasticsearch.common.xcontent.XContentHelper;
import org.elasticsearch.common.xcontent.XContentParser;
import org.elasticsearch.common.xcontent.XContentParser.Token;

public class PreAnalyzedTokenStream extends TokenStream {
	private static final Log log = LogFactory
			.getLog(PreAnalyzedTokenStream.class);
	private final CharTermAttribute termAtt = addAttribute(CharTermAttribute.class);
	private final OffsetAttribute offsetAtt = addAttribute(OffsetAttribute.class);
	private final PositionIncrementAttribute posIncrAtt = addAttribute(PositionIncrementAttribute.class);
	private final PayloadAttribute payloadAtt = addAttribute(PayloadAttribute.class);
	private final TypeAttribute typeAtt = addAttribute(TypeAttribute.class);
	private final FlagsAttribute flagsAtt = addAttribute(FlagsAttribute.class);
	private XContentParser parser;
	private boolean termsFieldFound = false;
	private final BytesRef input;

	/**
	 * <p>
	 * Creates a <tt>PreAnalyzedTokenStream</tt> which converts a
	 * JSON-serialization of a TokenStream to an actual TokenStream.
	 * </p>
	 * <p>
	 * The accepted JSON format is that of the Solr JsonPreAnalyzed format (see
	 * reference below).
	 * </p>
	 * 
	 * @param input
	 *            - The whole serialized field data, including version, the data
	 *            to store and, of course, the list of tokens.
	 * @throws IOException
	 * @see <a
	 *      href="http://wiki.apache.org/solr/JsonPreAnalyzedParser">http://wiki.apache.org/solr/JsonPreAnalyzedParser</a>
	 */
	public PreAnalyzedTokenStream(BytesRef input) throws IOException {
		this.input = input;
		reset();
	}

	@Override
	public final boolean incrementToken() throws IOException {
		Token currentToken = parser.nextToken();
		if (termsFieldFound && currentToken != null
				&& currentToken != XContentParser.Token.END_ARRAY) {

			// First clear all attributes for the case that some attributes
			// are sometimes but not always specified.
			clearAttributes();

			boolean termFound = false;
			int start = -1;
			int end = -1;
			String currentFieldName = null;
			while ((currentToken = parser.nextToken()) != XContentParser.Token.END_OBJECT) {
				if (currentToken == XContentParser.Token.FIELD_NAME) {
					currentFieldName = parser.text();
				} else if (currentToken == XContentParser.Token.VALUE_STRING) {
					if ("t".equals(currentFieldName)) {
						char[] tokenBuffer = parser.textCharacters();
						termAtt.copyBuffer(tokenBuffer, parser.textOffset(),
								parser.textLength());
						termFound = true;
					} else if ("p".equals(currentFieldName)) {
						payloadAtt.setPayload(parser.bytes());
					} else if ("f".equals(currentFieldName)) {
						flagsAtt.setFlags(Integer.decode(parser.text()));
					} else if ("y".equals(currentFieldName)) {
						typeAtt.setType(parser.text());
					}
				} else if (currentToken == XContentParser.Token.VALUE_NUMBER) {
					if ("s".equals(currentFieldName)) {

						start = parser.intValue();
						log.info("startValue = " + start);
					} else if ("e".equals(currentFieldName)) {
						end = parser.intValue();
						log.info("endValue = " + end);
					} else if ("i".equals(currentFieldName)) {
						posIncrAtt.setPositionIncrement(parser.intValue());
					}
				}
			}

			if (-1 != start && -1 != end)
				offsetAtt.setOffset(start, end);

			if (!termFound) {
				throw new IllegalArgumentException(
						"There is at least one token object in the pre-analyzed field value where no actual term string is specified.");
			}

			return true;
		}
		return false;
	}

	/**
	 * Creates a new parser reading the input data and sets the parser state
	 * right to the beginning of the actual token list.
	 */
	@Override
	public void reset() throws IOException {
		parser = XContentHelper.createParser(input.bytes, 0, input.length);

		// Go to the beginning of the token array to be ready when the
		// tokenstream is read.
		Token token;
		String currentField;
		do {
			token = parser.nextToken();
			if (token == XContentParser.Token.FIELD_NAME) {
				currentField = parser.text();
				if ("tokens".equals(currentField))
					termsFieldFound = true;
			}
		} while (!termsFieldFound && token != null);
	}
}