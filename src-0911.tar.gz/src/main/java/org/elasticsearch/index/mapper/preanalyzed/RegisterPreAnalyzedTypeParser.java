package org.elasticsearch.index.mapper.preanalyzed;

import org.elasticsearch.common.inject.Inject;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.index.AbstractIndexComponent;
import org.elasticsearch.index.Index;
import org.elasticsearch.index.mapper.MapperService;
import org.elasticsearch.index.settings.IndexSettings;

public class RegisterPreAnalyzedTypeParser extends AbstractIndexComponent {
	@Inject
	public RegisterPreAnalyzedTypeParser(Index index,
			@IndexSettings Settings indexSettings, MapperService mapperService) {
		super(index, indexSettings);
		mapperService.documentMapperParser().putTypeParser("preanalyzed",
				new PreAnalyzedMapper.TypeParser());
		mapperService.documentMapperParser().putTypeParser("tokenstream_json",
				new PreAnalyzedFieldMapper.TypeParser());
	}
}
