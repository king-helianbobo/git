package org.elasticsearch.index.mapper.attachment;

import org.elasticsearch.common.inject.AbstractModule;

public class AttachmentsIndexModule extends AbstractModule {

	@Override
	protected void configure() {
		bind(RegisterAttachmentTypeParser.class).asEagerSingleton();
	}
}
