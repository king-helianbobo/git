package org.splitword.soul.recognition;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.splitword.soul.domain.Term;
import org.splitword.soul.domain.TermNature;
import org.splitword.soul.domain.TermNatures;
import org.splitword.soul.utility.Forest;
import org.splitword.soul.utility.LibraryToForest;
import org.splitword.soul.utility.TermUtil;
import org.splitword.soul.utility.TrieInterface;

public class UserDefineRecognition {
	private static Log log = LogFactory.getLog(UserDefineRecognition.class);
	private Term[] terms = null;
	private TrieInterface forest = null;
	private TrieInterface branch = forest;
	private int startOffe = -1;
	private int endOffe = -1;
	private String tmpNature = null;

	public UserDefineRecognition(Term[] terms) {
		this.terms = terms;
	}

	public UserDefineRecognition() {
		reset();
	}

	public UserDefineRecognition(Term[] terms, Forest forest) {
		this.terms = terms;
		if (forest != null) {
			this.forest = forest;
			branch = this.forest;
		}
		reset();
	}

	public void resetData(Term[] terms, Forest forest) {
		this.terms = terms;
		if (forest != null) {
			this.forest = forest;
			branch = this.forest;
		}
		reset();
	}

	private boolean checkTerm(int start, int end) {
		if (start >= end)
			return false;
		for (int i = start; i <= end; i++) {
			if (terms[i] != null) {
				// log.info(terms[i].getName());
				return true;
			}
		}
		return false;
	}

	public void recognition() { // 识别用户自定义词典中的词
		if (branch == null) {
			return;
		}
		int length = terms.length - 1;
		boolean bStartFromRoot = false;
		for (int i = 0; i <= length; i++) {
			if (terms[i] == null)
				continue;
			// log.info(terms[i].getName());
			if (i == length && branch == null)
				continue;
			else if (i == length && branch.getStatus() == 1
					&& checkTerm(startOffe + 1, length - 1)) {
				i = startOffe;
				reset();
				continue;
			} else if (i == length) {
				continue;
			}

			if (branch == forest) //
				bStartFromRoot = true;
			else
				bStartFromRoot = false;

			branch = LibraryToForest.termStatus(branch, terms[i]);
			if (branch == null) { // 必须先判断branch是否为空
				if (startOffe != -1)
					i = startOffe;
				reset();
			} else if (branch.getStatus() == 3) { // term 存在于用户词典
				endOffe = i;
				tmpNature = branch.getParams()[0];
				// tempFreq = ObjectBean.getInt(branch.getParams()[1], 50);
				if (startOffe != -1 && startOffe < i) {
					i = startOffe;
					makeNewTerm();
					reset();
				} else
					reset();
			} else if (branch.getStatus() == 2) {
				endOffe = i;
				if (startOffe == -1) {
					startOffe = i;
				} else {
					tmpNature = branch.getParams()[0];
					// if (!bStartFromRoot)
					if (startOffe < endOffe)
						makeNewTerm();
				}
			} else if (branch.getStatus() == 1) {
				if (startOffe == -1) {
					startOffe = i;
				}
			}
		}
		// 下面的这段代码被注释了，因为不需要组合Term了。
		// if (startOffe != -1 && startOffe < endOffe) {
		// makeNewTerm();
		// }
	}

	private void makeNewTerm() {
		List<Term> subTerms = new ArrayList<Term>();
		StringBuilder sb = new StringBuilder();
		for (int j = startOffe; j <= endOffe; j++) { // 注意，这里是小于等于关系
			if (terms[j] == null) {
				continue;
			} else {
				sb.append(terms[j].getName());
				subTerms.add(terms[j]);
			}
		}
		TermNatures termNatures = new TermNatures(new TermNature(tmpNature, 1));
		String name = sb.toString();
		// log.info("make new term:[ " + name + " ]");
		Term term = new Term(name, startOffe, termNatures);
		term.setNature(termNatures.termNatures[0].natureInLib);
		term.selfScore = -1 * sb.toString().length();
		if (subTerms.size() > 1 && name.length() >= 4)
			term.setSubTermList(subTerms);
		TermUtil.insertTerm(terms, term);
	}

	private void reset() {
		startOffe = -1;
		endOffe = -1;
		tmpNature = null;
		branch = forest;
	}

}
