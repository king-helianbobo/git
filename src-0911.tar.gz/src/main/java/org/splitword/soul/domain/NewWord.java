package org.splitword.soul.domain;

public class NewWord {

	private String name;
	private double score = 0;
	private NatureInLib nature;
	private int allFrequency; // 单词的词频

	public NewWord(String name, NatureInLib nature, double score) {
		this.name = name;
		this.nature = nature;
		this.score = score;
		this.allFrequency = 1;
	}

	public void setScore(double score) {
		this.score = score;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getScore() {
		return score;
	}

	public NatureInLib getNature() {
		return nature;
	}

	public void setNature(NatureInLib nature) {
		this.nature = nature;
	}

	public void update(double score, NatureInLib nature, int freq) {
		this.score += score * freq;
		this.allFrequency += freq;
		if (NatureInLib.NW != nature) {
			this.nature = nature;
		}
	}

	@Override
	public String toString() {
		return this.name + "\t" + this.score + "\t"
				+ this.getNature().natureStr;
	}

	public int getAllFreq() {
		return allFrequency;
	}

}
