package com.elasticsearch.action.restful;

import org.elasticsearch.action.ActionListener;
import org.elasticsearch.action.ActionRequestBuilder;
import org.elasticsearch.client.Client;
//import org.elasticsearch.client.internal.InternalGenericClient;

import com.elasticsearch.action.statistic.SuggestStatisticsAction;
import com.elasticsearch.action.statistic.SuggestStatisticsRequest;
import com.elasticsearch.action.statistic.SuggestStatisticsResponse;

public class StatisticRequestBuilder
		extends
		ActionRequestBuilder<SuggestStatisticsRequest, SuggestStatisticsResponse, StatisticRequestBuilder, Client> {

	public StatisticRequestBuilder(Client client) {
		super(client, new SuggestStatisticsRequest());
	}

	@Override
	protected void doExecute(ActionListener<SuggestStatisticsResponse> listener) {
		client.execute(SuggestStatisticsAction.INSTANCE, request, listener);
	}
}
