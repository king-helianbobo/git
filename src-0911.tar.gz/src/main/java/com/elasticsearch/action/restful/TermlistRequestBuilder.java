package com.elasticsearch.action.restful;

import org.elasticsearch.action.ActionListener;
import org.elasticsearch.action.support.broadcast.BroadcastOperationRequestBuilder;
import org.elasticsearch.client.Client;

import com.elasticsearch.action.termlist.TermlistAction;
import com.elasticsearch.action.termlist.TermlistRequest;
import com.elasticsearch.action.termlist.TermlistResponse;

/**
 * A request to get term lists of one or more indices. This class no effect at
 * present
 */
public class TermlistRequestBuilder
		extends
		BroadcastOperationRequestBuilder<TermlistRequest, TermlistResponse, TermlistRequestBuilder, Client> {

	public TermlistRequestBuilder(Client client) {
		super(client, new TermlistRequest());
	}

	@Override
	protected void doExecute(ActionListener<TermlistResponse> listener) {
		client.execute(TermlistAction.INSTANCE, request, listener);
	}
}
