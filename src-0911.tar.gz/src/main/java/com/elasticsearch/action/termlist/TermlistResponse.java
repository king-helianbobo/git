package com.elasticsearch.action.termlist;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.elasticsearch.action.ShardOperationFailedException;
import org.elasticsearch.action.support.broadcast.BroadcastOperationResponse;
import org.elasticsearch.common.io.stream.StreamInput;
import org.elasticsearch.common.io.stream.StreamOutput;

/**
 * A response for TermList action.
 */
public class TermlistResponse extends BroadcastOperationResponse {

	private Map<String, TermInfoPojo> map;

	TermlistResponse() {
	}

	TermlistResponse(int totalShards, int successfulShards, int failedShards,
			List<ShardOperationFailedException> shardFailures,
			Map<String, TermInfoPojo> map) {
		super(totalShards, successfulShards, failedShards, shardFailures);
		this.map = map;
	}

	public Map<String, TermInfoPojo> getTermMap() {
		return map;
	}

	@Override
	public void readFrom(StreamInput in) throws IOException {
		super.readFrom(in);
		int n = in.readInt();
		if (n > 0) {
			map = new HashMap<String, TermInfoPojo>();
			for (int i = 0; i < n; i++) {
				String text = in.readString();
				TermInfoPojo t = new TermInfoPojo();
				t.readFrom(in);
				map.put(text, t);
			}
		} else
			map = null;
	}

	@Override
	public void writeTo(StreamOutput out) throws IOException {
		super.writeTo(out);
		if (map != null && map.size() > 0) {
			out.writeInt(map.size());
			for (Map.Entry<String, TermInfoPojo> t : map.entrySet()) {
				out.writeString(t.getKey());
				t.getValue().writeTo(out);
			}
		} else
			out.writeInt(0);
	}
}