package com.elasticsearch.action.termlist;

import java.io.IOException;

import org.elasticsearch.common.io.stream.StreamInput;
import org.elasticsearch.common.io.stream.StreamOutput;
import org.elasticsearch.common.io.stream.Streamable;

public class TermInfoPojo implements Streamable {

	Integer docFreq = 0;
	Integer totalFreq = 0;

	public TermInfoPojo docFreq(int docFreq) {
		this.docFreq = docFreq;
		return this;
	}

	public Integer getDocFreq() {
		return docFreq;
	}

	public TermInfoPojo totalFreq(int totalFreq) {
		this.totalFreq = totalFreq;
		return this;
	}

	public Integer getTotalFreq() {
		return totalFreq;
	}

	@Override
	public void readFrom(StreamInput in) throws IOException {
		docFreq(in.readInt());
		totalFreq(in.readInt());
	}

	@Override
	public void writeTo(StreamOutput out) throws IOException {
		Integer docF = getDocFreq();
		if (docF != null)
			out.writeInt(docF);
		else
			out.writeInt(0);
		Integer total = getTotalFreq();
		if (total != null)
			out.writeInt(total);
		else
			out.writeInt(0);
	}
}
