package com.elasticsearch.action.suggest;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.elasticsearch.action.support.broadcast.BroadcastShardOperationResponse;
import org.elasticsearch.common.io.stream.StreamInput;
import org.elasticsearch.common.io.stream.StreamOutput;

public class ShardSuggestResponse extends BroadcastShardOperationResponse {

	private List<String> suggestionList;
	private static Log log = LogFactory.getLog(ShardSuggestResponse.class);

	public ShardSuggestResponse() {
	}

	public ShardSuggestResponse(String index, int shardId,
			List<String> anotherList) {
		super(index, shardId);
		int size = anotherList.size();
		if (size > 0) {
			suggestionList = new LinkedList<String>();
			for (int i = 0; i < size; i++)
				suggestionList.add(anotherList.get(i));
		} else
			suggestionList = null;
	}

	public List<String> suggestions() {
		return suggestionList;
	}

	@Override
	public void readFrom(StreamInput in) throws IOException {
		super.readFrom(in);
		int size = in.readInt();
		if (size > 0) {
			suggestionList = new LinkedList<String>();
			for (int i = 0; i < size; i++) {
				String text = in.readString();
				suggestionList.add(text);
			}
			log.info("when read,suggestion list is:" + suggestionList);
		} else
			suggestionList = null;
	}

	@Override
	public void writeTo(StreamOutput out) throws IOException {
		super.writeTo(out);
		if (suggestionList != null && suggestionList.size() > 0) {
			log.info("when write,suggestion list is:" + suggestionList);
			out.writeInt(suggestionList.size());
			for (int i = 0; i < suggestionList.size(); i++)
				out.writeString(suggestionList.get(i));
		} else
			out.writeInt(0);
	}
}
