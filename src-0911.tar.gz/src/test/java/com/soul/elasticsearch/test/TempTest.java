package com.soul.elasticsearch.test;

import static org.elasticsearch.common.xcontent.XContentFactory.jsonBuilder;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.io.MapWritable;
import org.codehaus.jackson.map.ObjectMapper;
import org.elasticsearch.action.admin.indices.create.CreateIndexResponse;
import org.elasticsearch.action.admin.indices.exists.indices.IndicesExistsResponse;
import org.elasticsearch.application.util.OfficialDataUtils;
import org.elasticsearch.application.util.TestDataReader;
import org.elasticsearch.common.Base64;
import org.elasticsearch.common.joda.time.DateTime;
import org.elasticsearch.common.xcontent.XContentBuilder;
import org.elasticsearch.hadoop.rest.RestClient;
import org.elasticsearch.hadoop.serailize.IndexCommand;
import org.elasticsearch.hadoop.util.BytesArray;
import org.elasticsearch.hadoop.util.WritableUtils;
import org.testng.annotations.Test;

public class TempTest extends AbstractDataTest {
	private static final Log log = LogFactory.getLog(TempTest.class);

	@Test
	public void testMethod2() throws Exception {
		// createIndexMapping();
		indexData();
	}

	private void createIndexMapping() {
		try {
			IndicesExistsResponse existsResponse = tcpClient().admin()
					.indices().prepareExists(indexName).execute().actionGet();
			if (existsResponse.isExists()) {
				// if index exist, delete it
				tcpClient().admin().indices().prepareDelete(indexName)
						.execute().actionGet();
			}
			XContentBuilder builder = (XContentBuilder) jsonBuilder()
					.startObject().startObject("mappings")
					.startObject(typeName).startObject("properties")
					.startObject("hello").field("type", "preanalyzed")
					.endObject().endObject().endObject().endObject();
			String settings = builder.string();
			log.info(settings);
			CreateIndexResponse createIndexResponse = tcpClient().admin()
					.indices().prepareCreate(indexName).setSource(settings)
					.execute().actionGet();
			assertThat(createIndexResponse.isAcknowledged(), is(true));
			tcpClient().admin().cluster().prepareHealth(indexName)
					.setWaitForGreenStatus().execute().actionGet();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void indexData() throws Exception {
		org.elasticsearch.hadoop.cfg.Settings settings = createSettings(
				indexName, typeName);
		ObjectMapper mapper = new ObjectMapper();
		RestClient client = new RestClient(settings);
		IndexCommand command = new IndexCommand(settings);
		BytesArray data = new BytesArray(20 * 1024);
		Map<String, String> entry = new HashMap<String, String>();
		entry.put("id", "1");
		XContentBuilder builder1 = jsonBuilder().startObject().field("v", "1")
				.field("str", "This string should be stored.")
				.startArray("tokens");
		builder1.startObject().field("t", "testterm1").field("s", 1)
				.field("e", 8).endObject();
		builder1.startObject().field("t", "testterm2").field("s", 1)
				.field("e", 8).field("i", 0).endObject();
		builder1.startObject().field("t", "testterm3").field("s", 9)
				.field("e", 15).endObject();
		builder1.startObject().field("t", "hello").field("s", 16)
				.field("e", 18).endObject();
		builder1.startObject().field("t", "testterm4")
				.field("p", Base64.encodeBytes("my payload".getBytes()))
				.field("y", "testtype").field("f", "0x4").endObject();
		String json1 = builder1.string();
		entry.put("hello", json1);
		String json = mapper.writeValueAsString(entry);
		log.info(json);
		MapWritable writable = (MapWritable) WritableUtils.toWritable(entry);
		int entrySize = command.prepare(writable);
		command.write(writable, data);
		log.info(data.size());
		client.bulk(settings.getIndexType(), data.bytes(), data.size());
		data.reset();
		client.close();
	}
}
