package com.soul.elasticsearch.test;

import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.elasticsearch.action.admin.indices.refresh.RefreshResponse;
import org.elasticsearch.client.Client;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.ImmutableSettings;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.elasticsearch.hadoop.cfg.ConfigurationOptions;
import org.elasticsearch.hadoop.cfg.SettingsManager;
import org.elasticsearch.hadoop.mr.MapReduceWriter;
import org.elasticsearch.hadoop.rest.InitializationUtils;
import org.elasticsearch.hadoop.serailize.MapWritableIdExtractor;
import org.elasticsearch.hadoop.serailize.SerializationUtils;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

public class AbstractDataTest {
	private static Log log = LogFactory.getLog(AbstractDataTest.class);
	protected static String hostName = "localhost";
	protected static String indexName = "temp_mini_2";
	protected static String typeName = "table";
	protected static String sourcePath = "/mnt/f/tmp/official-05-29/";
	private TransportClient tcpClient;

	@SuppressWarnings("resource")
	@BeforeClass
	public void startNode() throws Exception {
		// Settings settings = ImmutableSettings.settingsBuilder()
		// .put("cluster.name", "LiuboCluster").build();
		Settings settings = ImmutableSettings.settingsBuilder()
				.put("cluster.name", "elasticsearch").build();
		tcpClient = new TransportClient(settings)
				.addTransportAddress(new InetSocketTransportAddress(hostName,
						9300));
	}

	@AfterClass
	public void closeResources() {
		tcpClient.close();
	}

	protected void refresh(String... indices) {
		RefreshResponse actionGet1 = tcpClient().admin().indices()
				.prepareRefresh(indices).execute().actionGet();
		int fail1 = actionGet1.getFailedShards();
		log.info("failed shards should be " + fail1);
	}

	protected org.elasticsearch.hadoop.cfg.Settings createSettings(
			String indexName, String typeName) {
		org.elasticsearch.hadoop.cfg.Settings settings = null;
		Properties properties = new Properties();
		properties.put(ConfigurationOptions.ES_WRITE_OPERATION, "index");
		properties.put(ConfigurationOptions.ES_MAPPING_ID, "id");
		String resource = indexName + "/" + typeName;
		properties.put(ConfigurationOptions.ES_RESOURCE, resource);
		properties.put(ConfigurationOptions.ES_HOST, hostName);
		settings = SettingsManager.loadFrom(properties);
		SerializationUtils.setValueWriterIfNotSet(settings,
				MapReduceWriter.class, log);
		InitializationUtils.setIdExtractorIfNotSet(settings,
				MapWritableIdExtractor.class, log);
		return settings;
	}

	protected org.elasticsearch.hadoop.cfg.Settings updateSettings(
			String indexName, String typeName) {
		org.elasticsearch.hadoop.cfg.Settings settings = null;
		Properties properties = new Properties();
		properties.put(ConfigurationOptions.ES_WRITE_OPERATION, "update");
		properties.put(ConfigurationOptions.ES_MAPPING_ID, "id");
		String resource = indexName + "/" + typeName;
		properties.put(ConfigurationOptions.ES_RESOURCE, resource);
		properties.put(ConfigurationOptions.ES_HOST, hostName);
		properties.put(ConfigurationOptions.ES_UPSERT_DOC, false);
		settings = SettingsManager.loadFrom(properties);
		SerializationUtils.setValueWriterIfNotSet(settings,
				MapReduceWriter.class, log);
		InitializationUtils.setIdExtractorIfNotSet(settings,
				MapWritableIdExtractor.class, log);
		return settings;
	}

	protected Client tcpClient() {
		return tcpClient;
	}

}
