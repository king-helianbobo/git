package com.soul.check.data.test;

import java.util.regex.Pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.elasticsearch.utility.ChineseHelper;
import org.testng.annotations.Test;

public class CharacterTest {
	private final Log log = LogFactory.getLog(CharacterTest.class);

	@Test
	public void testMethod1() {
		String[] strs = new String[] { "www.micmiu.com",
				"!@#$%^&*()_+{}[]|\"'?/:;<>,.", "！￥……（）——：；“”‘’《》，。？、",
				"不要啊——", "やめて", "韩佳人；", "???" };
		for (String str : strs) {
			char[] ch = str.toCharArray();
			for (int i = 0; i < ch.length; i++) {
				char c = ch[i];
				String tmp = String.valueOf(c);
				log.info(c + "-->" + (ChineseHelper.isChinese(tmp) ? "是" : "否"));
				log.info(c + "-->"
						+ (ChineseHelper.isChineseChar(c) ? "是" : "否"));
				log.info(c + "-->" + (isChineseByName(tmp) ? "是" : "否"));
			}
		}
	}

	// 只能判断部分CJK字符（CJK统一汉字）
	public static boolean isChineseByName(String str) {
		if (str == null) {
			return false;
		}
		// 大小写不同：\\p 表示包含，\\P 表示不包含
		// \\p{Cn} 的意思为 Unicode 中未被定义字符的编码，\\P{Cn} 就表示 Unicode中已经被定义字符的编码
		String reg = "\\p{InCJK Unified Ideographs}&&\\P{Cn}";
		Pattern pattern = Pattern.compile(reg);
		return pattern.matcher(str.trim()).find();
	}
}