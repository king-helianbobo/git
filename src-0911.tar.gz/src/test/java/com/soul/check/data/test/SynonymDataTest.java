package com.soul.check.data.test;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Random;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.elasticsearch.application.util.ExtractUtil;
import org.elasticsearch.application.util.SoulFileWriter;
import org.elasticsearch.utility.ChineseHelper;
import org.testng.Assert;

public class SynonymDataTest {
	private static final Log log = LogFactory.getLog(SynonymDataTest.class);
	private static final String splitTag = ",";
	final int ratio = 50 * 1000;

	final String preTag = "**************************Beg**************************";
	final String postTag = "**************************End**************************";

	// @Test
	public void testMethod3() throws IOException {
		List<Set<String>> setList = SynonymDataUtil.getData("/tmp/a12.txt",
				splitTag);
		int num = 0;
		int line = 0;
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				new FileInputStream("library/im.txt"), "UTF-8"));
		String temp = null;
		terms: while ((temp = reader.readLine()) != null) {
			line++;
			String[] strs = temp.split(splitTag);
			Assert.assertEquals(strs.length, 2);
			String str1 = strs[0].trim();
			String str2 = strs[1].trim();
			if (!ChineseHelper.allChineseChar(str1)
					|| !ChineseHelper.allChineseChar(str2))
				log.error(line + "," + temp);
			// Assert.assertEquals(true, ChineseHelper.allChineseChar(str1));
			// Assert.assertEquals(true, ChineseHelper.allChineseChar(str2));
			boolean contained = false;
			for (int i = 0; i < setList.size(); i++) {
				Set<String> set = setList.get(i);
				if (set.contains(str1) && set.contains(str2)) {
					log.info("this line has contained!");
					contained = true;
					continue terms;
				} else if (set.contains(str1)) {
					// set.add(str2);
					// log.info("oneContained: " + str2);
					// contained = true;
				} else if (set.contains(str2)) {
					// set.add(str1);
					// log.info("oneContained: " + str1);
					// contained = true;
				} else {
					// do nothing
				}
			}
			if (!contained) {
				Set<String> set = new TreeSet<String>();
				set.add(str1);
				set.add(str2);
			}
			num++;
		}
		reader.close();
		log.info("Total Word count is " + num);
		log.info("Total Word Line Numer is " + setList.size());
		SoulFileWriter writer = new SoulFileWriter("/tmp/a1.txt");
		SoulFileWriter.writeSet(writer, setList);
	}

	// @Test
	public void splitSynonymDataFileTest() throws IOException {
		List<Set<String>> setList = SynonymDataUtil.getData(
				"library/synonym-new.txt", splitTag);
		log.info(setList.size());
		Map<Integer, Set<String>> map = new TreeMap<Integer, Set<String>>();
		for (int i = 0; i < setList.size(); i++)
			map.put(i, setList.get(i));
		Queue<Integer> queue = randomKey(map);
		log.info(queue.size());
		String writePath = "/tmp/haha/a";
		SoulFileWriter writer = null;
		Integer seq;
		int number = 0;
		Set<Integer> added = new TreeSet<Integer>();
		while ((seq = queue.poll()) != null) {
			if (number % 800 == 0) {
				if (writer != null)
					writer.close();
				int no = (number / 800) + 1;
				String path = writePath + "-" + String.valueOf(no) + ".txt";
				writer = new SoulFileWriter(path);
			}
			if (added.contains(seq))
				Assert.assertEquals(true, false);
			added.add(seq);
			Set<String> set1 = map.get(seq);
			Set<String> set2 = setList.get(seq);
			writer.writeWithNewLine(ExtractUtil.setToString(set1, false));
			number++;
			Assert.assertEquals(set1, set2);
			log.info(ExtractUtil.setToString(set1, false));
			log.info(ExtractUtil.setToString(set2, false));
		}
		if (writer != null)
			writer.close();
		log.info("set.size = " + added.size());
	}

	// @Test
	public void synonymExtractTest() throws FileNotFoundException, IOException {
		String synonymPath = "/tmp/synonym-new.txt";
		SoulFileWriter writer = new SoulFileWriter(synonymPath);
		@SuppressWarnings("resource")
		BufferedReader br = new BufferedReader(new InputStreamReader(
				new FileInputStream("/mnt/f/tmp/word.txt"), "gbk"));
		String temp = null;
		while ((temp = br.readLine()) != null) {
			String result = temp.trim();
			String[] texts = result.split(" ");
			String tag = texts[0];
			Assert.assertEquals(tag.length(), 8);
			String cTag = String.valueOf(tag.charAt(7));
			if (cTag.equals("=")) {
				Set<String> set = new TreeSet<String>();
				for (int i = 1; i < texts.length; i++) {
					String str = texts[i].trim();
					set.add(str);
				}
				if (set.size() >= 2)
					writer.writeStr(ExtractUtil.setToString(set));
				else
					log.error("This line error " + ExtractUtil.setToString(set));
			}
		}
		writer.close();
		List<Set<String>> setList = SynonymDataUtil.checkThisFile(synonymPath,
				splitTag);
		SoulFileWriter writer1 = new SoulFileWriter("/tmp/a1.txt");
		SoulFileWriter.writeSet(writer1, setList);
	}

	// @Test
	public void checkFileTest() throws IOException {
		List<Set<String>> setList = SynonymDataUtil.checkThisFile(
				"library/synonym-yiwu.txt-0624", splitTag);
		SoulFileWriter writer = new SoulFileWriter("/tmp/a22.txt");
		SoulFileWriter.writeSet(writer, setList);
	}

	private <KEY, VALUE> Queue<KEY> randomKey(Map<KEY, VALUE> integerMap) {
		Queue<KEY> queue = new LinkedList<KEY>();
		Set<KEY> set = new TreeSet<KEY>();
		List<KEY> keysAsArray = new LinkedList<KEY>(integerMap.keySet());
		Random r = new Random();
		while (set.size() < integerMap.size()) {
			int seq = r.nextInt(keysAsArray.size());
			KEY key = keysAsArray.get(seq);
			if (!set.contains(key)) {
				queue.add(key);
				set.add(key);
			}
		}
		return queue;
	}

	// @Test
	public void testMethod5() throws IOException {
		List<Set<String>> setList = SynonymDataUtil.getData(
				"library/synonym-yiwu.txt", splitTag);
		String writePath = "/tmp/b.txt";
		boolean bFlag = true;
		SoulFileWriter writer2 = new SoulFileWriter(writePath + "-2");
		SoulFileWriter writer1 = new SoulFileWriter(writePath + "-1");
		Map<String, List<Long>> stringMap = new TreeMap<String, List<Long>>();
		Map<Integer, Set<String>> integerMap = new TreeMap<Integer, Set<String>>();
		Set<Integer> filterSet = new TreeSet<Integer>();
		for (int i = 0; i < setList.size(); i++) {
			Set<String> set1 = setList.get(i);
			for (int j = i + 1; j < setList.size(); j++) {
				Set<String> set2 = setList.get(j);
				Set<String> commonSet = new TreeSet<String>();
				for (String str : set2) {
					if (set1.contains(str))
						commonSet.add(str);
				}
				if (commonSet.size() >= 1) {
					String key = ExtractUtil.setToString(commonSet, false);
					long ij = i * ratio + j;
					List<Long> list = stringMap.get(key);
					if (list == null)
						list = new LinkedList<Long>();
					list.add(ij);
					stringMap.put(key, list);
					Set<String> seti = integerMap.get(i);
					if (seti == null)
						seti = new TreeSet<String>();
					seti.add(key);
					Set<String> setj = integerMap.get(j);
					if (setj == null)
						setj = new TreeSet<String>();
					setj.add(key);
					integerMap.put(j, setj);
					integerMap.put(i, seti);
					filterSet.add(i);
					filterSet.add(j);
				}
			}
		}
		Set<Integer> addedFilterSet = new TreeSet<Integer>();
		// 随机扰乱key
		Queue<Integer> queue = randomKey(integerMap);
		Integer line = null;
		int numC = 0, numB = 0, numA = 0;
		while ((line = queue.poll()) != null) {
			Assert.assertEquals(true, filterSet.contains(line));
			if (addedFilterSet.contains(line))
				continue;
			Set<String> strSet = integerMap.get(line);
			if (strSet != null && !strSet.isEmpty()) {
				List<Integer> tmpList = new LinkedList<Integer>();
				tmpList.add(line);
				for (String str : strSet) {
					List<Long> list = stringMap.get(str);
					for (int i = 0; i < list.size(); i++) {
						long total = list.get(i);
						int ai = (int) (total / ratio);
						int aj = (int) (total % ratio);
						if (!addedFilterSet.contains(ai)
								&& !tmpList.contains(ai))
							tmpList.add(ai);
						if (!addedFilterSet.contains(aj)
								&& !tmpList.contains(aj))
							tmpList.add(aj);
					}
				}
				if (tmpList.size() >= 2) {
					if (bFlag)
						writer2.writeWithNewLine(preTag);
					for (Integer key : tmpList) {
						String result = ExtractUtil.setToString(setList
								.get(key));
						addedFilterSet.add(key);
						writer2.writeStr(result);
						numC++;
					}
					if (bFlag)
						writer2.writeWithNewLine(postTag);
				}
			}
		}
		// 随机扰乱序列
		Queue<String> queue2 = randomKey(stringMap);
		String key = null;
		while ((key = queue2.poll()) != null) {
			List<Long> list1 = stringMap.get(key);
			List<Integer> tmpList = new LinkedList<Integer>();
			for (int i = 0; i < list1.size(); i++) {
				long a = list1.get(i);
				int ai = (int) (a / ratio);
				int aj = (int) (a % ratio);
				if (!addedFilterSet.contains(ai) && !tmpList.contains(ai))
					tmpList.add(ai);
				if (!addedFilterSet.contains(aj) && !tmpList.contains(aj))
					tmpList.add(aj);
				Assert.assertEquals(true, filterSet.contains(ai));
				Assert.assertEquals(true, filterSet.contains(aj));
			}
			if (tmpList.size() > 0) {
				for (Integer num : tmpList) {
					String result = ExtractUtil.setToString(setList.get(num));
					addedFilterSet.add(num);
					writer1.writeStr(result);
					numB++;
				}
			}
		}
		for (int i = 0; i < setList.size(); i++) {
			if (filterSet.contains(i))
				continue;
			Set<String> set = setList.get(i);
			String result = ExtractUtil.setToString(set);
			writer1.writeStr(result);
			numA++;
		}
		log.info(addedFilterSet.size() + "," + numC + "," + numB + "," + numA);
		log.info("first size = " + (numB + numA) + " ,second size = " + numC);
		writer1.close();
		writer2.close();
	}
}
