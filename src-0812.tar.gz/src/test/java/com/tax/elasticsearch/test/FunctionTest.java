package com.tax.elasticsearch.test;

import java.util.List;
import java.util.Map;

import org.junit.Assert;

public class FunctionTest {
	private static void checkFields(String tableName, List<String> fields,
			Map<String, List<String>> fieldsMap) {
		List<String> integerFields = fieldsMap.get(tableName + "#integer");
		List<String> floatFields = fieldsMap.get(tableName + "#float");
		List<String> dateFields = fieldsMap.get(tableName + "#date");
		List<String> dateTimeFields = fieldsMap.get(tableName + "#datetime");
		List<String> chineseFields = fieldsMap.get(tableName + "#chinese");
		List<String> wordFields = fieldsMap.get(tableName + "#word");
		int number = 0;
		if (integerFields != null) {
			number += integerFields.size();
			for (String str : integerFields) {
				Assert.assertTrue(fields.contains(str));
			}
		}
		if (floatFields != null) {
			number += floatFields.size();
			for (String str : floatFields) {
				Assert.assertTrue(fields.contains(str));
			}
		}
		if (dateFields != null) {
			number += dateFields.size();
			for (String str : dateFields) {
				Assert.assertTrue(fields.contains(str));
			}
		}
		if (dateTimeFields != null) {
			number += dateTimeFields.size();
			for (String str : dateTimeFields) {
				Assert.assertTrue(fields.contains(str));
			}
		}
		if (chineseFields != null) {
			number += chineseFields.size();
			for (String str : chineseFields) {
				Assert.assertTrue(fields.contains(str));
			}
		}
		if (wordFields != null) {
			number += wordFields.size();
			for (String str : wordFields) {
				Assert.assertTrue(fields.contains(str));
			}
		}
		Assert.assertEquals(number, fields.size());
	}
}
