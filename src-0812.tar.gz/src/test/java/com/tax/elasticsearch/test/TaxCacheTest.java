package com.tax.elasticsearch.test;

import static org.elasticsearch.common.xcontent.XContentFactory.jsonBuilder;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.io.MapWritable;
import org.codehaus.jackson.map.ObjectMapper;
import org.elasticsearch.action.admin.indices.create.CreateIndexResponse;
import org.elasticsearch.action.admin.indices.exists.indices.IndicesExistsResponse;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.ImmutableSettings;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.elasticsearch.common.xcontent.XContentBuilder;
import org.elasticsearch.hadoop.cfg.ConfigurationOptions;
import org.elasticsearch.hadoop.cfg.SettingsManager;
import org.elasticsearch.hadoop.mr.MapReduceWriter;
import org.elasticsearch.hadoop.rest.InitializationUtils;
import org.elasticsearch.hadoop.rest.RestClient;
import org.elasticsearch.hadoop.serailize.IndexCommand;
import org.elasticsearch.hadoop.serailize.MapWritableIdExtractor;
import org.elasticsearch.hadoop.serailize.SerializationUtils;
import org.elasticsearch.hadoop.util.BytesArray;
import org.elasticsearch.hadoop.util.WritableUtils;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.elasticsearch.tax.ESMapUtility;
import com.elasticsearch.tax.TaxFinalVal;
import com.splitword.soul.utility.StringUtil;

public class TaxCacheTest {
	private static Log log = LogFactory.getLog(TaxCacheTest.class);
	private TransportClient tcpClient;
	public static String hostName = "61.177.121.182";
	//public static String hostName = "localhost";
	private ObjectMapper mapper = new ObjectMapper();

	@BeforeClass
	public void startNode() throws Exception {
//		Settings settings = ImmutableSettings.settingsBuilder()
//				.put("cluster.name", "LiuboCluster").build();
		Settings settings = ImmutableSettings.settingsBuilder()
				.put("cluster.name", "elasticsearch").build();
		tcpClient = new TransportClient(settings)
				.addTransportAddress(new InetSocketTransportAddress(hostName,
						9300));
	}

	private org.elasticsearch.hadoop.cfg.Settings createSettings(
			String indexName, String typeName) {
		org.elasticsearch.hadoop.cfg.Settings settings = null;
		Properties properties = new Properties();
		properties.put(ConfigurationOptions.ES_WRITE_OPERATION, "index");
		properties.put(ConfigurationOptions.ES_MAPPING_ID, "id");
		String resource = indexName + "/" + typeName;
		properties.put(ConfigurationOptions.ES_RESOURCE, resource);
		properties.put(ConfigurationOptions.ES_HOST, hostName);
		settings = SettingsManager.loadFrom(properties);
		SerializationUtils.setValueWriterIfNotSet(settings,
				MapReduceWriter.class, log);
		InitializationUtils.setIdExtractorIfNotSet(settings,
				MapWritableIdExtractor.class, log);

		return settings;

	}

	@AfterClass
	public void closeResources() {
		tcpClient.close();
		// client.close();
	}

	@Test(enabled = true)
	public void testMethod3() throws Exception {
		createMapping(TaxFinalVal.cacheIndex);
		String readPath = "liuboOutput/word.txt";
		indexData(readPath, TaxFinalVal.cacheIndex);
	}

	private void indexData(String readPath, String indexName) {
		try {
			org.elasticsearch.hadoop.cfg.Settings settings = createSettings(
					indexName, "table");
			RestClient client = new RestClient(settings);
			IndexCommand command = new IndexCommand(settings);
			BytesArray data = new BytesArray(20 * 1024 * 1024);
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					new FileInputStream(readPath), "UTF-8"));

			String temp = null;
			int line = 0;
			while ((temp = reader.readLine()) != null) {
				temp = temp.trim();
				if (StringUtil.isBlank(temp))
					continue;
				Map<String, String> entry = new HashMap<String, String>();
				line++;
				entry.put("id", String.valueOf(line));
				entry.put("word", temp);

				MapWritable writable = (MapWritable) WritableUtils
						.toWritable(entry);
				int entrySize = command.prepare(writable);
				if (entrySize + data.size() > data.capacity()) {
					client.bulk(settings.getIndexType(), data.bytes(),
							data.size());
					data.reset();
				}
				command.write(writable, data);
			}
			reader.close();
			client.bulk(settings.getIndexType(), data.bytes(), data.size());
			data.reset();
			client.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void createMapping(String indexName) {
		try {
			IndicesExistsResponse existsResponse = tcpClient.admin().indices()
					.prepareExists(indexName).execute().actionGet();
			if (existsResponse.isExists()) {
				// if index exist, delete it
				tcpClient.admin().indices().prepareDelete(indexName).execute()
						.actionGet();
			}

			XContentBuilder builder = (XContentBuilder) jsonBuilder()
					.humanReadable(true).startObject()
					.field("settings", ESMapUtility.settingMap())
					.field("mappings", cacheMapping()).endObject();

			String settings = builder.string();
			log.info(settings);
			CreateIndexResponse createIndexResponse = tcpClient.admin()
					.indices().prepareCreate(indexName).setSource(settings)
					.execute().actionGet();
			assertThat(createIndexResponse.isAcknowledged(), is(true));
			tcpClient.admin().cluster().prepareHealth(indexName)
					.setWaitForGreenStatus().execute().actionGet();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static Map<String, Object> cacheMapping() {
		Map<String, Object> map1 = new LinkedHashMap<String, Object>();
		map1.put("type", "string");
		map1.put("index", "not_analyzed");

		Map<String, Object> tmpMap = new LinkedHashMap<String, Object>();
		tmpMap.put("word", map1);
		Map<String, Object> typeMap = new LinkedHashMap<String, Object>();
		Map<String, Object> propertiesMap = new LinkedHashMap<String, Object>();
		propertiesMap.put("properties", tmpMap);
		typeMap.put("table", propertiesMap);
		return typeMap;
	}
}
