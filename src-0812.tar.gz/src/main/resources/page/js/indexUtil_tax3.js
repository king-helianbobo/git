/**
 * 参数注释 v:输入框关键字 f:记录是哪个栏目(比如tag1代表锡城资讯,tag2信息公开tag3行政服务,tag4政民互动,tag5代表锡城资讯,其他)
 * data:ajax请求后返回来的json数据 flag:记录跳转页 n:选择的页数(比如选择页码2或是页码3....这个页码2或是页码3就是n)
 * c:记录当前页(比如从当前页第2页跳转到第3页,这个第2页就是c) t:控制每页显示多少条标记位
 */
var size = 10;// 每页显示多少数据
var maxPage;
var map;
var array_t;
/**
 * 获取CSS标签
 * 
 * @return
 */
function getCss() {
	var styleStr = "<style type='text/css'>" + ".order_box .stitle { "
			+ "width: 825px;" + "clear: right;" + "height: 27px;"
			+ "border-bottom: 2px solid #A10000;}"
			+ ".order_box .stitle .close {" + "width: 80px;" + "height: 18px;"
			+ "border-top: 1px solid #dedede;"
			+ "border-left: 1px solid #dedede;"
			+ "border-right: 1px solid #dedede;" + "background: #f1f1f1;"
			+ "color: #000;" + "text-align: center;" + "float: left;"
			+ "margin-right: 5px;" + "padding-top: 8px;}"
			+ ".order_box .stitle .open {" + "width: 82px;" + "height: 20px;"
			+ "background: #A10000;" + "color: #fff;" + "text-align: center;"
			+ "float: left;" + "margin-right: 5px;" + "padding-top: 8px;"
			+ "overflow: hidden;}" + ".order_box ul li {" + "cursor: pointer;"
			+ "display: list-item;" + "list-style:none;}" + "a:hover{text-decoration:underline;}" + "</style>";
	return styleStr;
}

/**
 * 获取
 * <li>标签
 * 
 * @param url
 * @param value
 * @param time
 * @return
 */
function getLiTarGet(url, value, content) {
	var liStr = "<li><a href=" + url + " target=\"_blank\">" + value
			+ "</a>&nbsp;&nbsp;" + content + "</li><br>";
	return liStr;
}

/**
 * 获取栏目div
 * 
 * @param htmlStr
 * @return
 */
function getColumn(htmlStr) {
	var columnStr = "<div class='order_box'>"
			+

			"<div class='cntorder' id='tabInfoDiv' style=\"height: auto;\">"
			+ htmlStr
			+ "</div>"
			+ "<div class='cntorder' id='publicDiv' style='display: none;'></div>"
			+ "<div class='cntorder' id='serverDiv' style='display: none;'></div>"
			+ "<div class='cntorder' id='interactionDiv' style='display: none;'></div>"
			+ "<div class='cntorder' id='ontherDiv' style='display: none;'></div>"
			+ "</div> ";
	return columnStr;
}


function getColumnNameBySignature(signature,map){
	alert(map.get("1"));
}

function initMap(){
	 map = getMap();  
     map.put("1","test");  
     return map;
}

function getMap() {//初始化map_,给map_对象增加方法，使map_像Map    
    var map_ = new Object();    
    map_.put = function(key, value) {    
        map_[key+'_'] = value;    
    };    
    map_.get = function(key) {    
        return map_[key+'_'];    
    };    
    map_.remove = function(key) {    
        delete map_[key+'_'];    
    };    
    map_.keyset = function() {    
        var ret = "";    
        for(var p in map_) {    
            if(typeof p == 'string' && p.substring(p.length-1) == "_") {    
                ret += ",";    
                ret += p.substring(0,p.length-1);    
            }    
        }    
        if(ret == "") {    
            return ret.split(",");    
        } else {    
            return ret.substring(1).split(",");    
        }    
    };    
    return map_;    
}    

/**
 * 
 * @param v
 * @param data
 */
function skip(v,data){
	window.open("test.jsp?v=" + v);
}

function EnumaKey(smsTypeDesc,intiUrl,i,t,tableName){
	var str = '';
	var value = '';
	//intiUrl+="<tr>";
	var detail = '';
	var j = 0;
    for(var key in smsTypeDesc){
    	var keyValue = key;
    	if(j > 3)
    		break;
    	if(i == 0)
    		str+="<td style=\"vertical-align:middle; text-align:center;\"><Font color=blue>" + key
    			+ "</font></td>&nbsp;&nbsp;";
    		
    	//if(key.replace(/&nbsp;/g,"") != '表名')
    		value+="<td style=\"vertical-align:middle; text-align:center;\")><div>"
    				+ GetVal(smsTypeDesc,key)
    				+ "&nbsp;&nbsp;</div></td>";
    	/*else
    		value+="<td style=\"vertical-align:middle; text-align:center;\")><div><Font color=green>"
				+ GetVal(smsTypeDesc,key)
				+ "&nbsp;&nbsp;</Font></div></td>";*/
    	
    		j++;
    		
    }
    var idStr = "id" + i + j + t;
    value+="<td><span><a id=" + idStr+ " href='javascript:showTitle("+ i + "," + j + "," + t + "," + "\"" + deal(smsTypeDesc) + "\"" + ");' style='cursor:pointer; font-size:15px;'>显示详情</a></span></td>";
    intiUrl+="<tr>"+str+"</tr>";
    intiUrl+="<tr>" + value + "</tr>";
   // var idStr = "id" + i + j;
    //intiUrl+="<tr><td colspan='4' ><div style= 'display:none;border:0px solid black;background-color:white;' id=" + idStr+ ">" + deal(smsTypeDesc) + "</div></td></tr>";
    return intiUrl;
} 

/*function showTitle(i,j,keyValue) {
	var idStr = "id" + i + j;
	var tDiv = document.getElementById(idStr);
	tDiv.innerHTML = keyValue;
	
	if(tDiv.style.display == 'none')
		tDiv.style.display = '';
	else 
		tDiv.style.display = 'none'
}
*/
function showDiv(i,j,t,keyValue){
	var idStr = "#id" + i + j + t;
	var idStr_1 = "id" + i + j + t;
	var tDiv = document.getElementById(idStr_1);
	tDiv.innerHTML = keyValue;
	$('#tabInfoDiv').css('height','auto');
	//alert(obj.parent().parent().parent().next().find().find());
	$(idStr).slideToggle();
}

function showTitle(i,j,t,keyValue) {
	var idStr = "id" + i + j + t;
	document.getElementById(idStr).style.color = "red";
	var temp = "<div>" + keyValue + " </div>";
	$.layer({
	    type: 1,
	    title: ["<Font color=red>Info</Font>",true],
	    area: ['350px', 'auto'],
	    border: [10, 0.3, '#000'],
	    shade: [0],
	    shadeClose: true,
	    shift: 'right-bottom',
	    closeBtn: [1, true],
	    moveOut: true,
	    moveType: 1,
	    page: {
	        html: temp
	   },
	 end:function(){
		document.getElementById(idStr).style.color = "";
	}
	});
}

/**
 * 隐藏提示信息
 */
function hideTitle(i,j) {
	var idStr = "id" + i + j;
	var tDiv = document.getElementById(idStr);
			tDiv.style.display = 'none';
}

function deal(smsTypeDesc){
	var temp = '';
	var j = 0;
	for(var key in smsTypeDesc){
    	var keyValue = key;
    	if(j > 3){
    		temp+=key+" : " + GetVal(smsTypeDesc,key) + "</p>";
    	}
    		j++;
    }
	var regS = new RegExp("\"","g");
	if(null != temp)
		return temp.replace(regS,"\\\"");
	else
		return "null";
	return temp;
}

function dealError(v){
	var intiUrl = '';
	intiUrl+="<center><span >没有找到与<Font color=red>" + v + "</Font>相关的记录</span></cneter>";
	return intiUrl;
}

function subStr(str){
	var regS = new RegExp("\"","g");
	if(null != str){
		var temp = str.replace(regS,"\\\"");
		if (temp.indexOf('"') != -1)
			return str;
		if(temp.length > 5)
			return temp.substr(0,5) + "<Font color=red>...</Font>";
		else
			return temp;
	}
	else
		return "null";
}

function GetVal(smsTypeDesc,key){
    if("undefined"==typeof(smsTypeDesc[key])){  
        return;  
    }     
    return smsTypeDesc[key];  
}  

function initPage(v, data) {
	v = strTrim(v);
	var intiUrl = '';
	var jsonobj = eval('(' + data + ')');
	var strAry = new Array();
	var htmlStr = '';
	var pageStr = '';// 然后其他的地方columnUrl,pagination
	clearCache(null);// 初始化frame
	var time;
	if(null == jsonobj)
		return '';
	intiUrl+="<table>";
	intiUrl+="<div style=text-align:left;>搜索结果(共<Font color=red>" + Math.ceil(jsonobj.count) + 
	"</font>条记录)"+
			"<p>";

	var tableSize = jsonobj.tableSize;
	var tableColumns = jsonobj.tables;
	
	for (var t = 0; t < tableSize; t++) {
		
		intiUrl+="<tr><td colspan='4'><div><Font color=green>" + tableColumns[t] + "</Font></div></td></tr>";
		
		var pageList = 'pageList' + (t + 1);
		array_t = jsonobj.pageList;

		for(var i=0;i<jsonobj[pageList].length;i++){
			var temp = '';
			temp+=EnumaKey(jsonobj[pageList][i],temp,i,t,tableColumns[t]);
			intiUrl+=temp;
		}
	}
	
	if (jsonobj.count <= size)
		return intiUrl;
	intiUrl+="</table>";
	intiUrl += "<div style=width:600px;text-align:center;>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
	maxPage = Math.ceil(jsonobj.count / size);
	var pg;
	for (var i = 1; i <= Math.ceil(jsonobj.count / size); i++) {
		if (i <= size) {
			if (i == 1) {
				pg = "<Font color=black>" + i + "</font>";
			} else {
				pg = "<Font color=red>" + i + "</font>";
			}

			intiUrl += "<a style='cursor:pointer' onclick='javascript:pageT(\""
					+ v + "\"," + i + ","  + "0);'>[" + pg
					+ "]</a>&nbsp;";
		}
	}
	if (maxPage > 1)
		intiUrl += "<span id='page_next' style='cursor:pointer' onclick='pages_next(\""
				+ v + "\",1,0)'>下一页>></span>" + "</div>";
	else
		intiUrl += "</div>";
	return intiUrl;
}


function strTrim(str){
	if(null != str)
		return str.replace(/^\s+|\s+$/g,"");
}

/**
 * 引入js标签
 * 
 * @return
 */
function importJs() {
	var jsStr = "<script src='js/jquery.min.js'><" + "/script>"
			+ "<script src='js/jquery.autocomplete.min.js'><" + "/script> "
			+ "<script src='js/page.js'><" + "/script> "
			+ "<script src='js/indexUtil_tax3.js'><" + "/script>"
			+ "<script src='layer.min.js'><" + "/script>";
			+ "<script src='layer.js'></script>"
	return jsStr;
}

/**
 * jquery实现切换栏目
 * 
 * @param v
 * @return
 */
function jqueryColumn(v) {
	var jquertStr = "$(function () {"
			+ "$('.stitle li').click(function () {"
			+ " var tabFlag='';var index_tab = $(this).parent().children().index($(this));"
			+ "tabFlag = index_tab;"
			+ "$(this).parent().find('.open').removeClass('open').addClass('close'); "
			+ "$(this).removeClass('close').addClass('open');"
			+ "var content_obj = $('.cntorder');" + "content_obj.hide();"
			+ "content_obj.eq(index_tab).show();" + "columnPage(\"" + v
			+ "\",tabFlag,document.getElementById('tabInfoDiv'));" + "});"
			+ "});";
	return jquertStr;
}
/**
 * 切换栏目,内容填充
 * 
 * @param v
 * @return
 */
function columnUrl(v) {
	var columnStr = "function columnPage(v,flag,div){" + "$.ajax({"
			+ "type:'POST'," + "url:'../?method=mypage&nature=true',"
			+ "data:'input='+v+'&&from=0&&size="
			+ size
			+ "&&tagType=tag'+parseInt(flag+1)+'',"
			+ "success : function(data) {"
			+ "var obj='';var time;"
			+ "var jsonobj=eval('('+data+')');"
			+ "for(var i=0;i<jsonobj.pageList.length;i++){"
			+ "if(jsonobj.pageList[i].time=='null'){"
			+ "	  time ='';"
			+ "	}else{"
			+ "  time = jsonobj.pageList[i].time;"
			+ "}"
			+ "obj+='<li><a href='+jsonobj.pageList[i].url+'>'+jsonobj.pageList[i].contenttitle+'</a>&nbsp;'+time+'<br>'+jsonobj.pageList[i].content+'</li><br>';"
			+ "}"
			+ "obj+='<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp</span>';"
			+ "for (var i = 1; i <= Math.ceil(jsonobj.count/"
			+ size
			+ "); i++){"
			+ " if (i <= "
			+ size
			+ "){"
			+ "if(i==1||i==parseInt(jsonobj.from/"
			+ size
			+ ")){"
			+ "var  pg = '<Font color=black>' + i + '</font>';"
			+ "}else{"
			+ "var pg = '<Font color=red>' + i + '</font>';"
			+ "}"
			+ "obj+='<a style=cursor:pointer onclick=javascript:pageT(\""
			+ v
			+ "\",'+i+','+jsonobj.from+','+flag+');>['+pg+']</a>&nbsp;'"
			+ "}"
			+ "}"
			+ "if(jsonobj.from/"
			+ size
			+ ">"
			+ size
			+ "){"
			+ "obj+='<span style=cursor:pointer onclick=pages_next(\""
			+ v
			+ "\",'+currentPage+','+flag+')>下一页>></span>';"
			+ "}"
			+ "document.getElementById('tabInfoDiv').style.display='none';"
			+ "document.getElementById('tabInfoDiv').innerHTML='';"
			+ "div.style.display='block';"
			+ "div.innerHTML=obj;"
			+ "}"
			+ "});"
			+ "}";
	return columnStr;
}


/**
 * 初始化frame
 * 
 * @param tabStr
 * @return
 */
function clearCache(tabStr) {
	/*window.parent.frames["NLP"].document.open();

	if (tabStr != null || tabStr != "")
		window.parent.frames["NLP"].document.write(tabStr);
	else
		window.parent.frames["NLP"].document.write("");

	window.parent.frames["NLP"].document.close();*/
	
	var tDiv = document.getElementById("contentDiv");
	tDiv.innerHTML = tabStr;
}
