package com.elasticsearch.tax;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.map.ObjectMapper;

import com.elasticsearch.query.SoulQueryUtil;
import com.splitword.lionsoul.jcseg.util.ChineseHelper;

public class TaxSchema {
	private static final Log log = LogFactory.getLog(TaxSchema.class);

	private static ObjectMapper mapper = new ObjectMapper();
	public final static String tableName = "tableName";
	public final static String fieldName = "fieldName";
	public final static String chineseFieldName = "chineseFieldName";
	public final static String chineseTableName = "chineseTableName";

	static String[] listStrs = { "资产负债表,资产负债", "利润表,利润", "税种鉴定表,税种鉴定",
			"人员情况表,人员情况", "个税申报,个人所得税申报" };
	// 这里需要优化

	static Map<String, List<String>> synonymMap = new HashMap<String, List<String>>();

	static {
		for (int i = 0; i < listStrs.length; i++) {
			String[] strs = listStrs[i].split(",");
			List<String> list1 = new LinkedList<String>();
			// List<String> list2 = new LinkedList<String>();
			list1.add(strs[0]);
			list1.add(strs[1]);
			synonymMap.put(strs[0], list1);
			synonymMap.put(strs[1], list1);
		}
	}

	public static Map<String, Object> schemaMap(
			Map<String, List<String>> resultMap, List<String> tokenList) {
		List<Map<String, Object>> arrayMap = new LinkedList<Map<String, Object>>();
		Set<String> fields = new TreeSet<String>();
		List<String> tokens = new LinkedList<String>();
		for (String str : tokenList) {
			if (resultMap.containsKey(str)) {
				for (String field : resultMap.get(str)) {
					if (field.endsWith(".all")) {
						Map<String, List<String>> fieldsMap = TaxFinalVal
								.fieldsMap();
						String[] strs = field.split("[.]");
						String tableName = strs[0];
						List<String> realFields = TaxQueryFields.realFieldList(
								tableName, fieldsMap);
						for (String fieldStr : realFields)
							fields.add(fieldStr);
					} else
						fields.add(field);
				}
			} else
				tokens.add(str);
		}
		for (String token : tokens) {
			for (String field : fields) {
				Map<String, Object> tjMap = TaxQueryFields.eachToken(field,
						token);
				if (tjMap != null)
					arrayMap.add(tjMap);
			}
		}
		if (arrayMap.size() == 0)
			return null;
		else if (arrayMap.size() == 1)
			return arrayMap.get(0);
		else {
			Map<String, Object> lastMap = SoulQueryUtil.createBooleanQueryMap(
					arrayMap, 1, "all");
			return lastMap;
		}
	}

	public static Map<String, Object> entityMap(Set<String> tables,
			List<String> companys) {
		List<Map<String, Object>> arrayMap = new ArrayList<Map<String, Object>>();
		Map<String, List<String>> fieldsMap = TaxFinalVal.fieldsMap();
		for (String tableName : tables) { // for each table
			List<String> realFields = TaxQueryFields.realFieldList(tableName,
					fieldsMap);
			for (String company : companys) {
				for (String realField : realFields) {
					Map<String, Object> tmpMap = TaxQueryFields.eachToken(
							realField, company);
					if (tmpMap != null)
						arrayMap.add(tmpMap);
				}
			}
		}
		if (arrayMap.size() == 0)
			return null;
		else if (arrayMap.size() == 1)
			return arrayMap.get(0);
		else {
			Map<String, Object> lastMap = SoulQueryUtil.createBooleanQueryMap(
					arrayMap, 1, "all");
			return lastMap;
		}
	}

	public static List<String> greenFields(Map<String, List<String>> resultMap,
			List<String> tokenList) {
		Set<String> fieldSet = new TreeSet<String>();
		List<String> allFields = new LinkedList<String>();
		for (String str : tokenList) {
			if (resultMap.containsKey(str)) {
				for (String field : resultMap.get(str)) {
					if (field.endsWith(".all")) {
						Map<String, List<String>> fieldsMap = TaxFinalVal
								.fieldsMap();
						String[] strs = field.split("[.]");
						String tableName = strs[0];
						List<String> realFields = TaxQueryFields.realFieldList(
								tableName, fieldsMap);
						for (String fieldStr : realFields)
							allFields.add(fieldStr);
					} else {
						fieldSet.add(field);
					}
				}
			}
		}
		List<String> fieldList = new LinkedList<String>();
		for (String field : fieldSet) {
			if (!allFields.contains(field))
				fieldList.add(field);
		}
		if (fieldList.isEmpty())
			return null;
		else
			return fieldList;
	}

	public static Map<String, Object> schemaQueryMap(String originalToken) {
		// 同样需要对token进行扩展，“资产负债表，资产负债”，“利润表，利润”
		List<String> list = synonymMap.get(originalToken);
		if (list == null) {
			list = new LinkedList<String>();
			list.add(originalToken);
		}
		List<Map<String, Object>> array1 = new ArrayList<Map<String, Object>>();
		for (String token : list) {
			Map<String, Object> map2 = SoulQueryUtil.termQueryMap(fieldName,
					token);
			array1.add(map2);
			if (ChineseHelper.allChineseChar(token)) {
				Map<String, Object> map1 = SoulQueryUtil.termQueryMap(
						chineseTableName, token);
				Map<String, Object> map3 = SoulQueryUtil.termQueryMap(
						chineseFieldName, token);
				array1.add(map1);
				array1.add(map3);
			}
		}
		Map<String, Object> queryMap = SoulQueryUtil.createBooleanQueryMap(
				array1, 1, "all");
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("query", queryMap);
		result.put("from", 0);
		result.put("size", 100);
		result.put("highlight", SoulQueryUtil.createHighLigthQuery(
				chineseFieldName, chineseTableName, fieldName));
		return result;
	}

	@SuppressWarnings("unchecked")
	public static List<String> analyzeHitsMap(Map<String, Object> map) {
		List<String> list = new LinkedList<String>();
		try {
			List<Map<String, Object>> hits = (List<Map<String, Object>>) map
					.get("hits");
			if (hits != null && hits.size() > 0) {
				for (int i = 0; i < hits.size(); i++) {
					Map<String, Object> map1 = hits.get(i);
					String tempResult = mapper.writeValueAsString(map1);
					// log.info(tempResult);
					Map<String, Object> lightMap = (Map<String, Object>) map1
							.get("highlight");
					Map<String, Object> sourceMap = (Map<String, Object>) map1
							.get("_source");
					String type = (String) map1.get("_id");
					if (type.startsWith("B"))
						continue;
					final String fieldNameText = (String) sourceMap
							.get(fieldName);
					final String[] fields = fieldNameText.split("\t");
					if (lightMap != null) {
						for (String highField : lightMap.keySet()) {
							List<String> highTextList = (List<String>) lightMap
									.get(highField);
							String highText = highTextList.get(0);
							String[] highs = highText.split("\t");
							for (int j = 0; j < highs.length; j++) {
								String high = highs[j];
								int idx1 = high.indexOf(SoulQueryUtil.preTag);
								int idx2 = high.indexOf(SoulQueryUtil.postTag);
								if (idx1 >= 0 && idx2 >= 0) {
									if (highField
											.equalsIgnoreCase(chineseFieldName))
										list.add(type + "." + fields[j]);
									else if (highField
											.equalsIgnoreCase(chineseTableName))
										list.add(type + ".all");
									else if (highField
											.equalsIgnoreCase(fieldName)) {
										list.add(type + "." + fields[j]);
									}
								}
							}
						}
					}
				}
				if (!list.isEmpty())
					return list;
				else
					return null;
			} else
				return null;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}
}
