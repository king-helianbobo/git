package com.elasticsearch.tax;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.elasticsearch.query.SoulQueryUtil;
import com.splitword.soul.utility.StringUtil;

public class TaxQueryMap {

	private static final Log log = LogFactory.getLog(TaxQueryMap.class);

	// 查询这个index下所有表的token
	public static Map<String, Object> tableMap(String indexName,
			List<String> tokenList) {
		List<String> tables = TaxFinalVal.indexTypeMap().get(indexName);
		Set<String> tableSet = new TreeSet<String>();
		for (String str : tables)
			tableSet.add(str);
		return tableMap(tableSet, tokenList);
	}

	// 查询这个index下所有表的token
	public static Map<String, Object> tableMap(List<String> tables,
			List<String> tokenList) {
		Set<String> tableSet = new TreeSet<String>();
		for (String str : tables)
			tableSet.add(str);
		return tableMap(tableSet, tokenList);
	}

	// 查询指定的某几个表中的token
	public static Map<String, Object> tableMap(Set<String> tables,
			List<String> tokenList) {
		Map<String, List<String>> fieldsMap = TaxFinalVal.fieldsMap();
		List<Map<String, Object>> lastArray = new ArrayList<Map<String, Object>>();
		for (String tableName : tables) { // for each table
			List<Map<String, Object>> arrayForEachTable = new ArrayList<Map<String, Object>>();
			// for each table ,first get all real fields
			List<String> realFields = TaxQueryFields.realFieldList(tableName,
					fieldsMap);
			// log.info(realFields);
			for (String token : tokenList) {
				List<Map<String, Object>> array = new ArrayList<Map<String, Object>>();
				for (String realField : realFields) {
					// log.info(token + "," + realField);
					Map<String, Object> tmpMap = TaxQueryFields.eachToken(
							realField, token);
					if (tmpMap != null)
						array.add(tmpMap);
				}
				Map<String, Object> map1 = SoulQueryUtil.createBooleanQueryMap(
						array, 1);
				if (map1 != null)
					arrayForEachTable.add(map1);
			}
			// 必须全都满足，否则匹配不到
			Map<String, Object> mapHaha = SoulQueryUtil.createBooleanQueryMap(
					arrayForEachTable, arrayForEachTable.size());
			Map<String, Object> mapForThisTable = TaxQueryUtil
					.queryMapWithFilter(mapHaha, tableName);
			lastArray.add(mapForThisTable);
		}
		Map<String, Object> lastMap = SoulQueryUtil.createBooleanQueryMap(
				lastArray, 1);
		return lastMap;
	}

	public static Map<String, List<String>> realTokens(
			Map<String, List<String>> resultMap, List<String> tokenList) {
		List<String> realTokens = new LinkedList<String>();
		Set<String> fieldsA = new HashSet<String>();
		Set<String> fieldsB = new HashSet<String>();
		List<String> company = new LinkedList<String>();
		List<String> list1 = new LinkedList<String>();
		List<String> list2 = new LinkedList<String>();
		for (String str : tokenList) {
			if (resultMap.containsKey(str)) {
				List<String> fields = resultMap.get(str);
				for (String field : fields) {
					if (field.endsWith(".all")) {
						String[] strs = field.split("[.]");
						fieldsA.add(strs[0]);
					} else
						fieldsB.add(field);
				}
				continue;
			} else
				realTokens.add(str);
		}
		Map<String, List<String>> result = new LinkedHashMap<String, List<String>>();
		if (realTokens.size() > 0)
			result.put("tokens", realTokens);

		for (String str : realTokens) {
			if (StringUtil.isBlank(str))
				continue;
			if (TaxFinalVal.companyMap().get(str) != null)
				company.add(str);
			if (TaxFinalVal.personMap().get(str) != null)
				company.add(str);
		}
		if (company.size() > 0)
			result.put("companys", company);

		for (String str : fieldsA)
			list1.add(str);
		for (String str : fieldsB) {
			String[] strs = str.split("[.]");
			String tableName = strs[0];
			if (!list1.contains(tableName))
				list2.add(str);
		}
		if (list1.size() > 0)
			result.put("tables", list1);
		if (list2.size() > 0)
			result.put("fields", list2);
		return result;
	}

	public static boolean existEntity(Map<String, List<String>> resultMap,
			List<String> tokenList) {
		List<String> realTokens = new LinkedList<String>();
		for (String key : resultMap.keySet()) {
			log.info(key + ", List = " + resultMap.get(key));
		}
		Set<String> tables = new HashSet<String>();
		for (String str : tokenList) {
			if (resultMap.containsKey(str)) {
				List<String> fields = resultMap.get(str);
				for (String field : fields) {
					String[] strs = field.split("[.]");
					tables.add(strs[0]);
				}
				continue;
			} else
				realTokens.add(str);
		}

		for (String str : realTokens) {
			if (StringUtil.isBlank(str))
				continue;
			if (TaxFinalVal.companyMap().get(str) != null)
				return true;
			if (TaxFinalVal.personMap().get(str) != null)
				return true;
		}
		return false;
	}

	@SuppressWarnings("unchecked")
	public static Map<String, Object> checkMap(Map<String, Object> map1,
			List<TaxPojo> tokenSet, List<String> greenFields) {
		Map<String, Object> resultMap = new LinkedHashMap<String, Object>();
		// LinkedHashMap could keep insert order
		String tableName = (String) map1.get("_type");
		resultMap.put("tableName", TaxFinalVal.tableMap().get(tableName));
		Map<String, List<String>> fieldsMap = TaxFinalVal.fieldsMap();
		List<String> displayFields = fieldsMap.get(tableName + "#display");
		Map<String, Object> defMap = TaxFinalVal.defMap().get(tableName);
		if (displayFields == null) {
			List<String> tmpList = new LinkedList<String>();
			for (String field : defMap.keySet()) {
				tmpList.add(field);
			}
			displayFields = tmpList;
		}
		Map<String, Object> lightMap = (Map<String, Object>) map1
				.get("highlight");
		Map<String, Object> sourceMap = (Map<String, Object>) map1
				.get("_source");
		List<String> list1 = new LinkedList<String>();
		List<String> list2 = new LinkedList<String>();
		list1.addAll(displayFields);
		for (String resultField : sourceMap.keySet()) {
			String[] strs = resultField.split("[.]");
			String field = strs[1];
			if (!displayFields.contains(field))
				list2.add(field);
		}

		int listSize = list1.size();
		list1.addAll(list2);
		for (int i = 0; i < list1.size(); i++) {
			String field = list1.get(i);
			Map<String, String> typeInfo = (Map<String, String>) defMap
					.get(field);
			String chineseFieldName = typeInfo.get("chineseFieldName");
			String resultField = tableName + "." + field;
			if (!sourceMap.containsKey(resultField))
				continue;
			String resultStr = (String) sourceMap.get(resultField);
			String anotherStr = null;
			if (lightMap != null && lightMap.containsKey(resultField)) {
				List<String> tmpList = (List<String>) lightMap.get(resultField);
				anotherStr = tmpList.get(0);
			} else if (greenFields == null
					|| !greenFields.contains(resultField)) {
				anotherStr = ESMapUtility.checkTwoStr(resultStr, tokenSet,
						"red");
				// 对resultStr进行可能的转换
			} else {
				String type = greenFields.get(0);
				if (type.equals("table")) {
					anotherStr = SoulQueryUtil.greenPreTag + resultStr
							+ SoulQueryUtil.greenPostTag;
					chineseFieldName = SoulQueryUtil.greenPreTag
							+ chineseFieldName + SoulQueryUtil.greenPostTag;
				} else {
					anotherStr = ESMapUtility.checkTwoStr(resultStr, tokenSet,
							"green");
					if (!anotherStr.equals(resultStr))
						chineseFieldName = SoulQueryUtil.greenPreTag
								+ chineseFieldName + SoulQueryUtil.greenPostTag;
				}

			}
			if (i < listSize)
				resultMap.put(chineseFieldName, anotherStr);
			else {
				if (!resultStr.equals(anotherStr))
					resultMap.put(chineseFieldName, anotherStr);
			}
		}
		return resultMap;
	}
}
