package com.elasticsearch.tax;

import java.io.Closeable;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.httpclient.HostConfiguration;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.URI;
import org.apache.commons.httpclient.params.HttpClientParams;
import org.apache.commons.httpclient.params.HttpConnectionManagerParams;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.junit.Assert;

import com.elasticsearch.query.PostQuery;
import com.elasticsearch.query.SoulQueryUtil;

public class TaxHttpClient implements Closeable {

	protected String url = null;
	private static ObjectMapper mapper = new ObjectMapper();
	protected PostQuery postQuery = null;
	private static final Log log = LogFactory.getLog(TaxHttpClient.class);

	public TaxHttpClient(String url) {
		HttpClientParams params = new HttpClientParams();
		params.setConnectionManagerTimeout(20 * 1000);
		HttpClient client = new HttpClient(params);
		HostConfiguration hostConfig = new HostConfiguration();
		this.url = url;
		try {
			hostConfig.setHost(new URI(this.url, false));
		} catch (IOException ex) {
			throw new IllegalArgumentException("Invalid target URI " + url, ex);
		}
		client.setHostConfiguration(hostConfig);
		HttpConnectionManagerParams connectionParams = client
				.getHttpConnectionManager().getParams();
		// make sure to disable Nagle's protocol
		connectionParams.setTcpNoDelay(true);
		this.postQuery = new PostQuery(client);
	}

	protected List<Map<String, Object>> primeTokenList(String indexName,
			String queryStr, String analyzer) {
		// String query = indexName + "/_analyze?analyzer=tax_query&pretty";
		String query = indexName + "/_analyze?analyzer=" + analyzer
				+ "&pretty=true";
		Map<String, Object> map = postQuery.post(query, queryStr);
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> tokenMaps = (List<Map<String, Object>>) map
				.get("tokens");
		return tokenMaps;
	}

	protected Map<Integer, List<Map<String, Object>>> secondTokenList(
			List<Map<String, Object>> tokenMaps) {
		Map<Integer, List<Map<String, Object>>> posMaps = new HashMap<Integer, List<Map<String, Object>>>();
		for (int i = 0; i < tokenMaps.size(); i++) {
			Map<String, Object> tmp = tokenMaps.get(i);
			String type = (String) tmp.get("type");
			int position = (Integer) tmp.get("position");
			if (type.equals("null") || type.equals("w"))
				continue;
			List<Map<String, Object>> mapList = posMaps.get(position);
			if (mapList == null)
				mapList = new LinkedList<Map<String, Object>>();
			mapList.add(tmp);
			posMaps.put(position, mapList);
		}
		if (posMaps.isEmpty())
			return null;
		else {
			Map<Integer, List<Map<String, Object>>> result = new HashMap<Integer, List<Map<String, Object>>>();
			Set<String> set = new TreeSet<String>();
			for (Integer pos : posMaps.keySet()) {
				List<Map<String, Object>> list = posMaps.get(pos);
				String key = (String) list.get(0).get("token");
				if (!set.contains(key)) {
					set.add(key);
					result.put(pos, list);
				}
			}
			return result;
		}
	}

	@Override
	public void close() {
		postQuery.close();
	}

	@SuppressWarnings("unchecked")
	public String suggestSearch(String queryStr) throws IOException {
		String json = SoulQueryUtil
				.suggestJson(queryStr, "suggest", "word", 10);
		String firstQuery = TaxFinalVal.cacheIndex + "/table/__suggest?pretty";
		Map<String, Object> map = postQuery.post(firstQuery, json);
		List<String> suggest = (List<String>) map.get("suggestions");
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("suggestions", suggest);
		result.put("size", suggest.size());
		result.put("term", queryStr);
		String resultJson = mapper.writeValueAsString(result);
		return resultJson;
	}

	@SuppressWarnings("unchecked")
	private Map<String, List<String>> schemaFields(List<String> tokenList) {
		String url = TaxFinalVal.schemaIndex + "/_search?pretty=true";
		Map<String, List<String>> resultMap = new HashMap<String, List<String>>();
		try {
			for (String token : tokenList) {
				Map<String, Object> queryMap = TaxSchema.schemaQueryMap(token);
				String json = mapper.writeValueAsString(queryMap);
				Map<String, Object> map = postQuery.post(url, json);
				map = (Map<String, Object>) map.get("hits");
				log.info("original token : " + token);
				if (map != null) {
					List<String> fields = TaxSchema.analyzeHitsMap(map);
					if (fields != null) {
						resultMap.put(token, fields);
						log.info("schema token : " + token);
					}
				}
			}
			if (resultMap.size() > 0)
				return resultMap;
			else
				return null;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	public String taxSearch(String queryStr, int from, int size)
			throws JsonGenerationException, JsonMappingException, IOException {
		List<Map<String, Object>> primeTokens = primeTokenList(
				TaxFinalVal.schemaIndex, queryStr, "tax_query");
		// split input string to get tokens
		Map<Integer, List<Map<String, Object>>> tokens = secondTokenList(primeTokens);
		if (tokens == null || tokens.isEmpty()) {
			log.info(queryStr + "," + from + "," + size);
			return null;
		}
		List<TaxPojo> tokenSet = new LinkedList<TaxPojo>();
		List<String> tokenList = new LinkedList<String>();
		for (Integer position : tokens.keySet()) {
			List<Map<String, Object>> tmpList = tokens.get(position);
			String token = (String) tmpList.get(0).get("token");
			tokenList.add(token);
			List<TaxPojo> expandTokens = ESMapUtility.expandToken(token);
			// tokenSet is used for highlight
			for (TaxPojo pojo : expandTokens)
				tokenSet.add(pojo);
		}
		String url = TaxFinalVal.indexOne + "/_search?pretty=true";
		Map<String, List<String>> resultMap = schemaFields(tokenList);
		if (resultMap != null) {
			Map<String, Object> tmpMap = TaxQueryFields.specialQueryMap(
					resultMap, tokenList);
			List<String> greenFields = (List<String>) tmpMap.get("greenFields");
			Map<String, Object> queryMap = (Map<String, Object>) tmpMap
					.get("queryMap");
			String json = TaxQueryUtil.queryJson(queryMap, from, size);
			log.info(json);
			Map<String, Object> esResultMap = postQuery.post(url, json);
			return constructPageList(esResultMap, tokenSet, greenFields, from);
		}
		// else if (tokenList.size() == 1 && tokenList.get(0).contains("-")) {
		// String token = tokenList.get(0);
		// log.info(token);
		// String[] strs = token.split("-");
		// String start = strs[0];
		// String end = strs[1];
		// String field = "A10.SIJMSSRE_JE";
		// Map<String, Object> tmp1 = new HashMap<String, Object>();
		// Map<String, Object> tmp2 = new HashMap<String, Object>();
		// Map<String, Object> tmp3 = new HashMap<String, Object>();
		// tmp1.put("gte", start);
		// tmp1.put("lte", end);
		// tmp2.put(field, tmp1);
		// tmp3.put("range", tmp2);
		// String json = TaxQueryUtil.queryJson(tmp3, from, size);
		// log.info(json);
		// Map<String, Object> esResultMap = postQuery.post(url, json);
		// return constructPageList(esResultMap, tokenSet, null, from);
		// }
		else {

			Map<String, Object> queryMap = TaxQueryMap.tableMap(
					TaxFinalVal.indexOne, tokenList);
			String json = TaxQueryUtil.queryJson(queryMap, from, size);
			log.info(json);
			Map<String, Object> esResultMap = postQuery.post(url, json);
			return constructPageList(esResultMap, tokenSet, null, from);
		}
	}

	@SuppressWarnings("unchecked")
	public static Map<String, Object> pageListMap(
			Map<String, Object> tmpResultMap, List<TaxPojo> tokenSet,
			List<String> greenFields, int from) {
		Map<String, Object> resultMap = (Map<String, Object>) tmpResultMap
				.get("hits");
		if (resultMap == null)
			return null;
		List<Map<String, Object>> hits = (List<Map<String, Object>>) resultMap
				.get("hits");

		Map<String, List<String>> fieldsMap = new LinkedHashMap<String, List<String>>();
		for (int i = 0; i < hits.size(); i++) {
			Map<String, Object> map1 = hits.get(i);
			Map<String, Object> checkedMap = TaxQueryMap.checkMap(map1,
					tokenSet, greenFields);
			String tableName = (String) checkedMap.get("tableName");
			List<String> fields = fieldsMap.get(tableName);
			if (fields == null)
				fields = new ArrayList<String>();
			for (String field : checkedMap.keySet()) {
				if (!fields.contains(field))
					fields.add(field);
			}
			fields.remove("tableName");
			fieldsMap.put(tableName, fields);
		}

		Map<String, List<Map<String, Object>>> lastMap = new LinkedHashMap<String, List<Map<String, Object>>>();
		for (int i = 0; i < hits.size(); i++) {
			Map<String, Object> map1 = hits.get(i);
			Map<String, Object> checkedMap = TaxQueryMap.checkMap(map1,
					tokenSet, greenFields);
			String tableName = (String) checkedMap.get("tableName");
			List<Map<String, Object>> array = lastMap.get(tableName);
			List<String> fields = fieldsMap.get(tableName);
			if (array == null)
				array = new ArrayList<Map<String, Object>>();
			checkedMap.remove("tableName");
			Map<String, Object> tmpMap = new LinkedHashMap<String, Object>();
			for (String field : fields) {
				String value = (String) checkedMap.get(field);
				if (value != null)
					tmpMap.put(field, value);
				else
					tmpMap.put(field, " ");
			}
			array.add(tmpMap);
			lastMap.put(tableName, array);
			fieldsMap.put(tableName, fields);
		}
		Map<String, Object> result = new LinkedHashMap<String, Object>();
		int totalSize = (Integer) resultMap.get("total");
		result.put("from", from);
		result.put("size", hits.size());
		result.put("count", totalSize);
		result.put("tableSize", lastMap.size());
		List<String> tables = new LinkedList<String>();
		for (String tableName : lastMap.keySet()) {
			tables.add(tableName);
		}
		result.put("tables", tables);
		int i = 1;
		for (String tableName : lastMap.keySet()) {
			String key = "pageList" + String.valueOf(i++);
			result.put(key, lastMap.get(tableName));
		}
		return result;
	}

	private static String constructPageList(Map<String, Object> tmpResultMap,
			List<TaxPojo> tokenSet, List<String> greenFields, int from) {
		try {
			Map<String, Object> resultMap = pageListMap(tmpResultMap, tokenSet,
					greenFields, from);
			String resultJson = mapper.writeValueAsString(resultMap);
			log.info(resultJson);
			return resultJson;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}

}
