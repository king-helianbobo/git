package com.soul.kaka.readExcel;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import com.splitword.soul.utility.StringUtil;

public class ExtractSpeContentSegData {

	private static ObjectMapper mapper = new ObjectMapper();
	private static Map<String, Integer> speSegmentMap = new HashMap<String, Integer>();
	private static FileOutputStream speSegmentOut;
	private static BufferedWriter speSegmentBw;

	static {
		try {
			speSegmentOut = new FileOutputStream(
					"zhouqiOutput/official-07-22Result/speSegResult.txt");
			speSegmentBw = new BufferedWriter(new OutputStreamWriter(
					speSegmentOut, "utf-8"));
		} catch (FileNotFoundException | UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}

	/**
	 * @param args
	 * @throws IOException
	 * @throws FileNotFoundException
	 */
	public static void main(String[] args) throws FileNotFoundException,
			IOException {
		// TODO Auto-generated method stub
		String officialTxtPath = "zhouqiOutput/official-07-22";
		listDirectory(officialTxtPath);
		outPutSpeSegMapToTxt(speSegmentMap, speSegmentBw);

		close();
	}

	public static void outPutSpeSegMapToTxt(Map<String, Integer> map,
			BufferedWriter wordSegmentBw) throws IOException {

		for (Map.Entry<String, Integer> entry : map.entrySet()) {
			String key = entry.getKey();
			Integer value = entry.getValue();
			String outStr = key + ":  " + value + "\n";
			wordSegmentBw.append(outStr);
		}

		wordSegmentBw.flush();
	}

	private static void close() throws IOException {
		if (speSegmentOut != null) {
			speSegmentOut.close();
		}
		if (speSegmentBw != null) {
			speSegmentBw.close();
		}
	}

	private static void listDirectory(String filepath)
			throws FileNotFoundException, IOException {
		File dir = new File(filepath);
		File file[] = dir.listFiles();

		for (int j = 0; j < file.length; j++) {
			if (file[j].isDirectory()) {
				listDirectory(file[j].getAbsolutePath());
			} else if (file[j].getName().endsWith("txt")) {
				String filename = file[j].getName();
				readSpeSegData("zhouqiOutput/official-07-22/" + filename);
				// readWordSegData("zhouqiOutput/contentTest/"+filename);
			} else {
				System.out.println("do nothing");
			}
		}
	}

	private static void readSpeSegData(String path) throws JsonParseException,
			JsonMappingException, IOException {

		BufferedReader reader = new BufferedReader(new InputStreamReader(
				new FileInputStream(path), "UTF-8"));
		String temp = null;
		while ((temp = reader.readLine()) != null) {
			temp = temp.trim();
			if (StringUtil.isBlank(temp))
				continue;
			JsonParser jsonParser = mapper.getJsonFactory().createJsonParser(
					temp);
			@SuppressWarnings("unchecked")
			Map<String, String> entry = mapper.readValue(jsonParser, Map.class);
			String contentAndTitle = entry.get("contenttitle") + "  "
					+ entry.get("content");
			System.out.println("charCount = " + contentAndTitle.length());
			char[] chLine = ExtractSegmentData.getTextData(contentAndTitle);

			ArrayList<String> speSegmentList = ExtractSpeSegData
					.makeSpeSegment(chLine);
			ExtractSpeSegData.countSpeSegmentMap(speSegmentList, speSegmentMap);
			System.out.println("speSegmentMap size  = " + speSegmentMap.size());
		}
		reader.close();

	}
}
