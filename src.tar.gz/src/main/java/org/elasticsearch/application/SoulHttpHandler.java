package org.elasticsearch.application;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.splitword.soul.utility.IOUtil;
import org.splitword.soul.utility.StringUtil;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

@SuppressWarnings("all")
public class SoulHttpHandler implements HttpHandler {

	private static final Log log = LogFactory.getLog(SoulHttpHandler.class);
	private static final String ENCODING = System.getProperty("file.encoding");
	private SoulHttpServlet httpServlet = null;

	public SoulHttpHandler(String host, String index, String type) {
		httpServlet = new SoulHttpServlet(host, index, type);
	}

	public void handle(HttpExchange httpExchange) {
		try {
			String path = httpExchange.getRequestURI().getPath();
			if (path != null && path.startsWith("/page")) {
				writeToClient(httpExchange, readFileToString(path, "utf-8"));
				return;
			} else if (path != null
					&& path.startsWith("/test")
					&& (path.endsWith("png") || path.endsWith("jpg") || path
							.endsWith("gif"))) {
				byte[] bytes = readBinaryFile(path);
				httpExchange.sendResponseHeaders(200, bytes.length);
				OutputStream out = httpExchange.getResponseBody();
				out.write(bytes);
				out.flush();
				return;
			} else if (path != null && path.startsWith("/test")) {
				writeToClient(httpExchange, readFileToString(path, "utf-8"));
				return;
			} else if (path != null && path.endsWith("favicon.ico")) {
				return;
			} else {
				Map<String, String> paramers = parseParamers(httpExchange);
				String input = paramers.get("input");
				String responseMsg = null;

				if (StringUtil.isNotBlank(input)) {
					String method = paramers.get("method");
					String nature = paramers.get("nature");
					String from = paramers.get("from");
					String size = paramers.get("size");
					String tagType = paramers.get("tagType");
					if ((from != null) && (size != null) && (tagType != null)) {
						responseMsg = httpServlet.processRequest(input, method,
								nature, from, size, tagType);
					} else
						responseMsg = httpServlet.processRequest(input, method,
								nature, null, null, null);
					if (responseMsg != null)
						writeToClient(httpExchange, responseMsg);
				} else {
					// do nothing
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			try {
				writeToClient(httpExchange, e.getMessage());
			} catch (IOException e1) {
				log.error("write to client error!");
			}
		} finally {
			httpExchange.close();
		}
	}

	private String readFileToString(String path, String coding) {
		InputStream resourceAsStream = null;
		try {
			resourceAsStream = this.getClass().getResourceAsStream(path);
			resourceAsStream.available();
			return IOUtil.getContent(resourceAsStream, coding);
		} catch (Exception e) {
			return String.valueOf("Error: 404, File Not Found!");
		} finally {
			if (resourceAsStream != null) {
				try {
					resourceAsStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	private byte[] readBinaryFile(String path) {
		InputStream resourceAsStream = null;
		try {
			resourceAsStream = this.getClass().getResourceAsStream(path);
			int length = resourceAsStream.available();
			byte[] buffer = new byte[length * 2];
			int len = resourceAsStream.read(buffer);
			byte[] result = new byte[len];
			System.arraycopy(buffer, 0, result, 0, len);
			return result;
		} catch (Exception e) {
			return String.valueOf("Error: 404, File Not Found!").getBytes();
		} finally {
			if (resourceAsStream != null) {
				try {
					resourceAsStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	private void writeToClient(HttpExchange httpExchange, String responseMsg)
			throws IOException {
		byte[] bytes = responseMsg.getBytes();
		httpExchange.sendResponseHeaders(200, bytes.length);
		OutputStream out = httpExchange.getResponseBody();
		out.write(bytes);
		out.flush();
	}

	private Map<String, String> parseParamers(HttpExchange httpExchange)
			throws UnsupportedEncodingException, IOException {
		BufferedReader reader = null;
		try {
			Map<String, String> parameters = new HashMap<String, String>();
			URI requestedUri = httpExchange.getRequestURI();
			String query = requestedUri.getRawQuery();
			parseQuery(query, parameters);
			reader = IOUtil.getReader(httpExchange.getRequestBody(), ENCODING);
			query = IOUtil.getContent(reader).trim();
			parseQuery(query, parameters);
			httpExchange.setAttribute("parameters", parameters);
			return parameters;
		} finally {
			if (reader != null) {
				reader.close();
			}
		}
	}

	/**
	 * parse parameters from get/post request
	 * 
	 * @param query
	 * @param parameters
	 */
	private void parseQuery(String query, Map<String, String> parameters) {
		if (StringUtil.isBlank(query)) {
			return;
		}
		String splitStrs[] = query.split("\\?");
		query = splitStrs[splitStrs.length - 1];
		splitStrs = query.split("&");
		String[] param = null;
		String key = null;
		String value = null;
		for (String kv : splitStrs) {
			try {
				param = kv.split("=");
				if (param.length == 2) {
					key = URLDecoder.decode(param[0], ENCODING);
					value = URLDecoder.decode(param[1], ENCODING);
					parameters.put(key, value);
				}
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
		}
	}

}
