package org.elasticsearch.application.query;

import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class SingleTermQuery extends SoulQuery {
	private static final Log log = LogFactory.getLog(SingleTermQuery.class);

	public SingleTermQuery(String index, String type, PostQuery postQuery) {
		super(index, type, postQuery);
	}

	@SuppressWarnings("unchecked")
	public Map<String, Object> singleTermForTitle(String keyWord, String tag) {
		String query = index + "/_analyze?analyzer=soul_query_nature&pretty";
		Map<String, Object> map = postQuery.post(query, keyWord);
		List<Map<String, Object>> tokens = (List<Map<String, Object>>) map
				.get("tokens");
		List<Object> array = singleQueryForTitle(tokens, 1.0f);
		if (array == null)
			return null;
		Map<String, Object> resultMap = SoulQueryUtil.createBooleanQueryMap(
				array, 1, tag);
		return resultMap;
	}

	@SuppressWarnings("unchecked")
	public Map<String, Object> singleTermForTitleAndContent(String keyWord,
			String tag) {
		String query = index + "/_analyze?analyzer=soul_query_nature&pretty";
		Map<String, Object> map = postQuery.post(query, keyWord);
		List<Map<String, Object>> tokens = (List<Map<String, Object>>) map
				.get("tokens");
		List<Object> array = singleQueryForTitleAndContent(tokens, 0.8f);
		if (array == null)
			return null;
		Map<String, Object> resultMap = SoulQueryUtil.createBooleanQueryMap(
				array, 1, tag);
		return resultMap;
	}

}
