package org.elasticsearch.application.query;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.testng.Assert;

public class DoubleTermQuery extends SoulQuery {

	private static final Log log = LogFactory.getLog(DoubleTermQuery.class);
	final int leastNumber = 4;
	Map<Integer, QueryPojo> nounWords = new HashMap<Integer, QueryPojo>();
	Map<Integer, List<String>> resultMap = new HashMap<Integer, List<String>>();
	List<String> keywords1 = null;
	List<String> keywords2 = null;

	public DoubleTermQuery(String index, String type, PostQuery postQuery) {
		super(index, type, postQuery);
	}

	public Map<String, Object> queryTitleAndContent(String queryStr, String tag) {
		fillTwoList(queryStr);
		List<Object> titleArray = combineQueryTitle(keywords1, keywords2);
		List<Object> contentArray = combineQueryContent(keywords1, keywords2);
		Map<String, Object> titleMap = SoulQueryUtil.createBooleanQueryMap(
				titleArray, 1, "all", 400.0f);
		Map<String, Object> contentMap = SoulQueryUtil.createBooleanQueryMap(
				contentArray, 1, "all", 300.0f);
		QueryPojo pojo = getSinglePojo(nounWords);
		List<Object> finalArray = new ArrayList<Object>();
		finalArray.add(titleMap);
		finalArray.add(contentMap);
		if (pojo != null) {
			List<Map<String, Object>> tokens = posMaps.get(pojo.getPosition());
			List<Object> array = singleQueryForTitleAndContent(tokens, 0.8f);
			if (array != null) {
				Map<String, Object> singleMap = SoulQueryUtil
						.createBooleanQueryMap(array, 1);
				finalArray.add(singleMap);
			}
		}
		Map<String, Object> finalMap = SoulQueryUtil.createBooleanQueryMap(
				finalArray, 1, tag);
		return finalMap;
	}

	private void fillTwoList(String queryStr) {
		fillBaseMap(queryStr);
		nounWords.clear();
		resultMap.clear();
		int number = fillNounWordMap(nounWords, resultMap);
		Assert.assertEquals(number, 2);
		keywords1 = resultMap.get(0);
		keywords2 = resultMap.get(1);
		if (keywords1.size() > leastNumber)
			keywords1 = keywords1.subList(0, leastNumber);
		if (keywords2.size() > leastNumber)
			keywords2 = keywords2.subList(0, leastNumber);
		log.info(keywords1 + " / " + keywords2);
	}

	protected QueryPojo compareTwoTerms(List<QueryPojo> twoTerms) {
		Assert.assertEquals(twoTerms.size(), 2);
		int docfreq = 10000000;
		int pos = -1;
		for (int i = 0; i < twoTerms.size(); i++) {
			QueryPojo pojo = twoTerms.get(i);
			int tmpFreq = termTotalFreq(pojo.getName());
			if (tmpFreq < docfreq) {
				docfreq = tmpFreq;
				pos = i;
			}
		}
		return twoTerms.get(pos);
	}

	protected QueryPojo getSinglePojo(Map<Integer, QueryPojo> nounWords) {
		if (nounWords.size() == 2) {
			List<QueryPojo> pojoList = new LinkedList<QueryPojo>();
			for (Integer pos : terms.keySet()) {
				QueryPojo pojo = terms.get(pos);
				pojoList.add(pojo);
			}
			QueryPojo pojo = compareTwoTerms(pojoList);
			return pojo;
		} else if (nounWords.size() == 0) {
			List<QueryPojo> termList = new LinkedList<QueryPojo>();
			List<QueryPojo> vnTermList = new LinkedList<QueryPojo>();
			for (Integer pos : terms.keySet()) {
				QueryPojo pojo = terms.get(pos);
				String nature = pojo.getNature();
				if (nature.equals("vn"))
					vnTermList.add(pojo);
				else
					termList.add(pojo);
			}
			QueryPojo pojo = null;
			if (vnTermList.size() == 1)
				pojo = vnTermList.get(0);
			else if (vnTermList.size() == 0)
				pojo = compareTwoTerms(termList);
			else {
				pojo = compareTwoTerms(vnTermList);
			}
			log.info("expected String is \"" + pojo.getName() + "\"");
			return pojo;
		} else if (nounWords.size() == 1) {
			Set<Integer> set = nounWords.keySet();
			Iterator<Integer> iter = set.iterator();
			if (iter.hasNext()) {
				int pos = iter.next();
				return nounWords.get(pos);
			}
		}
		return null;
	}

	public Map<String, Object> queryTitle(String queryStr, String tag) {
		fillTwoList(queryStr);
		List<Object> titleArray = combineQueryTitle(keywords1, keywords2);
		Map<String, Object> titleMap = SoulQueryUtil.createBooleanQueryMap(
				titleArray, 1, "all", 4.0f);
		QueryPojo pojo = getSinglePojo(nounWords);
		List<Object> finalArray = new ArrayList<Object>();
		finalArray.add(titleMap);
		if (pojo != null) {
			List<Map<String, Object>> tokens = posMaps.get(pojo.getPosition());
			log.info(pojo.getName() + "," + pojo.getNature());
			List<Object> array = singleQueryForTitle(tokens, 0.8f);
			if (array != null) {
				Map<String, Object> singleMap = SoulQueryUtil
						.createBooleanQueryMap(array, 1);
				finalArray.add(singleMap);
			}
		}
		Map<String, Object> finalMap = SoulQueryUtil.createBooleanQueryMap(
				finalArray, 1, tag);
		return finalMap;
	}
}
