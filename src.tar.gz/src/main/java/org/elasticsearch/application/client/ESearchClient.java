package org.elasticsearch.application.client;

import java.io.Closeable;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.httpclient.HostConfiguration;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.URI;
import org.apache.commons.httpclient.params.HttpClientParams;
import org.apache.commons.httpclient.params.HttpConnectionManagerParams;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.map.ObjectMapper;
import org.elasticsearch.application.query.PostQuery;
import org.elasticsearch.application.query.QueryPojo;

public class ESearchClient implements Closeable {
	protected static final String titleField = "contenttitle";
	protected String url = "http://localhost:9200";
	protected String index = "official_mini";
	protected String type = "table";
	protected ObjectMapper mapper = new ObjectMapper();
	protected PostQuery postQuery = null;
	private static final Log log = LogFactory.getLog(ESearchClient.class);

	public ESearchClient(String url, String index, String type) {
		HttpClientParams params = new HttpClientParams();
		params.setConnectionManagerTimeout(20 * 1000);
		HttpClient client = new HttpClient(params);
		HostConfiguration hostConfig = new HostConfiguration();
		this.url = url;
		this.index = index;
		this.type = type;
		try {
			hostConfig.setHost(new URI(this.url, false));
		} catch (IOException ex) {
			throw new IllegalArgumentException("Invalid target URI " + url, ex);
		}
		client.setHostConfiguration(hostConfig);
		HttpConnectionManagerParams connectionParams = client
				.getHttpConnectionManager().getParams();
		// make sure to disable Nagle's protocol
		connectionParams.setTcpNoDelay(true);
		this.postQuery = new PostQuery(client);
	}

	protected List<Map<String, Object>> tokenList(String queryStr) {
		Map<Integer, QueryPojo> terms = new HashMap<Integer, QueryPojo>();
		Map<Integer, Map<String, Object>> posMaps = new HashMap<Integer, Map<String, Object>>();
		String query = index + "/_analyze?analyzer=soul_query_nature&pretty";
		Map<String, Object> map = postQuery.post(query, queryStr);
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> tokenMaps = (List<Map<String, Object>>) map
				.get("tokens");
		for (int i = 0; i < tokenMaps.size(); i++) {
			Map<String, Object> tmp = tokenMaps.get(i);
			String type = (String) tmp.get("type");
			String token = (String) tmp.get("token");
			int position = (Integer) tmp.get("position");
			if (type.equals("null") || type.equals("w"))
				continue;
			if (type.equals(BasicTokenizer.TYPE_SYNONYM)
					|| type.equals(BasicTokenizer.TYPE_VECTOR))
				continue;
			QueryPojo pojo = new QueryPojo(token, type, position);
			terms.put(position, pojo);
			posMaps.put(position, tmp);
		}
		if (terms.isEmpty())
			return null;
		else {
			List<Map<String, Object>> result = new LinkedList<Map<String, Object>>();
			Set<String> set = new HashSet<String>();
			for (Integer pos : posMaps.keySet()) {
				String key = (String) posMaps.get(pos).get("token");
				if (!set.contains(key)) {
					set.add(key);
					result.add(posMaps.get(pos));
					log.info("key = " + key + "," + pos);
				}
			}
			return result;
		}
	}

	@Override
	public void close() {
		postQuery.close();
	}

}
