package com.elasticsearch.tax;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Assert;

import com.elasticsearch.query.SoulQueryUtil;
import com.splitword.soul.utility.StringUtil;

public class EntitySchemaQuery {
	private static final Log log = LogFactory.getLog(EntitySchemaQuery.class);

	public static Map<String, Object> entityQueryMap(
			Map<String, List<String>> schemaMap, List<String> tokenList) {
		Map<String, List<String>> map = analyzeMap(schemaMap, tokenList);

		List<String> tableList = map.get("tableList");
		List<String> greenFields = map.get("greenFields");
		List<String> otherFields = map.get("otherFields");
		List<String> entityList = map.get("entitys");
		List<String> realTokens = map.get("realTokens");
		log.info(realTokens);
		log.info(tableList);
		log.info(entityList);
		log.info(otherFields);

		List<Map<String, Object>> arrayMap = new LinkedList<Map<String, Object>>();
		if (tableList != null && otherFields == null) {
			Map<String, Object> map1 = TaxQueryMap.tableMap(tableList,
					realTokens);
			arrayMap.add(map1);
		} else if (tableList == null && otherFields != null) {
			Set<String> tableSet = new HashSet<String>();
			for (String str : otherFields) {
				String[] strs = str.split("[.]");
				tableSet.add(strs[0]);
			}
			List<String> otherTokens = otherTokens(realTokens, entityList);
			if (otherTokens != null) {
				// if realTokens contains not just entity's
				Map<String, Object> map1 = entityMap1(otherFields, entityList,
						otherTokens);
				arrayMap.add(map1);
			} else {
				Map<String, Object> map1 = TaxSchema.entityMap(tableSet,
						entityList);
				arrayMap.add(map1);
			}
		} else if (tableList != null && otherFields != null) {
			for (String str : otherFields) {
				String[] strs = str.split("[.]");
				tableList.add(strs[0]);
			}
			Set<String> tableSet = new HashSet<String>();
			for (String table : tableList)
				tableSet.add(table);
			List<String> otherTokens = otherTokens(realTokens, entityList);
			if (otherTokens != null) {
				Map<String, Object> map1 = entityMap1(otherFields, entityList,
						otherTokens);
				Map<String, Object> map2 = TaxQueryMap.tableMap(tableList,
						realTokens);
				arrayMap.add(map1);
				arrayMap.add(map2);
			} else {
				Map<String, Object> map2 = TaxSchema.entityMap(tableSet,
						entityList);
				arrayMap.add(map2);
			}
		} else {
			// this should never happened
			Assert.assertTrue(1 == 0);
		}
		arrayMap.add(TaxQueryMap.tableMap(TaxFinalVal.indexOne, tokenList));
		// check all tokens in 10 tables
		Map<String, Object> queryMap = SoulQueryUtil.createBooleanQueryMap(
				arrayMap, 1);
		Map<String, Object> tmpMap = new HashMap<String, Object>();
		if (greenFields != null)
			tmpMap.put("greenFields", greenFields);
		if (queryMap != null)
			tmpMap.put("queryMap", queryMap);
		return tmpMap;
	}

	private static List<String> otherTokens(List<String> realTokens,
			List<String> entityList) {
		List<String> otherTokens = new LinkedList<String>();
		for (String str : realTokens) {
			if (!entityList.contains(str))
				otherTokens.add(str);
		}
		if (otherTokens.size() > 0)
			return otherTokens;
		else {
			otherTokens = null; // clear memory
			return null;
		}

	}

	private static Map<String, List<String>> analyzeMap(
			Map<String, List<String>> resultMap, List<String> tokenList) {
		List<String> realTokens = new LinkedList<String>();
		List<String> tableList = new LinkedList<String>();
		// List<String> greenList = new LinkedList<String>();
		List<String> otherList = new LinkedList<String>();
		for (String str : tokenList) {
			if (resultMap.containsKey(str)) {
				List<String> fields = resultMap.get(str);
				for (String field : fields) {
					if (field.endsWith(".all")) {
						String[] strs = field.split("[.]");
						String tableName = strs[0];
						if (!tableList.contains(tableName))
							tableList.add(tableName);
					} else {
						if (!otherList.contains(field))
							otherList.add(field);
					}
				}
				continue;
			} else
				realTokens.add(str);
		}

		List<String> entitys = new LinkedList<String>();
		for (String str : realTokens) {
			if (StringUtil.isBlank(str))
				continue;
			if (TaxFinalVal.companyMap().get(str) != null)
				entitys.add(str);
			else if (TaxFinalVal.personMap().get(str) != null)
				entitys.add(str);
		}

		List<String> list1 = new LinkedList<String>();
		List<String> list2 = new LinkedList<String>();
		for (String str : otherList) {
			if (!list2.contains(str))
				list2.add(str);
			String[] strs = str.split("[.]");
			String tableName = strs[0];
			if (!tableList.contains(tableName))
				list1.add(str);
		}
		Map<String, List<String>> result = new HashMap<String, List<String>>();
		if (list1.size() > 0)
			result.put("otherFields", list1);
		if (list2.size() > 0)
			result.put("greenFields", list2);

		if (realTokens.size() > 0)
			result.put("realTokens", realTokens);
		if (entitys.size() > 0)
			result.put("entitys", entitys);

		if (tableList.size() > 0)
			result.put("tableList", tableList);
		return result;
	}

	private static Map<String, Object> entityMap1(List<String> otherFields,
			List<String> entitys, List<String> otherTokens) {
		Set<String> tables = new HashSet<String>();
		for (String field : otherFields) {
			String[] strs = field.split("[.]");
			String tableName = strs[0];
			tables.add(tableName);
		}
		Map<String, List<String>> fieldsMap = TaxFinalVal.fieldsMap();
		List<Map<String, Object>> array = new ArrayList<Map<String, Object>>();
		Map<String, Object> map2 = tableMap2(otherTokens, otherFields);
		for (String tableName : tables) {
			List<String> realFields = TaxQueryFields.realFieldList(tableName,
					fieldsMap);
			// log.info(entitys + "," + tableName + "," + otherTokens);
			List<Map<String, Object>> array1 = tableMapList(entitys,
					realFields, map2);
			array.addAll(array1);
		}
		return SoulQueryUtil.createBooleanQueryMap(array, 1);
	}

	private static Map<String, Object> tableMap2(List<String> otherTokens,
			List<String> otherFields) {
		List<Map<String, Object>> array = new ArrayList<Map<String, Object>>();
		for (String token : otherTokens) {
			for (String field : otherFields) {
				Map<String, Object> tmpMap = TaxQueryFields.eachToken(field,
						token);
				if (tmpMap != null)
					array.add(tmpMap);
			}
		}
		Map<String, Object> map = SoulQueryUtil.createBooleanQueryMap(array, 1);
		return map;
	}

	private static List<Map<String, Object>> tableMapList(List<String> entitys,
			List<String> realFields, Map<String, Object> map2) {
		List<Map<String, Object>> array = new ArrayList<Map<String, Object>>();
		for (String entity : entitys) {
			List<Map<String, Object>> array1 = new ArrayList<Map<String, Object>>();
			for (String realField : realFields) {
				Map<String, Object> tmpMap = TaxQueryFields.eachToken(
						realField, entity);
				if (tmpMap != null)
					array1.add(tmpMap);
			}
			Map<String, Object> map1 = SoulQueryUtil.createBooleanQueryMap(
					array1, 1);
			List<Map<String, Object>> array3 = new ArrayList<Map<String, Object>>();
			if (map1 != null)
				array3.add(map1);
			if (map2 != null)
				array3.add(map2);
			Map<String, Object> map3 = SoulQueryUtil.createBooleanQueryMap(
					array3, 2);
			if (map3 != null)
				array.add(map3);
		}
		return array;
	}
}
