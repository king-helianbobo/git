package com.elasticsearch.tax;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Assert;

import com.elasticsearch.query.SoulQueryUtil;

public class TaxQueryFields {
	private static final Log log = LogFactory.getLog(TaxQueryFields.class);

	public static Map<String, Object> eachToken(String realField, String token) {
		// need expand this token，realField is field in ES
		List<TaxPojo> pojoList = ESMapUtility.expandToken(token);
		if (pojoList.size() > 1) {
			List<Map<String, Object>> tmpArray = new ArrayList<Map<String, Object>>();
			for (TaxPojo pojo : pojoList) {
				Map<String, Object> tmpMap = eachTokenMap(realField, pojo);
				if (tmpMap != null)
					tmpArray.add(tmpMap);
			}
			if (tmpArray.size() == 0)
				return null;
			else if (tmpArray.size() == 1)
				return tmpArray.get(0);
			else {
				Map<String, Object> tmpMap = SoulQueryUtil
						.createBooleanQueryMap(tmpArray, 1);
				return tmpMap;
			}
		} else
			return eachTokenMap(realField, pojoList.get(0));
	}

	private static Map<String, Object> eachTokenMap(String realField,
			TaxPojo pojo) {
		Assert.assertEquals(true, realField.contains("."));
		String[] strs = realField.split("[.]");
		String tableName = strs[0];
		String field = strs[1];
		Map<String, Object> map1 = null;

		Map<String, List<String>> fieldsMap = TaxFinalVal.fieldsMap();
		List<String> integerFields = fieldsMap.get(tableName + "#integer");
		List<String> floatFields = fieldsMap.get(tableName + "#float");
		List<String> dateFields = fieldsMap.get(tableName + "#date");
		List<String> dateTimeFields = fieldsMap.get(tableName + "#datetime");
		List<String> chineseFields = fieldsMap.get(tableName + "#chinese");
		List<String> wordFields = fieldsMap.get(tableName + "#word");
		if (floatFields != null && floatFields.contains(field)) {
			if (pojo.getType().equals("float")) {
				map1 = SoulQueryUtil.termQueryMap(realField, pojo.getName());
			} else if (pojo.getType().equals("range")) {
				map1 = rangeQueryMap(realField, pojo.getName());
			}
		} else if (integerFields != null && integerFields.contains(field)) {
			if (pojo.getType().equals("integer")) {
				map1 = SoulQueryUtil.termQueryMap(realField, pojo.getName());
			} else if (pojo.getType().equals("range")) {
				map1 = rangeQueryMap(realField, pojo.getName());
			}
		} else if (dateFields != null && dateFields.contains(field)) {
			if (pojo.getType().equals("date")) {
				map1 = SoulQueryUtil.termQueryMap(realField, pojo.getName());
			}
		} else if (dateTimeFields != null && dateTimeFields.contains(field)) {
			if (pojo.getType().equals("date")) {
				map1 = SoulQueryUtil.termQueryMap(realField, pojo.getName());
			}
		} else if (chineseFields != null && chineseFields.contains(field)) {
			if (pojo.getType().equals("word")) {
				map1 = SoulQueryUtil.termQueryMap(realField, pojo.getName());
			}
		} else if (wordFields != null && wordFields.contains(field)) {
			if (pojo.getType().equals("word")) {
				map1 = SoulQueryUtil.termQueryMap(realField, pojo.getName());
			}
		} else {
			Assert.assertEquals(1, 0);
			// this should never happened
		}
		return map1;
	}

	static Map<String, Object> rangeQueryMap(String field, String token) {
		String[] strs = token.split("\t");
		String start = strs[0];
		String end = strs[1];
		Map<String, Object> tmp1 = new HashMap<String, Object>();
		Map<String, Object> tmp2 = new HashMap<String, Object>();
		Map<String, Object> tmp3 = new HashMap<String, Object>();
		tmp1.put("gte", start);
		tmp1.put("lte", end);
		tmp2.put(field, tmp1);
		tmp3.put("range", tmp2);
		return tmp3;
	}

	static public List<String> expectedList(String tableName,
			String expectedFieldType) {
		List<String> fieldList = new LinkedList<String>();
		Map<String, Object> tableDefMap = TaxFinalVal.defMap().get(tableName);
		if (tableDefMap != null) {
			for (String field : tableDefMap.keySet()) {
				@SuppressWarnings("unchecked")
				Map<String, String> tmp = (Map<String, String>) tableDefMap
						.get(field);
				String type = tmp.get("dataType");
				if (type.equals(expectedFieldType))
					fieldList.add(field);
			}
		}
		if (fieldList.size() > 0)
			return fieldList;
		else
			return null;
	}

	public static List<String> realFieldList(String tableName,
			Map<String, List<String>> fieldsMap) {
		List<String> realFields = new LinkedList<String>();
		List<String> fields = fieldList(tableName, fieldsMap);
		for (String field : fields)
			realFields.add(tableName + "." + field);
		return realFields;
	}

	private static List<String> fieldList(String tableName,
			Map<String, List<String>> fieldsMap) {
		List<String> fields = new LinkedList<String>();
		List<String> integerFields = fieldsMap.get(tableName + "#integer");
		List<String> floatFields = fieldsMap.get(tableName + "#float");
		List<String> dateFields = fieldsMap.get(tableName + "#date");
		List<String> dateTimeFields = fieldsMap.get(tableName + "#datetime");
		List<String> chineseFields = fieldsMap.get(tableName + "#chinese");
		List<String> wordFields = fieldsMap.get(tableName + "#word");
		int number = 0;
		if (integerFields != null) {
			number += integerFields.size();
			fields.addAll(integerFields);
		}
		if (floatFields != null) {
			number += floatFields.size();
			fields.addAll(floatFields);
		}
		if (dateFields != null) {
			number += dateFields.size();
			fields.addAll(dateFields);
		}
		if (dateTimeFields != null) {
			number += dateTimeFields.size();
			fields.addAll(dateTimeFields);
		}
		if (chineseFields != null) {
			number += chineseFields.size();
			fields.addAll(chineseFields);
		}
		if (wordFields != null) {
			number += wordFields.size();
			fields.addAll(wordFields);
		}
		Assert.assertEquals(number, fields.size());
		return fields;
	}

}
