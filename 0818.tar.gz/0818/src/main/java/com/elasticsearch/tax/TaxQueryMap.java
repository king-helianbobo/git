package com.elasticsearch.tax;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import com.elasticsearch.query.SoulQueryUtil;
import com.splitword.soul.utility.StringUtil;

public class TaxQueryMap {

	private static final Log log = LogFactory.getLog(TaxQueryMap.class);
	private static ObjectMapper mapper = new ObjectMapper();

	// query all tables belong to this index
	public static Map<String, Object> tableMap(String indexName,
			List<String> tokenList) {
		List<String> tables = TaxFinalVal.indexTypeMap().get(indexName);
		Set<String> tableSet = new TreeSet<String>();
		for (String str : tables)
			tableSet.add(str);
		return tableMap(tableSet, tokenList);
	}

	// query all tables belong to this index
	public static Map<String, Object> tableMap(List<String> tables,
			List<String> tokenList) {
		Set<String> tableSet = new TreeSet<String>();
		for (String str : tables)
			tableSet.add(str);
		return tableMap(tableSet, tokenList);
	}

	// query tokens in table set
	public static Map<String, Object> tableMap(Set<String> tables,
			List<String> tokenList) {
		Map<String, List<String>> fieldsMap = TaxFinalVal.fieldsMap();
		List<Map<String, Object>> lastArray = new ArrayList<Map<String, Object>>();
		for (String tableName : tables) { // for each table
			List<Map<String, Object>> arrayForEachTable = new ArrayList<Map<String, Object>>();
			// for each table ,first get all real fields
			List<String> realFields = TaxQueryFields.realFieldList(tableName,
					fieldsMap);
			// log.info(realFields);
			for (String token : tokenList) {
				List<Map<String, Object>> array = new ArrayList<Map<String, Object>>();
				for (String realField : realFields) {
					// log.info(token + "," + realField);
					Map<String, Object> tmpMap = TaxQueryFields.eachToken(
							realField, token);
					if (tmpMap != null)
						array.add(tmpMap);
				}
				Map<String, Object> map1 = SoulQueryUtil.createBooleanQueryMap(
						array, 1);
				if (map1 != null)
					arrayForEachTable.add(map1);
			}
			// must satisfy all, else not match
			Map<String, Object> mapHaha = SoulQueryUtil.createBooleanQueryMap(
					arrayForEachTable, arrayForEachTable.size());
			Map<String, Object> mapForThisTable = TaxQueryUtil
					.queryMapWithFilter(mapHaha, tableName);
			lastArray.add(mapForThisTable);
		}
		Map<String, Object> lastMap = SoulQueryUtil.createBooleanQueryMap(
				lastArray, 1);
		return lastMap;
	}

	public static boolean existEntity(Map<String, List<String>> resultMap,
			List<String> tokenList) {
		List<String> realTokens = new LinkedList<String>();
		Set<String> tables = new HashSet<String>();
		for (String str : tokenList) {
			if (resultMap.containsKey(str)) {
				List<String> fields = resultMap.get(str);
				for (String field : fields) {
					String[] strs = field.split("[.]");
					tables.add(strs[0]);
				}
				continue;
			} else
				realTokens.add(str);
		}

		for (String str : realTokens) {
			if (StringUtil.isBlank(str))
				continue;
			if (TaxFinalVal.companyMap().get(str) != null)
				return true;
			else if (TaxFinalVal.personMap().get(str) != null)
				return true;
		}
		return false;
	}

	public static String convertToJson(Map<String, Object> map1) {
		try {
			String value = mapper.writeValueAsString(map1);
			// log.info(value);
			return value;
		} catch (JsonGenerationException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

}
