package com.elasticsearch.client;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.JsonParser;

import com.elasticsearch.keyword.TokenFreqMap;
import com.elasticsearch.query.DoubleTermQuery;
import com.elasticsearch.query.FiveTermQuery;
import com.elasticsearch.query.FourTermQuery;
import com.elasticsearch.query.SingleTermQuery;
import com.elasticsearch.query.SoulQueryUtil;
import com.elasticsearch.query.ThreeTermQuery;
//import java.util.HashMap;

public class SoulHttpClient extends BaseHttpClient {
	private static final Log log = LogFactory.getLog(SoulHttpClient.class);

	public SoulHttpClient(String url, String index, String type) {
		super(url, index, type);
	}

	@SuppressWarnings("unchecked")
	public String soulSearch(String queryStr, int from, int size, String tagType)
			throws IOException {
		String tag = tagType;
		log.info(queryStr + "," + from + "," + size + "," + tagType);
		if (tag.equals("first")) {
			String[] tags = { "tag1", "tag2", "tag3", "tag4", "tag5", "tag6",
					"tag7" };
			Map<String, String> header = new LinkedHashMap<String, String>();
			header.put("index", index);
			header.put("type", type);
			String headerJson = mapper.writeValueAsString(header);
			StringBuilder builder = new StringBuilder();
			for (String tagKey : tags) {
				Map<String, Object> queryMap = complexQueryMap(queryStr, from,
						size, tagKey, false);
				Map<String, Object> scriptMap = SoulQueryUtil.scriptQueryMap(
						queryMap, from, size);
				String body = mapper.writeValueAsString(scriptMap);
				builder.append(headerJson + "\n");
				builder.append(body + "\n");
			}
			String url = index + "/" + type + "/_msearch?pretty=true";
			Map<String, Object> esMaps = postQuery
					.post(url, builder.toString());

			Map<String, Object> resultMap = new LinkedHashMap<String, Object>();
			List<Map<String, Object>> resultList = (List<Map<String, Object>>) esMaps
					.get("responses");
			for (int i = 0; i < resultList.size(); i++) {
				Map<String, Object> eachMap = resultList.get(i);
				String tagKey = tags[i];
				String jsonValue = SoulQueryUtil.constructJsonResult(eachMap,
						from);
				JsonParser jsonParser = mapper.getJsonFactory()
						.createJsonParser(jsonValue);
				Map<String, Object> map = mapper.readValue(jsonParser,
						Map.class);
				Integer totalSize = (Integer) map.get("count");
				if (totalSize > 0)
					resultMap.put(tagKey, map);
			}
			if (TokenFreqMap.isLeader(queryStr)) {
				Map<String, String> leaderInfo = TokenFreqMap
						.leaderInfo(queryStr);
				if (leaderInfo != null && !leaderInfo.isEmpty())
					resultMap.put("tag8", leaderInfo);
			}
			String result = mapper.writeValueAsString(resultMap);
			log.info(result);
			return result;
		} else
			return complexQuerySearch(queryStr, from, size, tagType);
	}

	private String complexQuerySearch(String queryStr, int from, int size,
			String tagType) {
		boolean bTraditional = false;
		StringBuilder builder = new StringBuilder();
		builder.append(index + "/" + type + "/_search?pretty=true");
		Map<String, Object> queryMap = null;
		if (tagType.equals("tag7"))
			queryMap = complexQueryMap(queryStr, from, size, tagType, true);
		else
			queryMap = complexQueryMap(queryStr, from, size, tagType, false);

		String json = SoulQueryUtil.scriptQueryJson(queryMap, from, size);
		if (!bTraditional)
			builder.append("&routing=" + tagType
					+ "&search_type=query_and_fetch");
		String url = builder.toString();
		// log.info(json);
		// log.info(url);
		Map<String, Object> map = postQuery.post(url, json);
		return SoulQueryUtil.constructJsonResult(map, from);
	}

	private Map<String, Object> complexQueryMap(String queryStr, int from,
			int size, String tagType, boolean bOnlyTitle) {
		List<Map<String, Object>> primeTokens = primeTokenList(queryStr);
		Map<Integer, List<Map<String, Object>>> tokens = secondTokenList(primeTokens);
		if (tokens == null || tokens.isEmpty())
			return null;
		Map<String, Object> queryMap = null;
		if (tokens.size() == 1) { // single word
			SingleTermQuery singleQuery = new SingleTermQuery(tokens);
			List<Map<String, Object>> array = singleQuery.pageQuery(bOnlyTitle);
			queryMap = SoulQueryUtil.createBooleanQueryMap(array, 1, tagType);
		} else if (tokens.size() == 2) {
			DoubleTermQuery twotermQuery = new DoubleTermQuery(tokens);
			List<Map<String, Object>> array1 = twotermQuery
					.pageQuery(bOnlyTitle);
			queryMap = SoulQueryUtil.createBooleanQueryMap(array1, 1, tagType);
		} else if (tokens.size() == 3) {
			ThreeTermQuery threeTermQuery = new ThreeTermQuery(tokens);
			List<Map<String, Object>> array1 = threeTermQuery
					.pageQuery(bOnlyTitle);
			queryMap = SoulQueryUtil.createBooleanQueryMap(array1, 1, tagType);
		} else if (tokens.size() == 4) {
			FourTermQuery fourTermQuery = new FourTermQuery(tokens);
			List<Map<String, Object>> array1 = fourTermQuery
					.pageQuery(bOnlyTitle);
			queryMap = SoulQueryUtil.createBooleanQueryMap(array1, 1, tagType);
		} else if (tokens.size() > 4) {
			FiveTermQuery longTermQuery = new FiveTermQuery(tokens);
			List<Map<String, Object>> array1 = longTermQuery
					.pageQuery(bOnlyTitle);
			queryMap = SoulQueryUtil.createBooleanQueryMap(array1, 1, tagType);
		}
		return queryMap;
	}

}
