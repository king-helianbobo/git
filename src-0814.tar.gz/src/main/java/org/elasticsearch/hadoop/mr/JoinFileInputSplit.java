package org.elasticsearch.hadoop.mr;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;

public class JoinFileInputSplit extends FileSplit {

	private long anotherStart;
	private long anotherLen;
	private int currentSeq;
	private int anotherSeq;
	private int totalLines;

	JoinFileInputSplit() {
	}

	public JoinFileInputSplit(Path file, long start, long length,
			String[] hosts, int totalLines) {
		super(file, start, length, hosts);
		this.totalLines = totalLines;
	}

	public JoinFileInputSplit(Path file, long start, long length,
			String[] hosts, int currentNum, int anotherNum, long anotherStart,
			long anotherLen, int totalLines) {
		super(file, start, length, hosts);

		this.currentSeq = currentNum;
		this.anotherSeq = anotherNum;
		this.anotherStart = anotherStart;
		this.anotherLen = anotherLen;
		this.totalLines = totalLines;
	}

	public int getCurrentSeq() {
		return currentSeq;
	}

	public int getAnotherSeq() {
		return anotherSeq;
	}

	/** The file containing this split's data. */
	public Path getPath() {
		return super.getPath();
	}

	/** The position of the first byte in the file to process. */
	public long getStart() {
		return super.getStart();
	}

	/** The number of bytes in the file to process. */
	@Override
	public long getLength() {
		return super.getLength();
	}

	@Override
	public String toString() {
		return super.getPath() + ":" + super.getStart() + "+"
				+ super.getLength();
	}

	public long getAnotherStart() {
		return anotherStart;
	}

	public long getAnotherLen() {
		return anotherLen;
	}

	public int getTotalLines() {
		return totalLines;
	}

	@Override
	public void write(DataOutput out) throws IOException {
		super.write(out);
		out.writeInt(currentSeq);
		out.writeInt(anotherSeq);
		out.writeInt(totalLines);
		out.writeLong(anotherStart);
		out.writeLong(anotherLen);
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		super.readFields(in);
		currentSeq = in.readInt();
		anotherSeq = in.readInt();
		totalLines = in.readInt();
		anotherStart = in.readLong();
		anotherLen = in.readLong();
	}

	@Override
	public String[] getLocations() throws IOException {
		return super.getLocations();
	}
}
