/*
 * Copyright 2013 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.elasticsearch.hadoop.serailize;

import java.io.Closeable;

public interface Parser extends Closeable {
	enum Token {
		START_OBJECT {
			@Override
			public boolean isValue() {
				return false;
			}
		},

		END_OBJECT {
			@Override
			public boolean isValue() {
				return false;
			}
		},

		START_ARRAY {
			@Override
			public boolean isValue() {
				return false;
			}
		},

		END_ARRAY {
			@Override
			public boolean isValue() {
				return false;
			}
		},

		FIELD_NAME {
			@Override
			public boolean isValue() {
				return false;
			}
		},

		VALUE_STRING {
			@Override
			public boolean isValue() {
				return true;
			}
		},

		VALUE_NUMBER {
			@Override
			public boolean isValue() {
				return true;
			}
		},

		VALUE_BOOLEAN {
			@Override
			public boolean isValue() {
				return true;
			}
		},

		// usually a binary value
		VALUE_EMBEDDED_OBJECT {
			@Override
			public boolean isValue() {
				return true;
			}
		},

		VALUE_NULL {
			@Override
			public boolean isValue() {
				return true;
			}
		};

		public abstract boolean isValue();
	}

	enum NumberType {
		INT, LONG, FLOAT, DOUBLE, BIG_INTEGER, BIG_DECIMAL
	}

	Token currentToken();

	Token nextToken();

	void skipChildren();

	String currentName();

	String text();

	byte[] bytes();

	Number numberValue();

	NumberType numberType();

	short shortValue();

	int intValue();

	long longValue();

	float floatValue();

	double doubleValue();

	boolean booleanValue();

	byte[] binaryValue();

	void close();
}