package com.elasticsearch.tax;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.elasticsearch.common.joda.FormatDateTimeFormatter;
import org.elasticsearch.common.joda.Joda;
import org.elasticsearch.common.joda.time.DateTime;
import org.elasticsearch.common.joda.time.format.DateTimeFormat;
import org.elasticsearch.common.joda.time.format.DateTimeFormatter;

import com.elasticsearch.query.SoulQueryUtil;
import com.splitword.lionsoul.jcseg.util.ChineseHelper;
import com.splitword.soul.utility.StringUtil;

public class ESMapUtility {
	private final static Log log = LogFactory.getLog(ESMapUtility.class);

	public static Map<String, Object> settingMap() {
		Map<String, Object> tmp1 = new LinkedHashMap<String, Object>();
		tmp1.put("refresh_interval", 2);
		tmp1.put("number_of_replicas", 1);
		Map<String, Object> tmp2 = new LinkedHashMap<String, Object>();
		tmp2.put("index", tmp1);
		return tmp2;
	}

	public static Map<String, Object> settingMap2() {
		Map<String, Object> tmp1 = new LinkedHashMap<String, Object>();
		tmp1.put("index.refresh_interval", 2);
		tmp1.put("index.number_of_replicas", 1);
		tmp1.put("index.store.type", "memory");
		return tmp1;
	}

	public static Map<String, Object> untouchedMap(String fieldName,
			String analyzer) {
		Map<String, Object> tmp1 = new LinkedHashMap<String, Object>();
		tmp1.put("type", "string");
		tmp1.put("index_analyzer", analyzer);

		Map<String, Object> tmp2 = new LinkedHashMap<String, Object>();
		tmp2.put("type", "string");
		tmp2.put("index", "not_analyzed");

		Map<String, Object> second = new LinkedHashMap<String, Object>();
		second.put(fieldName, tmp1);
		second.put("untouched", tmp2);

		Map<String, Object> first = new LinkedHashMap<String, Object>();
		first.put("type", "multi_field");
		first.put("fields", second);
		return first;
	}

	public static boolean isFloat(String value) {
		if (StringUtil.isBlank(value)) {
			return false;
		}
		Float number = null;
		try {
			number = Float.parseFloat(value);
		} catch (NumberFormatException e) {
			return false;
		}
		if (!value.contains(".")) {
			return false;
		} else if (value.startsWith("0.")) {
			return true;
		} else if (value.startsWith("0"))
			return false;
		else
			return true;
	}

	public static boolean isInteger(String value) {
		if (StringUtil.isBlank(value)) {
			return false;
		}
		Integer number = null;
		try {
			number = Integer.parseInt(value);
		} catch (NumberFormatException e) {
			return false;
		}
		if (String.valueOf(number).equals(value))
			return true;
		else
			return false;
	}

	public static boolean isLong(String value) {
		if (StringUtil.isBlank(value)) {
			return false;
		}
		Long number = null;
		try {
			number = Long.parseLong(value);
		} catch (NumberFormatException e) {
			return false;
		}
		if (String.valueOf(number).equals(value))
			return true;
		else
			return false;
	}

	public static String convertDate1(String token) {
		String date = null;
		FormatDateTimeFormatter formatter = Joda
				.forPattern("yyyy-MM-dd||yyyyMMdd||yyyy.MM.dd || yyyy/MM/dd");
		DateTimeFormatter outputFormat = DateTimeFormat
				.forPattern("yyyy-MM-dd");
		try {
			DateTime dt = formatter.parser().parseDateTime(token);
			date = dt.toString(outputFormat);
			// log.info(token + "," + date);
			return date;
		} catch (IllegalArgumentException e) {
			return null;
		}
	}

	public static String convertDate2(String token) {
		String date = null;
		FormatDateTimeFormatter formatter = Joda
				.forPattern("yyyy-MM||yyyyMM||yyyy.MM|| yyyy/MM");
		DateTimeFormatter outputFormat = DateTimeFormat.forPattern("yyyy-MM");
		try {
			DateTime dt = formatter.parser().parseDateTime(token);
			date = dt.toString(outputFormat);
			// log.info(token + "," + date);
			return date;
		} catch (IllegalArgumentException e) {
			return null;
		}
	}

	public static boolean isDateTime(String token) {
		FormatDateTimeFormatter formatter = Joda
				.forPattern("yyyy-MM-dd HH:mm:ss");
		try {
			DateTime dt = formatter.parser().parseDateTime(token);
			return true;
		} catch (IllegalArgumentException e) {
			return false;
		}
	}

	public static List<TaxPojo> expandToken(String token) {
		List<TaxPojo> result = new LinkedList<TaxPojo>();
		TaxPojo wordPojo = new TaxPojo(token, "word");
		result.add(wordPojo);
		if (isInteger(token)) {
			int value = Integer.valueOf(token);
			if (value >= 1990 && value <= 2100) {
				TaxPojo datePojo = new TaxPojo(token, "date");
				result.add(datePojo);
			}
			String floatToken = token + ".0";
			TaxPojo floatPojo = new TaxPojo(floatToken, "float");
			TaxPojo intPojo = new TaxPojo(token, "integer");
			result.add(floatPojo);
			result.add(intPojo);
			String date = convertDate1(token);
			if (date != null) {
				TaxPojo datePojo = new TaxPojo(date, "date");
				result.add(datePojo);
			} else if ((date = convertDate2(token)) != null) {
				TaxPojo datePojo = new TaxPojo(date, "date");
				result.add(datePojo);
			}
		} else if (isFloat(token)) {
			String date = convertDate2(token);
			if (date != null) {
				TaxPojo datePojo = new TaxPojo(date, "date");
				result.add(datePojo);
			}
			String floatToken = convertFloat(token);
			TaxPojo floatPojo = new TaxPojo(floatToken, "float");
			result.add(floatPojo);
		} else if (TaxFinalVal.companyMap().get(token) != null) {
			List<String> synonymList = TaxFinalVal.companyMap().get(token);
			for (String str : synonymList) {
				TaxPojo pojo1 = new TaxPojo(str, "word");
				result.add(pojo1);
			}
		} else if (TaxFinalVal.personMap().get(token) != null) {
			// name need to expand, identify number should not
			if (!ChineseHelper.containChineseChar(token)) {
				// do nothing
			} else {
				List<String> synonymList = TaxFinalVal.personMap().get(token);
				for (String str : synonymList) {
					TaxPojo pojo1 = new TaxPojo(str, "word");
					result.add(pojo1);
				}
			}
		} else {
			String date = convertDate1(token);
			if (date != null) {
				TaxPojo pojo = new TaxPojo(date, "date");
				result.add(pojo);
			} else if ((date = convertDate2(token)) != null) {
				TaxPojo pojo2 = new TaxPojo(date, "date");
				result.add(pojo2);
			}
			String range = convertRange(token);
			if (range != null) {
				TaxPojo pojo = new TaxPojo(range, "range");
				result.add(pojo);
			}

		}
		return result;
	}

	public static String convertRange(String token) {
		String splitTag = "~";
		if (!isRange(token, splitTag))
			return null;
		else {
			StringBuilder builder = new StringBuilder();
			String[] tokens = token.split(splitTag);
			// only accept ""~"
			String start = tokens[0];
			String end = tokens[1];
			float a = Float.valueOf(start);
			float b = Float.valueOf(end);
			if (a < b)
				builder.append(start + "\t" + end);
			else
				builder.append(end + "\t" + start);
			return builder.toString();
		}
	}

	private static boolean isRange(String token, String splitTag) {
		String[] tokens = token.split(splitTag);
		if (tokens.length == 2) {
			String start = tokens[0];
			String end = tokens[1];
			boolean value1 = (ESMapUtility.isFloat(start) || ESMapUtility
					.isInteger(start));
			boolean value2 = (ESMapUtility.isFloat(end) || ESMapUtility
					.isInteger(end));
			if (value1 && value2)
				return true;
			else
				return false;
		} else
			return false;
	}

	public static String convertFloat(String token) {
		if (isFloat(token)) {
			String[] strs = token.split("[.]");
			String firstPart = strs[0];
			String secondPart = strs[1];
			int i = secondPart.length() - 1;
			for (; i >= 0; i--) {
				char c = secondPart.charAt(i);
				if (c != '0')
					break;
			}
			if (i < 0) { // 小数点后的数全是0
				return firstPart + ".0";
			} else {
				String str = firstPart + "." + secondPart.substring(0, i + 1);
				return str;
			}
		} else
			return token;
	}

	public static String colorSourceString(String sourceStr,
			List<TaxPojo> pojoList, String color) {
		String preTag = SoulQueryUtil.preTag;
		String postTag = SoulQueryUtil.postTag;
		if (color.equals("green")) {
			preTag = SoulQueryUtil.greenPreTag;
			postTag = SoulQueryUtil.greenPostTag;
		}
		StringBuilder builder = new StringBuilder();
		String convertedStr = convertFloat(sourceStr);

		for (TaxPojo pojo : pojoList) {
			String name = pojo.getName();
			if (convertedStr.equalsIgnoreCase(name)) {
				builder.append(preTag + sourceStr + postTag);
				return builder.toString();
			} else if (pojo.getType().equals("date")) {
				int index1 = sourceStr.indexOf(name);
				log.info(sourceStr + "," + name);
				if (index1 >= 0) {
					int index2 = index1 + name.length();
					String str = sourceStr.substring(index1, index2);
					builder.append(sourceStr.substring(0, index1));
					builder.append(preTag + str + postTag);
					builder.append(sourceStr.substring(index2));
					return builder.toString();
				} else
					continue; // fix one bug
				// return sourceStr;
			} else if (pojo.getType().equals("range")) {
				String[] tokens = name.split("\\s+");
				float a = Float.valueOf(tokens[0]);
				float b = Float.valueOf(tokens[1]);
				if (ESMapUtility.isFloat(convertedStr)
						|| ESMapUtility.isInteger(convertedStr)) {
					float c = Float.valueOf(convertedStr);
					if (c >= a && c <= b) {
						builder.append(preTag + sourceStr + postTag);
						return builder.toString();
					}
				}
			}
		}
		return sourceStr; // no need to highlight
	}
}
