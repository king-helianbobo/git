package com.elasticsearch.tax;

import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import com.elasticsearch.query.SoulQueryUtil;

public class NewTaxUtil {
	private static ObjectMapper mapper = new ObjectMapper();
	private static final Log log = LogFactory.getLog(NewTaxUtil.class);

	public static List<String> fieldList(Map<String, Object> map1) {
		List<String> list = new LinkedList<String>();
		for (String key : map1.keySet())
			list.add(key);
		return list;
	}

	public static String convertToJson(Map<String, Object> map1) {
		try {
			String value = mapper.writeValueAsString(map1);
			// log.info(value);
			return value;
		} catch (JsonGenerationException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	// public static String convertToJson(Map<String, String> map1) {
	// try {
	// String value = mapper.writeValueAsString(map1);
	// // log.info(value);
	// return value;
	// } catch (JsonGenerationException e) {
	// e.printStackTrace();
	// } catch (JsonMappingException e) {
	// e.printStackTrace();
	// } catch (IOException e) {
	// e.printStackTrace();
	// }
	// return null;
	// }

	public static Map<String, Object> specialFieldMap(
			Map<String, List<String>> schemaMap, List<String> tokenList) {
		// entity not exist, just schema map
		Map<String, List<String>> map = TaxSchema.greenFields(schemaMap,
				tokenList);
		List<String> greenFields = map.get("otherFields");
		List<Map<String, Object>> array = tmpSchemaArray(map, tokenList);
		Map<String, Object> map2 = TaxQueryMap.tableMap(TaxFinalVal.indexOne,
				tokenList);
		if (map2 != null)
			array.add(map2);
		Map<String, Object> queryMap = SoulQueryUtil.createBooleanQueryMap(
				array, 1);
		Map<String, Object> tmpMap = new HashMap<String, Object>();
		if (greenFields != null)
			tmpMap.put("greenFields", greenFields);
		if (queryMap != null)
			tmpMap.put("queryMap", queryMap);
		return tmpMap;
	}

	private static List<Map<String, Object>> tmpSchemaArray(
			Map<String, List<String>> map, List<String> tokenList) {
		List<Map<String, Object>> arrayMap = new LinkedList<Map<String, Object>>();
		List<String> realTokens = map.get("realTokens");
		List<String> tables = map.get("tableList");
		List<String> otherFields = map.get("otherFields");
		if (realTokens == null)
			// if real tokens not exist
			return arrayMap;
		if (tables != null) {
			Map<String, Object> tjMap = TaxQueryMap
					.tableMap(tables, realTokens);
			if (tjMap != null)
				arrayMap.add(tjMap);
		}
		if (otherFields != null) {
			for (String token : realTokens) {
				for (String field : otherFields) {
					Map<String, Object> tjMap = TaxQueryFields.eachToken(field,
							token);
					if (tjMap != null)
						arrayMap.add(tjMap);
				}
			}
		}
		return arrayMap;
	}

	private static Map<String, List<Map<String, Object>>> convertMap(
			Map<String, List<Map<String, Object>>> map1,
			Map<String, List<String>> fieldsMap) {
		Map<String, List<Map<String, Object>>> pageMap = new LinkedHashMap<String, List<Map<String, Object>>>();
		for (String tableName : map1.keySet()) {
			List<Map<String, Object>> mapList = map1.get(tableName);
			List<String> fieldList = fieldsMap.get(tableName);
			for (int i = 0; i < mapList.size(); i++) {
				Map<String, Object> currentMap = mapList.get(i);
				Map<String, Object> anotherMap = new LinkedHashMap<String, Object>();
				for (String field : fieldList) {
					String value = (String) currentMap.get(field);
					if (value == null)
						anotherMap.put(field, " ");
					else
						anotherMap.put(field, value);
				}
				List<Map<String, Object>> mapList1 = pageMap.get(tableName);
				if (mapList1 == null)
					mapList1 = new LinkedList<Map<String, Object>>();
				mapList1.add(anotherMap);
				pageMap.put(tableName, mapList1);
			}
		}
		return pageMap;
	}

	private static Map<String, Object> toJsonMap(Map<String, Object> resultMap,
			Map<String, List<Map<String, Object>>> pageMap, int from, int size) {
		Map<String, Object> result = new LinkedHashMap<String, Object>();
		int totalSize = (Integer) resultMap.get("total");
		result.put("from", from);
		result.put("size", size);
		result.put("count", totalSize);
		result.put("tableSize", pageMap.size());
		List<String> tables = new LinkedList<String>();
		for (String tableName : pageMap.keySet()) {
			tables.add(tableName);
		}
		result.put("tables", tables);
		int i = 1;
		for (String tableName : pageMap.keySet()) {
			String key = "pageList" + String.valueOf(i++);
			result.put(key, pageMap.get(tableName));
		}
		return result;
	}

	private static Map<String, List<String>> getAllFields(
			Map<String, List<Map<String, Object>>> lastMap) {
		Map<String, List<String>> fieldsMap = new LinkedHashMap<String, List<String>>();
		for (String tableName : lastMap.keySet()) {
			List<Map<String, Object>> mapList = lastMap.get(tableName);
			for (int i = 0; i < mapList.size(); i++) {
				List<String> oldList = fieldsMap.get(tableName);
				List<String> newList = NewTaxUtil.fieldList(mapList.get(i));
				if (oldList == null) {
					log.info(tableName + "," + newList);
					fieldsMap.put(tableName, newList);
				} else { // merge two list,but keep frequent field ahead
					List<String> common = new LinkedList<String>();
					List<String> mergeList = new LinkedList<String>();
					log.info(oldList);
					log.info(newList);
					for (String str : oldList) {
						if (newList.contains(str))
							common.add(str);
					}
					mergeList.addAll(common);
					oldList.addAll(newList);
					for (String str : oldList) {
						if (!mergeList.contains(str))
							mergeList.add(str);
					}
					fieldsMap.put(tableName, mergeList);
				}
			}
		}
		return fieldsMap;
	}

	// @SuppressWarnings("unchecked")
	// public static Map<String, Object> entityListMap(
	// Map<String, Object> tmpResultMap, List<TaxPojo> pojoList,
	// List<String> greenFields, int from, String mode) {
	// Map<String, Object> resultMap = (Map<String, Object>) tmpResultMap
	// .get("hits");
	// if (resultMap == null)
	// return null;
	// List<Map<String, Object>> hits = (List<Map<String, Object>>) resultMap
	// .get("hits");
	// Map<String, List<Map<String, String>>> lastMap = new
	// LinkedHashMap<String, List<Map<String, String>>>();
	// for (int i = 0; i < hits.size(); i++) {
	// Map<String, Object> map1 = hits.get(i);
	// String json = NewTaxUtil.convertToJson(map1);
	// Map<String, String> checkedMap = TaxQueryMap.specialMap(map1,
	// pojoList, greenFields, mode);
	// String tableName = (String) checkedMap.get("tableName");
	// List<Map<String, String>> array = lastMap.get(tableName);
	// if (array == null)
	// array = new LinkedList<Map<String, String>>();
	// checkedMap.remove("tableName");
	// array.add(checkedMap);
	// lastMap.put(tableName, array);
	// }
	// Map<String, List<String>> fieldsMap = getAllFields(lastMap);
	// Map<String, List<Map<String, Object>>> pageMap = convertMap(lastMap,
	// fieldsMap);
	// return toJsonMap(resultMap, pageMap, from, hits.size());
	// }

	@SuppressWarnings("unchecked")
	public static Map<String, Object> pageListMap(
			Map<String, Object> tmpResultMap, List<TaxPojo> pojoList,
			List<String> greenFields, int from, String mode) {
		Map<String, Object> resultMap = (Map<String, Object>) tmpResultMap
				.get("hits");
		if (resultMap == null)
			return null;
		List<Map<String, Object>> hits = (List<Map<String, Object>>) resultMap
				.get("hits");
		Map<String, List<Map<String, Object>>> lastMap = new LinkedHashMap<String, List<Map<String, Object>>>();
		for (int i = 0; i < hits.size(); i++) {
			Map<String, Object> map1 = hits.get(i);
			String json = NewTaxUtil.convertToJson(map1);
			Map<String, Object> checkedMap = TaxQueryMap.checkMap(map1,
					pojoList, greenFields, mode);
			String json1 = NewTaxUtil.convertToJson(checkedMap);
			log.info(json1);
			String tableName = (String) checkedMap.get("tableName");
			List<Map<String, Object>> array = lastMap.get(tableName);
			if (array == null)
				array = new LinkedList<Map<String, Object>>();
			checkedMap.remove("tableName");
			array.add(checkedMap);
			lastMap.put(tableName, array);
		}
		Map<String, List<String>> fieldsMap = getAllFields(lastMap);
		Map<String, List<Map<String, Object>>> pageMap = convertMap(lastMap,
				fieldsMap);
		return toJsonMap(resultMap, pageMap, from, hits.size());
	}
}
