package com.elasticsearch.tax;

import java.io.Closeable;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.httpclient.HostConfiguration;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.URI;
import org.apache.commons.httpclient.params.HttpClientParams;
import org.apache.commons.httpclient.params.HttpConnectionManagerParams;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import com.elasticsearch.query.PostQuery;
import com.elasticsearch.query.SoulQueryUtil;

public class TaxHttpClient implements Closeable {

	protected String url = null;
	private static ObjectMapper mapper = new ObjectMapper();
	protected PostQuery postQuery = null;
	private static final Log log = LogFactory.getLog(TaxHttpClient.class);

	public TaxHttpClient(String url) {
		HttpClientParams params = new HttpClientParams();
		params.setConnectionManagerTimeout(20 * 1000);
		HttpClient client = new HttpClient(params);
		HostConfiguration hostConfig = new HostConfiguration();
		this.url = url;
		try {
			hostConfig.setHost(new URI(this.url, false));
		} catch (IOException ex) {
			throw new IllegalArgumentException("Invalid target URI " + url, ex);
		}
		client.setHostConfiguration(hostConfig);
		HttpConnectionManagerParams connectionParams = client
				.getHttpConnectionManager().getParams();
		// make sure to disable Nagle's protocol
		connectionParams.setTcpNoDelay(true);
		this.postQuery = new PostQuery(client);
	}

	protected List<Map<String, Object>> primeTokenList(String indexName,
			String queryStr, String analyzer) {
		// String query = indexName + "/_analyze?analyzer=tax_query&pretty";
		String query = indexName + "/_analyze?analyzer=" + analyzer + "&pretty";
		Map<String, Object> map = postQuery.post(query, queryStr);
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> tokenMaps = (List<Map<String, Object>>) map
				.get("tokens");
		return tokenMaps;
	}

	protected Map<Integer, List<Map<String, Object>>> secondTokenList(
			List<Map<String, Object>> tokenMaps) {
		Map<Integer, List<Map<String, Object>>> posMaps = new HashMap<Integer, List<Map<String, Object>>>();
		for (int i = 0; i < tokenMaps.size(); i++) {
			Map<String, Object> tmp = tokenMaps.get(i);
			String type = (String) tmp.get("type");
			int position = (Integer) tmp.get("position");
			if (type.equals("null") || type.equals("w"))
				continue;
			List<Map<String, Object>> mapList = posMaps.get(position);
			if (mapList == null)
				mapList = new LinkedList<Map<String, Object>>();
			mapList.add(tmp);
			posMaps.put(position, mapList);
		}
		if (posMaps.isEmpty())
			return null;
		else {
			Map<Integer, List<Map<String, Object>>> result = new HashMap<Integer, List<Map<String, Object>>>();
			Set<String> set = new TreeSet<String>();
			for (Integer pos : posMaps.keySet()) {
				List<Map<String, Object>> list = posMaps.get(pos);
				String key = (String) list.get(0).get("token");
				if (!set.contains(key)) {
					set.add(key);
					result.put(pos, list);
				}
			}
			return result;
		}
	}

	@Override
	public void close() {
		postQuery.close();
	}

	@SuppressWarnings("unchecked")
	public String suggestSearch(String queryStr) throws IOException {
		String json = SoulQueryUtil
				.suggestJson(queryStr, "suggest", "word", 10);
		String firstQuery = TaxFinalVal.cacheIndex + "/table/__suggest?pretty";
		Map<String, Object> map = postQuery.post(firstQuery, json);
		List<String> suggest = (List<String>) map.get("suggestions");
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("suggestions", suggest);
		result.put("size", suggest.size());
		result.put("term", queryStr);
		String resultJson = mapper.writeValueAsString(result);
		return resultJson;
	}

	@SuppressWarnings("unchecked")
	private Map<String, List<String>> schemaFields(List<String> tokenList) {
		String url = TaxFinalVal.schemaIndex + "/_search?pretty=true";
		Map<String, List<String>> resultMap = new HashMap<String, List<String>>();
		try {
			for (String token : tokenList) {
				Map<String, Object> queryMap = TaxSchema.schemaQueryMap(token);
				String json = mapper.writeValueAsString(queryMap);
				Map<String, Object> map = postQuery.post(url, json);
				map = (Map<String, Object>) map.get("hits");
				// log.info("original token : " + token);
				if (map != null) {
					List<String> fields = TaxSchema.analyzeHitsMap(map);
					if (fields != null) {
						resultMap.put(token, fields);
						log.info("schema token : " + token);
					}
				}
			}
			if (resultMap.size() > 0)
				return resultMap;
			else
				return null;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	public String taxSearch(String queryStr, int from, int size)
			throws JsonGenerationException, JsonMappingException, IOException {
		List<Map<String, Object>> primeTokens = primeTokenList(
				TaxFinalVal.schemaIndex, queryStr, "tax_query");
		// split input string to get tokens
		Map<Integer, List<Map<String, Object>>> tokens = secondTokenList(primeTokens);
		if (tokens == null || tokens.isEmpty()) {
			log.info(queryStr + "," + from + "," + size);
			return null;
		}
		List<TaxPojo> pojoList = new LinkedList<TaxPojo>();
		//List<String> nameList = new LinkedList<String>();
		List<String> tokenList = new LinkedList<String>();
		for (Integer position : tokens.keySet()) {
			List<Map<String, Object>> tmpList = tokens.get(position);
			String token = (String) tmpList.get(0).get("token");
			tokenList.add(token);
			List<TaxPojo> expandTokens = ESMapUtility.expandToken(token);
			// pojoList is used for highlight
			for (TaxPojo pojo : expandTokens) {
				String name = pojo.getName();
//				if (!nameList.contains(name)) {
//					nameList.add(name);
					pojoList.add(pojo);
				// }
			}
		}
		String url = TaxFinalVal.indexOne + "/_search?pretty=true";
		Map<String, List<String>> schemaMap = schemaFields(tokenList);
		if (schemaMap != null && TaxQueryMap.existEntity(schemaMap, tokenList)) {
			Map<String, Object> tmpMap = TaxQueryFields.entityQueryMap(
					schemaMap, tokenList);
			List<String> greenFields = (List<String>) tmpMap.get("greenFields");
			if (greenFields != null)
				greenFields.add(0, "table");
			Map<String, Object> queryMap = (Map<String, Object>) tmpMap
					.get("queryMap");
			String json = TaxQueryUtil.queryJson(queryMap, from, size);
			Map<String, Object> esResultMap = postQuery.post(url, json);
			return entityList(esResultMap, pojoList, greenFields, from, true);
		} else if (schemaMap != null) { // entity not exist
			Map<String, Object> tmpMap = NewTaxUtil.specialFieldMap(schemaMap,
					tokenList);
			List<String> greenFields = (List<String>) tmpMap.get("greenFields");
			if (greenFields != null)
				greenFields.add(0, "field");
			Map<String, Object> queryMap = (Map<String, Object>) tmpMap
					.get("queryMap");
			String json = TaxQueryUtil.queryJson(queryMap, from, size);
			Map<String, Object> esResultMap = postQuery.post(url, json);
			return pageList(esResultMap, pojoList, greenFields, from);
		} else {
			Map<String, Object> queryMap = TaxQueryMap.tableMap(
					TaxFinalVal.indexOne, tokenList);
			String json = TaxQueryUtil.queryJson(queryMap, from, size);
			Map<String, Object> esResultMap = postQuery.post(url, json);
			return pageList(esResultMap, pojoList, null, from);
		}
	}

	private static String pageList(Map<String, Object> result,
			List<TaxPojo> pojoList, List<String> greenFields, int from) {
		Map<String, Object> resultMap = NewTaxUtil.pageListMap(result,
				pojoList, greenFields, from, "");
		String resultJson = NewTaxUtil.convertToJson(resultMap);
		log.info(resultJson);
		return resultJson;
	}

	private static String entityList(Map<String, Object> tmpResultMap,
			List<TaxPojo> pojoList, List<String> greenFields, int from,
			boolean bEntity) {
		boolean mode1 = false;
		boolean mode2 = false;
		// List<String> tokenList = new LinkedList<String>();
		for (int i = 0; i < pojoList.size(); i++) {
			String name1 = pojoList.get(i).getName();
			for (int j = i + 1; j < pojoList.size(); j++) {
				String name2 = pojoList.get(j).getName();
				boolean val1 = (name1.equals("纳税申报") || name2.equals("纳税申报"));
				boolean val2 = (TaxFinalVal.companyMap().get(name1) != null || TaxFinalVal
						.companyMap().get(name2) != null);
				if (val1 && val2) {
					mode1 = true;
					break;
				}
				boolean val3 = (name1.equals("四金") || name2.equals("四金"));
				boolean val4 = (TaxFinalVal.personMap().get(name1) != null || TaxFinalVal
						.personMap().get(name2) != null);
				if (val3 && val4) {
					mode2 = true;
					break;
				}
			}
		}
		Map<String, Object> resultMap = null;
		log.info(greenFields);
		if (mode1)
			resultMap = NewTaxUtil.pageListMap(tmpResultMap, pojoList,
					greenFields, from, "company");
		else if (mode2)
			resultMap = NewTaxUtil.pageListMap(tmpResultMap, pojoList,
					greenFields, from, "person");
		else
			resultMap = NewTaxUtil.pageListMap(tmpResultMap, pojoList,
					greenFields, from, " ");
		String resultJson = NewTaxUtil.convertToJson(resultMap);
		// log.info(resultJson);
		return resultJson;
	}
}
