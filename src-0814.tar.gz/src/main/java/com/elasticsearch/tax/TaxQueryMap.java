package com.elasticsearch.tax;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import junit.framework.Assert;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.elasticsearch.query.SoulQueryUtil;
import com.splitword.soul.utility.StringUtil;

public class TaxQueryMap {

	private static final Log log = LogFactory.getLog(TaxQueryMap.class);

	// query all tables belong to this index
	public static Map<String, Object> tableMap(String indexName,
			List<String> tokenList) {
		List<String> tables = TaxFinalVal.indexTypeMap().get(indexName);
		Set<String> tableSet = new TreeSet<String>();
		for (String str : tables)
			tableSet.add(str);
		return tableMap(tableSet, tokenList);
	}

	// query all tables belong to this index
	public static Map<String, Object> tableMap(List<String> tables,
			List<String> tokenList) {
		Set<String> tableSet = new TreeSet<String>();
		for (String str : tables)
			tableSet.add(str);
		return tableMap(tableSet, tokenList);
	}

	// query tokens in table set
	public static Map<String, Object> tableMap(Set<String> tables,
			List<String> tokenList) {
		Map<String, List<String>> fieldsMap = TaxFinalVal.fieldsMap();
		List<Map<String, Object>> lastArray = new ArrayList<Map<String, Object>>();
		for (String tableName : tables) { // for each table
			List<Map<String, Object>> arrayForEachTable = new ArrayList<Map<String, Object>>();
			// for each table ,first get all real fields
			List<String> realFields = TaxQueryFields.realFieldList(tableName,
					fieldsMap);
			// log.info(realFields);
			for (String token : tokenList) {
				List<Map<String, Object>> array = new ArrayList<Map<String, Object>>();
				for (String realField : realFields) {
					// log.info(token + "," + realField);
					Map<String, Object> tmpMap = TaxQueryFields.eachToken(
							realField, token);
					if (tmpMap != null)
						array.add(tmpMap);
				}
				Map<String, Object> map1 = SoulQueryUtil.createBooleanQueryMap(
						array, 1);
				if (map1 != null)
					arrayForEachTable.add(map1);
			}
			// must satisfy all, else not match
			Map<String, Object> mapHaha = SoulQueryUtil.createBooleanQueryMap(
					arrayForEachTable, arrayForEachTable.size());
			Map<String, Object> mapForThisTable = TaxQueryUtil
					.queryMapWithFilter(mapHaha, tableName);
			lastArray.add(mapForThisTable);
		}
		Map<String, Object> lastMap = SoulQueryUtil.createBooleanQueryMap(
				lastArray, 1);
		return lastMap;
	}

	public static Map<String, List<String>> realTokens(
			Map<String, List<String>> resultMap, List<String> tokenList) {
		List<String> realTokens = new LinkedList<String>();
		List<String> tableList = new LinkedList<String>();
		// List<String> greenList = new LinkedList<String>();
		List<String> otherList = new LinkedList<String>();
		for (String str : tokenList) {
			if (resultMap.containsKey(str)) {
				List<String> fields = resultMap.get(str);
				for (String field : fields) {
					if (field.endsWith(".all")) {
						String[] strs = field.split("[.]");
						String tableName = strs[0];
						if (!tableList.contains(tableName))
							tableList.add(tableName);
					} else {
						if (!otherList.contains(field))
							otherList.add(field);
					}
				}
				continue;
			} else
				realTokens.add(str);
		}

		List<String> entitys = new LinkedList<String>();
		for (String str : realTokens) {
			if (StringUtil.isBlank(str))
				continue;
			if (TaxFinalVal.companyMap().get(str) != null)
				entitys.add(str);
			else if (TaxFinalVal.personMap().get(str) != null)
				entitys.add(str);
		}

		List<String> list1 = new LinkedList<String>();
		for (String str : otherList) {
			String[] strs = str.split("[.]");
			String tableName = strs[0];
			if (!tableList.contains(tableName))
				list1.add(str);
		}
		Map<String, List<String>> result = new HashMap<String, List<String>>();
		if (list1.size() > 0)
			result.put("otherFields", list1);

		if (realTokens.size() > 0)
			result.put("realTokens", realTokens);
		if (entitys.size() > 0)
			result.put("entitys", entitys);

		if (tableList.size() > 0)
			result.put("tableList", tableList);
		return result;
	}

	public static boolean existEntity(Map<String, List<String>> resultMap,
			List<String> tokenList) {
		List<String> realTokens = new LinkedList<String>();
		Set<String> tables = new HashSet<String>();
		for (String str : tokenList) {
			if (resultMap.containsKey(str)) {
				List<String> fields = resultMap.get(str);
				for (String field : fields) {
					String[] strs = field.split("[.]");
					tables.add(strs[0]);
				}
				continue;
			} else
				realTokens.add(str);
		}

		for (String str : realTokens) {
			if (StringUtil.isBlank(str))
				continue;
			if (TaxFinalVal.companyMap().get(str) != null)
				return true;
			else if (TaxFinalVal.personMap().get(str) != null)
				return true;
		}
		return false;
	}

	private static List<String> whichFields(String tableName) {
		Map<String, List<String>> fieldsMap = TaxFinalVal.fieldsMap();
		List<String> displayFields = fieldsMap.get(tableName + "#display");
		Map<String, Object> defMap = TaxFinalVal.defMap().get(tableName);
		if (displayFields == null) {
			List<String> tmpList = new LinkedList<String>();
			for (String field : defMap.keySet()) {
				tmpList.add(field);
			}
			displayFields = tmpList;
		}
		return displayFields;
	}

	// we use LinkedHashMap because it could keep insert order
	@SuppressWarnings("unchecked")
	public static Map<String, Object> checkMap(Map<String, Object> map1,
			List<TaxPojo> pojoList, List<String> greenFields, String mode) {
		Map<String, Object> resultMap = new LinkedHashMap<String, Object>();
		String tableName = (String) map1.get("_type");
		resultMap.put("tableName", TaxFinalVal.tableMap().get(tableName));
		Map<String, Object> lightMap = (Map<String, Object>) map1
				.get("highlight");
		Map<String, Object> sourceMap = (Map<String, Object>) map1
				.get("_source");
		List<String> list1 = new LinkedList<String>();
		List<String> list2 = new LinkedList<String>();
		List<String> displayFields = whichFields(tableName);
		list1.addAll(displayFields);
		for (String resultField : sourceMap.keySet()) {
			String[] strs = resultField.split("[.]");
			String field = strs[1];
			if (!list1.contains(field))
				list2.add(field);
		}
		Map<String, Object> defMap = TaxFinalVal.defMap().get(tableName);
		int listSize = list1.size();
		list1.addAll(list2);
		log.info(list1);
		if (mode.equals("person")) {
			list1.add(4, "纳税尊重(个人)");
			list1.add(5, "纳税尊重(企业)");
			Assert.assertEquals(tableName, "A10");
		} else if (mode.equals("company")) {
			log.info("haha");
			list1.add(5, "纳税尊重(企业)");
			Assert.assertEquals(tableName, "A04");
		}
		for (int i = 0; i < list1.size(); i++) {
			String field = list1.get(i);
			if (mode.equals("person") && field.equals("纳税尊重(个人)")) {
				if (sourceMap.containsKey(TaxFinalVal.realPaid)
						&& sourceMap.containsKey(TaxFinalVal.shouldPaid)) {
					String str1 = (String) sourceMap.get(TaxFinalVal.realPaid);
					String str2 = (String) sourceMap
							.get(TaxFinalVal.shouldPaid);
					boolean value = TaxPostFilter.checkPaid(str1, str2);
					if (value)
						resultMap.put("纳税尊重\n(个人)", "正常缴纳");
					else
						resultMap.put("纳税尊重\n(个人)", "未缴纳");
					resultMap.put("纳税尊重\n（企业）", "100/2");
				}
				i++;
				continue;
			} else if (mode.equals("company") && field.equals("纳税尊重(企业)")) {
				if (sourceMap.containsKey(TaxFinalVal.realDate)
						&& sourceMap.containsKey(TaxFinalVal.shouldDate)) {
					String str1 = (String) sourceMap.get(TaxFinalVal.realDate);
					String str2 = (String) sourceMap
							.get(TaxFinalVal.shouldDate);
					boolean value = TaxPostFilter.checkDate(str1, str2);
					if (value)
						resultMap.put(field, "正常缴纳");
					else
						resultMap.put(field, "未缴纳");
				}
				continue;
			}
			Map<String, String> typeInfo = (Map<String, String>) defMap
					.get(field);
			String chineseFieldName = typeInfo.get("chineseFieldName");
			String resultField = tableName + "." + field;
			if (!sourceMap.containsKey(resultField))
				continue;
			String resultStr = (String) sourceMap.get(resultField);
			String anotherStr = null;
			if (lightMap != null && lightMap.containsKey(resultField)) {
				List<String> tmpList = (List<String>) lightMap.get(resultField);
				anotherStr = tmpList.get(0);
			} else if (greenFields == null
					|| !greenFields.contains(resultField)) {
				log.info(anotherStr + "," + resultStr);

				anotherStr = ESMapUtility.colorSourceString(resultStr,
						pojoList, "red");
				log.info(anotherStr + "," + resultStr);
			} else {
				String type = greenFields.get(0);
				if (type.equals("table")) {
					log.info(anotherStr + "," + resultStr);
					// neither match or not, color source string
					anotherStr = SoulQueryUtil.greenPreTag + resultStr
							+ SoulQueryUtil.greenPostTag;
					log.info(anotherStr + "," + resultStr);
				} else {
					anotherStr = ESMapUtility.colorSourceString(resultStr,
							pojoList, "green");
				}
			}
			if (i < listSize)
				resultMap.put(chineseFieldName, anotherStr);
			else {
				log.info(anotherStr);
				if (!resultStr.equals(anotherStr)) {
					resultMap.put(chineseFieldName, anotherStr);
				}
			}
		}
		return resultMap;
	}

	// // we use LinkedHashMap because it could keep insert order
	// @SuppressWarnings("unchecked")
	// public static Map<String, String> specialMap(Map<String, Object> map1,
	// List<TaxPojo> pojoList, List<String> greenFields, String mode) {
	// Map<String, String> resultMap = new LinkedHashMap<String, String>();
	// String tableName = (String) map1.get("_type");
	// resultMap.put("tableName", TaxFinalVal.tableMap().get(tableName));
	// Map<String, Object> lightMap = (Map<String, Object>) map1
	// .get("highlight");
	// Map<String, Object> sourceMap = (Map<String, Object>) map1
	// .get("_source");
	// List<String> list1 = new LinkedList<String>();
	// List<String> list2 = new LinkedList<String>();
	// List<String> displayFields = whichFields(tableName);
	// list1.addAll(displayFields);
	// for (String resultField : sourceMap.keySet()) {
	// String[] strs = resultField.split("[.]");
	// String field = strs[1];
	// if (!displayFields.contains(field))
	// list2.add(field);
	// }
	// Map<String, Object> defMap = TaxFinalVal.defMap().get(tableName);
	// int listSize = list1.size();
	// list1.addAll(list2);
	// if (mode.equals("person")) {
	// list1.add(4, "A10.nszz_person");
	// list1.add(5, "A10.nszz_company");
	// Assert.assertEquals(tableName, "A10");
	// }
	// for (int i = 0; i < list1.size(); i++) {
	// String field = list1.get(i);
	// if (field.equals("A10.nszz_person")) {
	// if (sourceMap.containsKey(TaxFinalVal.realPaid)
	// && sourceMap.containsKey(TaxFinalVal.shouldPaid)) {
	// String str1 = (String) sourceMap.get(TaxFinalVal.realPaid);
	// String str2 = (String) sourceMap
	// .get(TaxFinalVal.shouldPaid);
	// boolean value = TaxPostFilter.checkPaid(str1, str2);
	// if (value)
	// resultMap.put("纳税尊重\n(个人)", "正常缴纳");
	// else
	// resultMap.put("纳税尊重\n(个人)", "未缴纳");
	// resultMap.put("纳税尊重\n（企业）", "100/2");
	// }
	// i++;
	// continue;
	// }
	// Map<String, String> typeInfo = (Map<String, String>) defMap
	// .get(field);
	// String chineseFieldName = typeInfo.get("chineseFieldName");
	// String resultField = tableName + "." + field;
	// if (!sourceMap.containsKey(resultField))
	// continue;
	// String resultStr = (String) sourceMap.get(resultField);
	// String anotherStr = null;
	// if (lightMap != null && lightMap.containsKey(resultField)) {
	// List<String> tmpList = (List<String>) lightMap.get(resultField);
	// anotherStr = tmpList.get(0);
	// } else if (greenFields == null
	// || !greenFields.contains(resultField)) {
	//
	// anotherStr = ESMapUtility.colorSourceString(resultStr,
	// pojoList, "red");
	// } else {
	// String type = greenFields.get(0);
	// if (type.equals("table")) {
	// // neither match or not, color source string
	// anotherStr = SoulQueryUtil.greenPreTag + resultStr
	// + SoulQueryUtil.greenPostTag;
	// } else {
	// anotherStr = ESMapUtility.colorSourceString(resultStr,
	// pojoList, "green");
	// }
	// }
	// if (i < listSize)
	// resultMap.put(chineseFieldName, anotherStr);
	// else {
	// if (!resultStr.equals(anotherStr)) {
	// resultMap.put(chineseFieldName, anotherStr);
	// }
	// }
	// }
	//
	// return resultMap;
	// }
	//
	// private Map<String, Object> covert(Map<String, Object> sourceMap,
	// Map<String, String> resultMap) {
	//
	// Map<String, Object> anotherMap = new LinkedHashMap<String, Object>();
	// int i = 0;
	// if (sourceMap.containsKey(TaxFinalVal.realPaid)
	// && sourceMap.containsKey(TaxFinalVal.shouldPaid)) {
	// String str1 = (String) sourceMap.get(TaxFinalVal.realPaid);
	// String str2 = (String) sourceMap.get(TaxFinalVal.shouldPaid);
	// boolean value = TaxPostFilter.checkPaid(str1, str2);
	// for (String key : resultMap.keySet()) {
	// String sourceVal = (String) resultMap.get(key);
	// if (i != 5)
	// anotherMap.put(key, sourceVal);
	// else {
	// if (value)
	// anotherMap.put("纳税尊重", "正常缴纳");
	// else
	// anotherMap.put("纳税尊重", "未缴纳");
	// }
	// i++;
	// }
	// } else if (sourceMap.containsKey(TaxFinalVal.realDate)
	// && sourceMap.containsKey(TaxFinalVal.shouldDate)) {
	// String str1 = (String) sourceMap.get(TaxFinalVal.realDate);
	// String str2 = (String) sourceMap.get(TaxFinalVal.shouldDate);
	// boolean value = TaxPostFilter.checkDate(str1, str2);
	// for (String key : resultMap.keySet()) {
	// String sourceVal = (String) resultMap.get(key);
	// if (i != 5)
	// anotherMap.put(key, sourceVal);
	// else {
	// if (value)
	// anotherMap.put("纳税尊重", "正常缴纳");
	// else
	// anotherMap.put("纳税尊重", "未缴纳");
	// }
	// i++;
	// }
	// }
	// return anotherMap;
	// }
}
